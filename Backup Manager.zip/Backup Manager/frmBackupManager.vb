Option Explicit On

Imports Scripting
Imports System.IO
Imports Microsoft.VisualBasic

Public Class frmBackupManager

    Private mblnAtLeast1ErrorReported As Boolean, mstrErrorFiles As String, mstrErrorFileSizes As String
    Private mblnDoneBackup As Boolean, mstrBackupDrive As String
    Private mlngItemCountToDo As Long, mstrPath As String, mlngZipsDone As Long, mlngFoldersDone As Long
    Private mstrBackupDay As String

    Private Sub mnuExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuExit.Click

        cmdClose_Click(sender, e)

    End Sub

    Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click

        Me.Close()

    End Sub

    Private Function LoadOptions() As String

        Dim objStream As StreamReader, strLine As String

        Try
            objStream = New StreamReader(Application.StartupPath & "\BackupOptions.txt")

            strLine = objStream.ReadLine()

            objStream.Close()

            If Not IsHomePC() Then

                strLine = ROOT_DRIVE
            End If

        Catch ex As FileNotFoundException

            strLine = ROOT_DRIVE

        End Try

        If Trim$(strLine) <> "" Then

            txtDrive.Text = strLine
        Else

            txtDrive.Text = ROOT_DRIVE
        End If

    End Function

    <MTAThread()> _
    Private Sub frmBackupManager_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        LoadOptions()

        LoadFolders(lvwFolders)

        mstrBackupDrive = LoadDriveOption()

        Me.Height = 725

        Show()

        cmdBackup.Focus()

        SetCaption()

    End Sub

    Private Sub cmdBackup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBackup.Click

        Dim objItem As ListViewItem, blnRestartChaosManager As Boolean, lngItemCount As Long

        mlngZipsDone = 0
        mlngFoldersDone = 0
        mlngItemCountToDo = 0

        If Not CheckFoldersExist() Then

            Exit Sub
        End If

        For Each objItem In lvwFolders.CheckedItems

            If InStr(objItem.ToString.ToLower, (ROOT_DRIVE & "\turboVB").ToLower) > 0 Then

                If MessageBox.Show("Have you backed up Firefox Settings?", My.Application.Info.ProductName, MessageBoxButtons.YesNo,
                       MessageBoxIcon.Question) = vbNo Then

                    MessageBox.Show("Well back it up then!", My.Application.Info.ProductName, MessageBoxButtons.OK)
                    Exit Sub
                End If

                If MessageBox.Show("Backup Chaos Manager? If yes close the app now.", My.Application.Info.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                    If Not BackupChaosManager() Then

                        Exit Sub
                    Else

                        blnRestartChaosManager = True
                    End If
                End If
            End If

            mlngItemCountToDo = mlngItemCountToDo + 1
        Next

        For Each objItem In lvwFolders.CheckedItems

            If objItem.SubItems(1).Text.ToUpper = "COPY" Then

                lngItemCount = lngItemCount + 1
            Else

                lngItemCount = lngItemCount + 2
            End If
        Next

        prgProgress.Maximum = lngItemCount

        prgProgress.Minimum = 0
        prgProgress.Value = 0

        Windows.Forms.Cursor.Current = Windows.Forms.Cursors.WaitCursor

        mblnDoneBackup = True

        mstrBackupDay = Format$(Now, "dd MMM yyyy")

        For Each objItem In lvwFolders.CheckedItems

            prgProgress.Value = prgProgress.Value + 1
            Application.DoEvents()

            Me.Text = Application.ProductName & " - Working on " & RemovePath(objItem.Text) & ".zip"

            Me.Refresh()

            If Backup(objItem.Text, objItem.SubItems(1).Text) Then

            Else

                Exit For
            End If
        Next

        prgProgress.Value = 0

        Me.Text = Application.ProductName

        Windows.Forms.Cursor.Current = Windows.Forms.Cursors.Default

        Interaction.Beep()

        If blnRestartChaosManager Then

            RestartchaosManager()
        End If

        ' Copy file list file
        If My.Computer.FileSystem.FileExists("BackupFolders.txt") Then

            My.Computer.FileSystem.CopyFile("BackupFolders.txt", ROOT_DRIVE & "TurboVB\Backup Tools\BackupFolders.txt", True)
        End If

        Report(mlngItemCountToDo, mlngZipsDone, mlngFoldersDone)

        SetCaption()

    End Sub

    Private Sub CopyToDrive(ByVal strDrive As String)

        Dim strPath As String, strBackupPath As String, objFile As FileInfo, strFile As String
        Dim objFolder As DirectoryInfo, objCopyFolder As Directory

        My.Computer.FileSystem.CreateDirectory(strDrive & mstrBackupDay)

        strPath = "strDrive & mstrBackupDay"

        objFolder = New DirectoryInfo(mstrBackupDrive & mstrBackupDay)

        For Each objFile In objFolder.GetFiles

            Me.Text = "Backup Manager - " & objFile.Name

            objFile.CopyTo(strPath & "\" & objFile.Name, True)
        Next

        For Each objFolder In objFolder.GetDirectories

            Me.Text = "Backup Manager - " & objFolder.FullName
            My.Computer.FileSystem.CopyDirectory(objFolder.FullName, strPath & "\" & objFolder.Name, True)
        Next

    End Sub

    Private Sub Report(ByVal lngItemCountToDo As Long, ByVal lngZipFilesDone As Long, ByVal lngFoldersToCreateDone As Long)

        Dim strFiles As Object, strFolders As Object

        If mstrPath = "" Then Exit Sub

        strFiles = My.Computer.FileSystem.GetFiles(mstrPath)
        strFolders = My.Computer.FileSystem.GetDirectories(mstrPath)

        If (lngFoldersToCreateDone + lngZipFilesDone) <> lngItemCountToDo Then

            MessageBox.Show("Count of items to do and done are different!", My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

        If (strFiles.count + strFolders.count) <> lngItemCountToDo Then

            MessageBox.Show("Count of items to do and files/folders present are different!", My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

        If mstrErrorFileSizes <> "" Then MessageBox.Show(mstrErrorFileSizes, My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)
        If mstrErrorFiles <> "" Then MessageBox.Show(mstrErrorFiles, My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)

        If (lngFoldersToCreateDone + lngZipFilesDone) = lngItemCountToDo And mstrErrorFileSizes = "" And mstrErrorFiles = "" And mblnDoneBackup Then

            DoPlaySound()

            MessageBox.Show("Finished with no Problems!", My.Application.Info.ProductName, MessageBoxButtons.OK)
        End If

    End Sub

    Private Function Backup(ByVal strPath As String, ByVal strType As String) As Boolean

        Dim strBackupPath As String, strFile As String, objTS As TextStream, objFSO As New FileSystemObject
        Dim strResult As String, intCount As Integer

        strBackupPath = RemovePath(strPath)

        Try

            My.Computer.FileSystem.CreateDirectory(mstrBackupDrive & mstrBackupDay)

        Catch ex As DirectoryNotFoundException

            MessageBox.Show(mstrBackupDrive & " not found!")
            Exit Function

        End Try

        mstrPath = mstrBackupDrive & mstrBackupDay

        strBackupPath = mstrBackupDrive & mstrBackupDay & "\" & strBackupPath

        For intCount = 0 To My.Computer.FileSystem.Drives.Count - 1

            If My.Computer.FileSystem.Drives(intCount).Name = mstrBackupDrive Then

                If My.Computer.FileSystem.Drives(intCount).AvailableFreeSpace < 1500000000 Then

                    MessageBox.Show("Not enough free space on " & My.Computer.FileSystem.Drives(intCount).Name, "Space Problem", MessageBoxButtons.OK)
                End If
            End If
        Next

        If strType.ToUpper = "COPY" Then

            Me.Text = Application.ProductName & " - Copying " & strPath

            Application.DoEvents()

            Backup_Type_Copy(strPath, strBackupPath)

            Backup = True
            mlngFoldersDone = mlngFoldersDone + 1
        Else

            Backup_Type_Zip(strPath, strBackupPath, mstrErrorFileSizes, mstrErrorFiles, mblnAtLeast1ErrorReported, Me)

            Backup = True
            mlngZipsDone = mlngZipsDone + 1
        End If

    End Function

    Private Sub frmFolders_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize

        lvwFolders.Columns(0).Width = lvwFolders.Width - 65

    End Sub

    Private Sub mnuFolders_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFolders.Click

        frmFolders.ShowDialog()

        LoadOptions()

        LoadFolders(lvwFolders)

    End Sub

    Private Sub ReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReportToolStripMenuItem.Click

        Report(mlngItemCountToDo, mlngZipsDone, mlngFoldersDone)

    End Sub

    Private Sub RestartchaosManager()

        Dim objChaos As New Process

        With objChaos

            .StartInfo.FileName = "C:\Program Files (x86)\Chaos Manager 2\cm2.exe"
            .StartInfo.UseShellExecute = False
            .StartInfo.WindowStyle = ProcessWindowStyle.Hidden
            .Start()
        End With

    End Sub

    Private Function TestFolder(ByVal strPath) As Boolean

        Dim objFiles() As FileInfo, lngCount As Long, strFile As String
        Dim strResult As String

        objFiles = My.Computer.FileSystem.GetDirectoryInfo(strPath).GetFiles("*.zip")

        For lngCount = objFiles.GetLowerBound(0) To objFiles.GetUpperBound(0)

            strFile = strPath & "\" & objFiles(lngCount).ToString

            Me.Text = My.Application.Info.ProductName & " - Testing - " & objFiles(lngCount).ToString

            If My.Computer.FileSystem.FileExists(strFile) Then

                ' Test File Size - 2.1 GB limit when stored in NERO
                If GetFileSize(strFile) > 2000000000 Then

                    mstrErrorFileSizes = mstrErrorFileSizes & "The size of " & strFile & " is too large for a DVD!" & vbCrLf
                End If

                Dim p As New Process

                ' Redirect the output stream of the child process.

                p.StartInfo.FileName = ROOT_DRIVE & "program files\winzip\wzunzip.exe"
                p.StartInfo.Arguments = "-t """ & strFile & """"
                p.StartInfo.UseShellExecute = False
                p.StartInfo.CreateNoWindow = True
                p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
                p.StartInfo.RedirectStandardOutput = True

                Try

                    p.Start()

                Catch ex As System.ComponentModel.Win32Exception

                    MessageBox.Show(ROOT_DRIVE & "program files\winzip\wzunzip.exe is missing!")
                    Exit Function

                End Try

                ' Create bat files
                strResult = p.StandardOutput.ReadToEnd()

                p.WaitForExit()

                If InStr(strResult, " No errors detected in compressed data ", Microsoft.VisualBasic.CompareMethod.Text) <> 0 Then

                    mblnAtLeast1ErrorReported = True
                    mstrErrorFiles = mstrErrorFiles & strFile & "," & vbCrLf
                End If

                p = Nothing

            End If
        Next

        Me.Text = My.Application.Info.ProductName

        If mstrErrorFileSizes <> "" Then MessageBox.Show(mstrErrorFileSizes, My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)
        If mstrErrorFiles <> "" Then MessageBox.Show(mstrErrorFiles, My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)

        If mstrErrorFileSizes = "" And mstrErrorFiles = "" Then

            tsMessage.Text = "Finished with no Problems!"
            TestFolder = True
        Else

            TestFolder = False
        End If

    End Function

    Private Sub TestFolderToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TestFolderToolStripMenuItem.Click

        Dim strPath As String

        FolderBrowserDialog1.SelectedPath = ROOT_DRIVE & ""

        If FolderBrowserDialog1.ShowDialog() <> Windows.Forms.DialogResult.OK Then Exit Sub

        If FolderBrowserDialog1.SelectedPath <> "" Then

            strPath = Mid(FolderBrowserDialog1.SelectedPath, 1, 1).ToLower & Mid(FolderBrowserDialog1.SelectedPath, 2)
        Else

            MessageBox.Show("No zips found!", My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If

        TestFolder(strPath)

    End Sub

    Private Sub SelectAllToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SelectAllToolStripMenuItem.Click

        Dim lngCount As Integer

        For lngCount = 0 To lvwFolders.Items.Count - 1

            lvwFolders.Items(lngCount).checked = True
        Next

        SetCaption()

    End Sub

    Private Sub UnselectAllToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UnselectAllToolStripMenuItem.Click

        Dim lngCount As Integer

        For lngCount = 0 To lvwFolders.Items.Count - 1

            lvwFolders.Items(lngCount).Checked = False
        Next

        SetCaption()

    End Sub

    Private Sub DoPlaySound()

        PlaySound(My.Computer.FileSystem.CurrentDirectory & "\Buzzer.wav")
        PlaySound(My.Computer.FileSystem.CurrentDirectory & "\Buzzer.wav")
        PlaySound(My.Computer.FileSystem.CurrentDirectory & "\Buzzer.wav")

    End Sub

    Private Sub SetCaption()

        Me.Text = "Backup Manager - " & lvwFolders.Items.Count & " items (" & lvwFolders.CheckedItems.Count & " selected)"

    End Sub

    Private Sub mnuInvert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuInvert.Click

        Dim lngCount As Integer

        For lngCount = 0 To lvwFolders.Items.Count - 1

            If lvwFolders.Items(lngCount).Checked Then

                lvwFolders.Items(lngCount).Checked = False
            Else

                lvwFolders.Items(lngCount).Checked = True
            End If

        Next

        SetCaption()

    End Sub

    Private Sub txtDrive_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtDrive.KeyPress

        e.Handled = True

    End Sub

    Private Function CheckFoldersExist()

        Dim objItem As ListViewItem, lngItemCount As Long, strFolders As String

        For Each objItem In lvwFolders.Items

            If objItem.Checked Then

                If Not My.Computer.FileSystem.DirectoryExists(objItem.Text) Then

                    strFolders = strFolders & objItem.Text & vbCrLf
                End If
            End If
        Next

        If strFolders <> "" Then

            MessageBox.Show("The following don't exist - " & vbCrLf & vbCrLf & strFolders, "Folders", MessageBoxButtons.OK)
            CheckFoldersExist = False
        Else

            CheckFoldersExist = True
        End If

    End Function

    Private Sub ToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem2.Click

        checkFoldersExist()

    End Sub

    Private Sub UpdateFolder(ByVal strUpdateDrive As String, ByVal strFromDrive As String)

        Dim strPath As String, strBackupPath As String, objFile As FileInfo, strFile As String
        Dim objFolder As DirectoryInfo, objCopyFolder As Directory

        strPath = "strDrive & mstrBackupDay"

        If mstrBackupDay = "" Then

            MessageBox.Show("Can't proceed mstrBackupDay is blank!")
            Exit Sub
        End If

        objFolder = New DirectoryInfo(strFromDrive & mstrBackupDay)

        For Each objFile In objFolder.GetFiles

            Me.Text = "Backup Manager - " & objFile.Name

            If Not My.Computer.FileSystem.FileExists(strUpdateDrive & mstrBackupDay & "\" & objFile.Name) Then

                objFile.CopyTo(strUpdateDrive & mstrBackupDay & "\" & objFile.Name, True)
            End If
        Next

        For Each objFolder In objFolder.GetDirectories

            Me.Text = "Backup Manager - " & objFolder.FullName

            If Not My.Computer.FileSystem.DirectoryExists(strUpdateDrive & mstrBackupDay & "\" & objFolder.Name) Then

                My.Computer.FileSystem.CopyDirectory(objFolder.FullName, strUpdateDrive & mstrBackupDay & "\" & objFolder.Name, True)

            End If

        Next

    End Sub

    Private Sub TestACopiedFolderToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TestACopiedFolderToolStripMenuItem.Click

        Dim strSourcePath As String, strBackupPath As String

        FolderBrowserDialog1.Description = "Source Folder"
        FolderBrowserDialog1.SelectedPath = ROOT_DRIVE & ""

        If FolderBrowserDialog1.ShowDialog() <> Windows.Forms.DialogResult.OK Then Exit Sub

        If FolderBrowserDialog1.SelectedPath <> "" Then

            strSourcePath = Mid(FolderBrowserDialog1.SelectedPath, 1, 1).ToLower & Mid(FolderBrowserDialog1.SelectedPath, 2)
        End If

        FolderBrowserDialog1.Description = "Backup Folder"
        FolderBrowserDialog1.SelectedPath = txtDrive.Text

        If FolderBrowserDialog1.ShowDialog() <> Windows.Forms.DialogResult.OK Then Exit Sub

        If FolderBrowserDialog1.SelectedPath <> "" Then

            strBackupPath = Mid(FolderBrowserDialog1.SelectedPath, 1, 1).ToLower & Mid(FolderBrowserDialog1.SelectedPath, 2)
        End If

        TestACopiedFolder(strSourcePath, strBackupPath)

    End Sub

    Private Sub TestACopiedFolder(ByVal strSourcePath As String, ByVal strBackupPath As String)

        Dim strSourceFiles() As String
        Dim strBackupFiles() As String





    End Sub

    Public Function GetFiles() As String()



    End Function

    Public Function GetAllTheFilesWithinPath(ByVal strPath As String) As String()

        Dim strDir As String
        Dim strFile As String
        Dim strFiles() As String

        Try
            For Each strDir In Directory.GetDirectories(strPath)

                For Each strFile In Directory.GetFiles(strDir)


                    '                    mstrFiles = mstrFiles & ";"
                Next

                GetAllTheFilesWithinPath(strDir)
            Next

        Catch excpt As System.Exception

            MessageBox.Show(excpt.Message)
        End Try

    End Function

    Private Sub lvwFolders_ItemChecked(sender As Object, e As ItemCheckedEventArgs) Handles lvwFolders.ItemChecked

        SetCaption()

    End Sub

    Private Sub txtDrive_TextChanged(sender As Object, e As EventArgs) Handles txtDrive.TextChanged

    End Sub
End Class
