Public Class frmFolders

    Private Sub cmdFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFolder.Click

        FolderBrowserDialog1.SelectedPath = "c:\"

        If FolderBrowserDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then

            If FolderBrowserDialog1.SelectedPath <> "" Then txtFolder.Text = Mid(FolderBrowserDialog1.SelectedPath, 1, 1).ToLower & Mid(FolderBrowserDialog1.SelectedPath, 2)
        End If

    End Sub

    Private Sub cmdDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDelete.Click

        lvwFolders.Items.Remove(lvwFolders.SelectedItems(0))

    End Sub

    Private Sub frmFolders_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        LoadOptions()

        LoadFolders(lvwFolders)

    End Sub

    Private Sub cmdAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAdd.Click

        Dim objListItem As ListViewItem

        objListItem = lvwFolders.Items.Add(Mid(txtFolder.Text, 1, 1).ToLower & Mid(txtFolder.Text, 2))

        objListItem.SubItems.Add("Zip")
        objListItem.Checked = True

    End Sub

    Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click

        SaveFolders(lvwFolders)

        SaveOptions()

        Me.Close()

    End Sub

    Private Function LoadOptions() As String

        Dim objStream As StreamReader, strLine As String, strLineII As String

        Try
            objStream = New StreamReader(Application.StartupPath & "\BackupOptions.txt")

            strLine = objStream.ReadLine()
            strLineII = objStream.ReadLine()

            objStream.Close()

        Catch ex As FileNotFoundException

            strLine = "C:\"

        End Try

        If Trim$(strLine) <> "" Then

            txtDrive.Text = strLine
        Else

            txtDrive.Text = "C:\"
        End If

    End Function

    Private Sub SaveOptions()

        Dim objStream As StreamWriter

        objStream = New StreamWriter(Application.StartupPath & "\BackupOptions.txt")

        objStream.WriteLine(txtDrive.Text)

        objStream.Close()

    End Sub

    Private Sub SaveFolders(ByVal lvwFolders As ListView)

        Dim objStream As StreamWriter, objItem As Object

        objStream = New StreamWriter(Application.StartupPath & "\BackupFolders.txt")

        lvwFolders.Sort()

        For Each objItem In lvwFolders.Items

            objStream.WriteLine(objItem.text & "," & objItem.checked & "," & objItem.subitems(1).text)
        Next

        objStream.Close()

        objStream = New StreamWriter(Application.StartupPath & "\BackupOptions.txt")

        objStream.WriteLine(txtDrive.ToString)

        objStream.Close()

    End Sub

    Private Sub txtFolder_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFolder.TextChanged

        cmdAdd.Enabled = txtFolder.Text.Trim <> ""

    End Sub

    Private Sub frmFolders_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize

        lvwFolders.Columns(0).Width = lvwFolders.Width - 64

    End Sub

    Private Sub lvwFolders_Click1(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvwFolders.Click

        cmdDelete.Enabled = lvwFolders.SelectedItems.Count > 0

    End Sub

    Private Sub lvwFolders_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvwFolders.DoubleClick

        If lvwFolders.SelectedItems(0).SubItems(1).Text = "Zip" Then

            lvwFolders.SelectedItems(0).SubItems(1).Text = "Copy"
        Else

            lvwFolders.SelectedItems(0).SubItems(1).Text = "Zip"
        End If

    End Sub

End Class