﻿Module modDates

    Public Function IsAWorkDay_Basic(ByVal dtmDate As Date) As Boolean

        Select Case Microsoft.VisualBasic.Format(dtmDate, "ddd")

            Case "Sat", "Sun" : IsAWorkDay_Basic = False

            Case Else : IsAWorkDay_Basic = True

        End Select

    End Function

    Public Function IsYear(ByVal strText As String, ByVal intMinimumYear As Integer) As Boolean

        Dim intYear As Integer

        strText = strText.Trim

        IsYear = False

        If Len(strText) = 4 Then

            If IsNumeric(strText) Then

                intYear = CInt(strText)

                If intYear >= intMinimumYear Then

                    IsYear = True
                End If
            End If
        End If

    End Function

    Public Function IsNumericDay(ByVal strText As String) As Boolean

        IsNumericDay = False

        If IsNumeric(strtext) Then

            If CInt(strtext) > 0 And CInt(strtext) < 32 Then

                IsNumericDay = True
            End If
        End If

    End Function

    Public Function ChangeNumericMonthToMMM(ByVal strText As String) As String

        ChangeNumericMonthToMMM = ""

        If IsNumeric(strText) Then

            If CInt(strText) > 0 And CInt(strText) < 13 Then

                ChangeNumericMonthToMMM = Microsoft.VisualBasic.Strings.Format(CDate("1 " & strText & " 2000"), "MMM")
            End If
        End If

    End Function

    Public Function IsNumericMonth(ByVal strText As String) As Boolean

        IsNumericMonth = False

        If IsNumeric(strText) Then

            If CInt(strText) > 0 And CInt(strText) < 13 Then

                IsNumericMonth = True
            End If
        End If

    End Function

    Public Function IsMonth(ByVal strText As String) As Boolean

        strText = strText.Trim.ToUpper

        If strText.Length = 3 Then

            Select Case strText

                Case "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"

                    Return True

                Case Else

                    Return False

            End Select
        End If

        If strText.Length = 4 Then

            Select Case strText

                Case "JANU", "FEBU", "MARC", "APRI", "MAY", "JUNE", "JULY", "AUGU", "SEPT", "OCTO", "NOVE", "DECE"

                    Return True

                Case Else

                    Return False
            End Select

        End If

        Select Case strText.ToUpper

            Case "JANUARY", "FEBURARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"

                Return True
        End Select

        Return False

    End Function

    Public Function IsMonth_4CharsOrFull(ByVal strText As String) As Boolean

        strText = strText.Trim.ToUpper

        If strText.Length = 4 Then

            Select Case strText

                Case "JANU", "FEBU", "MARC", "APRI", "MAY", "JUNE", "JULY", "AUGU", "SEPT", "OCTO", "NOVE", "DECE"

                    Return True

                Case Else

                    Return False
            End Select

        End If

        Select Case strText.ToUpper

            Case "JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"

                Return True
        End Select

        Return False

    End Function

    Public Function Is3Digitmonth(ByVal strMonth As String) As Boolean

        Select Case strMonth.ToUpper

            Case "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC" : Is3Digitmonth = True

            Case Else

                Is3Digitmonth = False

        End Select


    End Function

    Public Function IsStringADate(ByVal strDate As String) As Boolean

        Dim dtmDate As Date

        IsStringADate = True

        Try

            dtmDate = CDate(strDate)

        Catch ex As Exception

            IsStringADate = False
        End Try

    End Function

    Public Function IsStringATwoDigitMonthAndYear(ByVal strDate As String) As Boolean

        Dim intPos As Integer
        Dim strLeft As String, strRight As String

        IsStringATwoDigitMonthAndYear = False

        Try

            intPos = InStr(strDate, " ")

            If intPos = 2 Then

                strLeft = Mid(strDate, 1, intPos).Trim
                strRight = Mid(strDate, 3)

                If IsNumeric(strLeft) And IsNumeric(strRight) Then

                    If (CInt(strLeft) > 0 And CInt(strLeft) <= 9) And CInt(strRight) >= 2010 Then

                        Return True
                    End If
                End If
            End If

            If intPos = 3 Then

                strLeft = Mid(strDate, 1, intPos).Trim
                strRight = Mid(strDate, 4)

                If IsNumeric(strLeft) And IsNumeric(strRight) Then

                    If (CInt(strLeft) > 0 And CInt(strLeft) <= 12) And CInt(strRight) >= 2010 Then

                        Return True
                    End If
                End If
            End If

        Catch ex As Exception

            IsStringATwoDigitMonthAndYear = False
        End Try

    End Function

    Public Function GetThreeDigitMonth(ByVal strTwoDigitMonth As String) As String

        Select Case strTwoDigitMonth

            Case "1", "01" : GetThreeDigitMonth = "Jan"
            Case "2", "02" : GetThreeDigitMonth = "Feb"
            Case "3", "03" : GetThreeDigitMonth = "Mar"
            Case "4", "04" : GetThreeDigitMonth = "Apr"
            Case "5", "05" : GetThreeDigitMonth = "May"
            Case "6", "06" : GetThreeDigitMonth = "Jun"
            Case "7", "07" : GetThreeDigitMonth = "Jul"
            Case "8", "08" : GetThreeDigitMonth = "Aug"
            Case "9", "09" : GetThreeDigitMonth = "Sep"
            Case "10" : GetThreeDigitMonth = "Oct"
            Case "11" : GetThreeDigitMonth = "Nov"
            Case "12" : GetThreeDigitMonth = "Dec"

        End Select

    End Function

End Module
