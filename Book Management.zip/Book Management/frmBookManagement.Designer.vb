﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBookManagement
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBookManagement))
        Me.cmdCopyStructureBooks = New System.Windows.Forms.Button()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cmdDupsByRev = New System.Windows.Forms.Button()
        Me.cmdDupsByName = New System.Windows.Forms.Button()
        Me.cmdDupsBySize = New System.Windows.Forms.Button()
        Me.cmdDupsByLevenshteinDistance = New System.Windows.Forms.Button()
        Me.cmdDupsByBinaryPatternMatching = New System.Windows.Forms.Button()
        Me.cmdKeep = New System.Windows.Forms.Button()
        Me.cmdMags = New System.Windows.Forms.Button()
        Me.cmdMags_PDFEditing = New System.Windows.Forms.Button()
        Me.cmdKeep_PDFEditing = New System.Windows.Forms.Button()
        Me.chkPDFEditing_AutoApplyStandard = New System.Windows.Forms.CheckBox()
        Me.cmdPDFEditing_GSCompressFolder = New System.Windows.Forms.Button()
        Me.cmdBooks_LoadPDF = New System.Windows.Forms.Button()
        Me.cmdTorrents_LoadPDF = New System.Windows.Forms.Button()
        Me.cmdTorrents_LoadPDFPage0 = New System.Windows.Forms.Button()
        Me.cmdBooks_LoadPDFPage0 = New System.Windows.Forms.Button()
        Me.cmdPDFEditing_LoadPDFPage0 = New System.Windows.Forms.Button()
        Me.cmdBooks_PDFEditing = New System.Windows.Forms.Button()
        Me.chkPDFEditing_StopLoad = New System.Windows.Forms.CheckBox()
        Me.chkPDFEditing_AutoLoadPage0 = New System.Windows.Forms.CheckBox()
        Me.cmdPDFEditing_Load_All_PageZeros = New System.Windows.Forms.Button()
        Me.chkPDFEditing_SaveMissingPages = New System.Windows.Forms.CheckBox()
        Me.chkTorrents_AutoLoadPage0 = New System.Windows.Forms.CheckBox()
        Me.chkBooks_AutoLoadPage0 = New System.Windows.Forms.CheckBox()
        Me.cmdLoadCBooksIntoListview = New System.Windows.Forms.Button()
        Me.chkAllFileTypes = New System.Windows.Forms.CheckBox()
        Me.cmdTorrents_MoveMags = New System.Windows.Forms.Button()
        Me.cmdTorrents_DeleteMag = New System.Windows.Forms.Button()
        Me.cmdBooks_DeleteMag = New System.Windows.Forms.Button()
        Me.cmdBooks_TransferFilename = New System.Windows.Forms.Button()
        Me.cmdTorrents_TransferFilename = New System.Windows.Forms.Button()
        Me.cmdTorrents_DeleteEmptyFolders = New System.Windows.Forms.Button()
        Me.chkPDFEditing_OnFolderChange_AutoLoadPage0s = New System.Windows.Forms.CheckBox()
        Me.cmdPDFEditing_DelBackups = New System.Windows.Forms.Button()
        Me.cmdTorrents_RemoveBrackets = New System.Windows.Forms.Button()
        Me.mnuListviewRightClick = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnuOpenFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSwapNamesAndDelete1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSwapNamesAndDelete2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOpenPath = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDeleteFiles = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuRemoveHiddenFlag = New System.Windows.Forms.ToolStripMenuItem()
        Me.proProgress = New System.Windows.Forms.ProgressBar()
        Me.tabBook = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.fraBookManagement = New System.Windows.Forms.GroupBox()
        Me.txtFilterByText = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.cmdFiles_NextSelection = New System.Windows.Forms.Button()
        Me.cmdFiles_PreviousSelection = New System.Windows.Forms.Button()
        Me.updwnMatchPercent = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.chkShowInternalName = New System.Windows.Forms.CheckBox()
        Me.updwnBytes = New System.Windows.Forms.NumericUpDown()
        Me.updwnLevenshteinDistance = New System.Windows.Forms.NumericUpDown()
        Me.chkShowOnlySelected = New System.Windows.Forms.CheckBox()
        Me.cboUniqueTypes = New System.Windows.Forms.ComboBox()
        Me.lblTypeFilter = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmdLoadRecursive = New System.Windows.Forms.Button()
        Me.cmdLoad = New System.Windows.Forms.Button()
        Me.lvwFiles = New System.Windows.Forms.ListView()
        Me.colNameOnDisk = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colSize = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader15 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colFolder = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colInternalName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.cmdPath = New System.Windows.Forms.Button()
        Me.txtPath = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.AccBookBottom = New AxAcroPDFLib.AxAcroPDF()
        Me.accBookTop = New AxAcroPDFLib.AxAcroPDF()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.fraMoveMags = New System.Windows.Forms.GroupBox()
        Me.cmdTorrents_MagCleanup = New System.Windows.Forms.Button()
        Me.cmdBooks_IndividualEdit = New System.Windows.Forms.Button()
        Me.cmdTorrents_IndividualEdit = New System.Windows.Forms.Button()
        Me.txtMagCopier_TorrentFilename = New System.Windows.Forms.TextBox()
        Me.lvwMagCopier_PossibleDups = New System.Windows.Forms.ListView()
        Me.ColumnHeader10 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader11 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader12 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.cmdBooks_GSCompress = New System.Windows.Forms.Button()
        Me.cmdTorrents_GSCompress = New System.Windows.Forms.Button()
        Me.cmdBooksForward = New System.Windows.Forms.Button()
        Me.cmdBooksBack = New System.Windows.Forms.Button()
        Me.txtMagCopier_BooksFilename = New System.Windows.Forms.TextBox()
        Me.txtBooksPath_MagCopier = New System.Windows.Forms.TextBox()
        Me.cmdTorrentsForward = New System.Windows.Forms.Button()
        Me.cmdTorrentsBack = New System.Windows.Forms.Button()
        Me.cmdBooks_RemovePageZero = New System.Windows.Forms.Button()
        Me.cmdTorrents_RemovePageZero = New System.Windows.Forms.Button()
        Me.accBooksPDF = New AxAcroPDFLib.AxAcroPDF()
        Me.lvwBooksMags = New System.Windows.Forms.ListView()
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.lvwTorrentMags = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.cmdLoad_MagCopier = New System.Windows.Forms.Button()
        Me.cmdPath_MagCopier = New System.Windows.Forms.Button()
        Me.txtPath_MagCopier = New System.Windows.Forms.TextBox()
        Me.accTorrentPDF = New AxAcroPDFLib.AxAcroPDF()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.fraPDFEditing = New System.Windows.Forms.GroupBox()
        Me.cmdPDFEditing_RemoveFoldersPageZeros = New System.Windows.Forms.Button()
        Me.cmdPDFEditing_MovePageZero = New System.Windows.Forms.Button()
        Me.cmdPDFEditing_RemovePageZero = New System.Windows.Forms.Button()
        Me.cmdPDFEditing_GSCompress = New System.Windows.Forms.Button()
        Me.cmdPDFEditing_Refresh = New System.Windows.Forms.Button()
        Me.cmdPDFEditing_Clear = New System.Windows.Forms.Button()
        Me.cmdPDFEditing_LoadFile = New System.Windows.Forms.Button()
        Me.cboPDFEditing_StandardTypesDuringLoad = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cmdPDFEditing_Save = New System.Windows.Forms.Button()
        Me.cboPDFEditing_Pages = New System.Windows.Forms.ComboBox()
        Me.lblPages = New System.Windows.Forms.Label()
        Me.cboPDFEditing_StandardTypesAfterLoad = New System.Windows.Forms.ComboBox()
        Me.lblPDFEditing_Types = New System.Windows.Forms.Label()
        Me.accPDFEditing_Main = New AxAcroPDFLib.AxAcroPDF()
        Me.panPDFEditing = New System.Windows.Forms.Panel()
        Me.txtPDFEDiting_FolderGSCompression = New System.Windows.Forms.TextBox()
        Me.cmdPDFEditingForward = New System.Windows.Forms.Button()
        Me.cmdPDFEditingBack = New System.Windows.Forms.Button()
        Me.lvwPDFEditing = New System.Windows.Forms.ListView()
        Me.ColumnHeader7 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader8 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader9 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.cmdLoad_PDFEditing = New System.Windows.Forms.Button()
        Me.cmdPath_PDFEditing = New System.Windows.Forms.Button()
        Me.txtPath_PDFEditing = New System.Windows.Forms.TextBox()
        Me.lblLoadPage0Filename = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.cmdAutoBookSort_Move = New System.Windows.Forms.Button()
        Me.cmdAutoBookSort_Process = New System.Windows.Forms.Button()
        Me.fraAutoBookSort = New System.Windows.Forms.GroupBox()
        Me.lvwAutoBookSort_Results = New System.Windows.Forms.ListView()
        Me.ColumnHeader13 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader14 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.cmdAutoBookSort_TargetPath = New System.Windows.Forms.Button()
        Me.txtAutoBookSort_TargetPath = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.cmdAutoBookSort_PathToSort = New System.Windows.Forms.Button()
        Me.txtAutoBookSort_PathToSort = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.fraMagazineFinder = New System.Windows.Forms.GroupBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.cboMagazineFinderSelectionOptions = New System.Windows.Forms.ComboBox()
        Me.cboMagazineFinderSearchType = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.prgMagazineFinder = New System.Windows.Forms.ProgressBar()
        Me.cmdMagazineFinderDownload = New System.Windows.Forms.Button()
        Me.cmdMagazineFinderLoadFiles = New System.Windows.Forms.Button()
        Me.lvwMagazineFinderFiles = New System.Windows.Forms.ListView()
        Me.ColumnHeader19 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.lblMagFinderSearch = New System.Windows.Forms.Label()
        Me.txtMagazineFinderSearchTerm = New System.Windows.Forms.TextBox()
        Me.txtMagazineFinderPath = New System.Windows.Forms.TextBox()
        Me.cmdMagazineFinderForward = New System.Windows.Forms.Button()
        Me.cmdMagazineFinderBack = New System.Windows.Forms.Button()
        Me.cmdMagazineFinderProcess = New System.Windows.Forms.Button()
        Me.cboMagazineFinderWebSites = New System.Windows.Forms.ComboBox()
        Me.lvwMagazineFinderURLs = New System.Windows.Forms.ListView()
        Me.ColumnHeader16 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader17 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader18 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader20 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cmdMagazineFinderPath = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.fraMagazineReview = New System.Windows.Forms.GroupBox()
        Me.AxAcroPDF8 = New AxAcroPDFLib.AxAcroPDF()
        Me.AxAcroPDF7 = New AxAcroPDFLib.AxAcroPDF()
        Me.AxAcroPDF6 = New AxAcroPDFLib.AxAcroPDF()
        Me.AxAcroPDF5 = New AxAcroPDFLib.AxAcroPDF()
        Me.AxAcroPDF4 = New AxAcroPDFLib.AxAcroPDF()
        Me.AxAcroPDF3 = New AxAcroPDFLib.AxAcroPDF()
        Me.AxAcroPDF2 = New AxAcroPDFLib.AxAcroPDF()
        Me.AxAcroPDF1 = New AxAcroPDFLib.AxAcroPDF()
        Me.accMagazineReview_6 = New AxAcroPDFLib.AxAcroPDF()
        Me.accMagazineReview_1 = New AxAcroPDFLib.AxAcroPDF()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.cmdMagazineReview_Prev = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.cmdMagazineReview_Next = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.fraGSComp = New System.Windows.Forms.GroupBox()
        Me.txtGSCompTab_Details = New System.Windows.Forms.TextBox()
        Me.lvwGSCompTab_Files = New System.Windows.Forms.ListView()
        Me.ColumnHeader21 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader22 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader23 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.cmdGSCompTab_GSCompress = New System.Windows.Forms.Button()
        Me.cmdGSCompTab_LoadRec = New System.Windows.Forms.Button()
        Me.cmdGSCompTab_Load = New System.Windows.Forms.Button()
        Me.cmdGSCompTab_Path = New System.Windows.Forms.Button()
        Me.txtGSCompTab_Path = New System.Windows.Forms.TextBox()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.fraePubConv = New System.Windows.Forms.GroupBox()
        Me.txtePubConvTab_Details = New System.Windows.Forms.TextBox()
        Me.lvwePubConvTab_Files = New System.Windows.Forms.ListView()
        Me.ColumnHeader24 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader25 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader26 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.cmdePubConvTab_EpubConv = New System.Windows.Forms.Button()
        Me.cmdePubConvTab_LoadRec = New System.Windows.Forms.Button()
        Me.cmdePubConvTab_Load = New System.Windows.Forms.Button()
        Me.cmdePubConvTab_Path = New System.Windows.Forms.Button()
        Me.txtePubConvTab_Path = New System.Windows.Forms.TextBox()
        Me.txtErrors = New System.Windows.Forms.TextBox()
        Me.lblErrors = New System.Windows.Forms.Label()
        Me.tmrClearError = New System.Windows.Forms.Timer(Me.components)
        Me.tmrClearMessages = New System.Windows.Forms.Timer(Me.components)
        Me.cmdTorrents_LoadBothPage0s = New System.Windows.Forms.Button()
        Me.mnuListviewRightClick.SuspendLayout()
        Me.tabBook.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.fraBookManagement.SuspendLayout()
        CType(Me.updwnMatchPercent, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.updwnBytes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.updwnLevenshteinDistance, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AccBookBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.accBookTop, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.fraMoveMags.SuspendLayout()
        CType(Me.accBooksPDF, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.accTorrentPDF, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.fraPDFEditing.SuspendLayout()
        CType(Me.accPDFEditing_Main, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panPDFEditing.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.fraAutoBookSort.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.fraMagazineFinder.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.fraMagazineReview.SuspendLayout()
        CType(Me.AxAcroPDF8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AxAcroPDF7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AxAcroPDF6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AxAcroPDF5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AxAcroPDF4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AxAcroPDF3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AxAcroPDF2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AxAcroPDF1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.accMagazineReview_6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.accMagazineReview_1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage7.SuspendLayout()
        Me.fraGSComp.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.fraePubConv.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdCopyStructureBooks
        '
        Me.cmdCopyStructureBooks.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdCopyStructureBooks.Location = New System.Drawing.Point(813, 597)
        Me.cmdCopyStructureBooks.Name = "cmdCopyStructureBooks"
        Me.cmdCopyStructureBooks.Size = New System.Drawing.Size(130, 25)
        Me.cmdCopyStructureBooks.TabIndex = 18
        Me.cmdCopyStructureBooks.Text = "Copy Structure - Books"
        Me.ToolTip1.SetToolTip(Me.cmdCopyStructureBooks, "Copies structure of current books folder to a folder in temp allow me to allocate" &
        " location of books while in work Making it easier later to manually copy them")
        Me.cmdCopyStructureBooks.UseVisualStyleBackColor = True
        '
        'cmdClose
        '
        Me.cmdClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdClose.Location = New System.Drawing.Point(1368, 717)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Size = New System.Drawing.Size(89, 27)
        Me.cmdClose.TabIndex = 19
        Me.cmdClose.Text = "Close"
        Me.cmdClose.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(496, 632)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(129, 13)
        Me.Label4.TabIndex = 52
        Me.Label4.Text = "Looks for reversed names"
        Me.ToolTip1.SetToolTip(Me.Label4, "Looks for reversed names - Mexicana - Desserts.pdf && Desserts - Mexicana.pdf")
        '
        'cmdDupsByRev
        '
        Me.cmdDupsByRev.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdDupsByRev.Location = New System.Drawing.Point(395, 628)
        Me.cmdDupsByRev.Name = "cmdDupsByRev"
        Me.cmdDupsByRev.Size = New System.Drawing.Size(95, 25)
        Me.cmdDupsByRev.TabIndex = 51
        Me.cmdDupsByRev.Text = "Dups by Rev."
        Me.ToolTip1.SetToolTip(Me.cmdDupsByRev, "Looks for reversed names - Mexicana - Desserts.pdf && Desserts - Mexicana.pdf")
        Me.cmdDupsByRev.UseVisualStyleBackColor = True
        '
        'cmdDupsByName
        '
        Me.cmdDupsByName.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdDupsByName.Location = New System.Drawing.Point(395, 597)
        Me.cmdDupsByName.Name = "cmdDupsByName"
        Me.cmdDupsByName.Size = New System.Drawing.Size(95, 25)
        Me.cmdDupsByName.TabIndex = 48
        Me.cmdDupsByName.Text = "Dups by Name"
        Me.ToolTip1.SetToolTip(Me.cmdDupsByName, "Dups by Name")
        Me.cmdDupsByName.UseVisualStyleBackColor = True
        '
        'cmdDupsBySize
        '
        Me.cmdDupsBySize.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdDupsBySize.Location = New System.Drawing.Point(6, 628)
        Me.cmdDupsBySize.Name = "cmdDupsBySize"
        Me.cmdDupsBySize.Size = New System.Drawing.Size(95, 25)
        Me.cmdDupsBySize.TabIndex = 38
        Me.cmdDupsBySize.Text = "Dups by Size"
        Me.ToolTip1.SetToolTip(Me.cmdDupsBySize, "Dups by Size")
        Me.cmdDupsBySize.UseVisualStyleBackColor = True
        '
        'cmdDupsByLevenshteinDistance
        '
        Me.cmdDupsByLevenshteinDistance.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdDupsByLevenshteinDistance.Location = New System.Drawing.Point(6, 597)
        Me.cmdDupsByLevenshteinDistance.Name = "cmdDupsByLevenshteinDistance"
        Me.cmdDupsByLevenshteinDistance.Size = New System.Drawing.Size(95, 25)
        Me.cmdDupsByLevenshteinDistance.TabIndex = 36
        Me.cmdDupsByLevenshteinDistance.Text = "Dups by Lev."
        Me.ToolTip1.SetToolTip(Me.cmdDupsByLevenshteinDistance, "Dups by Levenshtein Distance")
        Me.cmdDupsByLevenshteinDistance.UseVisualStyleBackColor = True
        '
        'cmdDupsByBinaryPatternMatching
        '
        Me.cmdDupsByBinaryPatternMatching.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdDupsByBinaryPatternMatching.Location = New System.Drawing.Point(712, 597)
        Me.cmdDupsByBinaryPatternMatching.Name = "cmdDupsByBinaryPatternMatching"
        Me.cmdDupsByBinaryPatternMatching.Size = New System.Drawing.Size(95, 25)
        Me.cmdDupsByBinaryPatternMatching.TabIndex = 53
        Me.cmdDupsByBinaryPatternMatching.Text = "Dups by Binary"
        Me.ToolTip1.SetToolTip(Me.cmdDupsByBinaryPatternMatching, "Dups by Binary Pattern Matching")
        Me.cmdDupsByBinaryPatternMatching.UseVisualStyleBackColor = True
        '
        'cmdKeep
        '
        Me.cmdKeep.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdKeep.Location = New System.Drawing.Point(1241, 25)
        Me.cmdKeep.Name = "cmdKeep"
        Me.cmdKeep.Size = New System.Drawing.Size(50, 23)
        Me.cmdKeep.TabIndex = 58
        Me.cmdKeep.Text = "Keep"
        Me.ToolTip1.SetToolTip(Me.cmdKeep, "Go to the Keep folder")
        Me.cmdKeep.UseVisualStyleBackColor = True
        '
        'cmdMags
        '
        Me.cmdMags.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdMags.Location = New System.Drawing.Point(1297, 25)
        Me.cmdMags.Name = "cmdMags"
        Me.cmdMags.Size = New System.Drawing.Size(50, 23)
        Me.cmdMags.TabIndex = 59
        Me.cmdMags.TabStop = False
        Me.cmdMags.Text = "Mags"
        Me.ToolTip1.SetToolTip(Me.cmdMags, "Go to first Mags folder")
        Me.cmdMags.UseVisualStyleBackColor = True
        '
        'cmdMags_PDFEditing
        '
        Me.cmdMags_PDFEditing.Location = New System.Drawing.Point(547, 27)
        Me.cmdMags_PDFEditing.Name = "cmdMags_PDFEditing"
        Me.cmdMags_PDFEditing.Size = New System.Drawing.Size(45, 20)
        Me.cmdMags_PDFEditing.TabIndex = 59
        Me.cmdMags_PDFEditing.TabStop = False
        Me.cmdMags_PDFEditing.Text = "Mags"
        Me.ToolTip1.SetToolTip(Me.cmdMags_PDFEditing, "Go to first _Torrent\Completed\_Magazines folder")
        Me.cmdMags_PDFEditing.UseVisualStyleBackColor = True
        '
        'cmdKeep_PDFEditing
        '
        Me.cmdKeep_PDFEditing.Location = New System.Drawing.Point(500, 27)
        Me.cmdKeep_PDFEditing.Name = "cmdKeep_PDFEditing"
        Me.cmdKeep_PDFEditing.Size = New System.Drawing.Size(45, 20)
        Me.cmdKeep_PDFEditing.TabIndex = 58
        Me.cmdKeep_PDFEditing.Text = "Keep"
        Me.ToolTip1.SetToolTip(Me.cmdKeep_PDFEditing, "Go to the 50 Assorted Magazines Keep folder")
        Me.cmdKeep_PDFEditing.UseVisualStyleBackColor = True
        '
        'chkPDFEditing_AutoApplyStandard
        '
        Me.chkPDFEditing_AutoApplyStandard.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkPDFEditing_AutoApplyStandard.Checked = True
        Me.chkPDFEditing_AutoApplyStandard.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkPDFEditing_AutoApplyStandard.Location = New System.Drawing.Point(464, 309)
        Me.chkPDFEditing_AutoApplyStandard.Name = "chkPDFEditing_AutoApplyStandard"
        Me.chkPDFEditing_AutoApplyStandard.Size = New System.Drawing.Size(176, 17)
        Me.chkPDFEditing_AutoApplyStandard.TabIndex = 73
        Me.chkPDFEditing_AutoApplyStandard.Text = "Auto Apply Standard"
        Me.ToolTip1.SetToolTip(Me.chkPDFEditing_AutoApplyStandard, "Load PDF on item selection")
        Me.chkPDFEditing_AutoApplyStandard.UseVisualStyleBackColor = True
        '
        'cmdPDFEditing_GSCompressFolder
        '
        Me.cmdPDFEditing_GSCompressFolder.Location = New System.Drawing.Point(444, 562)
        Me.cmdPDFEditing_GSCompressFolder.Name = "cmdPDFEditing_GSCompressFolder"
        Me.cmdPDFEditing_GSCompressFolder.Size = New System.Drawing.Size(95, 25)
        Me.cmdPDFEditing_GSCompressFolder.TabIndex = 77
        Me.cmdPDFEditing_GSCompressFolder.Text = "GS Comp. Folder"
        Me.ToolTip1.SetToolTip(Me.cmdPDFEditing_GSCompressFolder, "GS Compress all the files that need it")
        Me.cmdPDFEditing_GSCompressFolder.UseVisualStyleBackColor = True
        '
        'cmdBooks_LoadPDF
        '
        Me.cmdBooks_LoadPDF.Location = New System.Drawing.Point(1322, 302)
        Me.cmdBooks_LoadPDF.Name = "cmdBooks_LoadPDF"
        Me.cmdBooks_LoadPDF.Size = New System.Drawing.Size(95, 25)
        Me.cmdBooks_LoadPDF.TabIndex = 64
        Me.cmdBooks_LoadPDF.Text = "Load PDF"
        Me.ToolTip1.SetToolTip(Me.cmdBooks_LoadPDF, "Load all pages")
        Me.cmdBooks_LoadPDF.UseVisualStyleBackColor = True
        '
        'cmdTorrents_LoadPDF
        '
        Me.cmdTorrents_LoadPDF.Location = New System.Drawing.Point(618, 299)
        Me.cmdTorrents_LoadPDF.Name = "cmdTorrents_LoadPDF"
        Me.cmdTorrents_LoadPDF.Size = New System.Drawing.Size(95, 25)
        Me.cmdTorrents_LoadPDF.TabIndex = 63
        Me.cmdTorrents_LoadPDF.Text = "Load PDF"
        Me.ToolTip1.SetToolTip(Me.cmdTorrents_LoadPDF, "Load all pages")
        Me.cmdTorrents_LoadPDF.UseVisualStyleBackColor = True
        '
        'cmdTorrents_LoadPDFPage0
        '
        Me.cmdTorrents_LoadPDFPage0.Location = New System.Drawing.Point(618, 330)
        Me.cmdTorrents_LoadPDFPage0.Name = "cmdTorrents_LoadPDFPage0"
        Me.cmdTorrents_LoadPDFPage0.Size = New System.Drawing.Size(95, 25)
        Me.cmdTorrents_LoadPDFPage0.TabIndex = 65
        Me.cmdTorrents_LoadPDFPage0.Text = "Load Page 0"
        Me.ToolTip1.SetToolTip(Me.cmdTorrents_LoadPDFPage0, "Load page zero")
        Me.cmdTorrents_LoadPDFPage0.UseVisualStyleBackColor = True
        '
        'cmdBooks_LoadPDFPage0
        '
        Me.cmdBooks_LoadPDFPage0.Location = New System.Drawing.Point(1322, 330)
        Me.cmdBooks_LoadPDFPage0.Name = "cmdBooks_LoadPDFPage0"
        Me.cmdBooks_LoadPDFPage0.Size = New System.Drawing.Size(95, 25)
        Me.cmdBooks_LoadPDFPage0.TabIndex = 66
        Me.cmdBooks_LoadPDFPage0.Text = "Load Page 0"
        Me.ToolTip1.SetToolTip(Me.cmdBooks_LoadPDFPage0, "Load page zero")
        Me.cmdBooks_LoadPDFPage0.UseVisualStyleBackColor = True
        '
        'cmdPDFEditing_LoadPDFPage0
        '
        Me.cmdPDFEditing_LoadPDFPage0.Location = New System.Drawing.Point(398, 602)
        Me.cmdPDFEditing_LoadPDFPage0.Name = "cmdPDFEditing_LoadPDFPage0"
        Me.cmdPDFEditing_LoadPDFPage0.Size = New System.Drawing.Size(95, 25)
        Me.cmdPDFEditing_LoadPDFPage0.TabIndex = 79
        Me.cmdPDFEditing_LoadPDFPage0.Text = "Load Page 0"
        Me.ToolTip1.SetToolTip(Me.cmdPDFEditing_LoadPDFPage0, "Load page zero")
        Me.cmdPDFEditing_LoadPDFPage0.UseVisualStyleBackColor = True
        '
        'cmdBooks_PDFEditing
        '
        Me.cmdBooks_PDFEditing.Location = New System.Drawing.Point(595, 27)
        Me.cmdBooks_PDFEditing.Name = "cmdBooks_PDFEditing"
        Me.cmdBooks_PDFEditing.Size = New System.Drawing.Size(45, 20)
        Me.cmdBooks_PDFEditing.TabIndex = 80
        Me.cmdBooks_PDFEditing.TabStop = False
        Me.cmdBooks_PDFEditing.Text = "Books"
        Me.ToolTip1.SetToolTip(Me.cmdBooks_PDFEditing, "Go to first Books\Magazines folder")
        Me.cmdBooks_PDFEditing.UseVisualStyleBackColor = True
        '
        'chkPDFEditing_StopLoad
        '
        Me.chkPDFEditing_StopLoad.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkPDFEditing_StopLoad.Location = New System.Drawing.Point(464, 583)
        Me.chkPDFEditing_StopLoad.Name = "chkPDFEditing_StopLoad"
        Me.chkPDFEditing_StopLoad.Size = New System.Drawing.Size(176, 17)
        Me.chkPDFEditing_StopLoad.TabIndex = 81
        Me.chkPDFEditing_StopLoad.Text = "Stop PDF from loading"
        Me.ToolTip1.SetToolTip(Me.chkPDFEditing_StopLoad, "Stop PDF from Loading")
        Me.chkPDFEditing_StopLoad.UseVisualStyleBackColor = True
        Me.chkPDFEditing_StopLoad.Visible = False
        '
        'chkPDFEditing_AutoLoadPage0
        '
        Me.chkPDFEditing_AutoLoadPage0.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkPDFEditing_AutoLoadPage0.Location = New System.Drawing.Point(464, 602)
        Me.chkPDFEditing_AutoLoadPage0.Name = "chkPDFEditing_AutoLoadPage0"
        Me.chkPDFEditing_AutoLoadPage0.Size = New System.Drawing.Size(176, 17)
        Me.chkPDFEditing_AutoLoadPage0.TabIndex = 82
        Me.chkPDFEditing_AutoLoadPage0.Text = "Auto Load Page 0"
        Me.ToolTip1.SetToolTip(Me.chkPDFEditing_AutoLoadPage0, "Auto Load Page 0 when item selected")
        Me.chkPDFEditing_AutoLoadPage0.UseVisualStyleBackColor = True
        '
        'cmdPDFEditing_Load_All_PageZeros
        '
        Me.cmdPDFEditing_Load_All_PageZeros.Location = New System.Drawing.Point(524, 594)
        Me.cmdPDFEditing_Load_All_PageZeros.Name = "cmdPDFEditing_Load_All_PageZeros"
        Me.cmdPDFEditing_Load_All_PageZeros.Size = New System.Drawing.Size(111, 25)
        Me.cmdPDFEditing_Load_All_PageZeros.TabIndex = 83
        Me.cmdPDFEditing_Load_All_PageZeros.Text = "Load All Page 0's"
        Me.ToolTip1.SetToolTip(Me.cmdPDFEditing_Load_All_PageZeros, "Load all the page zeros")
        Me.cmdPDFEditing_Load_All_PageZeros.UseVisualStyleBackColor = True
        '
        'chkPDFEditing_SaveMissingPages
        '
        Me.chkPDFEditing_SaveMissingPages.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkPDFEditing_SaveMissingPages.Checked = True
        Me.chkPDFEditing_SaveMissingPages.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkPDFEditing_SaveMissingPages.Location = New System.Drawing.Point(467, 614)
        Me.chkPDFEditing_SaveMissingPages.Name = "chkPDFEditing_SaveMissingPages"
        Me.chkPDFEditing_SaveMissingPages.Size = New System.Drawing.Size(72, 48)
        Me.chkPDFEditing_SaveMissingPages.TabIndex = 84
        Me.chkPDFEditing_SaveMissingPages.Text = "Save Missing Pages"
        Me.ToolTip1.SetToolTip(Me.chkPDFEditing_SaveMissingPages, "Save any missing pages")
        Me.chkPDFEditing_SaveMissingPages.UseVisualStyleBackColor = True
        '
        'chkTorrents_AutoLoadPage0
        '
        Me.chkTorrents_AutoLoadPage0.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkTorrents_AutoLoadPage0.Location = New System.Drawing.Point(409, 335)
        Me.chkTorrents_AutoLoadPage0.Name = "chkTorrents_AutoLoadPage0"
        Me.chkTorrents_AutoLoadPage0.Size = New System.Drawing.Size(176, 17)
        Me.chkTorrents_AutoLoadPage0.TabIndex = 83
        Me.chkTorrents_AutoLoadPage0.Text = "Auto Load Page 0"
        Me.ToolTip1.SetToolTip(Me.chkTorrents_AutoLoadPage0, "Auto Load Page 0 when item selected")
        Me.chkTorrents_AutoLoadPage0.UseVisualStyleBackColor = True
        '
        'chkBooks_AutoLoadPage0
        '
        Me.chkBooks_AutoLoadPage0.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkBooks_AutoLoadPage0.Location = New System.Drawing.Point(1119, 335)
        Me.chkBooks_AutoLoadPage0.Name = "chkBooks_AutoLoadPage0"
        Me.chkBooks_AutoLoadPage0.Size = New System.Drawing.Size(176, 17)
        Me.chkBooks_AutoLoadPage0.TabIndex = 84
        Me.chkBooks_AutoLoadPage0.Text = "Auto Load Page 0"
        Me.ToolTip1.SetToolTip(Me.chkBooks_AutoLoadPage0, "Auto Load Page 0 when item selected")
        Me.chkBooks_AutoLoadPage0.UseVisualStyleBackColor = True
        '
        'cmdLoadCBooksIntoListview
        '
        Me.cmdLoadCBooksIntoListview.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdLoadCBooksIntoListview.Location = New System.Drawing.Point(949, 598)
        Me.cmdLoadCBooksIntoListview.Name = "cmdLoadCBooksIntoListview"
        Me.cmdLoadCBooksIntoListview.Size = New System.Drawing.Size(164, 25)
        Me.cmdLoadCBooksIntoListview.TabIndex = 56
        Me.cmdLoadCBooksIntoListview.Text = "Load c:\Books into listview"
        Me.ToolTip1.SetToolTip(Me.cmdLoadCBooksIntoListview, "Load c:\Books into listview without a clear first - Move files from Assorted book" &
        "s folder first into books")
        Me.cmdLoadCBooksIntoListview.UseVisualStyleBackColor = True
        '
        'chkAllFileTypes
        '
        Me.chkAllFileTypes.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkAllFileTypes.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkAllFileTypes.Location = New System.Drawing.Point(1298, 629)
        Me.chkAllFileTypes.Name = "chkAllFileTypes"
        Me.chkAllFileTypes.Size = New System.Drawing.Size(122, 17)
        Me.chkAllFileTypes.TabIndex = 64
        Me.chkAllFileTypes.Text = "All File Types"
        Me.ToolTip1.SetToolTip(Me.chkAllFileTypes, "Load All File Types into listview")
        Me.chkAllFileTypes.UseVisualStyleBackColor = True
        '
        'cmdTorrents_MoveMags
        '
        Me.cmdTorrents_MoveMags.Location = New System.Drawing.Point(618, 423)
        Me.cmdTorrents_MoveMags.Name = "cmdTorrents_MoveMags"
        Me.cmdTorrents_MoveMags.Size = New System.Drawing.Size(95, 25)
        Me.cmdTorrents_MoveMags.TabIndex = 85
        Me.cmdTorrents_MoveMags.Text = "Move Mag(s)"
        Me.ToolTip1.SetToolTip(Me.cmdTorrents_MoveMags, "Move any mags where checked or them all if none checked")
        Me.cmdTorrents_MoveMags.UseVisualStyleBackColor = True
        '
        'cmdTorrents_DeleteMag
        '
        Me.cmdTorrents_DeleteMag.Location = New System.Drawing.Point(618, 454)
        Me.cmdTorrents_DeleteMag.Name = "cmdTorrents_DeleteMag"
        Me.cmdTorrents_DeleteMag.Size = New System.Drawing.Size(95, 25)
        Me.cmdTorrents_DeleteMag.TabIndex = 86
        Me.cmdTorrents_DeleteMag.Text = "Delete Mag"
        Me.ToolTip1.SetToolTip(Me.cmdTorrents_DeleteMag, "Move to recycle bin")
        Me.cmdTorrents_DeleteMag.UseVisualStyleBackColor = True
        '
        'cmdBooks_DeleteMag
        '
        Me.cmdBooks_DeleteMag.Location = New System.Drawing.Point(1322, 394)
        Me.cmdBooks_DeleteMag.Name = "cmdBooks_DeleteMag"
        Me.cmdBooks_DeleteMag.Size = New System.Drawing.Size(95, 25)
        Me.cmdBooks_DeleteMag.TabIndex = 87
        Me.cmdBooks_DeleteMag.Text = "Delete Mag"
        Me.ToolTip1.SetToolTip(Me.cmdBooks_DeleteMag, "Move to recycle bin")
        Me.cmdBooks_DeleteMag.UseVisualStyleBackColor = True
        '
        'cmdBooks_TransferFilename
        '
        Me.cmdBooks_TransferFilename.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.cmdBooks_TransferFilename.Location = New System.Drawing.Point(1322, 468)
        Me.cmdBooks_TransferFilename.Name = "cmdBooks_TransferFilename"
        Me.cmdBooks_TransferFilename.Size = New System.Drawing.Size(95, 25)
        Me.cmdBooks_TransferFilename.TabIndex = 93
        Me.cmdBooks_TransferFilename.Text = "<< Copy Name"
        Me.ToolTip1.SetToolTip(Me.cmdBooks_TransferFilename, "Apply the name of the selected books file to the selected mags file")
        Me.cmdBooks_TransferFilename.UseVisualStyleBackColor = True
        '
        'cmdTorrents_TransferFilename
        '
        Me.cmdTorrents_TransferFilename.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.cmdTorrents_TransferFilename.Location = New System.Drawing.Point(618, 516)
        Me.cmdTorrents_TransferFilename.Name = "cmdTorrents_TransferFilename"
        Me.cmdTorrents_TransferFilename.Size = New System.Drawing.Size(95, 25)
        Me.cmdTorrents_TransferFilename.TabIndex = 94
        Me.cmdTorrents_TransferFilename.Text = "Copy Name >>"
        Me.ToolTip1.SetToolTip(Me.cmdTorrents_TransferFilename, "Apply the name of the selected mags file to the selected books file")
        Me.cmdTorrents_TransferFilename.UseVisualStyleBackColor = True
        '
        'cmdTorrents_DeleteEmptyFolders
        '
        Me.cmdTorrents_DeleteEmptyFolders.Location = New System.Drawing.Point(618, 611)
        Me.cmdTorrents_DeleteEmptyFolders.Name = "cmdTorrents_DeleteEmptyFolders"
        Me.cmdTorrents_DeleteEmptyFolders.Size = New System.Drawing.Size(95, 25)
        Me.cmdTorrents_DeleteEmptyFolders.TabIndex = 95
        Me.cmdTorrents_DeleteEmptyFolders.Text = "Del Empty Fldrs"
        Me.ToolTip1.SetToolTip(Me.cmdTorrents_DeleteEmptyFolders, "Delete Empty Folders")
        Me.cmdTorrents_DeleteEmptyFolders.UseVisualStyleBackColor = True
        '
        'chkPDFEditing_OnFolderChange_AutoLoadPage0s
        '
        Me.chkPDFEditing_OnFolderChange_AutoLoadPage0s.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkPDFEditing_OnFolderChange_AutoLoadPage0s.Location = New System.Drawing.Point(499, 593)
        Me.chkPDFEditing_OnFolderChange_AutoLoadPage0s.Name = "chkPDFEditing_OnFolderChange_AutoLoadPage0s"
        Me.chkPDFEditing_OnFolderChange_AutoLoadPage0s.Size = New System.Drawing.Size(176, 26)
        Me.chkPDFEditing_OnFolderChange_AutoLoadPage0s.TabIndex = 86
        Me.chkPDFEditing_OnFolderChange_AutoLoadPage0s.Text = "Auto Load 0s on folder chg"
        Me.ToolTip1.SetToolTip(Me.chkPDFEditing_OnFolderChange_AutoLoadPage0s, "Auto Load Page 0s when folder changed")
        Me.chkPDFEditing_OnFolderChange_AutoLoadPage0s.UseVisualStyleBackColor = True
        '
        'cmdPDFEditing_DelBackups
        '
        Me.cmdPDFEditing_DelBackups.Location = New System.Drawing.Point(524, 490)
        Me.cmdPDFEditing_DelBackups.Name = "cmdPDFEditing_DelBackups"
        Me.cmdPDFEditing_DelBackups.Size = New System.Drawing.Size(68, 25)
        Me.cmdPDFEditing_DelBackups.TabIndex = 89
        Me.cmdPDFEditing_DelBackups.Text = "Del Bkups"
        Me.ToolTip1.SetToolTip(Me.cmdPDFEditing_DelBackups, "Del. Backups")
        Me.cmdPDFEditing_DelBackups.UseVisualStyleBackColor = True
        '
        'cmdTorrents_RemoveBrackets
        '
        Me.cmdTorrents_RemoveBrackets.Location = New System.Drawing.Point(618, 578)
        Me.cmdTorrents_RemoveBrackets.Name = "cmdTorrents_RemoveBrackets"
        Me.cmdTorrents_RemoveBrackets.Size = New System.Drawing.Size(95, 25)
        Me.cmdTorrents_RemoveBrackets.TabIndex = 99
        Me.cmdTorrents_RemoveBrackets.Text = "Rem. Brackets"
        Me.ToolTip1.SetToolTip(Me.cmdTorrents_RemoveBrackets, "Remove Brackets")
        Me.cmdTorrents_RemoveBrackets.UseVisualStyleBackColor = True
        '
        'mnuListviewRightClick
        '
        Me.mnuListviewRightClick.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuOpenFile, Me.mnuSwapNamesAndDelete1, Me.mnuSwapNamesAndDelete2, Me.mnuOpenPath, Me.mnuDeleteFiles, Me.mnuRemoveHiddenFlag})
        Me.mnuListviewRightClick.Name = "mnuRightClick"
        Me.mnuListviewRightClick.Size = New System.Drawing.Size(210, 136)
        '
        'mnuOpenFile
        '
        Me.mnuOpenFile.Name = "mnuOpenFile"
        Me.mnuOpenFile.Size = New System.Drawing.Size(209, 22)
        Me.mnuOpenFile.Text = "Open File(s)"
        '
        'mnuSwapNamesAndDelete1
        '
        Me.mnuSwapNamesAndDelete1.Name = "mnuSwapNamesAndDelete1"
        Me.mnuSwapNamesAndDelete1.Size = New System.Drawing.Size(209, 22)
        Me.mnuSwapNamesAndDelete1.Text = "Swap names and delete - "
        Me.mnuSwapNamesAndDelete1.Visible = False
        '
        'mnuSwapNamesAndDelete2
        '
        Me.mnuSwapNamesAndDelete2.Name = "mnuSwapNamesAndDelete2"
        Me.mnuSwapNamesAndDelete2.Size = New System.Drawing.Size(209, 22)
        Me.mnuSwapNamesAndDelete2.Text = "Swap names and delete - "
        Me.mnuSwapNamesAndDelete2.Visible = False
        '
        'mnuOpenPath
        '
        Me.mnuOpenPath.Name = "mnuOpenPath"
        Me.mnuOpenPath.Size = New System.Drawing.Size(209, 22)
        Me.mnuOpenPath.Text = "Open Path"
        '
        'mnuDeleteFiles
        '
        Me.mnuDeleteFiles.AutoSize = False
        Me.mnuDeleteFiles.Name = "mnuDeleteFiles"
        Me.mnuDeleteFiles.Size = New System.Drawing.Size(200, 22)
        Me.mnuDeleteFiles.Text = "Delete File"
        '
        'mnuRemoveHiddenFlag
        '
        Me.mnuRemoveHiddenFlag.Name = "mnuRemoveHiddenFlag"
        Me.mnuRemoveHiddenFlag.Size = New System.Drawing.Size(209, 22)
        Me.mnuRemoveHiddenFlag.Text = "Remove Hidden Flag"
        '
        'proProgress
        '
        Me.proProgress.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.proProgress.Location = New System.Drawing.Point(813, 629)
        Me.proProgress.Name = "proProgress"
        Me.proProgress.Size = New System.Drawing.Size(479, 16)
        Me.proProgress.TabIndex = 54
        Me.proProgress.Visible = False
        '
        'tabBook
        '
        Me.tabBook.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tabBook.Controls.Add(Me.TabPage1)
        Me.tabBook.Controls.Add(Me.TabPage2)
        Me.tabBook.Controls.Add(Me.TabPage3)
        Me.tabBook.Controls.Add(Me.TabPage4)
        Me.tabBook.Controls.Add(Me.TabPage5)
        Me.tabBook.Controls.Add(Me.TabPage6)
        Me.tabBook.Controls.Add(Me.TabPage7)
        Me.tabBook.Controls.Add(Me.TabPage8)
        Me.tabBook.Location = New System.Drawing.Point(3, 10)
        Me.tabBook.Name = "tabBook"
        Me.tabBook.SelectedIndex = 0
        Me.tabBook.Size = New System.Drawing.Size(1454, 701)
        Me.tabBook.TabIndex = 55
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.fraBookManagement)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1446, 675)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Book Management"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'fraBookManagement
        '
        Me.fraBookManagement.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.fraBookManagement.Controls.Add(Me.txtFilterByText)
        Me.fraBookManagement.Controls.Add(Me.Label9)
        Me.fraBookManagement.Controls.Add(Me.chkAllFileTypes)
        Me.fraBookManagement.Controls.Add(Me.cmdFiles_NextSelection)
        Me.fraBookManagement.Controls.Add(Me.cmdFiles_PreviousSelection)
        Me.fraBookManagement.Controls.Add(Me.cmdLoadCBooksIntoListview)
        Me.fraBookManagement.Controls.Add(Me.cmdDupsByBinaryPatternMatching)
        Me.fraBookManagement.Controls.Add(Me.Label4)
        Me.fraBookManagement.Controls.Add(Me.proProgress)
        Me.fraBookManagement.Controls.Add(Me.cmdDupsByRev)
        Me.fraBookManagement.Controls.Add(Me.updwnMatchPercent)
        Me.fraBookManagement.Controls.Add(Me.cmdCopyStructureBooks)
        Me.fraBookManagement.Controls.Add(Me.Label5)
        Me.fraBookManagement.Controls.Add(Me.cmdDupsByName)
        Me.fraBookManagement.Controls.Add(Me.chkShowInternalName)
        Me.fraBookManagement.Controls.Add(Me.updwnBytes)
        Me.fraBookManagement.Controls.Add(Me.updwnLevenshteinDistance)
        Me.fraBookManagement.Controls.Add(Me.chkShowOnlySelected)
        Me.fraBookManagement.Controls.Add(Me.cboUniqueTypes)
        Me.fraBookManagement.Controls.Add(Me.lblTypeFilter)
        Me.fraBookManagement.Controls.Add(Me.Label3)
        Me.fraBookManagement.Controls.Add(Me.cmdDupsBySize)
        Me.fraBookManagement.Controls.Add(Me.Label2)
        Me.fraBookManagement.Controls.Add(Me.cmdDupsByLevenshteinDistance)
        Me.fraBookManagement.Controls.Add(Me.cmdLoadRecursive)
        Me.fraBookManagement.Controls.Add(Me.cmdLoad)
        Me.fraBookManagement.Controls.Add(Me.lvwFiles)
        Me.fraBookManagement.Controls.Add(Me.cmdPath)
        Me.fraBookManagement.Controls.Add(Me.txtPath)
        Me.fraBookManagement.Controls.Add(Me.Label1)
        Me.fraBookManagement.Controls.Add(Me.AccBookBottom)
        Me.fraBookManagement.Controls.Add(Me.accBookTop)
        Me.fraBookManagement.Location = New System.Drawing.Point(10, 10)
        Me.fraBookManagement.Name = "fraBookManagement"
        Me.fraBookManagement.Size = New System.Drawing.Size(1430, 659)
        Me.fraBookManagement.TabIndex = 18
        Me.fraBookManagement.TabStop = False
        Me.fraBookManagement.Text = "Book Management"
        '
        'txtFilterByText
        '
        Me.txtFilterByText.AccessibleName = "1"
        Me.txtFilterByText.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtFilterByText.Location = New System.Drawing.Point(1320, 10)
        Me.txtFilterByText.Name = "txtFilterByText"
        Me.txtFilterByText.Size = New System.Drawing.Size(104, 20)
        Me.txtFilterByText.TabIndex = 69
        Me.txtFilterByText.TabStop = False
        '
        'Label9
        '
        Me.Label9.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(1228, 13)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(67, 13)
        Me.Label9.TabIndex = 65
        Me.Label9.Text = "Filter by Text"
        '
        'cmdFiles_NextSelection
        '
        Me.cmdFiles_NextSelection.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdFiles_NextSelection.Location = New System.Drawing.Point(1158, 600)
        Me.cmdFiles_NextSelection.Name = "cmdFiles_NextSelection"
        Me.cmdFiles_NextSelection.Size = New System.Drawing.Size(29, 19)
        Me.cmdFiles_NextSelection.TabIndex = 63
        Me.cmdFiles_NextSelection.TabStop = False
        Me.cmdFiles_NextSelection.Text = ">>"
        Me.cmdFiles_NextSelection.UseVisualStyleBackColor = True
        '
        'cmdFiles_PreviousSelection
        '
        Me.cmdFiles_PreviousSelection.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdFiles_PreviousSelection.Location = New System.Drawing.Point(1123, 600)
        Me.cmdFiles_PreviousSelection.Name = "cmdFiles_PreviousSelection"
        Me.cmdFiles_PreviousSelection.Size = New System.Drawing.Size(29, 19)
        Me.cmdFiles_PreviousSelection.TabIndex = 62
        Me.cmdFiles_PreviousSelection.TabStop = False
        Me.cmdFiles_PreviousSelection.Text = "<<"
        Me.cmdFiles_PreviousSelection.UseVisualStyleBackColor = True
        '
        'updwnMatchPercent
        '
        Me.updwnMatchPercent.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.updwnMatchPercent.Increment = New Decimal(New Integer() {5, 0, 0, 0})
        Me.updwnMatchPercent.Location = New System.Drawing.Point(643, 601)
        Me.updwnMatchPercent.Name = "updwnMatchPercent"
        Me.updwnMatchPercent.Size = New System.Drawing.Size(40, 20)
        Me.updwnMatchPercent.TabIndex = 50
        Me.updwnMatchPercent.Value = New Decimal(New Integer() {80, 0, 0, 0})
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(496, 603)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(141, 13)
        Me.Label5.TabIndex = 49
        Me.Label5.Text = "Sort by name first! - % Match"
        '
        'chkShowInternalName
        '
        Me.chkShowInternalName.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkShowInternalName.AutoSize = True
        Me.chkShowInternalName.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkShowInternalName.Location = New System.Drawing.Point(1298, 613)
        Me.chkShowInternalName.Name = "chkShowInternalName"
        Me.chkShowInternalName.Size = New System.Drawing.Size(122, 17)
        Me.chkShowInternalName.TabIndex = 47
        Me.chkShowInternalName.Text = "Show Internal Name"
        Me.chkShowInternalName.UseVisualStyleBackColor = True
        '
        'updwnBytes
        '
        Me.updwnBytes.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.updwnBytes.Increment = New Decimal(New Integer() {50, 0, 0, 0})
        Me.updwnBytes.Location = New System.Drawing.Point(316, 632)
        Me.updwnBytes.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.updwnBytes.Name = "updwnBytes"
        Me.updwnBytes.Size = New System.Drawing.Size(56, 20)
        Me.updwnBytes.TabIndex = 45
        Me.updwnBytes.Value = New Decimal(New Integer() {1000, 0, 0, 0})
        '
        'updwnLevenshteinDistance
        '
        Me.updwnLevenshteinDistance.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.updwnLevenshteinDistance.Location = New System.Drawing.Point(316, 601)
        Me.updwnLevenshteinDistance.Name = "updwnLevenshteinDistance"
        Me.updwnLevenshteinDistance.Size = New System.Drawing.Size(40, 20)
        Me.updwnLevenshteinDistance.TabIndex = 43
        Me.updwnLevenshteinDistance.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'chkShowOnlySelected
        '
        Me.chkShowOnlySelected.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkShowOnlySelected.AutoSize = True
        Me.chkShowOnlySelected.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkShowOnlySelected.Location = New System.Drawing.Point(1298, 597)
        Me.chkShowOnlySelected.Name = "chkShowOnlySelected"
        Me.chkShowOnlySelected.Size = New System.Drawing.Size(122, 17)
        Me.chkShowOnlySelected.TabIndex = 42
        Me.chkShowOnlySelected.Text = "Show Only Selected"
        Me.chkShowOnlySelected.UseVisualStyleBackColor = True
        '
        'cboUniqueTypes
        '
        Me.cboUniqueTypes.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cboUniqueTypes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboUniqueTypes.FormattingEnabled = True
        Me.cboUniqueTypes.Location = New System.Drawing.Point(1320, 28)
        Me.cboUniqueTypes.Name = "cboUniqueTypes"
        Me.cboUniqueTypes.Size = New System.Drawing.Size(104, 21)
        Me.cboUniqueTypes.TabIndex = 41
        '
        'lblTypeFilter
        '
        Me.lblTypeFilter.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblTypeFilter.AutoSize = True
        Me.lblTypeFilter.Location = New System.Drawing.Point(1228, 31)
        Me.lblTypeFilter.Name = "lblTypeFilter"
        Me.lblTypeFilter.Size = New System.Drawing.Size(86, 13)
        Me.lblTypeFilter.TabIndex = 40
        Me.lblTypeFilter.Text = "Filter by FileType"
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(107, 634)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(118, 13)
        Me.Label3.TabIndex = 39
        Me.Label3.Text = "Sort by size first! - Bytes"
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(107, 603)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(203, 13)
        Me.Label2.TabIndex = 37
        Me.Label2.Text = "Sort by name first! - Levenshtein Distance"
        '
        'cmdLoadRecursive
        '
        Me.cmdLoadRecursive.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdLoadRecursive.Location = New System.Drawing.Point(1119, 26)
        Me.cmdLoadRecursive.Name = "cmdLoadRecursive"
        Me.cmdLoadRecursive.Size = New System.Drawing.Size(101, 23)
        Me.cmdLoadRecursive.TabIndex = 35
        Me.cmdLoadRecursive.TabStop = False
        Me.cmdLoadRecursive.Text = "Load Recursive"
        Me.cmdLoadRecursive.UseVisualStyleBackColor = True
        '
        'cmdLoad
        '
        Me.cmdLoad.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdLoad.Location = New System.Drawing.Point(1063, 26)
        Me.cmdLoad.Name = "cmdLoad"
        Me.cmdLoad.Size = New System.Drawing.Size(50, 23)
        Me.cmdLoad.TabIndex = 34
        Me.cmdLoad.TabStop = False
        Me.cmdLoad.Text = "Load"
        Me.cmdLoad.UseVisualStyleBackColor = True
        '
        'lvwFiles
        '
        Me.lvwFiles.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lvwFiles.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colNameOnDisk, Me.colSize, Me.ColumnHeader15, Me.colFolder, Me.colInternalName})
        Me.lvwFiles.FullRowSelect = True
        Me.lvwFiles.GridLines = True
        Me.lvwFiles.HideSelection = False
        Me.lvwFiles.Location = New System.Drawing.Point(6, 53)
        Me.lvwFiles.Name = "lvwFiles"
        Me.lvwFiles.Size = New System.Drawing.Size(1418, 533)
        Me.lvwFiles.TabIndex = 33
        Me.lvwFiles.UseCompatibleStateImageBehavior = False
        Me.lvwFiles.View = System.Windows.Forms.View.Details
        '
        'colNameOnDisk
        '
        Me.colNameOnDisk.Text = "Name"
        Me.colNameOnDisk.Width = 500
        '
        'colSize
        '
        Me.colSize.Text = "Size (in MB)"
        Me.colSize.Width = 125
        '
        'ColumnHeader15
        '
        Me.ColumnHeader15.Text = "Extact Size"
        Me.ColumnHeader15.Width = 125
        '
        'colFolder
        '
        Me.colFolder.Text = "Folder"
        Me.colFolder.Width = 500
        '
        'colInternalName
        '
        Me.colInternalName.Text = "Internal Name"
        Me.colInternalName.Width = 0
        '
        'cmdPath
        '
        Me.cmdPath.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdPath.Location = New System.Drawing.Point(1028, 30)
        Me.cmdPath.Name = "cmdPath"
        Me.cmdPath.Size = New System.Drawing.Size(29, 19)
        Me.cmdPath.TabIndex = 32
        Me.cmdPath.TabStop = False
        Me.cmdPath.Text = "..."
        Me.cmdPath.UseVisualStyleBackColor = True
        '
        'txtPath
        '
        Me.txtPath.AccessibleName = "1"
        Me.txtPath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPath.Location = New System.Drawing.Point(41, 27)
        Me.txtPath.Name = "txtPath"
        Me.txtPath.Size = New System.Drawing.Size(981, 20)
        Me.txtPath.TabIndex = 31
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 13)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "Path"
        '
        'AccBookBottom
        '
        Me.AccBookBottom.Enabled = True
        Me.AccBookBottom.Location = New System.Drawing.Point(1176, 256)
        Me.AccBookBottom.Name = "AccBookBottom"
        Me.AccBookBottom.OcxState = CType(resources.GetObject("AccBookBottom.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AccBookBottom.Size = New System.Drawing.Size(244, 330)
        Me.AccBookBottom.TabIndex = 71
        Me.AccBookBottom.Visible = False
        '
        'accBookTop
        '
        Me.accBookTop.Enabled = True
        Me.accBookTop.Location = New System.Drawing.Point(1176, 55)
        Me.accBookTop.Name = "accBookTop"
        Me.accBookTop.OcxState = CType(resources.GetObject("accBookTop.OcxState"), System.Windows.Forms.AxHost.State)
        Me.accBookTop.Size = New System.Drawing.Size(244, 330)
        Me.accBookTop.TabIndex = 70
        Me.accBookTop.Visible = False
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.fraMoveMags)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1446, 675)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Magazine Copier"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'fraMoveMags
        '
        Me.fraMoveMags.Controls.Add(Me.cmdTorrents_LoadBothPage0s)
        Me.fraMoveMags.Controls.Add(Me.cmdTorrents_RemoveBrackets)
        Me.fraMoveMags.Controls.Add(Me.cmdTorrents_MagCleanup)
        Me.fraMoveMags.Controls.Add(Me.cmdBooks_IndividualEdit)
        Me.fraMoveMags.Controls.Add(Me.cmdTorrents_IndividualEdit)
        Me.fraMoveMags.Controls.Add(Me.txtMagCopier_TorrentFilename)
        Me.fraMoveMags.Controls.Add(Me.cmdTorrents_DeleteEmptyFolders)
        Me.fraMoveMags.Controls.Add(Me.cmdTorrents_TransferFilename)
        Me.fraMoveMags.Controls.Add(Me.cmdBooks_TransferFilename)
        Me.fraMoveMags.Controls.Add(Me.lvwMagCopier_PossibleDups)
        Me.fraMoveMags.Controls.Add(Me.cmdBooks_GSCompress)
        Me.fraMoveMags.Controls.Add(Me.cmdTorrents_GSCompress)
        Me.fraMoveMags.Controls.Add(Me.cmdBooksForward)
        Me.fraMoveMags.Controls.Add(Me.cmdBooksBack)
        Me.fraMoveMags.Controls.Add(Me.cmdBooks_DeleteMag)
        Me.fraMoveMags.Controls.Add(Me.cmdTorrents_DeleteMag)
        Me.fraMoveMags.Controls.Add(Me.cmdTorrents_MoveMags)
        Me.fraMoveMags.Controls.Add(Me.chkBooks_AutoLoadPage0)
        Me.fraMoveMags.Controls.Add(Me.chkTorrents_AutoLoadPage0)
        Me.fraMoveMags.Controls.Add(Me.txtMagCopier_BooksFilename)
        Me.fraMoveMags.Controls.Add(Me.cmdBooks_LoadPDFPage0)
        Me.fraMoveMags.Controls.Add(Me.cmdTorrents_LoadPDFPage0)
        Me.fraMoveMags.Controls.Add(Me.cmdBooks_LoadPDF)
        Me.fraMoveMags.Controls.Add(Me.cmdTorrents_LoadPDF)
        Me.fraMoveMags.Controls.Add(Me.txtBooksPath_MagCopier)
        Me.fraMoveMags.Controls.Add(Me.cmdTorrentsForward)
        Me.fraMoveMags.Controls.Add(Me.cmdTorrentsBack)
        Me.fraMoveMags.Controls.Add(Me.cmdMags)
        Me.fraMoveMags.Controls.Add(Me.cmdKeep)
        Me.fraMoveMags.Controls.Add(Me.cmdBooks_RemovePageZero)
        Me.fraMoveMags.Controls.Add(Me.cmdTorrents_RemovePageZero)
        Me.fraMoveMags.Controls.Add(Me.accBooksPDF)
        Me.fraMoveMags.Controls.Add(Me.lvwBooksMags)
        Me.fraMoveMags.Controls.Add(Me.lvwTorrentMags)
        Me.fraMoveMags.Controls.Add(Me.cmdLoad_MagCopier)
        Me.fraMoveMags.Controls.Add(Me.cmdPath_MagCopier)
        Me.fraMoveMags.Controls.Add(Me.txtPath_MagCopier)
        Me.fraMoveMags.Controls.Add(Me.accTorrentPDF)
        Me.fraMoveMags.Location = New System.Drawing.Point(10, 10)
        Me.fraMoveMags.Name = "fraMoveMags"
        Me.fraMoveMags.Size = New System.Drawing.Size(1430, 659)
        Me.fraMoveMags.TabIndex = 0
        Me.fraMoveMags.TabStop = False
        Me.fraMoveMags.Text = "Magazine Copier"
        '
        'cmdTorrents_MagCleanup
        '
        Me.cmdTorrents_MagCleanup.Location = New System.Drawing.Point(618, 547)
        Me.cmdTorrents_MagCleanup.Name = "cmdTorrents_MagCleanup"
        Me.cmdTorrents_MagCleanup.Size = New System.Drawing.Size(95, 25)
        Me.cmdTorrents_MagCleanup.TabIndex = 98
        Me.cmdTorrents_MagCleanup.Text = "Mag. Cleanup"
        Me.cmdTorrents_MagCleanup.UseVisualStyleBackColor = True
        '
        'cmdBooks_IndividualEdit
        '
        Me.cmdBooks_IndividualEdit.Location = New System.Drawing.Point(1313, 302)
        Me.cmdBooks_IndividualEdit.Name = "cmdBooks_IndividualEdit"
        Me.cmdBooks_IndividualEdit.Size = New System.Drawing.Size(50, 19)
        Me.cmdBooks_IndividualEdit.TabIndex = 97
        Me.cmdBooks_IndividualEdit.TabStop = False
        Me.cmdBooks_IndividualEdit.Text = "Save"
        Me.cmdBooks_IndividualEdit.UseVisualStyleBackColor = True
        '
        'cmdTorrents_IndividualEdit
        '
        Me.cmdTorrents_IndividualEdit.Location = New System.Drawing.Point(599, 299)
        Me.cmdTorrents_IndividualEdit.Name = "cmdTorrents_IndividualEdit"
        Me.cmdTorrents_IndividualEdit.Size = New System.Drawing.Size(50, 19)
        Me.cmdTorrents_IndividualEdit.TabIndex = 96
        Me.cmdTorrents_IndividualEdit.TabStop = False
        Me.cmdTorrents_IndividualEdit.Text = "Save"
        Me.cmdTorrents_IndividualEdit.UseVisualStyleBackColor = True
        '
        'txtMagCopier_TorrentFilename
        '
        Me.txtMagCopier_TorrentFilename.AccessibleName = "1"
        Me.txtMagCopier_TorrentFilename.Location = New System.Drawing.Point(409, 299)
        Me.txtMagCopier_TorrentFilename.Name = "txtMagCopier_TorrentFilename"
        Me.txtMagCopier_TorrentFilename.Size = New System.Drawing.Size(203, 20)
        Me.txtMagCopier_TorrentFilename.TabIndex = 67
        Me.txtMagCopier_TorrentFilename.TabStop = False
        '
        'lvwMagCopier_PossibleDups
        '
        Me.lvwMagCopier_PossibleDups.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader10, Me.ColumnHeader11, Me.ColumnHeader12})
        Me.lvwMagCopier_PossibleDups.FullRowSelect = True
        Me.lvwMagCopier_PossibleDups.GridLines = True
        Me.lvwMagCopier_PossibleDups.HideSelection = False
        Me.lvwMagCopier_PossibleDups.Location = New System.Drawing.Point(409, 363)
        Me.lvwMagCopier_PossibleDups.MultiSelect = False
        Me.lvwMagCopier_PossibleDups.Name = "lvwMagCopier_PossibleDups"
        Me.lvwMagCopier_PossibleDups.Size = New System.Drawing.Size(203, 220)
        Me.lvwMagCopier_PossibleDups.TabIndex = 92
        Me.lvwMagCopier_PossibleDups.UseCompatibleStateImageBehavior = False
        Me.lvwMagCopier_PossibleDups.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader10
        '
        Me.ColumnHeader10.Text = "Possible Dups"
        Me.ColumnHeader10.Width = 400
        '
        'ColumnHeader11
        '
        Me.ColumnHeader11.Text = "Torrents"
        Me.ColumnHeader11.Width = 0
        '
        'ColumnHeader12
        '
        Me.ColumnHeader12.Text = "Books"
        Me.ColumnHeader12.Width = 0
        '
        'cmdBooks_GSCompress
        '
        Me.cmdBooks_GSCompress.Location = New System.Drawing.Point(1322, 437)
        Me.cmdBooks_GSCompress.Name = "cmdBooks_GSCompress"
        Me.cmdBooks_GSCompress.Size = New System.Drawing.Size(95, 25)
        Me.cmdBooks_GSCompress.TabIndex = 91
        Me.cmdBooks_GSCompress.Text = "GS Compress"
        Me.cmdBooks_GSCompress.UseVisualStyleBackColor = True
        '
        'cmdTorrents_GSCompress
        '
        Me.cmdTorrents_GSCompress.Location = New System.Drawing.Point(618, 485)
        Me.cmdTorrents_GSCompress.Name = "cmdTorrents_GSCompress"
        Me.cmdTorrents_GSCompress.Size = New System.Drawing.Size(95, 25)
        Me.cmdTorrents_GSCompress.TabIndex = 90
        Me.cmdTorrents_GSCompress.Text = "GS Compress"
        Me.cmdTorrents_GSCompress.UseVisualStyleBackColor = True
        '
        'cmdBooksForward
        '
        Me.cmdBooksForward.Location = New System.Drawing.Point(1388, 25)
        Me.cmdBooksForward.Name = "cmdBooksForward"
        Me.cmdBooksForward.Size = New System.Drawing.Size(29, 19)
        Me.cmdBooksForward.TabIndex = 89
        Me.cmdBooksForward.TabStop = False
        Me.cmdBooksForward.Text = ">>"
        Me.cmdBooksForward.UseVisualStyleBackColor = True
        '
        'cmdBooksBack
        '
        Me.cmdBooksBack.Location = New System.Drawing.Point(1353, 25)
        Me.cmdBooksBack.Name = "cmdBooksBack"
        Me.cmdBooksBack.Size = New System.Drawing.Size(29, 19)
        Me.cmdBooksBack.TabIndex = 88
        Me.cmdBooksBack.TabStop = False
        Me.cmdBooksBack.Text = "<<"
        Me.cmdBooksBack.UseVisualStyleBackColor = True
        '
        'txtMagCopier_BooksFilename
        '
        Me.txtMagCopier_BooksFilename.AccessibleName = "1"
        Me.txtMagCopier_BooksFilename.Location = New System.Drawing.Point(1119, 302)
        Me.txtMagCopier_BooksFilename.Name = "txtMagCopier_BooksFilename"
        Me.txtMagCopier_BooksFilename.Size = New System.Drawing.Size(203, 20)
        Me.txtMagCopier_BooksFilename.TabIndex = 68
        Me.txtMagCopier_BooksFilename.TabStop = False
        '
        'txtBooksPath_MagCopier
        '
        Me.txtBooksPath_MagCopier.AccessibleName = "1"
        Me.txtBooksPath_MagCopier.Enabled = False
        Me.txtBooksPath_MagCopier.Location = New System.Drawing.Point(716, 26)
        Me.txtBooksPath_MagCopier.Name = "txtBooksPath_MagCopier"
        Me.txtBooksPath_MagCopier.Size = New System.Drawing.Size(521, 20)
        Me.txtBooksPath_MagCopier.TabIndex = 62
        '
        'cmdTorrentsForward
        '
        Me.cmdTorrentsForward.Location = New System.Drawing.Point(681, 27)
        Me.cmdTorrentsForward.Name = "cmdTorrentsForward"
        Me.cmdTorrentsForward.Size = New System.Drawing.Size(29, 19)
        Me.cmdTorrentsForward.TabIndex = 61
        Me.cmdTorrentsForward.TabStop = False
        Me.cmdTorrentsForward.Text = ">>"
        Me.cmdTorrentsForward.UseVisualStyleBackColor = True
        '
        'cmdTorrentsBack
        '
        Me.cmdTorrentsBack.Location = New System.Drawing.Point(646, 27)
        Me.cmdTorrentsBack.Name = "cmdTorrentsBack"
        Me.cmdTorrentsBack.Size = New System.Drawing.Size(29, 19)
        Me.cmdTorrentsBack.TabIndex = 60
        Me.cmdTorrentsBack.TabStop = False
        Me.cmdTorrentsBack.Text = "<<"
        Me.cmdTorrentsBack.UseVisualStyleBackColor = True
        '
        'cmdBooks_RemovePageZero
        '
        Me.cmdBooks_RemovePageZero.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.cmdBooks_RemovePageZero.Location = New System.Drawing.Point(1322, 361)
        Me.cmdBooks_RemovePageZero.Name = "cmdBooks_RemovePageZero"
        Me.cmdBooks_RemovePageZero.Size = New System.Drawing.Size(95, 25)
        Me.cmdBooks_RemovePageZero.TabIndex = 55
        Me.cmdBooks_RemovePageZero.Text = "Remove Page 0"
        Me.cmdBooks_RemovePageZero.UseVisualStyleBackColor = True
        '
        'cmdTorrents_RemovePageZero
        '
        Me.cmdTorrents_RemovePageZero.Location = New System.Drawing.Point(618, 392)
        Me.cmdTorrents_RemovePageZero.Name = "cmdTorrents_RemovePageZero"
        Me.cmdTorrents_RemovePageZero.Size = New System.Drawing.Size(95, 25)
        Me.cmdTorrents_RemovePageZero.TabIndex = 54
        Me.cmdTorrents_RemovePageZero.Text = "Remove Page 0"
        Me.cmdTorrents_RemovePageZero.UseVisualStyleBackColor = True
        '
        'accBooksPDF
        '
        Me.accBooksPDF.Enabled = True
        Me.accBooksPDF.Location = New System.Drawing.Point(719, 299)
        Me.accBooksPDF.Name = "accBooksPDF"
        Me.accBooksPDF.OcxState = CType(resources.GetObject("accBooksPDF.OcxState"), System.Windows.Forms.AxHost.State)
        Me.accBooksPDF.Size = New System.Drawing.Size(394, 354)
        Me.accBooksPDF.TabIndex = 49
        '
        'lvwBooksMags
        '
        Me.lvwBooksMags.CheckBoxes = True
        Me.lvwBooksMags.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader3, Me.ColumnHeader4, Me.ColumnHeader6})
        Me.lvwBooksMags.FullRowSelect = True
        Me.lvwBooksMags.GridLines = True
        Me.lvwBooksMags.HideSelection = False
        Me.lvwBooksMags.Location = New System.Drawing.Point(716, 53)
        Me.lvwBooksMags.MultiSelect = False
        Me.lvwBooksMags.Name = "lvwBooksMags"
        Me.lvwBooksMags.Size = New System.Drawing.Size(701, 240)
        Me.lvwBooksMags.TabIndex = 48
        Me.lvwBooksMags.UseCompatibleStateImageBehavior = False
        Me.lvwBooksMags.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Name"
        Me.ColumnHeader3.Width = 500
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Size (in MB)"
        Me.ColumnHeader4.Width = 90
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "Extact Size"
        Me.ColumnHeader6.Width = 90
        '
        'lvwTorrentMags
        '
        Me.lvwTorrentMags.CheckBoxes = True
        Me.lvwTorrentMags.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader5})
        Me.lvwTorrentMags.FullRowSelect = True
        Me.lvwTorrentMags.GridLines = True
        Me.lvwTorrentMags.HideSelection = False
        Me.lvwTorrentMags.Location = New System.Drawing.Point(9, 53)
        Me.lvwTorrentMags.MultiSelect = False
        Me.lvwTorrentMags.Name = "lvwTorrentMags"
        Me.lvwTorrentMags.Size = New System.Drawing.Size(701, 240)
        Me.lvwTorrentMags.TabIndex = 47
        Me.lvwTorrentMags.UseCompatibleStateImageBehavior = False
        Me.lvwTorrentMags.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Name"
        Me.ColumnHeader1.Width = 500
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Size (in MB)"
        Me.ColumnHeader2.Width = 90
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "Extact Size"
        Me.ColumnHeader5.Width = 90
        '
        'cmdLoad_MagCopier
        '
        Me.cmdLoad_MagCopier.Location = New System.Drawing.Point(590, 27)
        Me.cmdLoad_MagCopier.Name = "cmdLoad_MagCopier"
        Me.cmdLoad_MagCopier.Size = New System.Drawing.Size(50, 19)
        Me.cmdLoad_MagCopier.TabIndex = 45
        Me.cmdLoad_MagCopier.TabStop = False
        Me.cmdLoad_MagCopier.Text = "Load"
        Me.cmdLoad_MagCopier.UseVisualStyleBackColor = True
        '
        'cmdPath_MagCopier
        '
        Me.cmdPath_MagCopier.Location = New System.Drawing.Point(555, 27)
        Me.cmdPath_MagCopier.Name = "cmdPath_MagCopier"
        Me.cmdPath_MagCopier.Size = New System.Drawing.Size(29, 19)
        Me.cmdPath_MagCopier.TabIndex = 44
        Me.cmdPath_MagCopier.TabStop = False
        Me.cmdPath_MagCopier.Text = "..."
        Me.cmdPath_MagCopier.UseVisualStyleBackColor = True
        '
        'txtPath_MagCopier
        '
        Me.txtPath_MagCopier.AccessibleName = "1"
        Me.txtPath_MagCopier.Location = New System.Drawing.Point(9, 27)
        Me.txtPath_MagCopier.Name = "txtPath_MagCopier"
        Me.txtPath_MagCopier.Size = New System.Drawing.Size(540, 20)
        Me.txtPath_MagCopier.TabIndex = 43
        '
        'accTorrentPDF
        '
        Me.accTorrentPDF.Enabled = True
        Me.accTorrentPDF.Location = New System.Drawing.Point(9, 299)
        Me.accTorrentPDF.Name = "accTorrentPDF"
        Me.accTorrentPDF.OcxState = CType(resources.GetObject("accTorrentPDF.OcxState"), System.Windows.Forms.AxHost.State)
        Me.accTorrentPDF.Size = New System.Drawing.Size(394, 354)
        Me.accTorrentPDF.TabIndex = 0
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.fraPDFEditing)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1446, 675)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "PDF Editing"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'fraPDFEditing
        '
        Me.fraPDFEditing.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.fraPDFEditing.Controls.Add(Me.cmdPDFEditing_DelBackups)
        Me.fraPDFEditing.Controls.Add(Me.cmdPDFEditing_RemoveFoldersPageZeros)
        Me.fraPDFEditing.Controls.Add(Me.chkPDFEditing_OnFolderChange_AutoLoadPage0s)
        Me.fraPDFEditing.Controls.Add(Me.cmdPDFEditing_MovePageZero)
        Me.fraPDFEditing.Controls.Add(Me.chkPDFEditing_AutoLoadPage0)
        Me.fraPDFEditing.Controls.Add(Me.cmdPDFEditing_Load_All_PageZeros)
        Me.fraPDFEditing.Controls.Add(Me.chkPDFEditing_StopLoad)
        Me.fraPDFEditing.Controls.Add(Me.cmdBooks_PDFEditing)
        Me.fraPDFEditing.Controls.Add(Me.cmdPDFEditing_LoadPDFPage0)
        Me.fraPDFEditing.Controls.Add(Me.cmdPDFEditing_RemovePageZero)
        Me.fraPDFEditing.Controls.Add(Me.cmdPDFEditing_GSCompressFolder)
        Me.fraPDFEditing.Controls.Add(Me.cmdPDFEditing_GSCompress)
        Me.fraPDFEditing.Controls.Add(Me.cmdPDFEditing_Refresh)
        Me.fraPDFEditing.Controls.Add(Me.cmdPDFEditing_Clear)
        Me.fraPDFEditing.Controls.Add(Me.chkPDFEditing_AutoApplyStandard)
        Me.fraPDFEditing.Controls.Add(Me.cmdPDFEditing_LoadFile)
        Me.fraPDFEditing.Controls.Add(Me.cboPDFEditing_StandardTypesDuringLoad)
        Me.fraPDFEditing.Controls.Add(Me.Label6)
        Me.fraPDFEditing.Controls.Add(Me.cmdPDFEditing_Save)
        Me.fraPDFEditing.Controls.Add(Me.cboPDFEditing_Pages)
        Me.fraPDFEditing.Controls.Add(Me.lblPages)
        Me.fraPDFEditing.Controls.Add(Me.cboPDFEditing_StandardTypesAfterLoad)
        Me.fraPDFEditing.Controls.Add(Me.lblPDFEditing_Types)
        Me.fraPDFEditing.Controls.Add(Me.accPDFEditing_Main)
        Me.fraPDFEditing.Controls.Add(Me.panPDFEditing)
        Me.fraPDFEditing.Controls.Add(Me.cmdPDFEditingForward)
        Me.fraPDFEditing.Controls.Add(Me.cmdPDFEditingBack)
        Me.fraPDFEditing.Controls.Add(Me.cmdMags_PDFEditing)
        Me.fraPDFEditing.Controls.Add(Me.cmdKeep_PDFEditing)
        Me.fraPDFEditing.Controls.Add(Me.lvwPDFEditing)
        Me.fraPDFEditing.Controls.Add(Me.cmdLoad_PDFEditing)
        Me.fraPDFEditing.Controls.Add(Me.cmdPath_PDFEditing)
        Me.fraPDFEditing.Controls.Add(Me.txtPath_PDFEditing)
        Me.fraPDFEditing.Controls.Add(Me.chkPDFEditing_SaveMissingPages)
        Me.fraPDFEditing.Controls.Add(Me.lblLoadPage0Filename)
        Me.fraPDFEditing.Location = New System.Drawing.Point(10, 10)
        Me.fraPDFEditing.Name = "fraPDFEditing"
        Me.fraPDFEditing.Size = New System.Drawing.Size(1430, 659)
        Me.fraPDFEditing.TabIndex = 1
        Me.fraPDFEditing.TabStop = False
        Me.fraPDFEditing.Text = "PDF Editing"
        '
        'cmdPDFEditing_RemoveFoldersPageZeros
        '
        Me.cmdPDFEditing_RemoveFoldersPageZeros.Location = New System.Drawing.Point(477, 593)
        Me.cmdPDFEditing_RemoveFoldersPageZeros.Name = "cmdPDFEditing_RemoveFoldersPageZeros"
        Me.cmdPDFEditing_RemoveFoldersPageZeros.Size = New System.Drawing.Size(153, 25)
        Me.cmdPDFEditing_RemoveFoldersPageZeros.TabIndex = 88
        Me.cmdPDFEditing_RemoveFoldersPageZeros.Text = "Remove Page 0 - Folder"
        Me.cmdPDFEditing_RemoveFoldersPageZeros.UseVisualStyleBackColor = True
        '
        'cmdPDFEditing_MovePageZero
        '
        Me.cmdPDFEditing_MovePageZero.Location = New System.Drawing.Point(507, 583)
        Me.cmdPDFEditing_MovePageZero.Name = "cmdPDFEditing_MovePageZero"
        Me.cmdPDFEditing_MovePageZero.Size = New System.Drawing.Size(85, 25)
        Me.cmdPDFEditing_MovePageZero.TabIndex = 85
        Me.cmdPDFEditing_MovePageZero.Text = "Move Page 0"
        Me.cmdPDFEditing_MovePageZero.UseVisualStyleBackColor = True
        '
        'cmdPDFEditing_RemovePageZero
        '
        Me.cmdPDFEditing_RemovePageZero.Location = New System.Drawing.Point(544, 625)
        Me.cmdPDFEditing_RemovePageZero.Name = "cmdPDFEditing_RemovePageZero"
        Me.cmdPDFEditing_RemovePageZero.Size = New System.Drawing.Size(95, 25)
        Me.cmdPDFEditing_RemovePageZero.TabIndex = 78
        Me.cmdPDFEditing_RemovePageZero.Text = "Remove Page 0"
        Me.cmdPDFEditing_RemovePageZero.UseVisualStyleBackColor = True
        '
        'cmdPDFEditing_GSCompress
        '
        Me.cmdPDFEditing_GSCompress.Location = New System.Drawing.Point(444, 508)
        Me.cmdPDFEditing_GSCompress.Name = "cmdPDFEditing_GSCompress"
        Me.cmdPDFEditing_GSCompress.Size = New System.Drawing.Size(95, 25)
        Me.cmdPDFEditing_GSCompress.TabIndex = 76
        Me.cmdPDFEditing_GSCompress.Text = "GS Compress"
        Me.cmdPDFEditing_GSCompress.UseVisualStyleBackColor = True
        '
        'cmdPDFEditing_Refresh
        '
        Me.cmdPDFEditing_Refresh.Location = New System.Drawing.Point(545, 583)
        Me.cmdPDFEditing_Refresh.Name = "cmdPDFEditing_Refresh"
        Me.cmdPDFEditing_Refresh.Size = New System.Drawing.Size(85, 25)
        Me.cmdPDFEditing_Refresh.TabIndex = 75
        Me.cmdPDFEditing_Refresh.Text = "Refresh"
        Me.cmdPDFEditing_Refresh.UseVisualStyleBackColor = True
        '
        'cmdPDFEditing_Clear
        '
        Me.cmdPDFEditing_Clear.Location = New System.Drawing.Point(444, 530)
        Me.cmdPDFEditing_Clear.Name = "cmdPDFEditing_Clear"
        Me.cmdPDFEditing_Clear.Size = New System.Drawing.Size(85, 25)
        Me.cmdPDFEditing_Clear.TabIndex = 74
        Me.cmdPDFEditing_Clear.Text = "Clear"
        Me.cmdPDFEditing_Clear.UseVisualStyleBackColor = True
        '
        'cmdPDFEditing_LoadFile
        '
        Me.cmdPDFEditing_LoadFile.Location = New System.Drawing.Point(545, 521)
        Me.cmdPDFEditing_LoadFile.Name = "cmdPDFEditing_LoadFile"
        Me.cmdPDFEditing_LoadFile.Size = New System.Drawing.Size(85, 25)
        Me.cmdPDFEditing_LoadFile.TabIndex = 72
        Me.cmdPDFEditing_LoadFile.Text = "Load"
        Me.cmdPDFEditing_LoadFile.UseVisualStyleBackColor = True
        '
        'cboPDFEditing_StandardTypesDuringLoad
        '
        Me.cboPDFEditing_StandardTypesDuringLoad.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPDFEditing_StandardTypesDuringLoad.FormattingEnabled = True
        Me.cboPDFEditing_StandardTypesDuringLoad.Location = New System.Drawing.Point(464, 363)
        Me.cboPDFEditing_StandardTypesDuringLoad.Name = "cboPDFEditing_StandardTypesDuringLoad"
        Me.cboPDFEditing_StandardTypesDuringLoad.Size = New System.Drawing.Size(176, 21)
        Me.cboPDFEditing_StandardTypesDuringLoad.TabIndex = 71
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(461, 338)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(178, 13)
        Me.Label6.TabIndex = 70
        Me.Label6.Text = "Apply Standard Types (During Load)"
        '
        'cmdPDFEditing_Save
        '
        Me.cmdPDFEditing_Save.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdPDFEditing_Save.Enabled = False
        Me.cmdPDFEditing_Save.Location = New System.Drawing.Point(550, 552)
        Me.cmdPDFEditing_Save.Name = "cmdPDFEditing_Save"
        Me.cmdPDFEditing_Save.Size = New System.Drawing.Size(85, 25)
        Me.cmdPDFEditing_Save.TabIndex = 69
        Me.cmdPDFEditing_Save.Text = "Save"
        Me.cmdPDFEditing_Save.UseVisualStyleBackColor = True
        '
        'cboPDFEditing_Pages
        '
        Me.cboPDFEditing_Pages.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPDFEditing_Pages.FormattingEnabled = True
        Me.cboPDFEditing_Pages.Location = New System.Drawing.Point(464, 422)
        Me.cboPDFEditing_Pages.Name = "cboPDFEditing_Pages"
        Me.cboPDFEditing_Pages.Size = New System.Drawing.Size(176, 21)
        Me.cboPDFEditing_Pages.TabIndex = 68
        '
        'lblPages
        '
        Me.lblPages.AutoSize = True
        Me.lblPages.Location = New System.Drawing.Point(464, 397)
        Me.lblPages.Name = "lblPages"
        Me.lblPages.Size = New System.Drawing.Size(58, 13)
        Me.lblPages.TabIndex = 67
        Me.lblPages.Text = "View Page"
        '
        'cboPDFEditing_StandardTypesAfterLoad
        '
        Me.cboPDFEditing_StandardTypesAfterLoad.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPDFEditing_StandardTypesAfterLoad.FormattingEnabled = True
        Me.cboPDFEditing_StandardTypesAfterLoad.Location = New System.Drawing.Point(464, 481)
        Me.cboPDFEditing_StandardTypesAfterLoad.Name = "cboPDFEditing_StandardTypesAfterLoad"
        Me.cboPDFEditing_StandardTypesAfterLoad.Size = New System.Drawing.Size(176, 21)
        Me.cboPDFEditing_StandardTypesAfterLoad.TabIndex = 65
        '
        'lblPDFEditing_Types
        '
        Me.lblPDFEditing_Types.AutoSize = True
        Me.lblPDFEditing_Types.Location = New System.Drawing.Point(461, 455)
        Me.lblPDFEditing_Types.Name = "lblPDFEditing_Types"
        Me.lblPDFEditing_Types.Size = New System.Drawing.Size(169, 13)
        Me.lblPDFEditing_Types.TabIndex = 64
        Me.lblPDFEditing_Types.Text = "Apply Standard Types (After Load)"
        '
        'accPDFEditing_Main
        '
        Me.accPDFEditing_Main.Enabled = True
        Me.accPDFEditing_Main.Location = New System.Drawing.Point(9, 299)
        Me.accPDFEditing_Main.Name = "accPDFEditing_Main"
        Me.accPDFEditing_Main.OcxState = CType(resources.GetObject("accPDFEditing_Main.OcxState"), System.Windows.Forms.AxHost.State)
        Me.accPDFEditing_Main.Size = New System.Drawing.Size(449, 354)
        Me.accPDFEditing_Main.TabIndex = 63
        '
        'panPDFEditing
        '
        Me.panPDFEditing.AutoScroll = True
        Me.panPDFEditing.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.panPDFEditing.Controls.Add(Me.txtPDFEDiting_FolderGSCompression)
        Me.panPDFEditing.Location = New System.Drawing.Point(646, 27)
        Me.panPDFEditing.Name = "panPDFEditing"
        Me.panPDFEditing.Size = New System.Drawing.Size(778, 626)
        Me.panPDFEditing.TabIndex = 62
        '
        'txtPDFEDiting_FolderGSCompression
        '
        Me.txtPDFEDiting_FolderGSCompression.AccessibleName = "1"
        Me.txtPDFEDiting_FolderGSCompression.BackColor = System.Drawing.SystemColors.Menu
        Me.txtPDFEDiting_FolderGSCompression.Location = New System.Drawing.Point(21, 12)
        Me.txtPDFEDiting_FolderGSCompression.Multiline = True
        Me.txtPDFEDiting_FolderGSCompression.Name = "txtPDFEDiting_FolderGSCompression"
        Me.txtPDFEDiting_FolderGSCompression.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtPDFEDiting_FolderGSCompression.Size = New System.Drawing.Size(311, 94)
        Me.txtPDFEDiting_FolderGSCompression.TabIndex = 79
        Me.txtPDFEDiting_FolderGSCompression.Text = "PDF EDiting  Folder GSCompression Results"
        Me.txtPDFEDiting_FolderGSCompression.Visible = False
        '
        'cmdPDFEditingForward
        '
        Me.cmdPDFEditingForward.Location = New System.Drawing.Point(483, 27)
        Me.cmdPDFEditingForward.Name = "cmdPDFEditingForward"
        Me.cmdPDFEditingForward.Size = New System.Drawing.Size(15, 20)
        Me.cmdPDFEditingForward.TabIndex = 61
        Me.cmdPDFEditingForward.TabStop = False
        Me.cmdPDFEditingForward.Text = ">"
        Me.cmdPDFEditingForward.UseVisualStyleBackColor = True
        '
        'cmdPDFEditingBack
        '
        Me.cmdPDFEditingBack.Location = New System.Drawing.Point(465, 27)
        Me.cmdPDFEditingBack.Name = "cmdPDFEditingBack"
        Me.cmdPDFEditingBack.Size = New System.Drawing.Size(15, 20)
        Me.cmdPDFEditingBack.TabIndex = 60
        Me.cmdPDFEditingBack.TabStop = False
        Me.cmdPDFEditingBack.Text = "<"
        Me.cmdPDFEditingBack.UseVisualStyleBackColor = True
        '
        'lvwPDFEditing
        '
        Me.lvwPDFEditing.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader7, Me.ColumnHeader8, Me.ColumnHeader9})
        Me.lvwPDFEditing.FullRowSelect = True
        Me.lvwPDFEditing.GridLines = True
        Me.lvwPDFEditing.HideSelection = False
        Me.lvwPDFEditing.Location = New System.Drawing.Point(9, 53)
        Me.lvwPDFEditing.Name = "lvwPDFEditing"
        Me.lvwPDFEditing.Size = New System.Drawing.Size(631, 240)
        Me.lvwPDFEditing.TabIndex = 47
        Me.lvwPDFEditing.UseCompatibleStateImageBehavior = False
        Me.lvwPDFEditing.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader7
        '
        Me.ColumnHeader7.Text = "Name"
        Me.ColumnHeader7.Width = 450
        '
        'ColumnHeader8
        '
        Me.ColumnHeader8.Text = "Size (in MB)"
        Me.ColumnHeader8.Width = 90
        '
        'ColumnHeader9
        '
        Me.ColumnHeader9.Text = "Extact Size"
        Me.ColumnHeader9.Width = 90
        '
        'cmdLoad_PDFEditing
        '
        Me.cmdLoad_PDFEditing.Location = New System.Drawing.Point(417, 27)
        Me.cmdLoad_PDFEditing.Name = "cmdLoad_PDFEditing"
        Me.cmdLoad_PDFEditing.Size = New System.Drawing.Size(45, 20)
        Me.cmdLoad_PDFEditing.TabIndex = 45
        Me.cmdLoad_PDFEditing.TabStop = False
        Me.cmdLoad_PDFEditing.Text = "Load"
        Me.cmdLoad_PDFEditing.UseVisualStyleBackColor = True
        '
        'cmdPath_PDFEditing
        '
        Me.cmdPath_PDFEditing.Location = New System.Drawing.Point(385, 27)
        Me.cmdPath_PDFEditing.Name = "cmdPath_PDFEditing"
        Me.cmdPath_PDFEditing.Size = New System.Drawing.Size(29, 20)
        Me.cmdPath_PDFEditing.TabIndex = 44
        Me.cmdPath_PDFEditing.TabStop = False
        Me.cmdPath_PDFEditing.Text = "..."
        Me.cmdPath_PDFEditing.UseVisualStyleBackColor = True
        '
        'txtPath_PDFEditing
        '
        Me.txtPath_PDFEditing.AccessibleName = "1"
        Me.txtPath_PDFEditing.Location = New System.Drawing.Point(9, 27)
        Me.txtPath_PDFEditing.Name = "txtPath_PDFEditing"
        Me.txtPath_PDFEditing.Size = New System.Drawing.Size(378, 20)
        Me.txtPath_PDFEditing.TabIndex = 43
        Me.txtPath_PDFEditing.Text = "e:\_Torrent\Completed"
        '
        'lblLoadPage0Filename
        '
        Me.lblLoadPage0Filename.AutoSize = True
        Me.lblLoadPage0Filename.Location = New System.Drawing.Point(488, 562)
        Me.lblLoadPage0Filename.Name = "lblLoadPage0Filename"
        Me.lblLoadPage0Filename.Size = New System.Drawing.Size(104, 13)
        Me.lblLoadPage0Filename.TabIndex = 87
        Me.lblLoadPage0Filename.Text = "LoadPage0Filename"
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.cmdAutoBookSort_Move)
        Me.TabPage4.Controls.Add(Me.cmdAutoBookSort_Process)
        Me.TabPage4.Controls.Add(Me.fraAutoBookSort)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(1446, 675)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Auto Book Sort"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'cmdAutoBookSort_Move
        '
        Me.cmdAutoBookSort_Move.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdAutoBookSort_Move.Location = New System.Drawing.Point(1345, 644)
        Me.cmdAutoBookSort_Move.Name = "cmdAutoBookSort_Move"
        Me.cmdAutoBookSort_Move.Size = New System.Drawing.Size(95, 25)
        Me.cmdAutoBookSort_Move.TabIndex = 38
        Me.cmdAutoBookSort_Move.Text = "Move"
        Me.cmdAutoBookSort_Move.UseVisualStyleBackColor = True
        '
        'cmdAutoBookSort_Process
        '
        Me.cmdAutoBookSort_Process.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdAutoBookSort_Process.Location = New System.Drawing.Point(1241, 644)
        Me.cmdAutoBookSort_Process.Name = "cmdAutoBookSort_Process"
        Me.cmdAutoBookSort_Process.Size = New System.Drawing.Size(95, 25)
        Me.cmdAutoBookSort_Process.TabIndex = 37
        Me.cmdAutoBookSort_Process.Text = "Process"
        Me.cmdAutoBookSort_Process.UseVisualStyleBackColor = True
        '
        'fraAutoBookSort
        '
        Me.fraAutoBookSort.Controls.Add(Me.lvwAutoBookSort_Results)
        Me.fraAutoBookSort.Controls.Add(Me.cmdAutoBookSort_TargetPath)
        Me.fraAutoBookSort.Controls.Add(Me.txtAutoBookSort_TargetPath)
        Me.fraAutoBookSort.Controls.Add(Me.Label8)
        Me.fraAutoBookSort.Controls.Add(Me.cmdAutoBookSort_PathToSort)
        Me.fraAutoBookSort.Controls.Add(Me.txtAutoBookSort_PathToSort)
        Me.fraAutoBookSort.Controls.Add(Me.Label7)
        Me.fraAutoBookSort.Location = New System.Drawing.Point(6, 6)
        Me.fraAutoBookSort.Name = "fraAutoBookSort"
        Me.fraAutoBookSort.Size = New System.Drawing.Size(1434, 614)
        Me.fraAutoBookSort.TabIndex = 0
        Me.fraAutoBookSort.TabStop = False
        Me.fraAutoBookSort.Text = "Auto Book Sort"
        '
        'lvwAutoBookSort_Results
        '
        Me.lvwAutoBookSort_Results.CheckBoxes = True
        Me.lvwAutoBookSort_Results.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader13, Me.ColumnHeader14})
        Me.lvwAutoBookSort_Results.FullRowSelect = True
        Me.lvwAutoBookSort_Results.GridLines = True
        Me.lvwAutoBookSort_Results.HideSelection = False
        Me.lvwAutoBookSort_Results.Location = New System.Drawing.Point(9, 74)
        Me.lvwAutoBookSort_Results.Name = "lvwAutoBookSort_Results"
        Me.lvwAutoBookSort_Results.Size = New System.Drawing.Size(1419, 524)
        Me.lvwAutoBookSort_Results.TabIndex = 48
        Me.lvwAutoBookSort_Results.UseCompatibleStateImageBehavior = False
        Me.lvwAutoBookSort_Results.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader13
        '
        Me.ColumnHeader13.Text = "Name"
        Me.ColumnHeader13.Width = 450
        '
        'ColumnHeader14
        '
        Me.ColumnHeader14.Text = "Path"
        Me.ColumnHeader14.Width = 500
        '
        'cmdAutoBookSort_TargetPath
        '
        Me.cmdAutoBookSort_TargetPath.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdAutoBookSort_TargetPath.Location = New System.Drawing.Point(1293, 28)
        Me.cmdAutoBookSort_TargetPath.Name = "cmdAutoBookSort_TargetPath"
        Me.cmdAutoBookSort_TargetPath.Size = New System.Drawing.Size(29, 19)
        Me.cmdAutoBookSort_TargetPath.TabIndex = 38
        Me.cmdAutoBookSort_TargetPath.TabStop = False
        Me.cmdAutoBookSort_TargetPath.Text = "..."
        Me.cmdAutoBookSort_TargetPath.UseVisualStyleBackColor = True
        '
        'txtAutoBookSort_TargetPath
        '
        Me.txtAutoBookSort_TargetPath.AccessibleName = "1"
        Me.txtAutoBookSort_TargetPath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtAutoBookSort_TargetPath.Location = New System.Drawing.Point(778, 28)
        Me.txtAutoBookSort_TargetPath.Name = "txtAutoBookSort_TargetPath"
        Me.txtAutoBookSort_TargetPath.Size = New System.Drawing.Size(509, 20)
        Me.txtAutoBookSort_TargetPath.TabIndex = 37
        Me.txtAutoBookSort_TargetPath.Text = "C:\_Torrent\Completed\_Books\Assorted Books Collection\Books - Sorted"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(700, 31)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(63, 13)
        Me.Label8.TabIndex = 36
        Me.Label8.Text = "Target Path"
        '
        'cmdAutoBookSort_PathToSort
        '
        Me.cmdAutoBookSort_PathToSort.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdAutoBookSort_PathToSort.Location = New System.Drawing.Point(590, 29)
        Me.cmdAutoBookSort_PathToSort.Name = "cmdAutoBookSort_PathToSort"
        Me.cmdAutoBookSort_PathToSort.Size = New System.Drawing.Size(29, 19)
        Me.cmdAutoBookSort_PathToSort.TabIndex = 35
        Me.cmdAutoBookSort_PathToSort.TabStop = False
        Me.cmdAutoBookSort_PathToSort.Text = "..."
        Me.cmdAutoBookSort_PathToSort.UseVisualStyleBackColor = True
        '
        'txtAutoBookSort_PathToSort
        '
        Me.txtAutoBookSort_PathToSort.AccessibleName = "1"
        Me.txtAutoBookSort_PathToSort.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtAutoBookSort_PathToSort.Location = New System.Drawing.Point(75, 29)
        Me.txtAutoBookSort_PathToSort.Name = "txtAutoBookSort_PathToSort"
        Me.txtAutoBookSort_PathToSort.Size = New System.Drawing.Size(509, 20)
        Me.txtAutoBookSort_PathToSort.TabIndex = 34
        Me.txtAutoBookSort_PathToSort.Text = "e:\_Torrent\Completed\_Books\Assorted Books Collection"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 32)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(63, 13)
        Me.Label7.TabIndex = 33
        Me.Label7.Text = "Path to Sort"
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.fraMagazineFinder)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(1446, 675)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Magazine Finder"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'fraMagazineFinder
        '
        Me.fraMagazineFinder.Controls.Add(Me.Label13)
        Me.fraMagazineFinder.Controls.Add(Me.cboMagazineFinderSelectionOptions)
        Me.fraMagazineFinder.Controls.Add(Me.cboMagazineFinderSearchType)
        Me.fraMagazineFinder.Controls.Add(Me.Label12)
        Me.fraMagazineFinder.Controls.Add(Me.prgMagazineFinder)
        Me.fraMagazineFinder.Controls.Add(Me.cmdMagazineFinderDownload)
        Me.fraMagazineFinder.Controls.Add(Me.cmdMagazineFinderLoadFiles)
        Me.fraMagazineFinder.Controls.Add(Me.lvwMagazineFinderFiles)
        Me.fraMagazineFinder.Controls.Add(Me.lblMagFinderSearch)
        Me.fraMagazineFinder.Controls.Add(Me.txtMagazineFinderSearchTerm)
        Me.fraMagazineFinder.Controls.Add(Me.txtMagazineFinderPath)
        Me.fraMagazineFinder.Controls.Add(Me.cmdMagazineFinderForward)
        Me.fraMagazineFinder.Controls.Add(Me.cmdMagazineFinderBack)
        Me.fraMagazineFinder.Controls.Add(Me.cmdMagazineFinderProcess)
        Me.fraMagazineFinder.Controls.Add(Me.cboMagazineFinderWebSites)
        Me.fraMagazineFinder.Controls.Add(Me.lvwMagazineFinderURLs)
        Me.fraMagazineFinder.Controls.Add(Me.Label11)
        Me.fraMagazineFinder.Controls.Add(Me.cmdMagazineFinderPath)
        Me.fraMagazineFinder.Controls.Add(Me.Label10)
        Me.fraMagazineFinder.Location = New System.Drawing.Point(6, 6)
        Me.fraMagazineFinder.Name = "fraMagazineFinder"
        Me.fraMagazineFinder.Size = New System.Drawing.Size(1434, 614)
        Me.fraMagazineFinder.TabIndex = 38
        Me.fraMagazineFinder.TabStop = False
        Me.fraMagazineFinder.Text = "Magazine Finder"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(700, 57)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(43, 13)
        Me.Label13.TabIndex = 74
        Me.Label13.Text = "Options"
        '
        'cboMagazineFinderSelectionOptions
        '
        Me.cboMagazineFinderSelectionOptions.FormattingEnabled = True
        Me.cboMagazineFinderSelectionOptions.Location = New System.Drawing.Point(754, 52)
        Me.cboMagazineFinderSelectionOptions.Name = "cboMagazineFinderSelectionOptions"
        Me.cboMagazineFinderSelectionOptions.Size = New System.Drawing.Size(272, 21)
        Me.cboMagazineFinderSelectionOptions.TabIndex = 73
        '
        'cboMagazineFinderSearchType
        '
        Me.cboMagazineFinderSearchType.FormattingEnabled = True
        Me.cboMagazineFinderSearchType.Location = New System.Drawing.Point(421, 54)
        Me.cboMagazineFinderSearchType.Name = "cboMagazineFinderSearchType"
        Me.cboMagazineFinderSearchType.Size = New System.Drawing.Size(265, 21)
        Me.cboMagazineFinderSearchType.TabIndex = 72
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(347, 56)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(68, 13)
        Me.Label12.TabIndex = 71
        Me.Label12.Text = "Search Type"
        '
        'prgMagazineFinder
        '
        Me.prgMagazineFinder.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.prgMagazineFinder.Location = New System.Drawing.Point(9, 592)
        Me.prgMagazineFinder.Name = "prgMagazineFinder"
        Me.prgMagazineFinder.Size = New System.Drawing.Size(1384, 16)
        Me.prgMagazineFinder.TabIndex = 70
        '
        'cmdMagazineFinderDownload
        '
        Me.cmdMagazineFinderDownload.Location = New System.Drawing.Point(1144, 25)
        Me.cmdMagazineFinderDownload.Name = "cmdMagazineFinderDownload"
        Me.cmdMagazineFinderDownload.Size = New System.Drawing.Size(95, 25)
        Me.cmdMagazineFinderDownload.TabIndex = 69
        Me.cmdMagazineFinderDownload.Text = "Download"
        Me.cmdMagazineFinderDownload.UseVisualStyleBackColor = True
        '
        'cmdMagazineFinderLoadFiles
        '
        Me.cmdMagazineFinderLoadFiles.Location = New System.Drawing.Point(602, 29)
        Me.cmdMagazineFinderLoadFiles.Name = "cmdMagazineFinderLoadFiles"
        Me.cmdMagazineFinderLoadFiles.Size = New System.Drawing.Size(45, 20)
        Me.cmdMagazineFinderLoadFiles.TabIndex = 68
        Me.cmdMagazineFinderLoadFiles.TabStop = False
        Me.cmdMagazineFinderLoadFiles.Text = "Load"
        Me.cmdMagazineFinderLoadFiles.UseVisualStyleBackColor = True
        '
        'lvwMagazineFinderFiles
        '
        Me.lvwMagazineFinderFiles.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader19})
        Me.lvwMagazineFinderFiles.FullRowSelect = True
        Me.lvwMagazineFinderFiles.GridLines = True
        Me.lvwMagazineFinderFiles.HideSelection = False
        Me.lvwMagazineFinderFiles.Location = New System.Drawing.Point(9, 79)
        Me.lvwMagazineFinderFiles.Name = "lvwMagazineFinderFiles"
        Me.lvwMagazineFinderFiles.Size = New System.Drawing.Size(476, 373)
        Me.lvwMagazineFinderFiles.TabIndex = 67
        Me.lvwMagazineFinderFiles.UseCompatibleStateImageBehavior = False
        Me.lvwMagazineFinderFiles.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader19
        '
        Me.ColumnHeader19.Text = "Name"
        Me.ColumnHeader19.Width = 450
        '
        'lblMagFinderSearch
        '
        Me.lblMagFinderSearch.AutoSize = True
        Me.lblMagFinderSearch.Location = New System.Drawing.Point(6, 56)
        Me.lblMagFinderSearch.Name = "lblMagFinderSearch"
        Me.lblMagFinderSearch.Size = New System.Drawing.Size(68, 13)
        Me.lblMagFinderSearch.TabIndex = 66
        Me.lblMagFinderSearch.Text = "Search Term"
        '
        'txtMagazineFinderSearchTerm
        '
        Me.txtMagazineFinderSearchTerm.AccessibleName = "1"
        Me.txtMagazineFinderSearchTerm.Location = New System.Drawing.Point(80, 53)
        Me.txtMagazineFinderSearchTerm.Name = "txtMagazineFinderSearchTerm"
        Me.txtMagazineFinderSearchTerm.Size = New System.Drawing.Size(261, 20)
        Me.txtMagazineFinderSearchTerm.TabIndex = 65
        '
        'txtMagazineFinderPath
        '
        Me.txtMagazineFinderPath.AccessibleName = "1"
        Me.txtMagazineFinderPath.Location = New System.Drawing.Point(80, 29)
        Me.txtMagazineFinderPath.Name = "txtMagazineFinderPath"
        Me.txtMagazineFinderPath.Size = New System.Drawing.Size(481, 20)
        Me.txtMagazineFinderPath.TabIndex = 64
        Me.txtMagazineFinderPath.Text = "e:\_Torrent\Completed"
        '
        'cmdMagazineFinderForward
        '
        Me.cmdMagazineFinderForward.Location = New System.Drawing.Point(671, 29)
        Me.cmdMagazineFinderForward.Name = "cmdMagazineFinderForward"
        Me.cmdMagazineFinderForward.Size = New System.Drawing.Size(15, 20)
        Me.cmdMagazineFinderForward.TabIndex = 63
        Me.cmdMagazineFinderForward.TabStop = False
        Me.cmdMagazineFinderForward.Text = ">"
        Me.cmdMagazineFinderForward.UseVisualStyleBackColor = True
        '
        'cmdMagazineFinderBack
        '
        Me.cmdMagazineFinderBack.Location = New System.Drawing.Point(653, 29)
        Me.cmdMagazineFinderBack.Name = "cmdMagazineFinderBack"
        Me.cmdMagazineFinderBack.Size = New System.Drawing.Size(15, 20)
        Me.cmdMagazineFinderBack.TabIndex = 62
        Me.cmdMagazineFinderBack.TabStop = False
        Me.cmdMagazineFinderBack.Text = "<"
        Me.cmdMagazineFinderBack.UseVisualStyleBackColor = True
        '
        'cmdMagazineFinderProcess
        '
        Me.cmdMagazineFinderProcess.Location = New System.Drawing.Point(1043, 26)
        Me.cmdMagazineFinderProcess.Name = "cmdMagazineFinderProcess"
        Me.cmdMagazineFinderProcess.Size = New System.Drawing.Size(95, 25)
        Me.cmdMagazineFinderProcess.TabIndex = 39
        Me.cmdMagazineFinderProcess.Text = "Process"
        Me.cmdMagazineFinderProcess.UseVisualStyleBackColor = True
        '
        'cboMagazineFinderWebSites
        '
        Me.cboMagazineFinderWebSites.FormattingEnabled = True
        Me.cboMagazineFinderWebSites.Location = New System.Drawing.Point(754, 26)
        Me.cboMagazineFinderWebSites.Name = "cboMagazineFinderWebSites"
        Me.cboMagazineFinderWebSites.Size = New System.Drawing.Size(272, 21)
        Me.cboMagazineFinderWebSites.TabIndex = 50
        '
        'lvwMagazineFinderURLs
        '
        Me.lvwMagazineFinderURLs.CheckBoxes = True
        Me.lvwMagazineFinderURLs.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader16, Me.ColumnHeader17, Me.ColumnHeader18, Me.ColumnHeader20})
        Me.lvwMagazineFinderURLs.FullRowSelect = True
        Me.lvwMagazineFinderURLs.GridLines = True
        Me.lvwMagazineFinderURLs.HideSelection = False
        Me.lvwMagazineFinderURLs.Location = New System.Drawing.Point(501, 79)
        Me.lvwMagazineFinderURLs.Name = "lvwMagazineFinderURLs"
        Me.lvwMagazineFinderURLs.Size = New System.Drawing.Size(892, 373)
        Me.lvwMagazineFinderURLs.TabIndex = 48
        Me.lvwMagazineFinderURLs.UseCompatibleStateImageBehavior = False
        Me.lvwMagazineFinderURLs.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader16
        '
        Me.ColumnHeader16.Text = "Name"
        Me.ColumnHeader16.Width = 400
        '
        'ColumnHeader17
        '
        Me.ColumnHeader17.Text = "URL"
        Me.ColumnHeader17.Width = 400
        '
        'ColumnHeader18
        '
        Me.ColumnHeader18.Text = "Target URL"
        Me.ColumnHeader18.Width = 400
        '
        'ColumnHeader20
        '
        Me.ColumnHeader20.Text = "PDF?"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(700, 31)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(48, 13)
        Me.Label11.TabIndex = 36
        Me.Label11.Text = "WebSite"
        '
        'cmdMagazineFinderPath
        '
        Me.cmdMagazineFinderPath.Location = New System.Drawing.Point(567, 29)
        Me.cmdMagazineFinderPath.Name = "cmdMagazineFinderPath"
        Me.cmdMagazineFinderPath.Size = New System.Drawing.Size(29, 19)
        Me.cmdMagazineFinderPath.TabIndex = 35
        Me.cmdMagazineFinderPath.TabStop = False
        Me.cmdMagazineFinderPath.Text = "..."
        Me.cmdMagazineFinderPath.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(6, 32)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(53, 13)
        Me.Label10.TabIndex = 33
        Me.Label10.Text = "Magazine"
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.fraMagazineReview)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(1446, 675)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Magazine Review"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'fraMagazineReview
        '
        Me.fraMagazineReview.Controls.Add(Me.AxAcroPDF8)
        Me.fraMagazineReview.Controls.Add(Me.AxAcroPDF7)
        Me.fraMagazineReview.Controls.Add(Me.AxAcroPDF6)
        Me.fraMagazineReview.Controls.Add(Me.AxAcroPDF5)
        Me.fraMagazineReview.Controls.Add(Me.AxAcroPDF4)
        Me.fraMagazineReview.Controls.Add(Me.AxAcroPDF3)
        Me.fraMagazineReview.Controls.Add(Me.AxAcroPDF2)
        Me.fraMagazineReview.Controls.Add(Me.AxAcroPDF1)
        Me.fraMagazineReview.Controls.Add(Me.accMagazineReview_6)
        Me.fraMagazineReview.Controls.Add(Me.accMagazineReview_1)
        Me.fraMagazineReview.Controls.Add(Me.ProgressBar1)
        Me.fraMagazineReview.Controls.Add(Me.cmdMagazineReview_Prev)
        Me.fraMagazineReview.Controls.Add(Me.Button2)
        Me.fraMagazineReview.Controls.Add(Me.TextBox2)
        Me.fraMagazineReview.Controls.Add(Me.cmdMagazineReview_Next)
        Me.fraMagazineReview.Controls.Add(Me.Button6)
        Me.fraMagazineReview.Controls.Add(Me.Label18)
        Me.fraMagazineReview.Location = New System.Drawing.Point(6, 6)
        Me.fraMagazineReview.Name = "fraMagazineReview"
        Me.fraMagazineReview.Size = New System.Drawing.Size(1434, 614)
        Me.fraMagazineReview.TabIndex = 39
        Me.fraMagazineReview.TabStop = False
        Me.fraMagazineReview.Text = "Magazine Review"
        '
        'AxAcroPDF8
        '
        Me.AxAcroPDF8.Enabled = True
        Me.AxAcroPDF8.Location = New System.Drawing.Point(853, 343)
        Me.AxAcroPDF8.Name = "AxAcroPDF8"
        Me.AxAcroPDF8.OcxState = CType(resources.GetObject("AxAcroPDF8.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxAcroPDF8.Size = New System.Drawing.Size(192, 192)
        Me.AxAcroPDF8.TabIndex = 80
        '
        'AxAcroPDF7
        '
        Me.AxAcroPDF7.Enabled = True
        Me.AxAcroPDF7.Location = New System.Drawing.Point(648, 343)
        Me.AxAcroPDF7.Name = "AxAcroPDF7"
        Me.AxAcroPDF7.OcxState = CType(resources.GetObject("AxAcroPDF7.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxAcroPDF7.Size = New System.Drawing.Size(192, 192)
        Me.AxAcroPDF7.TabIndex = 79
        '
        'AxAcroPDF6
        '
        Me.AxAcroPDF6.Enabled = True
        Me.AxAcroPDF6.Location = New System.Drawing.Point(441, 343)
        Me.AxAcroPDF6.Name = "AxAcroPDF6"
        Me.AxAcroPDF6.OcxState = CType(resources.GetObject("AxAcroPDF6.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxAcroPDF6.Size = New System.Drawing.Size(192, 192)
        Me.AxAcroPDF6.TabIndex = 78
        '
        'AxAcroPDF5
        '
        Me.AxAcroPDF5.Enabled = True
        Me.AxAcroPDF5.Location = New System.Drawing.Point(853, 84)
        Me.AxAcroPDF5.Name = "AxAcroPDF5"
        Me.AxAcroPDF5.OcxState = CType(resources.GetObject("AxAcroPDF5.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxAcroPDF5.Size = New System.Drawing.Size(192, 192)
        Me.AxAcroPDF5.TabIndex = 77
        '
        'AxAcroPDF4
        '
        Me.AxAcroPDF4.Enabled = True
        Me.AxAcroPDF4.Location = New System.Drawing.Point(648, 84)
        Me.AxAcroPDF4.Name = "AxAcroPDF4"
        Me.AxAcroPDF4.OcxState = CType(resources.GetObject("AxAcroPDF4.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxAcroPDF4.Size = New System.Drawing.Size(192, 192)
        Me.AxAcroPDF4.TabIndex = 76
        '
        'AxAcroPDF3
        '
        Me.AxAcroPDF3.Enabled = True
        Me.AxAcroPDF3.Location = New System.Drawing.Point(441, 84)
        Me.AxAcroPDF3.Name = "AxAcroPDF3"
        Me.AxAcroPDF3.OcxState = CType(resources.GetObject("AxAcroPDF3.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxAcroPDF3.Size = New System.Drawing.Size(192, 192)
        Me.AxAcroPDF3.TabIndex = 75
        '
        'AxAcroPDF2
        '
        Me.AxAcroPDF2.Enabled = True
        Me.AxAcroPDF2.Location = New System.Drawing.Point(236, 84)
        Me.AxAcroPDF2.Name = "AxAcroPDF2"
        Me.AxAcroPDF2.OcxState = CType(resources.GetObject("AxAcroPDF2.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxAcroPDF2.Size = New System.Drawing.Size(192, 192)
        Me.AxAcroPDF2.TabIndex = 74
        '
        'AxAcroPDF1
        '
        Me.AxAcroPDF1.Enabled = True
        Me.AxAcroPDF1.Location = New System.Drawing.Point(236, 343)
        Me.AxAcroPDF1.Name = "AxAcroPDF1"
        Me.AxAcroPDF1.OcxState = CType(resources.GetObject("AxAcroPDF1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxAcroPDF1.Size = New System.Drawing.Size(192, 192)
        Me.AxAcroPDF1.TabIndex = 73
        '
        'accMagazineReview_6
        '
        Me.accMagazineReview_6.Enabled = True
        Me.accMagazineReview_6.Location = New System.Drawing.Point(31, 343)
        Me.accMagazineReview_6.Name = "accMagazineReview_6"
        Me.accMagazineReview_6.OcxState = CType(resources.GetObject("accMagazineReview_6.OcxState"), System.Windows.Forms.AxHost.State)
        Me.accMagazineReview_6.Size = New System.Drawing.Size(192, 192)
        Me.accMagazineReview_6.TabIndex = 72
        '
        'accMagazineReview_1
        '
        Me.accMagazineReview_1.Enabled = True
        Me.accMagazineReview_1.Location = New System.Drawing.Point(31, 84)
        Me.accMagazineReview_1.Name = "accMagazineReview_1"
        Me.accMagazineReview_1.OcxState = CType(resources.GetObject("accMagazineReview_1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.accMagazineReview_1.Size = New System.Drawing.Size(192, 192)
        Me.accMagazineReview_1.TabIndex = 71
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ProgressBar1.Location = New System.Drawing.Point(9, 592)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(1384, 16)
        Me.ProgressBar1.TabIndex = 70
        '
        'cmdMagazineReview_Prev
        '
        Me.cmdMagazineReview_Prev.Location = New System.Drawing.Point(1068, 84)
        Me.cmdMagazineReview_Prev.Name = "cmdMagazineReview_Prev"
        Me.cmdMagazineReview_Prev.Size = New System.Drawing.Size(70, 25)
        Me.cmdMagazineReview_Prev.TabIndex = 69
        Me.cmdMagazineReview_Prev.Text = "<"
        Me.cmdMagazineReview_Prev.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(602, 29)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(45, 20)
        Me.Button2.TabIndex = 68
        Me.Button2.TabStop = False
        Me.Button2.Text = "Load"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'TextBox2
        '
        Me.TextBox2.AccessibleName = "1"
        Me.TextBox2.Location = New System.Drawing.Point(80, 29)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(481, 20)
        Me.TextBox2.TabIndex = 64
        Me.TextBox2.Text = "e:\_Torrent\Completed\50 Assorted Magazines\Keep"
        '
        'cmdMagazineReview_Next
        '
        Me.cmdMagazineReview_Next.Location = New System.Drawing.Point(1144, 84)
        Me.cmdMagazineReview_Next.Name = "cmdMagazineReview_Next"
        Me.cmdMagazineReview_Next.Size = New System.Drawing.Size(61, 25)
        Me.cmdMagazineReview_Next.TabIndex = 39
        Me.cmdMagazineReview_Next.Text = ">"
        Me.cmdMagazineReview_Next.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(567, 29)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(29, 19)
        Me.Button6.TabIndex = 35
        Me.Button6.TabStop = False
        Me.Button6.Text = "..."
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(6, 32)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(53, 13)
        Me.Label18.TabIndex = 33
        Me.Label18.Text = "Magazine"
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.fraGSComp)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(1446, 675)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "GS Comp."
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'fraGSComp
        '
        Me.fraGSComp.Controls.Add(Me.txtGSCompTab_Details)
        Me.fraGSComp.Controls.Add(Me.lvwGSCompTab_Files)
        Me.fraGSComp.Controls.Add(Me.cmdGSCompTab_GSCompress)
        Me.fraGSComp.Controls.Add(Me.cmdGSCompTab_LoadRec)
        Me.fraGSComp.Controls.Add(Me.cmdGSCompTab_Load)
        Me.fraGSComp.Controls.Add(Me.cmdGSCompTab_Path)
        Me.fraGSComp.Controls.Add(Me.txtGSCompTab_Path)
        Me.fraGSComp.Location = New System.Drawing.Point(10, 10)
        Me.fraGSComp.Name = "fraGSComp"
        Me.fraGSComp.Size = New System.Drawing.Size(1430, 659)
        Me.fraGSComp.TabIndex = 0
        Me.fraGSComp.TabStop = False
        Me.fraGSComp.Text = "GS Comp."
        '
        'txtGSCompTab_Details
        '
        Me.txtGSCompTab_Details.AccessibleName = "1"
        Me.txtGSCompTab_Details.BackColor = System.Drawing.SystemColors.Menu
        Me.txtGSCompTab_Details.Location = New System.Drawing.Point(831, 53)
        Me.txtGSCompTab_Details.Multiline = True
        Me.txtGSCompTab_Details.Name = "txtGSCompTab_Details"
        Me.txtGSCompTab_Details.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtGSCompTab_Details.Size = New System.Drawing.Size(593, 585)
        Me.txtGSCompTab_Details.TabIndex = 93
        '
        'lvwGSCompTab_Files
        '
        Me.lvwGSCompTab_Files.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader21, Me.ColumnHeader22, Me.ColumnHeader23})
        Me.lvwGSCompTab_Files.FullRowSelect = True
        Me.lvwGSCompTab_Files.GridLines = True
        Me.lvwGSCompTab_Files.HideSelection = False
        Me.lvwGSCompTab_Files.Location = New System.Drawing.Point(6, 53)
        Me.lvwGSCompTab_Files.Name = "lvwGSCompTab_Files"
        Me.lvwGSCompTab_Files.Size = New System.Drawing.Size(816, 585)
        Me.lvwGSCompTab_Files.TabIndex = 92
        Me.lvwGSCompTab_Files.UseCompatibleStateImageBehavior = False
        Me.lvwGSCompTab_Files.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader21
        '
        Me.ColumnHeader21.Text = "Full Name"
        Me.ColumnHeader21.Width = 625
        '
        'ColumnHeader22
        '
        Me.ColumnHeader22.Text = "Size (in MB)"
        Me.ColumnHeader22.Width = 90
        '
        'ColumnHeader23
        '
        Me.ColumnHeader23.Text = "Extact Size"
        Me.ColumnHeader23.Width = 90
        '
        'cmdGSCompTab_GSCompress
        '
        Me.cmdGSCompTab_GSCompress.Location = New System.Drawing.Point(631, 27)
        Me.cmdGSCompTab_GSCompress.Name = "cmdGSCompTab_GSCompress"
        Me.cmdGSCompTab_GSCompress.Size = New System.Drawing.Size(79, 20)
        Me.cmdGSCompTab_GSCompress.TabIndex = 91
        Me.cmdGSCompTab_GSCompress.Text = "GS Compress"
        Me.cmdGSCompTab_GSCompress.UseVisualStyleBackColor = True
        '
        'cmdGSCompTab_LoadRec
        '
        Me.cmdGSCompTab_LoadRec.Location = New System.Drawing.Point(546, 27)
        Me.cmdGSCompTab_LoadRec.Name = "cmdGSCompTab_LoadRec"
        Me.cmdGSCompTab_LoadRec.Size = New System.Drawing.Size(79, 20)
        Me.cmdGSCompTab_LoadRec.TabIndex = 90
        Me.cmdGSCompTab_LoadRec.TabStop = False
        Me.cmdGSCompTab_LoadRec.Text = "Load Recur."
        Me.cmdGSCompTab_LoadRec.UseVisualStyleBackColor = True
        '
        'cmdGSCompTab_Load
        '
        Me.cmdGSCompTab_Load.Location = New System.Drawing.Point(495, 27)
        Me.cmdGSCompTab_Load.Name = "cmdGSCompTab_Load"
        Me.cmdGSCompTab_Load.Size = New System.Drawing.Size(45, 20)
        Me.cmdGSCompTab_Load.TabIndex = 89
        Me.cmdGSCompTab_Load.TabStop = False
        Me.cmdGSCompTab_Load.Text = "Load"
        Me.cmdGSCompTab_Load.UseVisualStyleBackColor = True
        '
        'cmdGSCompTab_Path
        '
        Me.cmdGSCompTab_Path.Location = New System.Drawing.Point(460, 27)
        Me.cmdGSCompTab_Path.Name = "cmdGSCompTab_Path"
        Me.cmdGSCompTab_Path.Size = New System.Drawing.Size(29, 20)
        Me.cmdGSCompTab_Path.TabIndex = 88
        Me.cmdGSCompTab_Path.TabStop = False
        Me.cmdGSCompTab_Path.Text = "..."
        Me.cmdGSCompTab_Path.UseVisualStyleBackColor = True
        '
        'txtGSCompTab_Path
        '
        Me.txtGSCompTab_Path.AccessibleName = "1"
        Me.txtGSCompTab_Path.Location = New System.Drawing.Point(9, 28)
        Me.txtGSCompTab_Path.Name = "txtGSCompTab_Path"
        Me.txtGSCompTab_Path.Size = New System.Drawing.Size(445, 20)
        Me.txtGSCompTab_Path.TabIndex = 87
        Me.txtGSCompTab_Path.Text = "e:\Books\"
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.fraePubConv)
        Me.TabPage8.Location = New System.Drawing.Point(4, 22)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(1446, 675)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "ePub Conversion"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'fraePubConv
        '
        Me.fraePubConv.Controls.Add(Me.txtePubConvTab_Details)
        Me.fraePubConv.Controls.Add(Me.lvwePubConvTab_Files)
        Me.fraePubConv.Controls.Add(Me.cmdePubConvTab_EpubConv)
        Me.fraePubConv.Controls.Add(Me.cmdePubConvTab_LoadRec)
        Me.fraePubConv.Controls.Add(Me.cmdePubConvTab_Load)
        Me.fraePubConv.Controls.Add(Me.cmdePubConvTab_Path)
        Me.fraePubConv.Controls.Add(Me.txtePubConvTab_Path)
        Me.fraePubConv.Location = New System.Drawing.Point(10, 10)
        Me.fraePubConv.Name = "fraePubConv"
        Me.fraePubConv.Size = New System.Drawing.Size(1430, 659)
        Me.fraePubConv.TabIndex = 1
        Me.fraePubConv.TabStop = False
        Me.fraePubConv.Text = "ePub Conversion"
        '
        'txtePubConvTab_Details
        '
        Me.txtePubConvTab_Details.AccessibleName = "1"
        Me.txtePubConvTab_Details.BackColor = System.Drawing.SystemColors.Menu
        Me.txtePubConvTab_Details.Location = New System.Drawing.Point(831, 53)
        Me.txtePubConvTab_Details.Multiline = True
        Me.txtePubConvTab_Details.Name = "txtePubConvTab_Details"
        Me.txtePubConvTab_Details.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtePubConvTab_Details.Size = New System.Drawing.Size(593, 585)
        Me.txtePubConvTab_Details.TabIndex = 93
        '
        'lvwePubConvTab_Files
        '
        Me.lvwePubConvTab_Files.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader24, Me.ColumnHeader25, Me.ColumnHeader26})
        Me.lvwePubConvTab_Files.FullRowSelect = True
        Me.lvwePubConvTab_Files.GridLines = True
        Me.lvwePubConvTab_Files.HideSelection = False
        Me.lvwePubConvTab_Files.Location = New System.Drawing.Point(6, 53)
        Me.lvwePubConvTab_Files.Name = "lvwePubConvTab_Files"
        Me.lvwePubConvTab_Files.Size = New System.Drawing.Size(816, 585)
        Me.lvwePubConvTab_Files.TabIndex = 92
        Me.lvwePubConvTab_Files.UseCompatibleStateImageBehavior = False
        Me.lvwePubConvTab_Files.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader24
        '
        Me.ColumnHeader24.Text = "Full Name"
        Me.ColumnHeader24.Width = 625
        '
        'ColumnHeader25
        '
        Me.ColumnHeader25.Text = "Size (in MB)"
        Me.ColumnHeader25.Width = 90
        '
        'ColumnHeader26
        '
        Me.ColumnHeader26.Text = "Extact Size"
        Me.ColumnHeader26.Width = 90
        '
        'cmdePubConvTab_EpubConv
        '
        Me.cmdePubConvTab_EpubConv.Location = New System.Drawing.Point(631, 27)
        Me.cmdePubConvTab_EpubConv.Name = "cmdePubConvTab_EpubConv"
        Me.cmdePubConvTab_EpubConv.Size = New System.Drawing.Size(79, 20)
        Me.cmdePubConvTab_EpubConv.TabIndex = 91
        Me.cmdePubConvTab_EpubConv.Text = "ePub Conv."
        Me.cmdePubConvTab_EpubConv.UseVisualStyleBackColor = True
        '
        'cmdePubConvTab_LoadRec
        '
        Me.cmdePubConvTab_LoadRec.Location = New System.Drawing.Point(546, 27)
        Me.cmdePubConvTab_LoadRec.Name = "cmdePubConvTab_LoadRec"
        Me.cmdePubConvTab_LoadRec.Size = New System.Drawing.Size(79, 20)
        Me.cmdePubConvTab_LoadRec.TabIndex = 90
        Me.cmdePubConvTab_LoadRec.TabStop = False
        Me.cmdePubConvTab_LoadRec.Text = "Load Recur."
        Me.cmdePubConvTab_LoadRec.UseVisualStyleBackColor = True
        '
        'cmdePubConvTab_Load
        '
        Me.cmdePubConvTab_Load.Location = New System.Drawing.Point(495, 27)
        Me.cmdePubConvTab_Load.Name = "cmdePubConvTab_Load"
        Me.cmdePubConvTab_Load.Size = New System.Drawing.Size(45, 20)
        Me.cmdePubConvTab_Load.TabIndex = 89
        Me.cmdePubConvTab_Load.TabStop = False
        Me.cmdePubConvTab_Load.Text = "Load"
        Me.cmdePubConvTab_Load.UseVisualStyleBackColor = True
        '
        'cmdePubConvTab_Path
        '
        Me.cmdePubConvTab_Path.Location = New System.Drawing.Point(460, 27)
        Me.cmdePubConvTab_Path.Name = "cmdePubConvTab_Path"
        Me.cmdePubConvTab_Path.Size = New System.Drawing.Size(29, 20)
        Me.cmdePubConvTab_Path.TabIndex = 88
        Me.cmdePubConvTab_Path.TabStop = False
        Me.cmdePubConvTab_Path.Text = "..."
        Me.cmdePubConvTab_Path.UseVisualStyleBackColor = True
        '
        'txtePubConvTab_Path
        '
        Me.txtePubConvTab_Path.AccessibleName = "1"
        Me.txtePubConvTab_Path.Location = New System.Drawing.Point(9, 28)
        Me.txtePubConvTab_Path.Name = "txtePubConvTab_Path"
        Me.txtePubConvTab_Path.Size = New System.Drawing.Size(445, 20)
        Me.txtePubConvTab_Path.TabIndex = 87
        Me.txtePubConvTab_Path.Text = "e:\Books\"
        '
        'txtErrors
        '
        Me.txtErrors.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtErrors.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.txtErrors.Location = New System.Drawing.Point(44, 724)
        Me.txtErrors.Name = "txtErrors"
        Me.txtErrors.Size = New System.Drawing.Size(648, 20)
        Me.txtErrors.TabIndex = 56
        '
        'lblErrors
        '
        Me.lblErrors.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblErrors.AutoSize = True
        Me.lblErrors.Location = New System.Drawing.Point(4, 726)
        Me.lblErrors.Name = "lblErrors"
        Me.lblErrors.Size = New System.Drawing.Size(34, 13)
        Me.lblErrors.TabIndex = 57
        Me.lblErrors.Text = "Errors"
        '
        'tmrClearError
        '
        Me.tmrClearError.Interval = 5000
        '
        'tmrClearMessages
        '
        Me.tmrClearMessages.Interval = 3000
        '
        'cmdTorrents_LoadBothPage0s
        '
        Me.cmdTorrents_LoadBothPage0s.Location = New System.Drawing.Point(618, 361)
        Me.cmdTorrents_LoadBothPage0s.Name = "cmdTorrents_LoadBothPage0s"
        Me.cmdTorrents_LoadBothPage0s.Size = New System.Drawing.Size(95, 25)
        Me.cmdTorrents_LoadBothPage0s.TabIndex = 100
        Me.cmdTorrents_LoadBothPage0s.Text = "Load Both 0's"
        Me.ToolTip1.SetToolTip(Me.cmdTorrents_LoadBothPage0s, "Load both page zeros")
        Me.cmdTorrents_LoadBothPage0s.UseVisualStyleBackColor = True
        '
        'frmBookManagement
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1459, 753)
        Me.Controls.Add(Me.lblErrors)
        Me.Controls.Add(Me.txtErrors)
        Me.Controls.Add(Me.tabBook)
        Me.Controls.Add(Me.cmdClose)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmBookManagement"
        Me.Text = "Book Management"
        Me.mnuListviewRightClick.ResumeLayout(False)
        Me.tabBook.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.fraBookManagement.ResumeLayout(False)
        Me.fraBookManagement.PerformLayout()
        CType(Me.updwnMatchPercent, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.updwnBytes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.updwnLevenshteinDistance, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AccBookBottom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.accBookTop, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.fraMoveMags.ResumeLayout(False)
        Me.fraMoveMags.PerformLayout()
        CType(Me.accBooksPDF, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.accTorrentPDF, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.fraPDFEditing.ResumeLayout(False)
        Me.fraPDFEditing.PerformLayout()
        CType(Me.accPDFEditing_Main, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panPDFEditing.ResumeLayout(False)
        Me.panPDFEditing.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.fraAutoBookSort.ResumeLayout(False)
        Me.fraAutoBookSort.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.fraMagazineFinder.ResumeLayout(False)
        Me.fraMagazineFinder.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.fraMagazineReview.ResumeLayout(False)
        Me.fraMagazineReview.PerformLayout()
        CType(Me.AxAcroPDF8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AxAcroPDF7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AxAcroPDF6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AxAcroPDF5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AxAcroPDF4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AxAcroPDF3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AxAcroPDF2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AxAcroPDF1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.accMagazineReview_6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.accMagazineReview_1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage7.ResumeLayout(False)
        Me.fraGSComp.ResumeLayout(False)
        Me.fraGSComp.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.fraePubConv.ResumeLayout(False)
        Me.fraePubConv.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdCopyStructureBooks As System.Windows.Forms.Button
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents mnuListviewRightClick As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mnuDeleteFiles As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents proProgress As System.Windows.Forms.ProgressBar
    Friend WithEvents tabBook As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents fraBookManagement As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmdDupsByRev As System.Windows.Forms.Button
    Friend WithEvents updwnMatchPercent As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents cmdDupsByName As System.Windows.Forms.Button
    Friend WithEvents chkShowInternalName As System.Windows.Forms.CheckBox
    Friend WithEvents updwnBytes As System.Windows.Forms.NumericUpDown
    Friend WithEvents updwnLevenshteinDistance As System.Windows.Forms.NumericUpDown
    Friend WithEvents chkShowOnlySelected As System.Windows.Forms.CheckBox
    Friend WithEvents cboUniqueTypes As System.Windows.Forms.ComboBox
    Friend WithEvents lblTypeFilter As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cmdDupsBySize As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmdDupsByLevenshteinDistance As System.Windows.Forms.Button
    Friend WithEvents cmdLoadRecursive As System.Windows.Forms.Button
    Friend WithEvents cmdLoad As System.Windows.Forms.Button
    Friend WithEvents lvwFiles As System.Windows.Forms.ListView
    Friend WithEvents colNameOnDisk As System.Windows.Forms.ColumnHeader
    Friend WithEvents colSize As System.Windows.Forms.ColumnHeader
    Friend WithEvents colFolder As System.Windows.Forms.ColumnHeader
    Friend WithEvents colInternalName As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdPath As System.Windows.Forms.Button
    Friend WithEvents txtPath As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmdDupsByBinaryPatternMatching As System.Windows.Forms.Button
    Friend WithEvents fraMoveMags As System.Windows.Forms.GroupBox
    Friend WithEvents accTorrentPDF As AxAcroPDFLib.AxAcroPDF
    Friend WithEvents cmdLoad_MagCopier As System.Windows.Forms.Button
    Friend WithEvents cmdPath_MagCopier As System.Windows.Forms.Button
    Friend WithEvents txtPath_MagCopier As System.Windows.Forms.TextBox
    Friend WithEvents accBooksPDF As AxAcroPDFLib.AxAcroPDF
    Friend WithEvents lvwBooksMags As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvwTorrentMags As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdBooks_RemovePageZero As System.Windows.Forms.Button
    Friend WithEvents cmdTorrents_RemovePageZero As System.Windows.Forms.Button
    Friend WithEvents cmdMags As System.Windows.Forms.Button
    Friend WithEvents cmdKeep As System.Windows.Forms.Button
    Friend WithEvents cmdTorrentsForward As System.Windows.Forms.Button
    Friend WithEvents cmdTorrentsBack As System.Windows.Forms.Button
    Friend WithEvents txtBooksPath_MagCopier As System.Windows.Forms.TextBox
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents fraPDFEditing As System.Windows.Forms.GroupBox
    Friend WithEvents cmdPDFEditingForward As System.Windows.Forms.Button
    Friend WithEvents cmdPDFEditingBack As System.Windows.Forms.Button
    Friend WithEvents cmdMags_PDFEditing As System.Windows.Forms.Button
    Friend WithEvents cmdKeep_PDFEditing As System.Windows.Forms.Button
    Friend WithEvents lvwPDFEditing As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader8 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdLoad_PDFEditing As System.Windows.Forms.Button
    Friend WithEvents cmdPath_PDFEditing As System.Windows.Forms.Button
    Friend WithEvents txtPath_PDFEditing As System.Windows.Forms.TextBox
    Friend WithEvents panPDFEditing As System.Windows.Forms.Panel
    Friend WithEvents accPDFEditing_Main As AxAcroPDFLib.AxAcroPDF
    Friend WithEvents cboPDFEditing_StandardTypesAfterLoad As System.Windows.Forms.ComboBox
    Friend WithEvents lblPDFEditing_Types As System.Windows.Forms.Label
    Friend WithEvents cboPDFEditing_Pages As System.Windows.Forms.ComboBox
    Friend WithEvents lblPages As System.Windows.Forms.Label
    Friend WithEvents cmdPDFEditing_Save As System.Windows.Forms.Button
    Friend WithEvents cboPDFEditing_StandardTypesDuringLoad As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cmdPDFEditing_LoadFile As System.Windows.Forms.Button
    Friend WithEvents chkPDFEditing_AutoApplyStandard As System.Windows.Forms.CheckBox
    Friend WithEvents cmdPDFEditing_Clear As System.Windows.Forms.Button
    Friend WithEvents cmdPDFEditing_Refresh As System.Windows.Forms.Button
    Friend WithEvents cmdPDFEditing_GSCompress As System.Windows.Forms.Button
    Friend WithEvents cmdPDFEditing_GSCompressFolder As System.Windows.Forms.Button
    Friend WithEvents cmdBooks_LoadPDF As System.Windows.Forms.Button
    Friend WithEvents cmdTorrents_LoadPDF As System.Windows.Forms.Button
    Friend WithEvents cmdBooks_LoadPDFPage0 As System.Windows.Forms.Button
    Friend WithEvents cmdTorrents_LoadPDFPage0 As System.Windows.Forms.Button
    Friend WithEvents txtMagCopier_BooksFilename As System.Windows.Forms.TextBox
    Friend WithEvents txtMagCopier_TorrentFilename As System.Windows.Forms.TextBox
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdPDFEditing_RemovePageZero As System.Windows.Forms.Button
    Friend WithEvents txtPDFEDiting_FolderGSCompression As System.Windows.Forms.TextBox
    Friend WithEvents cmdPDFEditing_LoadPDFPage0 As System.Windows.Forms.Button
    Friend WithEvents cmdBooks_PDFEditing As System.Windows.Forms.Button
    Friend WithEvents ColumnHeader9 As System.Windows.Forms.ColumnHeader
    Friend WithEvents chkPDFEditing_StopLoad As System.Windows.Forms.CheckBox
    Friend WithEvents chkPDFEditing_AutoLoadPage0 As System.Windows.Forms.CheckBox
    Friend WithEvents cmdPDFEditing_Load_All_PageZeros As System.Windows.Forms.Button
    Friend WithEvents txtErrors As System.Windows.Forms.TextBox
    Friend WithEvents lblErrors As System.Windows.Forms.Label
    Friend WithEvents tmrClearError As System.Windows.Forms.Timer
    Friend WithEvents chkPDFEditing_SaveMissingPages As System.Windows.Forms.CheckBox
    Friend WithEvents chkTorrents_AutoLoadPage0 As System.Windows.Forms.CheckBox
    Friend WithEvents chkBooks_AutoLoadPage0 As System.Windows.Forms.CheckBox
    Friend WithEvents cmdPDFEditing_MovePageZero As System.Windows.Forms.Button
    Friend WithEvents cmdLoadCBooksIntoListview As System.Windows.Forms.Button
    Friend WithEvents cmdFiles_NextSelection As System.Windows.Forms.Button
    Friend WithEvents cmdFiles_PreviousSelection As System.Windows.Forms.Button
    Friend WithEvents chkAllFileTypes As System.Windows.Forms.CheckBox
    Friend WithEvents tmrClearMessages As System.Windows.Forms.Timer
    Friend WithEvents cmdTorrents_MoveMags As System.Windows.Forms.Button
    Friend WithEvents cmdTorrents_DeleteMag As System.Windows.Forms.Button
    Friend WithEvents cmdBooks_DeleteMag As System.Windows.Forms.Button
    Friend WithEvents cmdBooksForward As System.Windows.Forms.Button
    Friend WithEvents cmdBooksBack As System.Windows.Forms.Button
    Friend WithEvents cmdBooks_GSCompress As System.Windows.Forms.Button
    Friend WithEvents cmdTorrents_GSCompress As System.Windows.Forms.Button
    Friend WithEvents lvwMagCopier_PossibleDups As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader10 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdBooks_TransferFilename As System.Windows.Forms.Button
    Friend WithEvents cmdTorrents_TransferFilename As System.Windows.Forms.Button
    Friend WithEvents ColumnHeader11 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader12 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdTorrents_DeleteEmptyFolders As System.Windows.Forms.Button
    Friend WithEvents cmdBooks_IndividualEdit As System.Windows.Forms.Button
    Friend WithEvents cmdTorrents_IndividualEdit As System.Windows.Forms.Button
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents fraAutoBookSort As System.Windows.Forms.GroupBox
    Friend WithEvents cmdAutoBookSort_TargetPath As System.Windows.Forms.Button
    Friend WithEvents txtAutoBookSort_TargetPath As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents cmdAutoBookSort_PathToSort As System.Windows.Forms.Button
    Friend WithEvents txtAutoBookSort_PathToSort As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cmdAutoBookSort_Process As System.Windows.Forms.Button
    Friend WithEvents lvwAutoBookSort_Results As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader13 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader14 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdAutoBookSort_Move As System.Windows.Forms.Button
    Friend WithEvents txtFilterByText As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents mnuOpenFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ColumnHeader15 As System.Windows.Forms.ColumnHeader
    Friend WithEvents AccBookBottom As AxAcroPDFLib.AxAcroPDF
    Friend WithEvents accBookTop As AxAcroPDFLib.AxAcroPDF
    Friend WithEvents mnuOpenPath As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents chkPDFEditing_OnFolderChange_AutoLoadPage0s As System.Windows.Forms.CheckBox
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents cmdMagazineFinderProcess As System.Windows.Forms.Button
    Friend WithEvents fraMagazineFinder As System.Windows.Forms.GroupBox
    Friend WithEvents lvwMagazineFinderURLs As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader16 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader17 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents cmdMagazineFinderPath As System.Windows.Forms.Button
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents cboMagazineFinderWebSites As System.Windows.Forms.ComboBox
    Friend WithEvents ColumnHeader18 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdMagazineFinderForward As System.Windows.Forms.Button
    Friend WithEvents cmdMagazineFinderBack As System.Windows.Forms.Button
    Friend WithEvents lblMagFinderSearch As System.Windows.Forms.Label
    Friend WithEvents txtMagazineFinderSearchTerm As System.Windows.Forms.TextBox
    Friend WithEvents txtMagazineFinderPath As System.Windows.Forms.TextBox
    Friend WithEvents lvwMagazineFinderFiles As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader19 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdMagazineFinderLoadFiles As System.Windows.Forms.Button
    Friend WithEvents ColumnHeader20 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdMagazineFinderDownload As System.Windows.Forms.Button
    Friend WithEvents prgMagazineFinder As System.Windows.Forms.ProgressBar
    Friend WithEvents cboMagazineFinderSearchType As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents cboMagazineFinderSelectionOptions As System.Windows.Forms.ComboBox
    Friend WithEvents lblLoadPage0Filename As System.Windows.Forms.Label
    Friend WithEvents cmdPDFEditing_RemoveFoldersPageZeros As System.Windows.Forms.Button
    Friend WithEvents mnuSwapNamesAndDelete1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSwapNamesAndDelete2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmdPDFEditing_DelBackups As System.Windows.Forms.Button
    Friend WithEvents mnuRemoveHiddenFlag As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents fraMagazineReview As System.Windows.Forms.GroupBox
    Friend WithEvents AxAcroPDF8 As AxAcroPDFLib.AxAcroPDF
    Friend WithEvents AxAcroPDF7 As AxAcroPDFLib.AxAcroPDF
    Friend WithEvents AxAcroPDF6 As AxAcroPDFLib.AxAcroPDF
    Friend WithEvents AxAcroPDF5 As AxAcroPDFLib.AxAcroPDF
    Friend WithEvents AxAcroPDF4 As AxAcroPDFLib.AxAcroPDF
    Friend WithEvents AxAcroPDF3 As AxAcroPDFLib.AxAcroPDF
    Friend WithEvents AxAcroPDF2 As AxAcroPDFLib.AxAcroPDF
    Friend WithEvents AxAcroPDF1 As AxAcroPDFLib.AxAcroPDF
    Friend WithEvents accMagazineReview_6 As AxAcroPDFLib.AxAcroPDF
    Friend WithEvents accMagazineReview_1 As AxAcroPDFLib.AxAcroPDF
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents cmdMagazineReview_Prev As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents cmdMagazineReview_Next As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents cmdTorrents_MagCleanup As System.Windows.Forms.Button
    Friend WithEvents cmdTorrents_RemoveBrackets As System.Windows.Forms.Button
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents fraGSComp As System.Windows.Forms.GroupBox
    Friend WithEvents txtGSCompTab_Details As System.Windows.Forms.TextBox
    Friend WithEvents lvwGSCompTab_Files As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader21 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader22 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader23 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdGSCompTab_GSCompress As System.Windows.Forms.Button
    Friend WithEvents cmdGSCompTab_LoadRec As System.Windows.Forms.Button
    Friend WithEvents cmdGSCompTab_Load As System.Windows.Forms.Button
    Friend WithEvents cmdGSCompTab_Path As System.Windows.Forms.Button
    Friend WithEvents txtGSCompTab_Path As System.Windows.Forms.TextBox
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents fraePubConv As System.Windows.Forms.GroupBox
    Friend WithEvents txtePubConvTab_Details As System.Windows.Forms.TextBox
    Friend WithEvents lvwePubConvTab_Files As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader24 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader25 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader26 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdePubConvTab_EpubConv As System.Windows.Forms.Button
    Friend WithEvents cmdePubConvTab_LoadRec As System.Windows.Forms.Button
    Friend WithEvents cmdePubConvTab_Load As System.Windows.Forms.Button
    Friend WithEvents cmdePubConvTab_Path As System.Windows.Forms.Button
    Friend WithEvents txtePubConvTab_Path As System.Windows.Forms.TextBox
    Friend WithEvents cmdTorrents_LoadBothPage0s As Button
End Class
