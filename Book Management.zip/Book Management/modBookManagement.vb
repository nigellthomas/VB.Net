﻿Module modBookManagement

    Public Const APP_NAME As String = "Book Management"

    Public Const FILES_COL_NAME As Integer = 0
    Public Const FILES_COL_SIZE As Integer = 1
    Public Const FILES_COL_EXTACTSIZE As Integer = 2
    Public Const FILES_COL_PATH As Integer = 3
    Public Const FILES_COL_INTERNAL_NAME As Integer = 4

    Public Sub CopyStructureBooksFolder(ByRef d As DirectoryInfo, ByVal blnDoSubDirectory As Boolean, ByVal strDir As String)

        Dim strTempDir As String
        Dim objSubDir As DirectoryInfo, blnSubFolders As Boolean

        strTempDir = d.FullName.Replace("c:\Books", strDir)

        My.Computer.FileSystem.CreateDirectory(strTempDir)

        If blnDoSubDirectory Then

            Try

                For Each objSubDir In d.GetDirectories

                    blnSubFolders = objSubDir.GetDirectories.Length > 0

                    CopyStructureBooksFolder(objSubDir, blnSubFolders, strDir)
                Next

            Catch DirectoryNotFoundException As Exception

            End Try
        End If

    End Sub

    Public Function CopyStructureBooksFolders(ByVal strDir As String) As Boolean

        Dim d As DirectoryInfo
        Dim objDir As DirectoryInfo

        objDir = New DirectoryInfo("c:\Books")

        For Each d In objDir.GetDirectories()

            CopyStructureBooksFolder(d, True, strDir)
        Next

        CopyStructureBooksFolders = True

    End Function

End Module
