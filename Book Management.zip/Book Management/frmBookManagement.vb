﻿Public Class frmBookManagement

    Private mobjColumn_Files As ColumnHeader
    Private mobjColumn_TorrentMags As ColumnHeader
    Private mobjColumn_PDFEditing As ColumnHeader
    Private mstrLoadType As String

    Private Const COL_NAME_OTHER_LISTVIEWS As Integer = 0

    Private mblnDupsByBinary As Boolean = False
    Private mblnLookForFiles As Boolean, mblnLookForFilesBackwards As Boolean

    Private mintPDFEditing_PageCount As Integer, mintPDFEditing_TotalPageCount As Integer
    Private mintPDFEditing_LineItem As Integer
    Private mintPDFEditing_X As Integer, mintPDFEditing_Y As Integer, mstrPDFEditing_File As String

    Private mblnPDFEDitingFirstLoad As Boolean, mblnStopPDFLoad As Boolean

    Private mintFirstPDFLoaded As Integer = 999999, mintLastPDFLoaded As Integer = 0

    Private mstrPDFEditing_PDFSAdded As String = ""

    Private Const PDFEDITING_PDF_SPACING_DOWNWARDS As Integer = 250

    Private mintLVWFiles_CurrentlySelectedIdex As Integer = 0

    Private mstrMessageType As String
    Private Const PDF_EDITING As String = "PDF_EDITING"

    Private Const UNSELECT_ALL_LOAD_ALL As String = "Unselect All - Load All"
    Private Const SELECT_ALL_LOAD_ALL As String = "Select All - Load All"
    Private Const SELECT_ALL_LOAD_FIRST_QUARTER As String = "Select All - Load 1st 25%"
    Private Const SELECT_ALL_LOAD_SECOND_QUARTER As String = "Select All - Load 2nd 25%"
    Private Const SELECT_ALL_LOAD_THIRD_QUARTER As String = "Select All - Load 3rd 25%"
    Private Const SELECT_ALL_LOAD_FOURTH_QUARTER As String = "Select All - Load 4th 25%"

    Private Const SELECT_ALL As String = "Select All"
    Private Const UNSELECT_ALL As String = "Unselect All"

    Private Const SATURDAY As String = "Saturday"
    Private Const SATURDAY_START As Integer = 53
    Private Const SATURDAY_START_CHECKED As Integer = 57
    Private Const SATURDAY_END As Integer = 65
    Private Const SATURDAY_END_CHECKED As Integer = 61

    Private Const SUNDAY As String = "Sunday"
    Private Const SUNDAY_START As Integer = 25
    Private Const SUNDAY_START_CHECKED As Integer = 30
    Private Const SUNDAY_END As Integer = 40
    Private Const SUNDAY_END_CHECKED As Integer = 35

    Private Const SUNDAY_TIMES As String = "Sunday Times"
    Private Const SUNDAY_TIMES_START As Integer = 38
    Private Const SUNDAY_TIMES_START_CHECKED As Integer = 42
    Private Const SUNDAY_TIMES_END As Integer = 53
    Private Const SUNDAY_TIMES_END_CHECKED As Integer = 47

    Private Const TIMES As String = "Times"
    Private Const TIMES_START As Integer = 25
    Private Const TIMES_START_CHECKED As Integer = 29
    Private Const TIMES_END As Integer = 38
    Private Const TIMES_END_CHECKED As Integer = 35

    Private Const TOP_SANTE As String = "Top Sante"
    Private Const TOP_SANTE_START As Integer = 77
    Private Const TOP_SANTE_START_CHECKED As Integer = 80
    Private Const TOP_SANTE_END As Integer = 105
    Private Const TOP_SANTE_END_CHECKED As Integer = 95

    Private mblnMagCopier_UseBooksFolder As Boolean = False

    Private AUTO_SORT_FOLDER_LIMIT As Integer = 100
    Private AUTO_SORT_WORD_LIMIT As Integer = 50000

    Private mstrAutoSort_Folders(AUTO_SORT_FOLDER_LIMIT) As String
    Private mstrAutoSort_Words(AUTO_SORT_FOLDER_LIMIT, AUTO_SORT_WORD_LIMIT) As String
    Private mintAutoSort_WordCount(AUTO_SORT_FOLDER_LIMIT, AUTO_SORT_WORD_LIMIT) As Integer

    Private mintAutoSort_FolderCount As Integer = 1

    Private mblnLoad_accBookTop As Boolean = False

    Private mstrMagazineFinder_Website(mintMagazineFinder_SupportedCount + 1) As String
    Private mstrMagazineFinder_WebsiteURL(mintMagazineFinder_SupportedCount + 1) As String

    Private mintMagazineFinder_SupportedCount As Integer = 1

    Public mobjHTML As New HTMLReader.clsHTMLReader ' error here is nothign to do with HTML reader - the problem  is the acrobat file control thats on the form
    ' its not setup/installed here 


    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click

        Me.Close()

        End

    End Sub

    Private Sub txtPath_TextChanged(sender As Object, e As EventArgs) Handles txtPath.TextChanged

        My.Settings.LastPath = txtPath.Text

        cmdLoad.Enabled = (txtPath.Text.Trim <> "")

    End Sub

    Private Sub cmdPath_Click(sender As Object, e As EventArgs) Handles cmdPath.Click

        Me.Text = APP_NAME

        FolderBrowserDialog1.RootFolder = Environment.SpecialFolder.MyComputer

        If txtPath.Text = "" Then

            FolderBrowserDialog1.SelectedPath = ROOT_DRIVE & "\"
        Else

            FolderBrowserDialog1.SelectedPath = txtPath.Text
        End If

        If FolderBrowserDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then

            If FolderBrowserDialog1.SelectedPath <> "" Then

                txtPath.Text = Mid(FolderBrowserDialog1.SelectedPath, 1, 1).ToLower & Mid(FolderBrowserDialog1.SelectedPath, 2)
                LoadFiles(txtPath.Text)

                Reset()
            End If

        End If

    End Sub

    Sub LoadFiles(ByVal strPath As String, Optional ByVal strExtension As String = "")

        Dim objDir As New DirectoryInfo(strPath), objItem As ListViewItem, blnAdd As Boolean = False
        Dim strType As String, strAllTypes As String = "", strUniqueTypes() As String, intCount As Integer = 0
        Dim strInternalName As String
        Dim blnShownHiddenFilesWarning As Boolean = False, intHiddenFilesCount As Integer = 0

        Me.Text = APP_NAME

        lvwFiles.Items.Clear()

        If strPath.Trim = "" Then

            Reset()

            MessageBox.Show("Enter path!")
            Exit Sub
        End If

        If strExtension = "" Then

            strExtension = "*.*"
        Else

            strExtension = "*" & strExtension
        End If

        If chkAllFileTypes.Checked Then

            strExtension = "*.*"
        End If

        blnAdd = True

        Try

            For Each objFile As FileInfo In objDir.GetFiles(strExtension)

                strType = objFile.Extension.ToLower

                If (strType = ".pdf" OrElse strType = ".epub" OrElse strType = ".mobi" And chkAllFileTypes.Checked = False) Or chkAllFileTypes.Checked Then

                    blnAdd = True
                Else

                    blnAdd = False
                End If

                If blnAdd Then

                    If txtFilterByText.Text <> "" Then

                        If InStr(objFile.Name.ToLower, txtFilterByText.Text.ToLower) = 0 Then

                            blnAdd = False
                        End If
                    End If
                End If

                If blnAdd Then

                    If FileHasAttributeFlag(objFile, FileAttributes.Hidden) And strPath.ToLower <> ProperisePath(ROOT_DRIVE) Then

                        If Not blnShownHiddenFilesWarning Then

                            MessageBox.Show("At least 1 hidden file found! Filename - " & vbCrLf & vbCrLf & objFile.Name, My.Application.Info.ProductName, MessageBoxButtons.OK)

                            blnShownHiddenFilesWarning = True
                            intHiddenFilesCount = 1
                        Else

                            intHiddenFilesCount = intHiddenFilesCount + 1
                        End If
                    End If


                    objItem = lvwFiles.Items.Add(objFile.Name)

                    strPath = GetPath(objFile.FullName)

                    If InStr(strAllTypes, strType & ",", CompareMethod.Text) = 0 Then

                        strAllTypes = strAllTypes & strType & ","
                    End If

                    objItem.SubItems.Add(GetFileSizeInMB_UsingSize(objFile.Length))
                    objItem.SubItems.Add(objFile.Length)
                    objItem.SubItems.Add(strPath)

                    If chkShowInternalName.Checked Then

                        strInternalName = ""

                        Select Case strType

                            Case ".pdf"

                                strInternalName = GetInternalNameOfPDF(objFile.FullName)

                            Case ".mobi"



                        End Select

                        objItem.SubItems.Add(strInternalName)
                    Else

                        objItem.SubItems.Add("")
                    End If
                End If
            Next

        Catch ex As Exception

            MessageBox.Show(ex.Message)
        End Try

        strUniqueTypes = Split(strAllTypes, ",")

        cboUniqueTypes.Items.Clear()

        For intCount = strUniqueTypes.GetLowerBound(0) To strUniqueTypes.GetUpperBound(0)

            cboUniqueTypes.Items.Add(strUniqueTypes(intCount))
        Next

        Dim objE As New ColumnClickEventArgs(FILES_COL_NAME)
        lvwFiles_ColumnClick(Nothing, objE)

        If intHiddenFilesCount > 0 Then

            MessageBox.Show("Total of " & intHiddenFilesCount & " hidden files found!")
        End If

    End Sub

    Private Sub cmdLoad_Click(sender As Object, e As EventArgs) Handles cmdLoad.Click

        Cursor = Cursors.WaitCursor

        mstrLoadType = "LOAD"

        LoadFiles(txtPath.Text)

        Reset()

    End Sub

    Private Sub LoadRecursive(ByVal strUniqueType As String, ByVal strPath As String, ByVal blnDoClear As Boolean, ByVal blnIgnoreMagsFolder As Boolean)

        Dim colMyFiles As New colMyFileInfo, objItem As ListViewItem, strFile As String
        Dim objMyFile As clsMyFileInfo, strAllTypes As String = ""
        Dim intCount As Integer
        Dim strUniqueTypes() As String

        Me.Text = APP_NAME

        If strPath.Trim = "" Then

            MessageBox.Show("Enter path!")
            Exit Sub
        End If

        Cursor = Cursors.WaitCursor

        mstrLoadType = "LOADRECURSIVE"

        LoadAllFilesInFolder_Recursive(strPath, colMyFiles, strUniqueType, strAllTypes, blnIgnoreMagsFolder)

        If blnDoClear Then lvwFiles.Items.Clear()

        For Each objMyFile In colMyFiles

            strFile = RemovePath(objMyFile.Fullname)

            objItem = lvwFiles.Items.Add(strFile)

            strPath = GetPath(objMyFile.Fullname)

            objItem.SubItems.Add(GetFileSizeInMB_UsingSize(objMyFile.Size))
            objItem.SubItems.Add(objMyFile.Size)
            objItem.SubItems.Add(strPath)

            objItem.SubItems.Add("")
        Next

        My.Application.DoEvents()

        objMyFile = Nothing
        colMyFiles = Nothing
        colMyFiles = New colMyFileInfo

        strUniqueTypes = Split(strAllTypes, ",")

        cboUniqueTypes.Items.Clear()

        For intCount = strUniqueTypes.GetLowerBound(0) To strUniqueTypes.GetUpperBound(0)

            cboUniqueTypes.Items.Add(strUniqueTypes(intCount))
        Next

        Dim objE As New ColumnClickEventArgs(FILES_COL_NAME)
        lvwFiles_ColumnClick(Nothing, objE)

        Reset()

    End Sub

    Private Sub cmdLoadRecursive_Click(sender As Object, e As EventArgs) Handles cmdLoadRecursive.Click

        LoadRecursive("", txtPath.Text, True, False)

    End Sub

    Private Sub mnuRemoveHiddenFlag_Click(sender As Object, e As EventArgs) Handles mnuRemoveHiddenFlag.Click

        Dim intCount As Integer, strPath As String, objFile As FileInfo

        If lvwFiles.SelectedItems.Count > 0 Then

            For intCount = 0 To lvwFiles.SelectedItems.Count - 1

                strPath = txtPath.Text & "\" & lvwFiles.SelectedItems(intCount).SubItems(FILES_COL_NAME).Text

                Try
                    Me.Text = "Removing hidden - " & strPath

                    objFile = New FileInfo(strPath)

                    objFile.Attributes = FileAttributes.Normal

                    My.Application.DoEvents()

                Catch ex As Exception

                    DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name, "strPath = " & strPath & " - intCount = " & intCount)
                End Try

            Next

        End If

        Me.Text = "Book Management"

        cmdLoad_Click(Nothing, Nothing)

    End Sub

    Private Sub Reset()

        Cursor = Cursors.Default
        Me.Text = APP_NAME

        Me.Refresh()

        If lvwFiles.Items.Count = 0 Then

            fraBookManagement.Text = "Book Management"
        Else

            fraBookManagement.Text = "Book Management - " & lvwFiles.Items.Count & " files"
        End If

    End Sub

    Private Sub Reset_MagCopier()

        Cursor = Cursors.Default
        Me.Text = APP_NAME

        Me.Refresh()

        If lvwTorrentMags.Items.Count = 0 Then

            fraBookManagement.Text = "Book Management"
        Else

            fraBookManagement.Text = "Book Management - Torrent " & lvwTorrentMags.Items.Count & " files"
        End If

    End Sub

    Private Sub Reset_PDFEditing()

        Cursor = Cursors.Default
        Me.Text = APP_NAME

        Me.Refresh()

        If lvwPDFEditing.Items.Count = 0 Then

            fraBookManagement.Text = "Book Management"
        Else

            fraBookManagement.Text = "Book Management - Torrent " & lvwPDFEditing.Items.Count & " files"
        End If

    End Sub

    Public Sub LoadAllFilesInFolder_Recursive(ByVal strFrom As String, ByRef colMyFiles As colMyFileInfo, ByVal strPrefix As String, ByRef strAllTypes As String,
                                              ByVal blnIgnoreMagsFolder As Boolean)

        Dim objDir As DirectoryInfo, d As DirectoryInfo, objFile As FileInfo, objSubDir As DirectoryInfo
        Dim objMyFile As clsMyFileInfo, strType As String
        Dim blnAdd As Boolean

        If strFrom = "" Then

            MessageBox.Show("No Path!")
            Exit Sub
        End If

        objDir = New DirectoryInfo(strFrom)

        If Not blnIgnoreMagsFolder Or (blnIgnoreMagsFolder And InStr(strFrom, ROOT_DRIVE & "\Books\Audio Books") = 0 And InStr(strFrom, ROOT_DRIVE & "\Books\French\Audio Visual") = 0 And InStr(strFrom, ROOT_DRIVE & "\Books\Mags") = 0) Then

            For Each objFile In objDir.GetFiles

                objMyFile = New clsMyFileInfo

                strType = objFile.Extension.ToLower

                If (strType = ".pdf" OrElse strType = ".epub" OrElse strType = ".mobi" And Not chkAllFileTypes.Checked) Or chkAllFileTypes.Checked Then

                    blnAdd = True
                Else

                    blnAdd = False
                End If

                If blnAdd Then

                    If txtFilterByText.Text <> "" Then

                        If InStr(objFile.Name.ToLower, txtFilterByText.Text.ToLower) = 0 Then

                            blnAdd = False
                        End If
                    End If
                End If

                If blnAdd Then

                    objMyFile.Fullname = objFile.FullName
                    objMyFile.Size = objFile.Length

                    If strPrefix = "" OrElse strPrefix = strType Then

                        If InStr(strAllTypes, strType & ",", CompareMethod.Text) = 0 Then

                            strAllTypes = String.Concat(strAllTypes, strType, ",")
                        End If

                        colMyFiles.Add(objMyFile)
                    End If
                End If
            Next
        End If

        For Each d In objDir.GetDirectories()

            If Not blnIgnoreMagsFolder Or (blnIgnoreMagsFolder And InStr(strFrom, ROOT_DRIVE & "\Books\Audio Books") = 0 And InStr(strFrom, ROOT_DRIVE & "\Books\French\Audio Visual") = 0 And InStr(strFrom, ROOT_DRIVE & "\Books\Mags") = 0) Then

                For Each objFile In d.GetFiles

                    objMyFile = New clsMyFileInfo

                    strType = objFile.Extension.ToLower

                    If (strType = ".pdf" OrElse strType = ".epub" OrElse strType = ".mobi" And Not chkAllFileTypes.Checked) Or chkAllFileTypes.Checked Then

                        blnAdd = True
                    Else

                        blnAdd = False
                    End If

                    If blnAdd Then

                        If txtFilterByText.Text <> "" Then

                            If InStr(objFile.Name.ToLower, txtFilterByText.Text.ToLower) = 0 Then

                                blnAdd = False
                            End If
                        End If
                    End If

                    If blnAdd Then

                        objMyFile.Fullname = objFile.FullName
                        objMyFile.Size = objFile.Length

                        If strPrefix = "" OrElse strPrefix = strType Then

                            If InStr(strAllTypes, strType & ",", CompareMethod.Text) = 0 Then

                                strAllTypes = String.Concat(strAllTypes, strType, ",")
                            End If

                            colMyFiles.Add(objMyFile)
                        End If
                    End If

                    My.Application.DoEvents()
                Next
            End If

            For Each objSubDir In d.GetDirectories

                LoadAllFilesInFolder_Recursive(objSubDir.FullName, colMyFiles, strPrefix, strAllTypes, blnIgnoreMagsFolder)
            Next
        Next

    End Sub

    Private Sub frmBookManagement_Click(sender As Object, e As EventArgs) Handles Me.Click

        'modPdfSharp.CompressPdf("C:\BBC_Easy_Cook_UK_-_July_2020_.pdf")

    End Sub

    Private Sub frmBookManagement_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

        RemoveAnyPDFEditingPages()

    End Sub

    Private Sub frmBookManagement_Load(sender As Object, e As EventArgs) Handles Me.Load

        Dim intCount As Integer

        Me.Width = 1800
        Me.Left = 40

        txtPath.Text = My.Settings.LastPath

        txtPath_MagCopier.Text = FirstTorrentsMagsFolder()

        cboPDFEditing_StandardTypesDuringLoad.Items.Add(UNSELECT_ALL_LOAD_ALL)
        cboPDFEditing_StandardTypesDuringLoad.Items.Add(SELECT_ALL_LOAD_ALL)
        cboPDFEditing_StandardTypesDuringLoad.Items.Add(SELECT_ALL_LOAD_FIRST_QUARTER)
        cboPDFEditing_StandardTypesDuringLoad.Items.Add(SELECT_ALL_LOAD_SECOND_QUARTER)
        cboPDFEditing_StandardTypesDuringLoad.Items.Add(SELECT_ALL_LOAD_THIRD_QUARTER)
        cboPDFEditing_StandardTypesDuringLoad.Items.Add(SELECT_ALL_LOAD_FOURTH_QUARTER)
        cboPDFEditing_StandardTypesDuringLoad.Items.Add("")
        cboPDFEditing_StandardTypesDuringLoad.Items.Add(SUNDAY)
        cboPDFEditing_StandardTypesDuringLoad.Items.Add(SATURDAY)
        cboPDFEditing_StandardTypesDuringLoad.Items.Add("Se7en")
        cboPDFEditing_StandardTypesDuringLoad.Items.Add("Farmers Weekly")
        cboPDFEditing_StandardTypesDuringLoad.Items.Add(SUNDAY_TIMES)
        cboPDFEditing_StandardTypesDuringLoad.Items.Add(TIMES)
        cboPDFEditing_StandardTypesDuringLoad.Items.Add(TOP_SANTE)
        cboPDFEditing_StandardTypesDuringLoad.SelectedItem = cboPDFEditing_StandardTypesDuringLoad.Items(2)

        cboPDFEditing_StandardTypesAfterLoad.Items.Add(UNSELECT_ALL)
        cboPDFEditing_StandardTypesAfterLoad.Items.Add(SELECT_ALL)
        cboPDFEditing_StandardTypesAfterLoad.Items.Add("")
        cboPDFEditing_StandardTypesAfterLoad.Items.Add(SUNDAY)
        cboPDFEditing_StandardTypesAfterLoad.Items.Add(SATURDAY)
        cboPDFEditing_StandardTypesAfterLoad.Items.Add("Se7en")
        cboPDFEditing_StandardTypesAfterLoad.Items.Add("Farmers Weekly")
        cboPDFEditing_StandardTypesAfterLoad.Items.Add(SUNDAY_TIMES)
        cboPDFEditing_StandardTypesAfterLoad.Items.Add(TIMES)
        cboPDFEditing_StandardTypesAfterLoad.Items.Add(TOP_SANTE)

        For intcount = 1 To mintMagazineFinder_SupportedCount

            mstrMagazineFinder_Website(intCount) = "MagazineLib"
            mstrMagazineFinder_WebsiteURL(intcount) = "https://magazinelib.com/?s=XXX"

            cboMagazineFinderWebSites.Items.Add(mstrMagazineFinder_Website(intCount))
        Next

        cboMagazineFinderWebSites.Text = cboMagazineFinderWebSites.Items(0)

        txtMagazineFinderPath.Text = ROOT_DRIVE & "\Books\Mags"

        cboMagazineFinderSearchType.Items.Add("")
        cboMagazineFinderSearchType.Items.Add("Latest")
        cboMagazineFinderSearchType.Items.Add("Food & Cooking")
        cboMagazineFinderSearchType.Items.Add("Science")

        cboMagazineFinderSelectionOptions.Items.Add("")
        cboMagazineFinderSelectionOptions.Items.Add("Select All")
        cboMagazineFinderSelectionOptions.Items.Add("Unselect All")
        cboMagazineFinderSelectionOptions.Items.Add("Invert")

        lblLoadPage0Filename.Text = ""

        Me.WindowState = FormWindowState.Maximized

    End Sub

    Private Sub lvwFiles_ColumnClick(sender As Object, e As ColumnClickEventArgs) Handles lvwFiles.ColumnClick

        ' Get the new sorting column.
        Dim objListview As ListView, objColumnHeader As ColumnHeader

        objListview = lvwFiles
        objColumnHeader = mobjColumn_Files

        Dim new_sorting_column As ColumnHeader = objListview.Columns(e.Column)

        ' Figure out the new sorting order.
        Dim sort_order As System.Windows.Forms.SortOrder

        If objColumnHeader Is Nothing Then

            ' New column. Sort ascending.
            sort_order = SortOrder.Ascending
        Else

            ' See if this is the same column.
            If new_sorting_column.Equals(objColumnHeader) Then

                ' Same column. Switch the sort order.
                If objColumnHeader.Text.EndsWith(" >") Then

                    sort_order = SortOrder.Descending
                Else

                    sort_order = SortOrder.Ascending
                End If
            Else

                ' New column. Sort ascending.
                sort_order = SortOrder.Ascending
            End If

            ' Remove the old sort indicator.
            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, Len(objColumnHeader.Text) - 2)
        End If

        ' Display the new sort order.
        objColumnHeader = new_sorting_column

        If Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " >" Or Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " <" Then

            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, objColumnHeader.Text.Length - 2)
        End If

        If sort_order = SortOrder.Ascending Then

            objColumnHeader.Text = String.Concat(objColumnHeader.Text, " >")
        Else

            objColumnHeader.Text = String.Concat(objColumnHeader.Text, " <")
        End If

        mobjColumn_Files = objColumnHeader

        ' Create a comparer.
        objListview.ListViewItemSorter = New ListViewComparer(e.Column, sort_order)

        ' Sort.
        objListview.Sort()

    End Sub

    Private Sub cboUniqueTypes_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboUniqueTypes.SelectedIndexChanged

        If mstrLoadType = "LOAD" Then

            LoadFiles(txtPath.Text, cboUniqueTypes.SelectedItem & "")
        Else

            LoadRecursive(cboUniqueTypes.SelectedItem & "", txtPath.Text, True, False)
        End If

    End Sub

    Private Sub chkShowOnlySelected_CheckedChanged(sender As Object, e As EventArgs) Handles chkShowOnlySelected.CheckedChanged

        Dim objListItem As ListViewItem

        If chkShowOnlySelected.Checked Then

            For Each objListItem In lvwFiles.Items

                If objListItem.Selected = False Then

                    objListItem.Remove()
                End If
            Next

            lvwFiles.SelectedItems.Clear()

        Else

            LoadFiles(txtPath.Text, cboUniqueTypes.SelectedItem & "")
        End If

    End Sub

    Private Sub cmdDupsBySize_Click(sender As Object, e As EventArgs) Handles cmdDupsBySize.Click

        Dim objItem As ListViewItem, intSize1 As Integer, intSize2 As Integer
        Dim blnFirstFile As Boolean, objFirst As ListViewItem = Nothing
        Dim intCount As Integer

        mblnDupsByBinary = False

        frmBookManagement_Resize(Nothing, Nothing)

        blnFirstFile = True

        lvwFiles.SelectedItems.Clear()

        For Each objItem In lvwFiles.Items

            If blnFirstFile Then

                intSize1 = objItem.SubItems(FILES_COL_SIZE).Text
                objFirst = objItem
                blnFirstFile = False
            Else

                intSize2 = objItem.SubItems(FILES_COL_SIZE).Text

                If Math.Abs(intSize1 - intSize2) <= updwnBytes.Value Then

                    objItem.Selected = True
                    objFirst.Selected = True

                    intCount = intCount + 1
                End If

                intSize1 = intSize2
                objFirst = objItem
            End If
        Next

        lvwFiles.Refresh()

        Me.Text = APP_NAME & " - " & intCount & " selected"

    End Sub

    Private Sub cmdDupsByLevenshteinDistance_Click(sender As Object, e As EventArgs) Handles cmdDupsByLevenshteinDistance.Click

        Dim objItem As ListViewItem, strName1 As String = "", strName2 As String = ""
        Dim blnFirstFile As Boolean, objFirst As ListViewItem = Nothing
        Dim intCount As Integer

        mblnDupsByBinary = False

        frmBookManagement_Resize(Nothing, Nothing)

        blnFirstFile = True

        lvwFiles.SelectedItems.Clear()

        For Each objItem In lvwFiles.Items

            If blnFirstFile Then

                strName1 = objItem.SubItems(FILES_COL_NAME).Text
                objFirst = objItem
                blnFirstFile = False
            Else

                strName2 = objItem.SubItems(FILES_COL_NAME).Text

                If LevenshteinDistance(strName1, strName2, True, True, True, True) < updwnLevenshteinDistance.Value Then

                    If Not LastChecks_Volume12_Etc(strName1, strName2) Then

                        objItem.Selected = True
                        objFirst.Selected = True

                        intCount = intCount + 1
                    End If
                End If

                strName1 = strName2
                objFirst = objItem
            End If
        Next

        lvwFiles.Refresh()

        Me.Text = APP_NAME & " - " & intCount & " selected"

    End Sub

    Private Sub lvwFiles_MouseClick(sender As Object, e As MouseEventArgs) Handles lvwFiles.MouseClick

        If e.Button = Windows.Forms.MouseButtons.Right Then

            Dim p As New Point

            p = New Point(Windows.Forms.Cursor.Position.X, Windows.Forms.Cursor.Position.Y)

            mnuListviewRightClick.Tag = sender.name
            mnuListviewRightClick.Show(p)

        ElseIf e.Button = Windows.Forms.MouseButtons.Left Then

            Dim strFile As String, strPath As String = ""

            If accBookTop.Visible Then

                If lvwFiles.SelectedItems.Count <> 1 Then

                    txtErrors.Text = "Only one to be selected!"
                    tmrClearError.Enabled = True
                    Exit Sub
                End If

                strFile = lvwFiles.SelectedItems(0).Text

                lvwPDFEditing.Enabled = False

                Cursor = Cursors.WaitCursor

                strPath = ProperisePath(lvwFiles.SelectedItems(0).SubItems(FILES_COL_PATH).Text)

                If Not mblnLoad_accBookTop Then

                    If pdfSharp_CreateATempPage0(strPath & strFile, "Torrents") Then

                        accBookTop.LoadFile(ROOT_DRIVE & "\_Torrent\Completed\50 Assorted Magazines\Keep\RemovePageZero\Backups\Temp_PageZeros\Torrents_page0.pdf")
                    End If

                    mblnLoad_accBookTop = True
                Else

                    If pdfSharp_CreateATempPage0(strPath & strFile, "Torrents") Then

                        AccBookBottom.LoadFile(ROOT_DRIVE & "\_Torrent\Completed\50 Assorted Magazines\Keep\RemovePageZero\Backups\Temp_PageZeros\Torrents_page0.pdf")
                    End If

                    mblnLoad_accBookTop = False
                End If

                lvwPDFEditing.Enabled = True

                Cursor = Cursors.Default

            End If

        End If

    End Sub

    Private Sub lvwFiles_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvwFiles.SelectedIndexChanged

        Me.Text = APP_NAME

    End Sub

    Private Sub chkShowInternalName_CheckedChanged(sender As Object, e As EventArgs) Handles chkShowInternalName.CheckedChanged

        frmBookManagement_Resize(Nothing, Nothing)

        cmdLoad_Click(Nothing, Nothing)

    End Sub

    Private Sub mnuOpenPath_Click(sender As Object, e As EventArgs) Handles mnuOpenPath.Click

        Dim p As New Process, strPath As String

        If lvwFiles.SelectedItems.Count = 1 Then

            strPath = lvwFiles.SelectedItems(0).SubItems(FILES_COL_PATH).Text

            p.StartInfo.FileName = "Explorer.exe"

            p.StartInfo.Arguments = """" & strPath & """"
            p.StartInfo.UseShellExecute = False
            p.StartInfo.CreateNoWindow = True
            p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
            p.StartInfo.RedirectStandardOutput = True

            p.Start()

            p = Nothing
        End If

    End Sub

    Private Sub mnuOpenFile_Click(sender As Object, e As EventArgs) Handles mnuOpenFile.Click

        Dim p As New Process, strPrefix As String, strPath As String

        If lvwFiles.SelectedItems.Count = 1 Then

            strPath = lvwFiles.SelectedItems(0).SubItems(FILES_COL_PATH).Text & lvwFiles.SelectedItems(0).SubItems(FILES_COL_NAME).Text

            strPrefix = GetPrefix(lvwFiles.SelectedItems(0).SubItems(FILES_COL_NAME).Text)

            If strPrefix.ToUpper = "PDF" Or strPrefix.ToUpper = "EPUB" Then

                If strPrefix.ToUpper = "PDF" Then

                    p.StartInfo.FileName = "C:\Program Files\Foxit Software\Foxit Reader\FoxitReader.exe"

                ElseIf strPrefix.ToUpper = "EPUB" Then

                    p.StartInfo.FileName = "C:\Program Files\FBReader\FBReader.exe"
                End If

                p.StartInfo.Arguments = """" & strPath & """"
                p.StartInfo.UseShellExecute = False
                p.StartInfo.CreateNoWindow = True
                p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
                p.StartInfo.RedirectStandardOutput = True

                p.Start()

                p = Nothing
            End If
        End If

        If lvwFiles.SelectedItems.Count = 2 Then

            strPath = lvwFiles.SelectedItems(0).SubItems(FILES_COL_PATH).Text & lvwFiles.SelectedItems(0).SubItems(FILES_COL_NAME).Text

            strPrefix = GetPrefix(lvwFiles.SelectedItems(0).SubItems(FILES_COL_NAME).Text)

            If strPrefix.ToUpper = "PDF" Or strPrefix.ToUpper = "EPUB" Then

                If strPrefix.ToUpper = "PDF" Then

                    p.StartInfo.FileName = "C:\Program Files\Foxit Software\Foxit Reader\FoxitReader.exe"

                ElseIf strPrefix.ToUpper = "EPUB" Then

                    p.StartInfo.FileName = "C:\Program Files\FBReader\FBReader.exe"
                End If

                p.StartInfo.Arguments = """" & strPath & """"
                p.StartInfo.UseShellExecute = False
                p.StartInfo.CreateNoWindow = True
                p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
                p.StartInfo.RedirectStandardOutput = True

                p.Start()

                p = Nothing

                p = New Process
            End If

            strPath = lvwFiles.SelectedItems(1).SubItems(FILES_COL_PATH).Text & lvwFiles.SelectedItems(1).SubItems(FILES_COL_NAME).Text

            strPrefix = GetPrefix(lvwFiles.SelectedItems(1).SubItems(FILES_COL_NAME).Text)

            If strPrefix.ToUpper = "PDF" Or strPrefix.ToUpper = "EPUB" Then

                If strPrefix.ToUpper = "PDF" Then

                    p.StartInfo.FileName = "C:\Program Files\Foxit Software\Foxit Reader\FoxitReader.exe"

                ElseIf strPrefix.ToUpper = "EPUB" Then

                    p.StartInfo.FileName = "C:\Program Files\FBReader\FBReader.exe"
                End If

                p.StartInfo.Arguments = """" & strPath & """"
                p.StartInfo.UseShellExecute = False
                p.StartInfo.CreateNoWindow = True
                p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
                p.StartInfo.RedirectStandardOutput = True

                p.Start()

                p = Nothing
            End If

        End If

    End Sub

    Private Sub mnuDeleteFiles_Click(sender As Object, e As EventArgs) Handles mnuDeleteFiles.Click

        Dim strPath As String
        Dim strTitle As String

        strTitle = Me.Text

        If lvwFiles.SelectedItems.Count = 1 Then

            strPath = lvwFiles.SelectedItems(0).SubItems(FILES_COL_PATH).Text & lvwFiles.SelectedItems(0).SubItems(FILES_COL_NAME).Text

            Try
                Me.Text = "Deleting - " & strPath

                My.Computer.FileSystem.DeleteFile(strPath, FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin)

                My.Application.DoEvents()

            Catch ex As Exception

                DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name, "strPath = " & strPath)
            End Try

            lvwFiles.Items().RemoveAt(lvwFiles.SelectedItems(0).Index)
        End If

        Me.Text = strTitle

    End Sub

    Private Sub frmBookManagement_Resize(sender As Object, e As EventArgs) Handles Me.Resize

        Dim intWidth As Integer

        If Me.Width < 1385 Then Me.Width = 1385
        If Me.Height < 1000 Then Me.Height = 1000

        '                            columns for size 125 + 125 = 250
        intWidth = (lvwFiles.Width - 250) - 19

        If chkShowInternalName.Checked Or mblnDupsByBinary Then

            lvwFiles.Columns(FILES_COL_NAME).Width = (intWidth * 0.362)
            lvwFiles.Columns(FILES_COL_PATH).Width = (intWidth * 0.275)
            lvwFiles.Columns(FILES_COL_INTERNAL_NAME).Width = (intWidth * 0.362)
        Else

            lvwFiles.Columns(FILES_COL_NAME).Width = (intWidth * 0.5)
            lvwFiles.Columns(FILES_COL_PATH).Width = (intWidth * 0.5)
            lvwFiles.Columns(FILES_COL_INTERNAL_NAME).Width = 0
        End If

        ' Move Mags

        fraMoveMags.Width = tabBook.Width - 20
        fraMoveMags.Height = tabBook.Height - 42

        lvwTorrentMags.Width = (fraMoveMags.Width - 28) / 2
        lvwBooksMags.Width = lvwTorrentMags.Width

        lvwTorrentMags.Columns(0).Width = lvwTorrentMags.Width - ((lvwTorrentMags.Columns(1).Width + lvwTorrentMags.Columns(2).Width) + 20)
        lvwBooksMags.Columns(0).Width = lvwTorrentMags.Columns(0).Width '  lvwBooksMags.Width - 270

        lvwTorrentMags.Height = (fraMoveMags.Height - 65) / 2
        lvwBooksMags.Height = lvwTorrentMags.Height

        lvwBooksMags.Left = lvwTorrentMags.Left + lvwTorrentMags.Width + 6

        accTorrentPDF.Height = lvwTorrentMags.Height
        accTorrentPDF.Top = lvwTorrentMags.Top + lvwTorrentMags.Height + 7

        accBooksPDF.Left = lvwBooksMags.Left
        accBooksPDF.Height = accTorrentPDF.Height
        accBooksPDF.Top = accTorrentPDF.Top

        cmdTorrents_LoadPDF.Left = lvwTorrentMags.Left + lvwTorrentMags.Width - 95
        cmdTorrents_LoadPDF.Top = accTorrentPDF.Top

        cmdTorrents_LoadPDFPage0.Left = cmdTorrents_LoadPDF.Left
        cmdTorrents_LoadPDFPage0.Top = cmdTorrents_LoadPDF.Top + 30

        cmdTorrents_GSCompress.Left = cmdTorrents_LoadPDF.Left
        cmdTorrents_GSCompress.Top = cmdTorrents_LoadPDFPage0.Top + 30

        cmdTorrents_TransferFilename.Left = cmdTorrents_LoadPDF.Left
        cmdTorrents_TransferFilename.Top = cmdTorrents_GSCompress.Top + 30

        cmdTorrents_RemovePageZero.Left = cmdTorrents_LoadPDF.Left
        cmdTorrents_RemovePageZero.Top = fraMoveMags.Height - 30

        cmdTorrents_MoveMags.Left = cmdTorrents_LoadPDF.Left
        cmdTorrents_MoveMags.Top = cmdTorrents_TransferFilename.Top + 60

        cmdTorrents_MagCleanup.Left = cmdTorrents_MoveMags.Left
        cmdTorrents_MagCleanup.Top = cmdTorrents_MoveMags.Top + 60

        cmdTorrents_RemoveBrackets.Left = cmdTorrents_MagCleanup.Left
        cmdTorrents_RemoveBrackets.Top = cmdTorrents_MagCleanup.Top + 30

        cmdTorrents_DeleteMag.Left = cmdTorrents_LoadPDF.Left
        cmdTorrents_DeleteMag.Top = cmdTorrents_RemovePageZero.Top - 30

        cmdTorrents_LoadBothPage0s.Left = cmdTorrents_LoadPDF.Left
        cmdTorrents_LoadBothPage0s.Top = cmdTorrents_DeleteEmptyFolders.Top - 30

        cmdTorrents_DeleteEmptyFolders.Left = cmdTorrents_LoadPDF.Left
        cmdTorrents_DeleteEmptyFolders.Top = cmdTorrents_DeleteMag.Top - 30

        cmdBooks_LoadPDF.Left = lvwBooksMags.Left + lvwBooksMags.Width - 95
        cmdBooks_LoadPDF.Top = accBooksPDF.Top

        cmdBooks_LoadPDFPage0.Left = cmdBooks_LoadPDF.Left
        cmdBooks_LoadPDFPage0.Top = cmdTorrents_LoadPDFPage0.Top

        cmdBooks_GSCompress.Left = cmdBooks_LoadPDF.Left
        cmdBooks_GSCompress.Top = cmdTorrents_LoadPDFPage0.Top + 30

        cmdBooks_TransferFilename.Left = cmdBooks_LoadPDF.Left
        cmdBooks_TransferFilename.Top = cmdBooks_GSCompress.Top + 30

        cmdBooks_RemovePageZero.Left = cmdBooks_LoadPDF.Left
        cmdBooks_RemovePageZero.Top = cmdTorrents_RemovePageZero.Top

        cmdBooks_DeleteMag.Left = cmdBooks_LoadPDF.Left
        cmdBooks_DeleteMag.Top = cmdTorrents_DeleteMag.Top

        chkTorrents_AutoLoadPage0.Top = cmdTorrents_LoadPDFPage0.Top + 5
        chkBooks_AutoLoadPage0.Top = chkTorrents_AutoLoadPage0.Top

        cmdTorrentsForward.Left = (lvwTorrentMags.Left + lvwTorrentMags.Width) - cmdTorrentsForward.Width
        cmdTorrentsBack.Left = cmdTorrentsForward.Left - 33
        cmdLoad_MagCopier.Left = cmdTorrentsBack.Left - 56
        cmdPath_MagCopier.Left = cmdLoad_MagCopier.Left - 33

        txtPath_MagCopier.Width = txtPath_MagCopier.Left + (cmdPath_MagCopier.Left - 25)

        txtBooksPath_MagCopier.Left = lvwBooksMags.Left
        txtBooksPath_MagCopier.Width = lvwBooksMags.Width - 185

        cmdKeep.Left = txtBooksPath_MagCopier.Left + txtBooksPath_MagCopier.Width + 6
        cmdMags.Left = cmdKeep.Left + cmdKeep.Width + 6
        cmdBooksBack.Left = cmdMags.Left + cmdMags.Width + 6
        cmdBooksForward.Left = cmdBooksBack.Left + cmdBooksBack.Width + 6

        txtMagCopier_TorrentFilename.Left = accTorrentPDF.Left + accTorrentPDF.Width + 7
        txtMagCopier_TorrentFilename.Top = accTorrentPDF.Top
        txtMagCopier_TorrentFilename.Width = cmdTorrents_LoadPDF.Left - (accTorrentPDF.Left + accTorrentPDF.Width + 70)

        txtMagCopier_BooksFilename.Left = accBooksPDF.Left + accBooksPDF.Width + 7
        txtMagCopier_BooksFilename.Top = accTorrentPDF.Top
        txtMagCopier_BooksFilename.Width = txtMagCopier_TorrentFilename.Width

        lvwMagCopier_PossibleDups.Left = txtMagCopier_TorrentFilename.Left
        lvwMagCopier_PossibleDups.Width = txtMagCopier_TorrentFilename.Width + 30
        lvwMagCopier_PossibleDups.Top = chkTorrents_AutoLoadPage0.Top + 50
        lvwMagCopier_PossibleDups.Height = accTorrentPDF.Height - 100

        chkBooks_AutoLoadPage0.Left = txtMagCopier_BooksFilename.Left

        cmdTorrents_IndividualEdit.Top = txtMagCopier_TorrentFilename.Top
        cmdBooks_IndividualEdit.Top = txtMagCopier_TorrentFilename.Top

        cmdTorrents_IndividualEdit.Left = txtMagCopier_TorrentFilename.Left + txtMagCopier_TorrentFilename.Width + 5
        cmdBooks_IndividualEdit.Left = txtMagCopier_BooksFilename.Left + txtMagCopier_BooksFilename.Width + 5

        ' Edit PDF

        fraPDFEditing.Width = tabBook.Width - 20

        panPDFEditing.Width = fraPDFEditing.Width - 652
        panPDFEditing.Height = fraPDFEditing.Height - 33

        lvwPDFEditing.Columns(0).Width = lvwPDFEditing.Width - ((lvwPDFEditing.Columns(1).Width + lvwPDFEditing.Columns(2).Width) + 20)

        accPDFEditing_Main.Height = fraPDFEditing.Height - 305

        cmdPDFEditing_LoadFile.Left = cboPDFEditing_StandardTypesAfterLoad.Left
        cmdPDFEditing_Clear.Left = cmdPDFEditing_LoadFile.Left + cmdPDFEditing_LoadFile.Width + 7
        cmdPDFEditing_Clear.Top = cmdPDFEditing_LoadFile.Top
        cmdPDFEditing_Refresh.Left = cmdPDFEditing_LoadFile.Left
        cmdPDFEditing_Refresh.Top = cmdPDFEditing_LoadFile.Top + 30

        cmdPDFEditing_MovePageZero.Left = cmdPDFEditing_Refresh.Left + cmdPDFEditing_Refresh.Width + 7
        cmdPDFEditing_MovePageZero.Top = cmdPDFEditing_Refresh.Top

        cmdPDFEditing_GSCompress.Top = cmdPDFEditing_Refresh.Top + 30
        cmdPDFEditing_GSCompress.Left = cmdPDFEditing_Refresh.Left

        cmdPDFEditing_GSCompressFolder.Top = cmdPDFEditing_GSCompress.Top + 30
        cmdPDFEditing_GSCompressFolder.Left = cmdPDFEditing_GSCompress.Left

        chkPDFEditing_AutoLoadPage0.Top = cmdPDFEditing_GSCompressFolder.Top + 35

        cmdPDFEditing_Load_All_PageZeros.Top = chkPDFEditing_AutoLoadPage0.Top + 25
        cmdPDFEditing_Load_All_PageZeros.Left = cmdPDFEditing_LoadFile.Left

        chkPDFEditing_OnFolderChange_AutoLoadPage0s.Left = cmdPDFEditing_LoadFile.Left
        chkPDFEditing_OnFolderChange_AutoLoadPage0s.Top = cmdPDFEditing_Load_All_PageZeros.Top + 30

        cmdPDFEditing_DelBackups.Top = cmdPDFEditing_GSCompress.Top
        cmdPDFEditing_DelBackups.Left = cmdPDFEditing_GSCompress.Left + cmdPDFEditing_GSCompress.Width + 7

        ' Not always visible
        chkPDFEditing_StopLoad.Top = chkPDFEditing_OnFolderChange_AutoLoadPage0s.Top + 40
        chkPDFEditing_StopLoad.Left = cmdPDFEditing_LoadFile.Left

        cmdPDFEditing_LoadPDFPage0.Left = cmdPDFEditing_LoadFile.Left
        cmdPDFEditing_LoadPDFPage0.Top = chkPDFEditing_StopLoad.Top + 40

        cmdPDFEditing_RemovePageZero.Left = cmdPDFEditing_LoadFile.Left
        cmdPDFEditing_RemovePageZero.Top = cmdPDFEditing_LoadPDFPage0.Top + 30

        cmdPDFEditing_RemoveFoldersPageZeros.Left = cmdPDFEditing_RemovePageZero.Left
        cmdPDFEditing_RemoveFoldersPageZeros.Top = cmdPDFEditing_RemovePageZero.Top + 30

        cmdPDFEditing_Save.Top = accPDFEditing_Main.Height + accPDFEditing_Main.Top - 30
        cmdPDFEditing_Save.Left = cmdPDFEditing_Clear.Left

        chkPDFEditing_SaveMissingPages.Top = cmdPDFEditing_Save.Top - 15
        chkPDFEditing_SaveMissingPages.Left = cmdPDFEditing_LoadFile.Left

        lblLoadPage0Filename.Left = cmdPDFEditing_LoadFile.Left
        lblLoadPage0Filename.Top = cmdPDFEditing_LoadPDFPage0.Top - 35

        ' Magazine Finder

        fraMagazineFinder.Width = fraMoveMags.Width
        fraMagazineFinder.Height = fraMoveMags.Height

        cmdMagazineFinderProcess.Left = cboMagazineFinderWebSites.Left + cboMagazineFinderWebSites.Width + 15
        cmdMagazineFinderProcess.Top = cboMagazineFinderWebSites.Top

        cmdMagazineFinderPath.Left = txtMagazineFinderPath.Left + txtMagazineFinderPath.Width + 10
        cmdMagazineFinderPath.Top = txtMagazineFinderPath.Top

        lvwMagazineFinderURLs.Width = fraMagazineFinder.Width - lvwMagazineFinderFiles.Width - 40
        lvwMagazineFinderFiles.Height = fraMagazineFinder.Height - 110
        lvwMagazineFinderURLs.Height = lvwMagazineFinderFiles.Height

        prgMagazineFinder.Top = lvwMagazineFinderFiles.Top + lvwMagazineFinderFiles.Height + 7
        prgMagazineFinder.Left = lvwMagazineFinderFiles.Left
        prgMagazineFinder.Width = lvwMagazineFinderFiles.Width + lvwMagazineFinderURLs.Width + 18

        ' GS Comp

        fraGSComp.Width = tabBook.Width - 20
        fraGSComp.Height = tabBook.Height - 38

        lvwGSCompTab_Files.Width = (fraGSComp.Width - 20) * 0.6
        lvwGSCompTab_Files.Height = fraGSComp.Height - 60

        lvwGSCompTab_Files.Columns(0).Width = lvwGSCompTab_Files.Width - ((lvwGSCompTab_Files.Columns(1).Width + lvwGSCompTab_Files.Columns(2).Width) + 20)

        txtGSCompTab_Details.Width = (fraGSComp.Width - 20) * 0.4
        txtGSCompTab_Details.Left = lvwGSCompTab_Files.Left + lvwGSCompTab_Files.Width + 7
        txtGSCompTab_Details.Height = lvwGSCompTab_Files.Height

        ' ePubConv

        fraePubConv.Width = tabBook.Width - 20
        fraePubConv.Height = tabBook.Height - 38

        lvwePubConvTab_Files.Width = (fraePubConv.Width - 20) * 0.6
        lvwePubConvTab_Files.Height = fraePubConv.Height - 60

        lvwePubConvTab_Files.Columns(0).Width = lvwePubConvTab_Files.Width - ((lvwePubConvTab_Files.Columns(1).Width + lvwePubConvTab_Files.Columns(2).Width) + 20)

        txtePubConvTab_Details.Width = (fraGSComp.Width - 20) * 0.4
        txtePubConvTab_Details.Left = lvwePubConvTab_Files.Left + lvwePubConvTab_Files.Width + 7
        txtePubConvTab_Details.Height = lvwePubConvTab_Files.Height


    End Sub

    Private Sub cmdDupsByName_Click(sender As Object, e As EventArgs) Handles cmdDupsByName.Click

        Dim objItem As ListViewItem, strName1 As String = "", strName2 As String = ""
        Dim blnFirstFile As Boolean, objFirst As ListViewItem = Nothing
        Dim intCount As Integer

        mblnDupsByBinary = False

        frmBookManagement_Resize(Nothing, Nothing)

        If updwnMatchPercent.Value <= 0 Then

            MessageBox.Show("No match %!")
            Exit Sub
        End If

        blnFirstFile = True

        lvwFiles.SelectedItems.Clear()

        For Each objItem In lvwFiles.Items

            If blnFirstFile Then

                strName1 = objItem.SubItems(FILES_COL_NAME).Text
                objFirst = objItem
                blnFirstFile = False
            Else

                strName2 = objItem.SubItems(FILES_COL_NAME).Text

                If NamesSimilar(strName1, strName2, updwnMatchPercent.Value.ToString, True, True, True, True) Then

                    objItem.Selected = True
                    objFirst.Selected = True

                    intCount = intCount + 1
                End If

                strName1 = strName2
                objFirst = objItem
            End If
        Next

        lvwFiles.Refresh()

        Me.Text = APP_NAME & " - " & intCount & " selected"

    End Sub

    Private Sub cmdDupsByRev_Click(sender As Object, e As EventArgs) Handles cmdDupsByRev.Click

        Dim objItem As ListViewItem, strName1 As String = "", strName2 As String = ""
        Dim intCount As Integer, strReversed As String = "", intPos As Integer, strPrefix As String = ""
        Dim strFileNames(lvwFiles.Items.Count) As String
        Dim strFileNamesFilePaths(lvwFiles.Items.Count) As String
        Dim strMatches(lvwFiles.Items.Count) As String, intMatches As Integer
        Dim strMatchesFilePaths(lvwFiles.Items.Count) As String
        Dim intCount2 As Integer

        mblnDupsByBinary = False

        frmBookManagement_Resize(Nothing, Nothing)

        proProgress.Visible = True
        My.Application.DoEvents()
        proProgress.Refresh()

        If lvwFiles.Items.Count = 0 Then Exit Sub

        lvwFiles.ListViewItemSorter = Nothing

        lvwFiles.Columns(0).Text = "Name"
        lvwFiles.Columns(1).Text = "Size"
        lvwFiles.Columns(2).Text = "Folder"

        lvwFiles.SelectedItems.Clear()

        intCount = 1
        intMatches = 0

        For Each objItem In lvwFiles.Items

            strFileNames(intCount) = objItem.SubItems(FILES_COL_NAME).Text
            strFileNamesFilePaths(intCount) = objItem.SubItems(FILES_COL_PATH).Text

            intCount = intCount + 1
        Next

        proProgress.Minimum = 1
        proProgress.Maximum = strFileNames.GetUpperBound(0) - 1

        For intCount = 1 To strFileNames.GetUpperBound(0) - 1

            proProgress.Value = intCount

            My.Application.DoEvents()
            proProgress.Refresh()

            strName1 = strFileNames(intCount)

            For intCount2 = intCount + 1 To strFileNames.GetUpperBound(0)

                strName2 = strFileNames(intCount2)

                intPos = InStr(strName2, " - ")

                If InStr(strName1, " - ") > 0 And intPos > 0 Then

                    strPrefix = GetPrefix(strName2)
                    strReversed = RemovePrefix(strName2)

                    strReversed = Mid(strReversed, intPos + 2).Trim & " - " & Mid(strReversed, 1, intPos - 1).Trim & "." & strPrefix

                    If strName1 = strReversed Then ' Match

                        intMatches = intMatches + 1
                        strMatches(intMatches) = strName1
                        strMatchesFilePaths(intMatches) = strFileNamesFilePaths(intCount)

                        intMatches = intMatches + 1
                        strMatches(intMatches) = strFileNames(intCount2)
                        strMatchesFilePaths(intMatches) = strFileNamesFilePaths(intCount2)
                    End If
                End If
            Next
        Next

        If intMatches > 0 Then

            lvwFiles.Items.Clear()

            For intCount = 1 To intMatches

                objItem = lvwFiles.Items.Add(strMatches(intCount))

                objItem.SubItems.Add("") ' Size 
                objItem.SubItems.Add(strMatchesFilePaths(intCount))
            Next
        Else

            MessageBox.Show("None found!")
        End If

        lvwFiles.Refresh()

        Me.Text = APP_NAME & " - " & intMatches / 2 & " found"

        proProgress.Visible = False
        My.Application.DoEvents()

    End Sub

    Private Sub cmdCopyStructureBooks_Click(sender As Object, e As EventArgs) Handles cmdCopyStructureBooks.Click

        Dim strDir As String

        ' Copies structure of current books folder to a folder in temp allow me to allocate location of books while in work Making it easier later to manually copy them

        Me.Cursor = Cursors.WaitCursor
        cmdCopyStructureBooks.Enabled = False

        strDir = ROOT_DRIVE & "\temp\Books - " & Format(Now, "dd MMM yyyy HH mm")

        If Not CopyStructureFolders(strDir) Then

            Me.Cursor = Cursors.Default
            Exit Sub
        End If

        My.Computer.FileSystem.CreateDirectory(strDir & "\Shares")
        My.Computer.FileSystem.CreateDirectory(strDir & "\VB.Net")
        My.Computer.FileSystem.CreateDirectory(strDir & "\Health")

        Me.Cursor = Cursors.Default
        cmdCopyStructureBooks.Enabled = True

    End Sub

    Public Function CopyStructureFolders(ByVal strDir As String) As Boolean

        Dim d As DirectoryInfo
        Dim objDir As DirectoryInfo

        objDir = New DirectoryInfo(ROOT_DRIVE & "\Books")

        For Each d In objDir.GetDirectories()

            If d.Name <> "Mags" Then

                CopyStructureFolder(d, True, strDir)
            End If
        Next

        CopyStructureFolders = True

    End Function

    Private Sub cmdDupsByBinaryPatternMatching_Click(sender As Object, e As EventArgs) Handles cmdDupsByBinaryPatternMatching.Click

        Dim objA As ListViewItem, objB As ListViewItem, strPath1 As String = "", strPath2 As String = ""
        Dim intFound As Integer, intCountA As Integer, intCountB As Integer
        Dim strName1 As String = "", strName2 As String = ""
        Dim intTotal As Integer = 0, blnNewFile As Boolean, strStream As String = ""
        Dim intFileCount As Integer, strPrefix As String = ""

        Try

            mblnDupsByBinary = True

            frmBookManagement_Resize(Nothing, Nothing)

            lvwFiles.SelectedItems.Clear()
            lvwFiles.Columns(3).Text = "Binary non extact match"

            Me.Refresh()

            For Each objA In lvwFiles.Items

                If CInt(objA.SubItems(1).Text / 1000000) > DUPS_BY_BINARY_FILE_SIZE_LIMIT Then

                    objA.Remove()
                End If
            Next

            objA = Nothing

            Reset()

            intFileCount = lvwFiles.Items.Count

            For intCountA = 1 To lvwFiles.Items.Count

                objA = lvwFiles.Items(intCountA - 1)

                objA.SubItems(3).Text = ""

                For intCountB = intCountA + 1 To lvwFiles.Items.Count

                    intTotal = intTotal + 1
                Next
            Next

            objA = Nothing

            proProgress.Visible = True
            My.Application.DoEvents()
            proProgress.Refresh()

            proProgress.Minimum = 0
            proProgress.Value = 0
            proProgress.Maximum = intTotal

            System.GC.Collect()

            ' Redim array to store files in memory
            ReDim mstrFilesInMemory(intFileCount)

            mintInitial_AvailablePhysicalMemory = My.Computer.Info.AvailablePhysicalMemory

            For intCountA = 0 To lvwFiles.Items.Count - 1

                objA = lvwFiles.Items(intCountA)

                strPath1 = String.Concat(objA.SubItems(FILES_COL_PATH).Text, objA.SubItems(FILES_COL_NAME).Text)
                strName1 = objA.SubItems(FILES_COL_NAME).Text

                blnNewFile = True

                For intCountB = intCountA + 1 To lvwFiles.Items.Count - 1

                    objB = lvwFiles.Items(intCountB)

                    strPath2 = String.Concat(objB.SubItems(FILES_COL_PATH).Text, objB.SubItems(FILES_COL_NAME).Text)
                    strName2 = objB.SubItems(FILES_COL_NAME).Text

                    Me.Text = String.Concat("[", intFileCount, " files    -    ", intTotal, " comparisons]     (", intCountA + 1, ")    ", strName1, "    -    ", strName2, "    (", intCountB + 1, ")")
                    Me.Refresh()

                    If NonExact_DuplicateFile(strPath1, strPath2, blnNewFile, strStream, strPrefix, intCountA, intCountB, intFileCount) Then

                        objA.Selected = True

                        If objA.SubItems(3).Text = "" Then

                            objA.SubItems(3).Text = objB.SubItems(FILES_COL_NAME).Text
                        Else

                            objA.SubItems(3).Text = objA.SubItems(3).Text & " - " & objB.SubItems(FILES_COL_NAME).Text
                        End If
                        intFound = intFound + 1
                    End If

                    blnNewFile = False

                    If proProgress.Value < proProgress.Maximum Then

                        proProgress.Value = proProgress.Value + 1
                        proProgress.Refresh()
                    End If
                Next
            Next

            proProgress.Value = proProgress.Maximum

            lvwFiles.Refresh()

            For intCountA = 1 To lvwFiles.Items.Count

                mstrFilesInMemory(intCountA) = ""
            Next

            My.Application.DoEvents()
            ReDim mstrFilesInMemory(0)
            My.Application.DoEvents()

            Me.Text = APP_NAME & " - " & intFound & " found"

            proProgress.Visible = False
            My.Application.DoEvents()
            proProgress.Refresh()

            System.GC.Collect()

        Catch ex As Exception

            MessageBox.Show("cmdDupsByBinaryPatternMatching_Click - " & ex.ToString)
        End Try

    End Sub

    Private Sub txtPath_MagCopier_TextChanged(sender As Object, e As EventArgs) Handles txtPath_MagCopier.TextChanged

        cmdLoad_MagCopier.Enabled = (txtPath_MagCopier.Text.Trim <> "")

    End Sub

    Private Sub cmdLoad_MagCopier_Click(sender As Object, e As EventArgs) Handles cmdLoad_MagCopier.Click

        Cursor = Cursors.WaitCursor

        LoadFiles_TorrentMags(txtPath_MagCopier.Text)

        If mblnMagCopier_UseBooksFolder Then

            LoadFiles_BooksMags(txtBooksPath_MagCopier.Text)
        Else

            LoadFiles_BooksMags(txtPath_MagCopier.Text)
        End If

        Reset_MagCopier()

        If mblnLookForFiles Then

            If lvwTorrentMags.Items.Count > 0 Then

                mblnLookForFiles = False
            Else

                cmdTorrentsForward_Click(Nothing, Nothing)
            End If
        End If

        LoadMagCopier_PossibleDups()

    End Sub

    Private Sub cmdPath_MagCopier_Click(sender As Object, e As EventArgs) Handles cmdPath_MagCopier.Click

        Me.Text = APP_NAME

        FolderBrowserDialog1.RootFolder = Environment.SpecialFolder.MyComputer

        If txtPath_MagCopier.Text = "" Then

            FolderBrowserDialog1.SelectedPath = ROOT_DRIVE & "\_Torrent\Completed\_Magazines"
        Else

            FolderBrowserDialog1.SelectedPath = txtPath_MagCopier.Text
        End If

        If FolderBrowserDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then

            If FolderBrowserDialog1.SelectedPath <> "" Then

                txtPath_MagCopier.Text = Mid(FolderBrowserDialog1.SelectedPath, 1, 1).ToLower & Mid(FolderBrowserDialog1.SelectedPath, 2)
                LoadFiles_TorrentMags(txtPath_MagCopier.Text)

                Reset_MagCopier()
            End If

        End If

    End Sub

    Sub LoadFiles_TorrentMags(ByVal strPath As String, Optional ByVal strExtension As String = "")

        Dim objItem As ListViewItem, blnAdd As Boolean
        Dim strType As String, strAllTypes As String = "", strUniqueTypes() As String, intCount As Integer

        Me.Text = APP_NAME

        lvwTorrentMags.Items.Clear()

        If strPath.Trim = "" Then

            MessageBox.Show("Enter path!")
            Exit Sub
        End If

        If Not My.Computer.FileSystem.DirectoryExists(strPath) Then Exit Sub

        Dim objDir As New DirectoryInfo(strPath)

        If strExtension = "" Then

            strExtension = "*.*"
        Else

            strExtension = "*" & strExtension
        End If

        blnAdd = True

        Try

            For Each objFile As FileInfo In objDir.GetFiles(strExtension)

                strType = objFile.Extension.ToLower

                If strType = ".pdf" Then

                    blnAdd = True
                Else

                    blnAdd = False
                End If

                If blnAdd Then

                    objItem = lvwTorrentMags.Items.Add(objFile.Name)

                    strPath = GetPath(objFile.FullName)

                    If InStr(strAllTypes, strType & ",", CompareMethod.Text) = 0 Then

                        strAllTypes = strAllTypes & strType & ","
                    End If

                    objItem.SubItems.Add(GetFileSizeInMB_UsingSize(objFile.Length))
                    objItem.SubItems.Add(objFile.Length)
                    'objItem.SubItems.Add(strPath)
                End If
            Next

        Catch ex As Exception

            MessageBox.Show(ex.Message)
        End Try

        strUniqueTypes = Split(strAllTypes, ",")

        cboUniqueTypes.Items.Clear()

        For intCount = strUniqueTypes.GetLowerBound(0) To strUniqueTypes.GetUpperBound(0)

            cboUniqueTypes.Items.Add(strUniqueTypes(intCount))
        Next

        Dim objE As New ColumnClickEventArgs(COL_NAME_OTHER_LISTVIEWS)

        lvwTorrentMags_ColumnClick(Nothing, objE)

        lvwTorrentMags.Columns(0).Text = "Name - " & lvwTorrentMags.Items.Count & " file(s)"

    End Sub

    Private Sub LoadFiles_BooksMags(ByVal strPath As String, Optional ByVal strExtension As String = "")

        Dim objItem As ListViewItem, blnAdd As Boolean
        Dim strType As String, strAllTypes As String = "", strUniqueTypes() As String, intCount As Integer

        Me.Text = APP_NAME

        lvwBooksMags.Items.Clear()

        If Mid(strPath, 1, 33) = ROOT_DRIVE & "\_Torrent\Completed\_Magazines\" Then

            strPath = strPath.Replace(ROOT_DRIVE & "\_Torrent\Completed\_Magazines\", ROOT_DRIVE & "\Books\Mags\")
            txtBooksPath_MagCopier.Text = strPath

        ElseIf mblnMagCopier_UseBooksFolder Then

            ' Do nothing
        Else

            txtBooksPath_MagCopier.Text = ""
            Exit Sub
        End If

        If strPath.Trim = "" Then

            MessageBox.Show("Enter path!")
            Exit Sub
        End If

        If Not My.Computer.FileSystem.DirectoryExists(strPath) Then

            txtBooksPath_MagCopier.Text = ""
            Exit Sub
        End If


        Dim objDir As New DirectoryInfo(strPath)

        If strExtension = "" Then

            strExtension = "*.*"
        Else

            strExtension = "*" & strExtension
        End If

        blnAdd = True

        Try

            For Each objFile As FileInfo In objDir.GetFiles(strExtension)

                strType = objFile.Extension.ToLower

                If strType = ".pdf" Then

                    blnAdd = True
                Else

                    blnAdd = False
                End If

                If blnAdd Then

                    objItem = lvwBooksMags.Items.Add(objFile.Name)

                    strPath = GetPath(objFile.FullName)

                    If InStr(strAllTypes, strType & ",", CompareMethod.Text) = 0 Then

                        strAllTypes = strAllTypes & strType & ","
                    End If

                    objItem.SubItems.Add(GetFileSizeInMB_UsingSize(objFile.Length))
                    objItem.SubItems.Add(objFile.Length)
                    'objItem.SubItems.Add(strPath)
                End If
            Next

        Catch ex As Exception

            MessageBox.Show(ex.Message)
        End Try

        strUniqueTypes = Split(strAllTypes, ",")

        cboUniqueTypes.Items.Clear()

        For intCount = strUniqueTypes.GetLowerBound(0) To strUniqueTypes.GetUpperBound(0)

            cboUniqueTypes.Items.Add(strUniqueTypes(intCount))
        Next

        Dim objE As New ColumnClickEventArgs(COL_NAME_OTHER_LISTVIEWS)

        lvwTorrentMags_ColumnClick(Nothing, objE)

        lvwBooksMags.Columns(0).Text = "Name - " & lvwBooksMags.Items.Count & " file(s)"

    End Sub

    Private Sub lvwTorrentMags_Click(sender As Object, e As EventArgs) Handles lvwTorrentMags.Click

        If lvwTorrentMags.SelectedItems.Count = 1 Then txtMagCopier_TorrentFilename.Text = lvwTorrentMags.SelectedItems(0).Text

        If chkTorrents_AutoLoadPage0.Checked Then

            cmdTorrents_LoadPDFPage0_Click(Nothing, Nothing)
        End If

        cmdBooks_TransferFilename.Enabled = (lvwBooksMags.SelectedItems.Count = 1 And lvwTorrentMags.SelectedItems.Count = 1)
        cmdTorrents_TransferFilename.Enabled = cmdBooks_TransferFilename.Enabled

        EnableIndividualEditButtons()

    End Sub

    Private Sub lvwTorrentMags_ColumnClick(sender As Object, e As ColumnClickEventArgs) Handles lvwTorrentMags.ColumnClick

        ' Get the new sorting column.
        Dim objListview As ListView, objColumnHeader As ColumnHeader

        objListview = lvwFiles
        objColumnHeader = mobjColumn_TorrentMags

        Dim new_sorting_column As ColumnHeader = objListview.Columns(e.Column)

        ' Figure out the new sorting order.
        Dim sort_order As System.Windows.Forms.SortOrder

        If objColumnHeader Is Nothing Then

            ' New column. Sort ascending.
            sort_order = SortOrder.Ascending
        Else

            ' See if this is the same column.
            If new_sorting_column.Equals(objColumnHeader) Then

                ' Same column. Switch the sort order.
                If objColumnHeader.Text.EndsWith(" >") Then

                    sort_order = SortOrder.Descending
                Else

                    sort_order = SortOrder.Ascending
                End If
            Else

                ' New column. Sort ascending.
                sort_order = SortOrder.Ascending
            End If

            ' Remove the old sort indicator.
            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, Len(objColumnHeader.Text) - 2)
        End If

        ' Display the new sort order.
        objColumnHeader = new_sorting_column

        If Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " >" Or Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " <" Then

            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, objColumnHeader.Text.Length - 2)
        End If

        If sort_order = SortOrder.Ascending Then

            objColumnHeader.Text = String.Concat(objColumnHeader.Text, " >")
        Else

            objColumnHeader.Text = String.Concat(objColumnHeader.Text, " <")
        End If

        mobjColumn_TorrentMags = objColumnHeader

        ' Create a comparer.
        objListview.ListViewItemSorter = New ListViewComparer(e.Column, sort_order)

        ' Sort.
        objListview.Sort()

    End Sub

    Private Function FirstTorrentsMagsFolder() As String

        Dim objDir As New DirectoryInfo(TORRENT_MAGAZINES)
        Dim objSubDir As DirectoryInfo, objSubSubDir() As DirectoryInfo, intCount As Integer

        FirstTorrentsMagsFolder = ""

        If objDir.GetDirectories().Count = 0 Then

            FirstTorrentsMagsFolder = TORRENT_MAGAZINES
        Else

            For Each objSubDir In objDir.GetDirectories

                objSubSubDir = objSubDir.GetDirectories()

                For intCount = 0 To objSubSubDir.Length - 1

                    If objSubSubDir(intCount).GetFiles().Count > 0 Then

                        FirstTorrentsMagsFolder = objSubSubDir(intCount).FullName
                        Exit Function
                    End If
                Next
            Next
        End If

    End Function

    Private Function FirstBooksMagsFolder() As String

        Dim objDir As New DirectoryInfo(ROOT_DRIVE & "\Books\Mags")
        Dim objSubDir As DirectoryInfo, objSubSubDir() As DirectoryInfo, intCount As Integer

        FirstBooksMagsFolder = ""

        If objDir.GetDirectories().Count = 0 Then

            FirstBooksMagsFolder = ROOT_DRIVE & "\_Torrent\Completed\_Magazines"
        Else

            For Each objSubDir In objDir.GetDirectories

                objSubSubDir = objSubDir.GetDirectories()

                For intCount = 0 To objSubSubDir.Length - 1

                    If objSubSubDir(intCount).GetFiles().Count > 0 Then

                        FirstBooksMagsFolder = objSubSubDir(intCount).FullName
                        Exit Function
                    End If
                Next
            Next
        End If

    End Function

    Private Sub tabBook_SelectedIndexChanged(sender As Object, e As EventArgs) Handles tabBook.SelectedIndexChanged

        Dim intFileCount As Integer

        frmBookManagement_Resize(Nothing, Nothing)

        If tabBook.SelectedIndex = 1 Then

            If txtPath_MagCopier.Text <> "" Then

                cmdLoad_MagCopier_Click(Nothing, Nothing)
            End If

            DisableMagCopierButtons(True)

        ElseIf tabBook.SelectedIndex = 2 And Not mblnPDFEDitingFirstLoad Then

            If txtPath_PDFEditing.Text <> "" Then

                cmdLoad_PDFEditing_Click(Nothing, Nothing)
            End If

            GetCountOfFilesInFolder(TORRENT_REMOVEPAGEZERO_BACKUPS, "*.pdf", intFileCount)

            If intFileCount > 0 Then

                fraPDFEditing.Text = "PDF Editing - " & intFileCount & " files are in 50 Assorted Magazines\Keep\RemovePageZero\Backups"
            End If

            mblnPDFEDitingFirstLoad = True
        End If

    End Sub

    Private Sub cmdTorrents_LoadPDF_Click(sender As Object, e As EventArgs) Handles cmdTorrents_LoadPDF.Click

        Dim strFile As String

        If lvwTorrentMags.SelectedItems.Count = 0 And lvwTorrentMags.Items.Count > 0 Then

            lvwTorrentMags.Items(0).Selected = True
        Else

            If lvwTorrentMags.Items.Count = 0 Then

                txtErrors.Text = "No file selected!"
                tmrClearError.Enabled = True
                Exit Sub
            End If
        End If

        strFile = lvwTorrentMags.SelectedItems(0).Text

        If strFile = lvwTorrentMags.Tag Then Exit Sub

        txtMagCopier_TorrentFilename.Text = strFile

        Cursor = Cursors.WaitCursor

        DisableMagCopierButtons(False)

        accTorrentPDF.LoadFile(txtPath_MagCopier.Text & "\" & strFile)

        DisableMagCopierButtons(True)

        lvwTorrentMags.Tag = strFile

        Cursor = Cursors.Default

    End Sub

    Private Sub cmdBooks_LoadPDF_Click(sender As Object, e As EventArgs) Handles cmdBooks_LoadPDF.Click

        Dim strFile As String, strPath As String

        If lvwBooksMags.SelectedItems.Count = 0 And lvwBooksMags.Items.Count > 0 Then

            lvwBooksMags.Items(0).Selected = True
        Else

            If lvwBooksMags.Items.Count = 0 Then

                txtErrors.Text = "No file selected!"
                tmrClearError.Enabled = True
                Exit Sub
            End If
        End If

        strFile = lvwBooksMags.SelectedItems(0).Text

        If strFile = lvwBooksMags.Tag Then Exit Sub

        DisableMagCopierButtons(False)

        txtMagCopier_BooksFilename.Text = strFile

        Cursor = Cursors.WaitCursor

        strPath = txtPath_MagCopier.Text.Replace(ROOT_DRIVE & "\_Torrent\Completed\_Magazines\", ROOT_DRIVE & "\Books\Mags\")

        accBooksPDF.LoadFile(strPath & "\" & strFile)

        DisableMagCopierButtons(True)

        lvwBooksMags.Tag = strFile

        Cursor = Cursors.Default

    End Sub

    Private Sub lvwTorrentMags_DoubleClick(sender As Object, e As EventArgs) Handles lvwTorrentMags.DoubleClick

        cmdTorrents_LoadPDFPage0_Click(Nothing, Nothing)

    End Sub

    Private Sub lvwTorrentMags_KeyDown(sender As Object, e As KeyEventArgs) Handles lvwTorrentMags.KeyDown

        If e.KeyCode = Keys.Enter Then

            cmdTorrents_LoadPDFPage0_Click(Nothing, Nothing)
        End If

    End Sub



    Private Sub cmdKeep_Click(sender As Object, e As EventArgs) Handles cmdKeep.Click

        txtPath_MagCopier.Text = ROOT_DRIVE & "\_Torrent\Completed\50 Assorted Magazines\Keep"

        cmdLoad_MagCopier_Click(Nothing, Nothing)

    End Sub

    Private Sub cmdMags_Click(sender As Object, e As EventArgs) Handles cmdMags.Click

        txtPath_MagCopier.Text = FirstTorrentsMagsFolder()

        cmdLoad_MagCopier_Click(Nothing, Nothing)

    End Sub

    Private Sub cmdTorrents_RemovePageZero_Click(sender As Object, e As EventArgs) Handles cmdTorrents_RemovePageZero.Click

        Dim strFile As String

        If lvwTorrentMags.SelectedItems.Count = 0 Then

            txtErrors.Text = "No file selected!"
            tmrClearError.Enabled = True
            Exit Sub
        End If

        Cursor = Cursors.WaitCursor

        strFile = lvwTorrentMags.SelectedItems(0).Text

        If GetPrefix(strFile).ToUpper <> "PDF" Then

            Exit Sub
        End If

        DisableMagCopierButtons(False)

        pdfSharp_RemovePageZero_FromFileInPlace(txtPath_MagCopier.Text & "\" & strFile)

        accTorrentPDF.LoadFile(txtPath_MagCopier.Text & "\" & strFile)

        DisableMagCopierButtons(True)

        Cursor = Cursors.Default

    End Sub

    Private Sub cmdBooks_RemovePageZero_Click(sender As Object, e As EventArgs) Handles cmdBooks_RemovePageZero.Click

        Dim strFile As String

        If lvwBooksMags.SelectedItems.Count = 0 Then

            txtErrors.Text = "No file selected!"
            tmrClearError.Enabled = True
            Exit Sub
        End If

        Cursor = Cursors.WaitCursor

        strFile = lvwBooksMags.SelectedItems(0).Text

        If GetPrefix(strFile).ToUpper <> "PDF" Then

            Exit Sub
        End If

        DisableMagCopierButtons(False)

        pdfSharp_RemovePageZero_FromFileInPlace(txtBooksPath_MagCopier.Text & "\" & strFile)

        accBooksPDF.LoadFile(txtBooksPath_MagCopier.Text & "\" & strFile)

        DisableMagCopierButtons(True)

        Cursor = Cursors.Default

    End Sub

    Private Sub cmdTorrentsForward_Click(sender As Object, e As EventArgs) Handles cmdTorrentsForward.Click

        Dim objFolder As New DirectoryInfo(txtPath_MagCopier.Text)
        Dim colFolders() As DirectoryInfo
        Dim strPath As String, strNextPath As String

        mblnLookForFiles = True

        colFolders = objFolder.GetDirectories()

        If colFolders.Length <> 0 Then

            txtPath_MagCopier.Text = colFolders(0).FullName
            cmdLoad_MagCopier_Click(Nothing, Nothing)

            DisableMagCopierButtons(False)
        Else

            strPath = RemoveOneLevelAndSlash(txtPath_MagCopier.Text)

            Dim objParentFolder As New DirectoryInfo(strPath)

            strNextPath = FindNextFolder(objParentFolder.FullName, txtPath_MagCopier.Text)

            If strNextPath <> "" Then

                txtPath_MagCopier.Text = strNextPath
                cmdLoad_MagCopier_Click(Nothing, Nothing)
                DisableMagCopierButtons(True)
            Else

                strPath = RemoveOneLevelAndSlash(objParentFolder.FullName)

                strNextPath = FindNextFolder(strPath, objParentFolder.FullName)

                If strNextPath <> "" Then

                    txtPath_MagCopier.Text = strNextPath
                    cmdLoad_MagCopier_Click(Nothing, Nothing)
                    DisableMagCopierButtons(True)
                Else

                    strPath = RemoveOneLevelAndSlash(objParentFolder.FullName)

                    strNextPath = FindNextFolder(strPath, objParentFolder.FullName)

                End If

            End If
        End If

    End Sub

    Private Sub cmdTorrentsBack_Click(sender As Object, e As EventArgs) Handles cmdTorrentsBack.Click

        Dim objFolder As New DirectoryInfo(txtPath_MagCopier.Text)
        Dim strFolders() As DirectoryInfo
        Dim strPath As String, strNextPath As String

        mblnLookForFiles = True

        strFolders = objFolder.GetDirectories()

        If strFolders.Length = 0 Then

            strPath = RemoveOneLevelAndSlash(txtPath_MagCopier.Text)

            Dim objParentFolder As New DirectoryInfo(strPath)

            strNextPath = FindPrevFolder(objParentFolder.FullName, txtPath_MagCopier.Text)

            If strNextPath <> "" Then

                txtPath_MagCopier.Text = strNextPath
                cmdLoad_MagCopier_Click(Nothing, Nothing)

            Else

                strPath = RemoveOneLevelAndSlash(objParentFolder.FullName)

                strNextPath = FindPrevFolder(strPath, objParentFolder.FullName)

                If strNextPath <> "" Then

                    txtPath_MagCopier.Text = strNextPath
                    cmdLoad_MagCopier_Click(Nothing, Nothing)

                Else

                    strPath = RemoveOneLevelAndSlash(objParentFolder.FullName)

                    strNextPath = FindPrevFolder(strPath, objParentFolder.FullName)

                End If

            End If
        Else

            txtPath_MagCopier.Text = strFolders(0).FullName
            cmdLoad_MagCopier_Click(Nothing, Nothing)
        End If

    End Sub

    Private Sub cmdBooksForward_Click(sender As Object, e As EventArgs) Handles cmdBooksForward.Click

        Dim objFolder As New DirectoryInfo(txtBooksPath_MagCopier.Text)
        Dim colFolders() As DirectoryInfo
        Dim strPath As String, strNextPath As String

        mblnLookForFiles = True

        colFolders = objFolder.GetDirectories()

        If colFolders.Length <> 0 Then

            txtBooksPath_MagCopier.Text = colFolders(0).FullName
            cmdLoad_MagCopier_Click(Nothing, Nothing)
        Else

            strPath = RemoveOneLevelAndSlash(txtBooksPath_MagCopier.Text)

            Dim objParentFolder As New DirectoryInfo(strPath)

            strNextPath = FindNextFolder(objParentFolder.FullName, txtBooksPath_MagCopier.Text)

            If strNextPath <> "" Then

                txtBooksPath_MagCopier.Text = strNextPath

                mblnMagCopier_UseBooksFolder = True
                cmdLoad_MagCopier_Click(Nothing, Nothing)
                mblnMagCopier_UseBooksFolder = False
            Else

                strPath = RemoveOneLevelAndSlash(objParentFolder.FullName)

                strNextPath = FindNextFolder(strPath, objParentFolder.FullName)

                If strNextPath <> "" Then

                    txtBooksPath_MagCopier.Text = strNextPath

                    mblnMagCopier_UseBooksFolder = True
                    cmdLoad_MagCopier_Click(Nothing, Nothing)
                    mblnMagCopier_UseBooksFolder = False
                Else

                    strPath = RemoveOneLevelAndSlash(objParentFolder.FullName)

                    strNextPath = FindNextFolder(strPath, objParentFolder.FullName)

                End If

            End If
        End If

    End Sub

    Private Sub cmdBooksBack_Click(sender As Object, e As EventArgs) Handles cmdBooksBack.Click

        Dim objFolder As New DirectoryInfo(txtBooksPath_MagCopier.Text)
        Dim strFolders() As DirectoryInfo
        Dim strPath As String, strNextPath As String

        mblnLookForFiles = True

        strFolders = objFolder.GetDirectories()

        If strFolders.Length = 0 Then

            strPath = RemoveOneLevelAndSlash(txtBooksPath_MagCopier.Text)

            Dim objParentFolder As New DirectoryInfo(strPath)

            strNextPath = FindPrevFolder(objParentFolder.FullName, txtBooksPath_MagCopier.Text)

            If strNextPath <> "" Then

                txtBooksPath_MagCopier.Text = strNextPath

                mblnMagCopier_UseBooksFolder = True
                cmdLoad_MagCopier_Click(Nothing, Nothing)
                mblnMagCopier_UseBooksFolder = False
            Else

                strPath = RemoveOneLevelAndSlash(objParentFolder.FullName)

                strNextPath = FindPrevFolder(strPath, objParentFolder.FullName)

                If strNextPath <> "" Then

                    txtBooksPath_MagCopier.Text = strNextPath

                    mblnMagCopier_UseBooksFolder = True
                    cmdLoad_MagCopier_Click(Nothing, Nothing)
                    mblnMagCopier_UseBooksFolder = False
                Else

                    strPath = RemoveOneLevelAndSlash(objParentFolder.FullName)

                    strNextPath = FindPrevFolder(strPath, objParentFolder.FullName)
                End If

            End If
        Else

            txtBooksPath_MagCopier.Text = strFolders(0).FullName

            mblnMagCopier_UseBooksFolder = True
            cmdLoad_MagCopier_Click(Nothing, Nothing)
            mblnMagCopier_UseBooksFolder = False
        End If

    End Sub

    Private Sub PDFEditing_Load(ByVal strFile As String)

        Dim strPath As String = ""
        Dim intCount As Integer = 0, intTotal As Integer = 0, strFilename As String = "", strPrefix As String = "", intCount2 As Integer = 0
        Dim intLoop As Integer = 0, strText As String = ""

        If lvwPDFEditing.SelectedItems.Count = 0 Then Exit Sub

        If strFile = lvwPDFEditing.Tag Then Exit Sub

        strPrefix = GetPrefix(strFile)

        If strPrefix.ToUpper <> "PDF" Then Exit Sub

        strFilename = RemovePrefix(strFile)

        lvwPDFEditing.Enabled = False

        Cursor = Cursors.WaitCursor

        RemoveAnyPDFEditingPages()

        strPath = txtPath_PDFEditing.Text

        intTotal = pdfSharp_SplitPDF(strPath & "\" & strFile)

        If cboPDFEditing_Pages.SelectedIndex <> -1 Then cboPDFEditing_Pages.SelectedIndex = 0

        mintPDFEditing_PageCount = 1
        mintPDFEditing_TotalPageCount = intTotal
        mintPDFEditing_LineItem = 1
        mintPDFEditing_Y = 5

        mintFirstPDFLoaded = 99999
        mintLastPDFLoaded = 0

        mstrPDFEditing_PDFSAdded = ""

        RemoveAnyPDFEditingPages()

        If chkPDFEditing_AutoApplyStandard.Checked And mintPDFEditing_TotalPageCount > 25 Then

            For intLoop = 5 To cboPDFEditing_StandardTypesDuringLoad.Items.Count - 1

                strText = cboPDFEditing_StandardTypesDuringLoad.Items(intLoop).ToString & " - "

                If strText <> "" Then

                    If Mid(strFilename, 1, Len(strText)).ToUpper = strText.ToUpper Then

                        cboPDFEditing_StandardTypesDuringLoad.Text = strText
                        Exit For
                    End If
                End If

                If mblnStopPDFLoad Then

                    Exit Sub
                End If

                My.Application.DoEvents()
            Next
        End If

        mstrPDFEditing_File = ROOT_DRIVE & "\_Torrent\Completed\50 Assorted Magazines\Keep\RemovePageZero\Backups\SinglePages\" & strFilename & "_XXXYYYZZZ.pdf"

        Select Case cboPDFEditing_StandardTypesDuringLoad.Text

            Case "SELECT ALL - LOAD TOP 1/3"

                fraPDFEditing.Text = "Loading pages - 1 to " & (mintPDFEditing_TotalPageCount \ 3)

            Case "SELECT ALL - LOAD MID 1/3"

                fraPDFEditing.Text = "Loading pages - " & (mintPDFEditing_TotalPageCount \ 3) + 1 & " to " & (mintPDFEditing_TotalPageCount \ 3) * 2

            Case "SELECT ALL - LOAD BOT 1/3"

                fraPDFEditing.Text = "Loading pages - " & ((mintPDFEditing_TotalPageCount \ 3) * 2) + 1 & " +"

        End Select

        cboPDFEditing_Pages.Items.Add(" ")

        ' Load pages
        For intCount = 1 To intTotal

            LoadNextPage(strFilename, intCount)

            For intCount2 = 1 To 10

                My.Application.DoEvents()
                Sleep(10)
                My.Application.DoEvents()
            Next

            Me.Text = "Loading " & intCount & " of " & intTotal
            Me.Refresh()

            cboPDFEditing_Pages.Items.Add(intCount)

            If mblnStopPDFLoad Then

                Exit For
            End If
        Next

        mintPDFEditing_PageCount = mintPDFEditing_PageCount - 1

        PDFEditing_Load_PostProcess()

        lvwPDFEditing.Enabled = True

        lvwPDFEditing.Tag = strFile

        Cursor = Cursors.Default

        My.Application.DoEvents()

        panPDFEditing.Refresh()

        My.Application.DoEvents()

        Me.Refresh()

        My.Application.DoEvents()

        Me.Text = APP_NAME

    End Sub

    Public Sub PDFEditing_Load_PostProcess()

        Dim intCount As Integer, intCount2 As Integer
        Dim strName1 As String, strName2 As String, strName3 As String, strName4 As String, strName5 As String
        Dim intLinesRemoved As Integer = 0, intMoveUp As Integer
        Dim strCurrentLabels As String = ""

        ' From Top
        For intCount = 1 To mintPDFEditing_PageCount Step 5

            strName1 = "pdf" & intCount & ","
            strName2 = "pdf" & (intCount + 1) & ","
            strName3 = "pdf" & (intCount + 2) & ","
            strName4 = "pdf" & (intCount + 3) & ","
            strName5 = "pdf" & (intCount + 4) & ","

            If InStr(mstrPDFEditing_PDFSAdded, strName1) = 0 And InStr(mstrPDFEditing_PDFSAdded, strName2) = 0 And
               InStr(mstrPDFEditing_PDFSAdded, strName3) = 0 And InStr(mstrPDFEditing_PDFSAdded, strName4) = 0 And
               InStr(mstrPDFEditing_PDFSAdded, strName5) = 0 Then

                panPDFEditing.Controls.RemoveByKey("lbl" & intCount)
                intLinesRemoved = intLinesRemoved + 1
            Else

                Exit For
            End If
        Next

        If intLinesRemoved > 0 Then

            intMoveUp = PDFEDITING_PDF_SPACING_DOWNWARDS * intLinesRemoved

            For intCount2 = 1 To intLinesRemoved

                panPDFEditing.Controls.RemoveByKey("lbl" & intCount2)
            Next

            For intCount2 = 0 To panPDFEditing.Controls.Count - 1

                If Mid(panPDFEditing.Controls(intCount2).Name, 1, 3) = "lbl" Then

                    strCurrentLabels = strCurrentLabels & panPDFEditing.Controls(intCount2).Name & ","
                End If
            Next

            For intCount2 = 1 To mintPDFEditing_PageCount

                strName1 = "pdf" & intCount2 & ","

                If InStr(mstrPDFEditing_PDFSAdded, strName1) > 0 Then

                    panPDFEditing.Controls("pdf" & intCount2).Top = panPDFEditing.Controls("pdf" & intCount2).Top - intMoveUp
                    panPDFEditing.Controls("chk" & intCount2).Top = panPDFEditing.Controls("chk" & intCount2).Top - intMoveUp
                End If

                If (intCount Mod 5.0) = 1 Then

                    strName1 = "lbl" & intCount2

                    If InStr(strCurrentLabels, strName1 & ",") > 0 Then

                        panPDFEditing.Controls(strName1).Top = panPDFEditing.Controls(strName1).Top - intMoveUp
                    End If
                End If
            Next
        End If

        For intCount2 = 0 To panPDFEditing.Controls.Count - 1

            If intCount2 < panPDFEditing.Controls.Count - 1 Then

                If Mid(panPDFEditing.Controls(intCount2).Name, 1, 3) = "lbl" Then

                    If intCount2 > mintLastPDFLoaded Then

                        panPDFEditing.Controls.RemoveAt(intCount2)
                    End If
                End If
            End If
        Next

    End Sub

    Private Sub txtPath_PDFEditing_TextChanged(sender As Object, e As EventArgs) Handles txtPath_PDFEditing.TextChanged

        cmdLoad_PDFEditing.Enabled = (txtPath_PDFEditing.Text.Trim <> "")

    End Sub

    Private Sub cmdPath_PDFEditing_Click(sender As Object, e As EventArgs) Handles cmdPath_PDFEditing.Click

        Me.Text = APP_NAME

        FolderBrowserDialog1.RootFolder = Environment.SpecialFolder.MyComputer

        If txtPath_PDFEditing.Text = "" Then

            FolderBrowserDialog1.SelectedPath = ROOT_DRIVE & "\_Torrent\Completed\_Magazines"
        Else

            FolderBrowserDialog1.SelectedPath = txtPath_PDFEditing.Text
        End If

        If FolderBrowserDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then

            If FolderBrowserDialog1.SelectedPath <> "" Then

                txtPath_PDFEditing.Text = Mid(FolderBrowserDialog1.SelectedPath, 1, 1).ToLower & Mid(FolderBrowserDialog1.SelectedPath, 2)
                LoadFiles_PDFEditing(txtPath_PDFEditing.Text)

                Reset_PDFEditing()
            End If

        End If

    End Sub

    Private Sub cmdLoad_PDFEditing_Click(sender As Object, e As EventArgs) Handles cmdLoad_PDFEditing.Click

        If txtPath_PDFEditing.Text = "" Then Exit Sub

        Cursor = Cursors.WaitCursor

        LoadFiles_PDFEditing(txtPath_PDFEditing.Text)

        Reset_PDFEditing()

        If mblnLookForFiles Then

            If lvwPDFEditing.Items.Count > 0 Then

                mblnLookForFiles = False
                mblnLookForFilesBackwards = False
            Else

                If mblnLookForFilesBackwards Then

                    cmdPDFEditingBack_Click(Nothing, Nothing)
                Else

                    cmdPDFEditingForward_Click(Nothing, Nothing)
                End If
            End If
        End If

        RemoveAnyPDFEditingPages()

    End Sub

    Private Sub cmdPDFEditingForward_Click(sender As Object, e As EventArgs) Handles cmdPDFEditingForward.Click

        If txtPath_PDFEditing.Text = "" Then Exit Sub

        Dim objFolder As New DirectoryInfo(txtPath_PDFEditing.Text)
        Dim colFolders() As DirectoryInfo
        Dim strPath As String, strNextPath As String

        mblnLookForFiles = True

        colFolders = objFolder.GetDirectories()

        If colFolders.Length <> 0 Then

            txtPath_PDFEditing.Text = colFolders(0).FullName
            cmdLoad_PDFEditing_Click(Nothing, Nothing)
        Else

            strPath = RemoveOneLevelAndSlash(txtPath_PDFEditing.Text)

            Dim objParentFolder As New DirectoryInfo(strPath)

            strNextPath = FindNextFolder(objParentFolder.FullName, txtPath_PDFEditing.Text)

            If strNextPath <> "" Then

                txtPath_PDFEditing.Text = strNextPath
                cmdLoad_PDFEditing_Click(Nothing, Nothing)
            Else

                strPath = RemoveOneLevelAndSlash(objParentFolder.FullName)

                strNextPath = FindNextFolder(strPath, objParentFolder.FullName)

                If strNextPath <> "" Then

                    txtPath_PDFEditing.Text = strNextPath
                    cmdLoad_PDFEditing_Click(Nothing, Nothing)
                Else

                    strPath = RemoveOneLevelAndSlash(objParentFolder.FullName)

                    strNextPath = FindNextFolder(strPath, objParentFolder.FullName)
                End If

            End If
        End If

        My.Application.DoEvents()
        Me.Refresh()
        My.Application.DoEvents()

        If chkPDFEditing_OnFolderChange_AutoLoadPage0s.Checked Then

            cmdPDFEditing_Load_All_PageZeros_Click(Nothing, Nothing)
        End If

    End Sub

    Private Sub cmdPDFEditingBack_Click(sender As Object, e As EventArgs) Handles cmdPDFEditingBack.Click

        If txtPath_PDFEditing.Text = "" Then Exit Sub

        Dim objFolder As New DirectoryInfo(txtPath_PDFEditing.Text)
        Dim strFolders() As DirectoryInfo
        Dim strPath As String, strNextPath As String

        mblnLookForFiles = True
        mblnLookForFilesBackwards = True

        strFolders = objFolder.GetDirectories()

        If strFolders.Length = 0 Then

            strPath = RemoveOneLevelAndSlash(txtPath_PDFEditing.Text)

            Dim objParentFolder As New DirectoryInfo(strPath)

            strNextPath = FindPrevFolder(objParentFolder.FullName, txtPath_PDFEditing.Text)

            If strNextPath <> "" Then

                txtPath_PDFEditing.Text = strNextPath
                cmdLoad_PDFEditing_Click(Nothing, Nothing)
            Else

                strPath = RemoveOneLevelAndSlash(objParentFolder.FullName)

                strNextPath = FindPrevFolder(strPath, objParentFolder.FullName)

                If strNextPath <> "" Then

                    txtPath_PDFEditing.Text = strNextPath
                    cmdLoad_PDFEditing_Click(Nothing, Nothing)
                Else

                    strPath = RemoveOneLevelAndSlash(objParentFolder.FullName)

                    strNextPath = FindPrevFolder(strPath, objParentFolder.FullName)
                End If

            End If
        Else

            txtPath_PDFEditing.Text = strFolders(0).FullName
            cmdLoad_PDFEditing_Click(Nothing, Nothing)
        End If

        My.Application.DoEvents()
        Me.Refresh()
        My.Application.DoEvents()

        If chkPDFEditing_OnFolderChange_AutoLoadPage0s.Checked Then

            cmdPDFEditing_Load_All_PageZeros_Click(Nothing, Nothing)
        End If

    End Sub

    Sub LoadFiles_PDFEditing(ByVal strPath As String, Optional ByVal strExtension As String = "")

        Dim objItem As ListViewItem, blnAdd As Boolean
        Dim strType As String, strAllTypes As String = "", strUniqueTypes() As String, intCount As Integer

        Me.Text = APP_NAME

        lvwPDFEditing.Items.Clear()

        If strPath.Trim = "" Then

            MessageBox.Show("Enter path!")
            Exit Sub
        End If

        If Not My.Computer.FileSystem.DirectoryExists(strPath) Then Exit Sub

        Dim objDir As New DirectoryInfo(strPath)

        If strExtension = "" Then

            strExtension = "*.*"
        Else

            strExtension = "*" & strExtension
        End If

        blnAdd = True

        Try

            For Each objFile As FileInfo In objDir.GetFiles(strExtension)

                strType = objFile.Extension.ToLower

                If strType = ".pdf" Then

                    blnAdd = True
                Else

                    blnAdd = False
                End If

                If blnAdd Then

                    objItem = lvwPDFEditing.Items.Add(objFile.Name)

                    strPath = GetPath(objFile.FullName)

                    If InStr(strAllTypes, strType & ",", CompareMethod.Text) = 0 Then

                        strAllTypes = strAllTypes & strType & ","
                    End If

                    objItem.SubItems.Add(GetFileSizeInMB_UsingSize(objFile.Length))
                    objItem.SubItems.Add(objFile.Length)
                    objItem.SubItems.Add(strPath)
                End If
            Next

        Catch ex As Exception

            MessageBox.Show(ex.Message)
        End Try

        strUniqueTypes = Split(strAllTypes, ",")

        cboUniqueTypes.Items.Clear()

        For intCount = strUniqueTypes.GetLowerBound(0) To strUniqueTypes.GetUpperBound(0)

            cboUniqueTypes.Items.Add(strUniqueTypes(intCount))
        Next

        Dim objE As New ColumnClickEventArgs(COL_NAME_OTHER_LISTVIEWS)

        lvwPDFEditing_ColumnClick(Nothing, objE)

    End Sub

    Private Sub lvwPDFEditing_ColumnClick(sender As Object, e As ColumnClickEventArgs) Handles lvwPDFEditing.ColumnClick

        ' Get the new sorting column.
        Dim objListview As ListView, objColumnHeader As ColumnHeader

        objListview = lvwFiles
        objColumnHeader = mobjColumn_PDFEditing

        Dim new_sorting_column As ColumnHeader = objListview.Columns(e.Column)

        ' Figure out the new sorting order.
        Dim sort_order As System.Windows.Forms.SortOrder

        If objColumnHeader Is Nothing Then

            ' New column. Sort ascending.
            sort_order = SortOrder.Ascending
        Else

            ' See if this is the same column.
            If new_sorting_column.Equals(objColumnHeader) Then

                ' Same column. Switch the sort order.
                If objColumnHeader.Text.EndsWith(" >") Then

                    sort_order = SortOrder.Descending
                Else

                    sort_order = SortOrder.Ascending
                End If
            Else

                ' New column. Sort ascending.
                sort_order = SortOrder.Ascending
            End If

            ' Remove the old sort indicator.
            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, Len(objColumnHeader.Text) - 2)
        End If

        ' Display the new sort order.
        objColumnHeader = new_sorting_column

        If Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " >" Or Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " <" Then

            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, objColumnHeader.Text.Length - 2)
        End If

        If sort_order = SortOrder.Ascending Then

            objColumnHeader.Text = String.Concat(objColumnHeader.Text, " >")
        Else

            objColumnHeader.Text = String.Concat(objColumnHeader.Text, " <")
        End If

        mobjColumn_PDFEditing = objColumnHeader

        ' Create a comparer.
        objListview.ListViewItemSorter = New ListViewComparer(e.Column, sort_order)

        ' Sort.
        objListview.Sort()

    End Sub

    Private Sub LoadNextPage(ByVal strName As String, ByVal intCount As Integer)

        Dim intPDFWidth As Integer
        Dim strFile As String
        Dim lbl As Label
        Dim strPDFName As String, strChkName As String, intCount2 As Integer

        ' I can exit straight away for some

        Select Case cboPDFEditing_StandardTypesDuringLoad.Text

            Case SELECT_ALL_LOAD_FIRST_QUARTER

                If intCount > Math.Round((mintPDFEditing_TotalPageCount \ 4)) Then

                    Exit Sub
                End If

            Case SELECT_ALL_LOAD_SECOND_QUARTER

                If intCount > Math.Round((mintPDFEditing_TotalPageCount \ 4) * 2) Then

                    Exit Sub
                End If

            Case SELECT_ALL_LOAD_THIRD_QUARTER

                If intCount > Math.Round((mintPDFEditing_TotalPageCount \ 4) * 3) Then

                    Exit Sub
                End If
        End Select

        strPDFName = "pdf" & mintPDFEditing_PageCount
        strChkName = "chk" & mintPDFEditing_PageCount

        intPDFWidth = 200

        If mintPDFEditing_LineItem = 1 Then

            mintPDFEditing_X = 10

            If mintPDFEditing_PageCount > 2 Then

                mintPDFEditing_Y = mintPDFEditing_Y + PDFEDITING_PDF_SPACING_DOWNWARDS
            End If

            lbl = New Label
            lbl.Name = "lbl" & intCount
            lbl.Location = New System.Drawing.Point(mintPDFEditing_X + intPDFWidth + 3, mintPDFEditing_Y + 17)
            lbl.Text = intCount
            lbl.AutoSize = True

            panPDFEditing.Controls.Add(lbl)

            mintPDFEditing_LineItem = mintPDFEditing_LineItem + 1

        ElseIf mintPDFEditing_LineItem = 2 Then

            mintPDFEditing_X = 255  ' Diff is 245 across each time
            mintPDFEditing_Y = mintPDFEditing_Y

            mintPDFEditing_LineItem = mintPDFEditing_LineItem + 1

        ElseIf mintPDFEditing_LineItem = 3 Then

            mintPDFEditing_X = 500
            mintPDFEditing_Y = mintPDFEditing_Y

            mintPDFEditing_LineItem = mintPDFEditing_LineItem + 1

        ElseIf mintPDFEditing_LineItem = 4 Then

            mintPDFEditing_X = 745
            mintPDFEditing_Y = mintPDFEditing_Y

            mintPDFEditing_LineItem = mintPDFEditing_LineItem + 1

        ElseIf mintPDFEditing_LineItem = 5 Then

            mintPDFEditing_X = 990
            mintPDFEditing_Y = mintPDFEditing_Y

            mintPDFEditing_LineItem = 1
        End If

        For intCount2 = 1 To 10

            My.Application.DoEvents()
        Next

        strFile = ROOT_DRIVE & "\_Torrent\Completed\50 Assorted Magazines\Keep\RemovePageZero\Backups\SinglePages\" & strName & "_" & mintPDFEditing_PageCount & ".pdf"

        Select Case cboPDFEditing_StandardTypesDuringLoad.Text

            Case UNSELECT_ALL_LOAD_ALL

                AddPDF(strPDFName, strFile, intPDFWidth)
                AddCHK(strChkName, intPDFWidth, False)

            Case SELECT_ALL_LOAD_ALL

                AddPDF(strPDFName, strFile, intPDFWidth)
                AddCHK(strChkName, intPDFWidth, True)

            Case SELECT_ALL_LOAD_FIRST_QUARTER

                If intCount <= Math.Round((mintPDFEditing_TotalPageCount \ 4)) Then

                    AddPDF(strPDFName, strFile, intPDFWidth)
                    AddCHK(strChkName, intPDFWidth, True)
                End If

            Case SELECT_ALL_LOAD_SECOND_QUARTER

                If (intCount > Math.Round(mintPDFEditing_TotalPageCount \ 4)) And (intCount <= Math.Round((mintPDFEditing_TotalPageCount \ 4) * 2)) Then

                    AddPDF(strPDFName, strFile, intPDFWidth)
                    AddCHK(strChkName, intPDFWidth, True)
                End If

            Case SELECT_ALL_LOAD_THIRD_QUARTER

                If (intCount > Math.Round(mintPDFEditing_TotalPageCount \ 4) * 2) And (intCount <= Math.Round((mintPDFEditing_TotalPageCount \ 4) * 3)) Then

                    AddPDF(strPDFName, strFile, intPDFWidth)
                    AddCHK(strChkName, intPDFWidth, True)
                End If

            Case SELECT_ALL_LOAD_FOURTH_QUARTER

                If intCount > Math.Round((mintPDFEditing_TotalPageCount \ 4) * 3) Then

                    AddPDF(strPDFName, strFile, intPDFWidth)
                    AddCHK(strChkName, intPDFWidth, True)
                End If

            Case SUNDAY

                Select Case mintPDFEditing_PageCount

                    Case SUNDAY_START To SUNDAY_END

                        If mintPDFEditing_PageCount < SUNDAY_START_CHECKED Or mintPDFEditing_PageCount > SUNDAY_END_CHECKED Then

                            AddPDF(strPDFName, strFile, intPDFWidth)
                            AddCHK(strChkName, intPDFWidth, False)
                        Else

                            AddPDF(strPDFName, strFile, intPDFWidth)
                            AddCHK(strChkName, intPDFWidth, True)
                        End If
                End Select

            Case SATURDAY

                Select Case mintPDFEditing_PageCount

                    Case SATURDAY_START To SATURDAY_END

                        If mintPDFEditing_PageCount < SATURDAY_START_CHECKED Or mintPDFEditing_PageCount > SATURDAY_END_CHECKED Then

                            AddPDF(strPDFName, strFile, intPDFWidth)
                            AddCHK(strChkName, intPDFWidth, False)

                        Else

                            AddPDF(strPDFName, strFile, intPDFWidth)
                            AddCHK(strChkName, intPDFWidth, True)
                        End If
                End Select

            Case "SE7EN"

                Select Case mintPDFEditing_PageCount

                    Case 1, 4

                        AddPDF(strPDFName, strFile, intPDFWidth)
                        AddCHK(strChkName, intPDFWidth, False)

                    Case 2 To 3

                        AddPDF(strPDFName, strFile, intPDFWidth)
                        AddCHK(strChkName, intPDFWidth, True)

                End Select

            Case "FARMERS WEEKLY"

                Select Case mintPDFEditing_PageCount

                    Case 45, 60

                        AddPDF(strPDFName, strFile, intPDFWidth)
                        AddCHK(strChkName, intPDFWidth, False)

                    Case 46 To 59

                        AddPDF(strPDFName, strFile, intPDFWidth)
                        AddCHK(strChkName, intPDFWidth, True)

                End Select

            Case SUNDAY_TIMES

                Select Case mintPDFEditing_PageCount

                    Case SUNDAY_TIMES_START To SUNDAY_TIMES_END

                        If mintPDFEditing_PageCount < SUNDAY_TIMES_START_CHECKED Or mintPDFEditing_PageCount > SUNDAY_TIMES_END_CHECKED Then

                            AddPDF(strPDFName, strFile, intPDFWidth)
                            AddCHK(strChkName, intPDFWidth, False)
                        Else

                            AddPDF(strPDFName, strFile, intPDFWidth)
                            AddCHK(strChkName, intPDFWidth, True)
                        End If
                End Select

            Case TIMES

                Select Case mintPDFEditing_PageCount

                    Case TIMES_START To TIMES_END

                        If mintPDFEditing_PageCount < TIMES_START_CHECKED Or mintPDFEditing_PageCount > TIMES_END_CHECKED Then

                            AddPDF(strPDFName, strFile, intPDFWidth)
                            AddCHK(strChkName, intPDFWidth, False)
                        Else

                            AddPDF(strPDFName, strFile, intPDFWidth)
                            AddCHK(strChkName, intPDFWidth, True)
                        End If
                End Select

            Case TOP_SANTE

                Select Case mintPDFEditing_PageCount

                    Case TOP_SANTE_START To TOP_SANTE_END

                        If mintPDFEditing_PageCount < TOP_SANTE_START_CHECKED Or mintPDFEditing_PageCount > TOP_SANTE_END_CHECKED Then

                            AddPDF(strPDFName, strFile, intPDFWidth)
                            AddCHK(strChkName, intPDFWidth, False)
                        Else

                            AddPDF(strPDFName, strFile, intPDFWidth)
                            AddCHK(strChkName, intPDFWidth, True)
                        End If
                End Select

        End Select

        For intCount2 = 1 To 10

            My.Application.DoEvents()
        Next

        mintPDFEditing_PageCount = mintPDFEditing_PageCount + 1

        lbl = Nothing

    End Sub

    Private Sub AddCHK(ByVal strCHKName As String, ByVal intPDFWidth As Integer, ByVal blnChecked As Boolean)

        Dim chk As New CheckBox
        chk.Name = strCHKName
        chk.Location = New System.Drawing.Point(mintPDFEditing_X + intPDFWidth + 4, mintPDFEditing_Y)
        chk.Size = New System.Drawing.Size(30, 17)
        chk.Checked = False

        panPDFEditing.Controls.Add(chk)

        chk.Checked = blnChecked

        chk = Nothing

    End Sub

    Private Sub AddPDF(ByVal strPDFName As String, ByVal strFile As String, ByVal intPDFWidth As Integer)

        Dim pdf As New AxAcroPDFLib.AxAcroPDF

        If mintFirstPDFLoaded > mintPDFEditing_PageCount Then

            mintFirstPDFLoaded = mintPDFEditing_PageCount
        End If

        If mintPDFEditing_PageCount > mintLastPDFLoaded Then

            mintLastPDFLoaded = mintPDFEditing_PageCount
        End If

        pdf.Name = strPDFName
        pdf.Size = New System.Drawing.Size(intPDFWidth, 230)
        pdf.Location = New System.Drawing.Point(mintPDFEditing_X, mintPDFEditing_Y)
        pdf.Tag = strFile

        panPDFEditing.Controls.Add(pdf)

        mstrPDFEditing_PDFSAdded = mstrPDFEditing_PDFSAdded & strPDFName & ","

        pdf.LoadFile(strFile)

        pdf = Nothing

    End Sub

    Private Sub RemoveAnyPDFEditingPages()

        Dim blnRefresh As Boolean

        While panPDFEditing.Controls.Count > 1

            If panPDFEditing.Controls(0).Name <> "txtPDFEDiting_FolderGSCompression" Then

                panPDFEditing.Controls(0).Dispose()

                blnRefresh = True

            ElseIf panPDFEditing.Controls(1).Name <> "txtPDFEDiting_FolderGSCompression" And panPDFEditing.Controls.Count > 1 Then

                panPDFEditing.Controls(1).Dispose()
                blnRefresh = True
            End If

        End While

        If blnRefresh Then panPDFEditing.Refresh()

        System.GC.Collect()

    End Sub

    Private Sub cmdKeep_PDFEditing_Click(sender As Object, e As EventArgs) Handles cmdKeep_PDFEditing.Click

        txtPath_PDFEditing.Text = ROOT_DRIVE & "\_Torrent\Completed\50 Assorted Magazines\Keep"

        cmdLoad_PDFEditing_Click(Nothing, Nothing)

    End Sub

    Private Sub cmdMags_PDFEditing_Click(sender As Object, e As EventArgs) Handles cmdMags_PDFEditing.Click

        txtPath_PDFEditing.Text = FirstTorrentsMagsFolder()

        cmdLoad_PDFEditing_Click(Nothing, Nothing)

    End Sub

    Private Sub cboPDFEditing_Pages_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboPDFEditing_Pages.SelectedIndexChanged

        Dim strFile As String

        If cboPDFEditing_Pages.SelectedItem.ToString = " " Then Exit Sub

        strFile = mstrPDFEditing_File.Replace("XXXYYYZZZ", cboPDFEditing_Pages.SelectedItem.ToString)

        accPDFEditing_Main.LoadFile(strFile)

    End Sub

    Private Sub cboPDFEditing_TypesAfterLoad_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboPDFEditing_StandardTypesAfterLoad.SelectedIndexChanged

        Dim intCount As Integer, objChk As CheckBox

        Select Case cboPDFEditing_StandardTypesAfterLoad.SelectedItem.ToString

            Case UNSELECT_ALL

                For intCount = 1 To mintPDFEditing_PageCount

                    objChk = panPDFEditing.Controls("chk" & intCount)

                    If Not objChk Is Nothing Then objChk.Checked = False
                Next

            Case SELECT_ALL

                For intCount = 1 To mintPDFEditing_PageCount

                    objChk = panPDFEditing.Controls("chk" & intCount)

                    If Not objChk Is Nothing Then objChk.Checked = True
                Next

            Case SUNDAY

                For intCount = 1 To mintPDFEditing_PageCount

                    objChk = panPDFEditing.Controls("chk" & intCount)

                    Select Case intCount

                        Case SUNDAY_START To SUNDAY_END

                            If intCount < SUNDAY_START_CHECKED Or intCount > SUNDAY_END_CHECKED Then

                                If Not objChk Is Nothing Then objChk.Checked = True
                            Else

                                If Not objChk Is Nothing Then objChk.Checked = False
                            End If

                        Case Else : If Not objChk Is Nothing Then objChk.Checked = False
                    End Select
                Next

            Case SATURDAY

                For intCount = 1 To mintPDFEditing_PageCount

                    objChk = panPDFEditing.Controls("chk" & intCount)

                    Select Case intCount

                        Case SATURDAY_START To SATURDAY_END

                            If intCount < SATURDAY_START_CHECKED Or intCount > SATURDAY_END_CHECKED Then

                                If Not objChk Is Nothing Then objChk.Checked = False
                            Else

                                If Not objChk Is Nothing Then objChk.Checked = False
                            End If

                        Case Else : If Not objChk Is Nothing Then objChk.Checked = False

                    End Select
                Next

            Case "SE7EN"

                For intCount = 1 To mintPDFEditing_PageCount

                    objChk = panPDFEditing.Controls("chk" & intCount)

                    Select Case intCount

                        Case 2 To 4

                            If Not objChk Is Nothing Then objChk.Checked = True

                        Case Else

                            If Not objChk Is Nothing Then objChk.Checked = False
                    End Select
                Next

            Case "FARMERS WEEKLY"

                For intCount = 1 To mintPDFEditing_PageCount

                    objChk = panPDFEditing.Controls("chk" & intCount)

                    Select Case intCount

                        Case 45 To 57

                            If Not objChk Is Nothing Then objChk.Checked = True

                        Case Else

                            If Not objChk Is Nothing Then objChk.Checked = False
                    End Select
                Next

            Case SUNDAY_TIMES

                For intCount = 1 To mintPDFEditing_PageCount

                    objChk = panPDFEditing.Controls("chk" & intCount)

                    Select Case intCount

                        Case SUNDAY_TIMES_START To SUNDAY_TIMES_END

                            If intCount < SUNDAY_TIMES_START_CHECKED Or intCount > SUNDAY_TIMES_END_CHECKED Then

                                If Not objChk Is Nothing Then objChk.Checked = True
                            Else

                                If Not objChk Is Nothing Then objChk.Checked = False
                            End If

                        Case Else : If Not objChk Is Nothing Then objChk.Checked = False
                    End Select
                Next

            Case TIMES

                For intCount = 1 To mintPDFEditing_PageCount

                    objChk = panPDFEditing.Controls("chk" & intCount)

                    Select Case intCount

                        Case TIMES_START To TIMES_END

                            If intCount < TIMES_START_CHECKED Or intCount > TIMES_END_CHECKED Then

                                If Not objChk Is Nothing Then objChk.Checked = True
                            Else

                                If Not objChk Is Nothing Then objChk.Checked = False
                            End If

                        Case Else : If Not objChk Is Nothing Then objChk.Checked = False
                    End Select
                Next

            Case TOP_SANTE

                For intCount = 1 To mintPDFEditing_PageCount

                    objChk = panPDFEditing.Controls("chk" & intCount)

                    Select Case intCount

                        Case TOP_SANTE_START To TOP_SANTE_END

                            If intCount < TOP_SANTE_START_CHECKED Or intCount > TOP_SANTE_END_CHECKED Then

                                If Not objChk Is Nothing Then objChk.Checked = True
                            Else

                                If Not objChk Is Nothing Then objChk.Checked = False
                            End If

                        Case Else : If Not objChk Is Nothing Then objChk.Checked = False
                    End Select
                Next

        End Select

    End Sub

    Private Sub cmdPDFEditing_Save_Click(sender As Object, e As EventArgs) Handles cmdPDFEditing_Save.Click

        Dim strPages As String = "", intCount As Integer, objChk As CheckBox
        Dim blnChecked As Boolean

        If chkPDFEditing_SaveMissingPages.Checked = False Then

            If MessageBox.Show("Save will not save any missing pages! Proceed?", "Missing Pages", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.No Then

                Exit Sub
            End If
        End If

        Cursor = Cursors.WaitCursor

        EnableDisablePDFEditingButtons(False)

        For intCount = 1 To mintPDFEditing_TotalPageCount

            Try

                objChk = panPDFEditing.Controls("chk" & intCount)

                If objChk Is Nothing Then

                    blnChecked = chkPDFEditing_SaveMissingPages.Checked
                Else

                    blnChecked = objChk.Checked
                End If

            Catch ex As Exception

                blnChecked = chkPDFEditing_SaveMissingPages.Checked
            End Try

            strPages = strPages & blnChecked & ","
        Next

        pdfSharp_RemovePages_FromFileInPlace(txtPath_PDFEditing.Text & "\" & lvwPDFEditing.SelectedItems(0).Text, strPages)

        RemoveAnyPDFEditingPages()

        lvwPDFEditing.Tag = ""

        cmdLoad_PDFEditing_Click(Nothing, Nothing)

        EnableDisablePDFEditingButtons(True)

        Cursor = Cursors.Default

    End Sub

    Private Sub cmdPDFEditing_LoadFile_Click(sender As Object, e As EventArgs) Handles cmdPDFEditing_LoadFile.Click

        mblnStopPDFLoad = False

        If lvwPDFEditing.SelectedItems.Count = 0 And lvwPDFEditing.Items.Count > 0 Then

            lvwPDFEditing.Items(0).Selected = True
        Else

            If lvwPDFEditing.Items.Count = 0 Then

                txtErrors.Text = "No file selected!"
                tmrClearError.Enabled = True
                Exit Sub
            End If
        End If

        Cursor = Cursors.WaitCursor

        chkPDFEditing_SaveMissingPages.Checked = True

        Me.Text = My.Application.Info.ProductName & " - Starting"
        Me.fraPDFEditing.Text = "PDF Editing - Starting"

        My.Application.DoEvents()

        chkPDFEditing_StopLoad.Visible = True
        chkPDFEditing_StopLoad.Refresh()

        My.Application.DoEvents()

        EnableDisablePDFEditingButtons(False)

        lvwPDFEditing.Tag = ""

        Me.Text = My.Application.Info.ProductName & " - Removing Pages"
        Me.fraPDFEditing.Text = "PDF Editing - Removing Pages"

        RemoveAnyPDFEditingPages()

        accPDFEditing_Main.LoadFile("")

        Me.Text = My.Application.Info.ProductName & " - Loading - Start"
        Me.fraPDFEditing.Text = "PDF Editing - Loading - Start"

        PDFEditing_Load(lvwPDFEditing.SelectedItems(0).Text)

        Me.Text = My.Application.Info.ProductName & " - Loading - End"
        Me.fraPDFEditing.Text = "PDF Editing - Loading - End"

        EnableDisablePDFEditingButtons(True)

        mstrMessageType = PDF_EDITING
        tmrClearMessages.Enabled = True

        Cursor = Cursors.Default

    End Sub

    Private Sub cmdPDFEditing_Clear_Click(sender As Object, e As EventArgs) Handles cmdPDFEditing_Clear.Click

        RemoveAnyPDFEditingPages()

        cmdPDFEditing_Save.Enabled = False

        Me.Refresh()

        System.GC.Collect()

    End Sub

    Private Sub cmdPDFEditing_Refresh_Click(sender As Object, e As EventArgs) Handles cmdPDFEditing_Refresh.Click

        Dim objC As Control

        EnableDisablePDFEditingButtons(False)

        My.Application.DoEvents()

        For Each objC In panPDFEditing.Controls

            objC.Refresh()
        Next

        panPDFEditing.Refresh()

        My.Application.DoEvents()

        panPDFEditing.Update()

        EnableDisablePDFEditingButtons(True)

    End Sub

    Private Sub cmdPDFEditing_GSCompress_Click(sender As Object, e As EventArgs) Handles cmdPDFEditing_GSCompress.Click

        Dim strFile As String, strMessage As String = ""

        If lvwPDFEditing.SelectedItems.Count = 0 Then

            txtErrors.Text = "No file selected!"
            tmrClearError.Enabled = True
            Exit Sub
        End If

        EnableDisablePDFEditingButtons(False)

        strFile = ProperisePath(txtPath_PDFEditing.Text) & lvwPDFEditing.SelectedItems(0).Text

        If GSCompressFile_CheckSuitable(strFile, strMessage, False) Then

            If GSCompressFile(strFile) Then

                cmdLoad_PDFEditing_Click(Nothing, Nothing)
            End If
        Else

            MessageBox.Show(strMessage)
        End If

        EnableDisablePDFEditingButtons(True)

    End Sub

    Private Sub EnableDisablePDFEditingButtons(ByVal blnEnable As Boolean)

        cmdPDFEditing_LoadFile.Enabled = blnEnable

        cmdPDFEditing_GSCompress.Enabled = blnEnable
        cmdPDFEditing_GSCompressFolder.Enabled = blnEnable

        cmdPDFEditing_LoadPDFPage0.Enabled = blnEnable
        cmdPDFEditing_RemovePageZero.Enabled = blnEnable
        cmdPDFEditing_RemoveFoldersPageZeros.Enabled = blnEnable
        cmdPDFEditing_Load_All_PageZeros.Enabled = blnEnable
        chkPDFEditing_AutoLoadPage0.Enabled = blnEnable
        chkPDFEditing_OnFolderChange_AutoLoadPage0s.Enabled = blnEnable

        cmdPDFEditing_Clear.Enabled = blnEnable
        cmdPDFEditing_Refresh.Enabled = blnEnable

        cmdPDFEditing_MovePageZero.Enabled = blnEnable

        chkPDFEditing_SaveMissingPages.Enabled = blnEnable

        lblLoadPage0Filename.Enabled = blnEnable

        If panPDFEditing.Controls.Count > 1 Then

            cmdPDFEditing_Save.Enabled = blnEnable
        Else

            cmdPDFEditing_Save.Enabled = False
        End If

    End Sub

    Private Sub cmdPDFEditing_GSCompressFolder_Click(sender As Object, e As EventArgs) Handles cmdPDFEditing_GSCompressFolder.Click

        Dim strFile As String, strMessage As String = ""
        Dim objItem As ListViewItem, strInfoMessages As String = ""
        Dim blnDoSelected As Boolean = False, blnDoItem As Boolean = False, blnEndLoop As Boolean = False

        If lvwPDFEditing.Items.Count = 0 Then

            txtErrors.Text = "No file selected!"
            tmrClearError.Enabled = True
            Exit Sub
        End If

        txtPDFEDiting_FolderGSCompression.Left = 0
        txtPDFEDiting_FolderGSCompression.Top = 0
        txtPDFEDiting_FolderGSCompression.Width = panPDFEditing.Width - 10
        txtPDFEDiting_FolderGSCompression.Height = panPDFEditing.Height - 10
        txtPDFEDiting_FolderGSCompression.Text = ""

        txtPDFEDiting_FolderGSCompression.Visible = True

        EnableDisablePDFEditingButtons(False)

        If lvwPDFEditing.SelectedItems.Count > 0 Then

            blnDoSelected = True
        End If

        For Each objItem In lvwPDFEditing.Items

            If blnDoSelected And objItem.Selected Then

                blnDoItem = True

            ElseIf blnDoSelected And Not objItem.Selected Then

                blnDoItem = False
            Else

                blnDoItem = True
            End If

            If blnDoItem Then

                strFile = ProperisePath(txtPath_PDFEditing.Text) & objItem.Text

                My.Application.DoEvents()

                If GSCompressFile_CheckSuitable(strFile, strMessage, blnEndLoop) Then

                    If blnEndLoop Then Exit For

                    txtPDFEDiting_FolderGSCompression.Text = txtPDFEDiting_FolderGSCompression.Text & strFile & " is next" & vbCrLf

                    My.Application.DoEvents()
                    txtPDFEDiting_FolderGSCompression.Refresh()

                    My.Application.DoEvents()

                    GSCompressFile(strFile, False, strInfoMessages)

                    My.Application.DoEvents()
                    txtPDFEDiting_FolderGSCompression.Refresh()

                    txtPDFEDiting_FolderGSCompression.Text = txtPDFEDiting_FolderGSCompression.Text & strInfoMessages & vbCrLf

                    txtPDFEDiting_FolderGSCompression.Refresh()
                    My.Application.DoEvents()
                Else

                    My.Application.DoEvents()
                    txtPDFEDiting_FolderGSCompression.Refresh()

                    txtPDFEDiting_FolderGSCompression.Text = txtPDFEDiting_FolderGSCompression.Text & strFile & " is not suitable" & vbCrLf

                    txtPDFEDiting_FolderGSCompression.Refresh()
                    My.Application.DoEvents()
                End If

                My.Application.DoEvents()

                txtPDFEDiting_FolderGSCompression.Text = txtPDFEDiting_FolderGSCompression.Text & vbCrLf

                My.Application.DoEvents()

                txtPDFEDiting_FolderGSCompression.Refresh()
            End If
        Next

        cmdLoad_PDFEditing_Click(Nothing, Nothing)

        EnableDisablePDFEditingButtons(True)

        PlaySound(ROOT_DRIVE & "\VB.Net\My Projects\_Sounds\CompressionComplete.mp3")

        MessageBox.Show("Finished!")

        txtPDFEDiting_FolderGSCompression.Visible = False
        txtPDFEDiting_FolderGSCompression.Text = ""

    End Sub

    Private Sub cmdTorrents_LoadPDFPage0_Click(sender As Object, e As EventArgs) Handles cmdTorrents_LoadPDFPage0.Click

        Dim strFile As String, strPath As String = ""

        If lvwTorrentMags.SelectedItems.Count = 0 And lvwTorrentMags.Items.Count > 0 Then

            lvwTorrentMags.Items(0).Selected = True
        Else

            If lvwTorrentMags.Items.Count = 0 Then

                txtErrors.Text = "No file selected!"
                tmrClearError.Enabled = True
                Exit Sub
            End If
        End If

        strFile = lvwTorrentMags.SelectedItems(0).Text

        If strFile = lvwTorrentMags.Tag Then Exit Sub

        txtMagCopier_TorrentFilename.Text = strFile

        DisableMagCopierButtons(False)

        Cursor = Cursors.WaitCursor

        strPath = ProperisePath(txtPath_MagCopier.Text)

        If pdfSharp_CreateATempPage0(strPath & strFile, "Torrents") Then

            accTorrentPDF.LoadFile(ROOT_DRIVE & "\_Torrent\Completed\50 Assorted Magazines\Keep\RemovePageZero\Backups\Temp_PageZeros\Torrents_page0.pdf")

            lvwTorrentMags.Tag = strFile
        End If

        DisableMagCopierButtons(True)

        Cursor = Cursors.Default

    End Sub

    Private Sub cmdBooks_LoadPDFPage0_Click(sender As Object, e As EventArgs) Handles cmdBooks_LoadPDFPage0.Click

        Dim strFile As String, strPath As String = ""

        If lvwBooksMags.SelectedItems.Count = 0 And lvwBooksMags.Items.Count > 0 Then

            lvwBooksMags.Items(0).Selected = True
        Else

            If lvwBooksMags.Items.Count = 0 Then

                txtErrors.Text = "No file selected!"
                tmrClearError.Enabled = True
                Exit Sub
            End If
        End If

        strFile = lvwBooksMags.SelectedItems(0).Text

        If strFile = lvwBooksMags.Tag Then Exit Sub

        DisableMagCopierButtons(False)

        txtMagCopier_BooksFilename.Text = strFile

        Cursor = Cursors.WaitCursor

        strPath = ProperisePath(txtBooksPath_MagCopier.Text)

        If pdfSharp_CreateATempPage0(strPath & strFile, "BOOKS") Then

            accBooksPDF.LoadFile(ROOT_DRIVE & "\_Torrent\Completed\50 Assorted Magazines\Keep\RemovePageZero\Backups\Temp_PageZeros\Books_page0.pdf")

            lvwBooksMags.Tag = strFile
        End If

        DisableMagCopierButtons(True)

        Cursor = Cursors.Default

    End Sub

    Private Sub lvwBooksMags_Click(sender As Object, e As EventArgs) Handles lvwBooksMags.Click

        If lvwBooksMags.SelectedItems.Count = 1 Then txtMagCopier_BooksFilename.Text = lvwBooksMags.SelectedItems(0).Text

        If chkBooks_AutoLoadPage0.Checked Then

            cmdBooks_LoadPDFPage0_Click(Nothing, Nothing)
        End If

        cmdBooks_TransferFilename.Enabled = (lvwBooksMags.SelectedItems.Count = 1 And lvwTorrentMags.SelectedItems.Count = 1)
        cmdTorrents_TransferFilename.Enabled = cmdBooks_TransferFilename.Enabled

        EnableIndividualEditButtons()

    End Sub

    Private Sub lvwBooksMags_DoubleClick(sender As Object, e As EventArgs) Handles lvwBooksMags.DoubleClick

        cmdBooks_LoadPDFPage0_Click(Nothing, Nothing)

    End Sub

    Private Sub lvwBooksMags_KeyDown(sender As Object, e As KeyEventArgs) Handles lvwBooksMags.KeyDown

        If e.KeyCode = Keys.Enter Then

            cmdBooks_LoadPDFPage0_Click(Nothing, Nothing)
        End If

    End Sub

    Private Sub cmdPDFEditing_RemovePageZero_Click(sender As Object, e As EventArgs) Handles cmdPDFEditing_RemovePageZero.Click

        Dim strFile As String, intCount As Integer

        If lvwPDFEditing.SelectedItems.Count = 0 Or txtPath_PDFEditing.Text.Trim = "" Then

            Exit Sub
        End If

        Cursor = Cursors.WaitCursor

        EnableDisablePDFEditingButtons(False)

        For intCount = 0 To lvwPDFEditing.SelectedItems.Count - 1

            strFile = lvwPDFEditing.SelectedItems(intCount).Text

            Me.Text = My.Application.Info.ProductName & " - " & strFile
            Me.Refresh()

            If GetPrefix(strFile).ToUpper <> "PDF" Then

                ' ignore
            Else

                RemovePageZeroFromFile(ProperisePath(txtPath_PDFEditing.Text) & strFile)
            End If
        Next

        cmdPDFEditing_LoadPDFPage0_Click(Nothing, Nothing)

        Cursor = Cursors.Default

        EnableDisablePDFEditingButtons(True)

        Me.Text = My.Application.Info.ProductName

    End Sub

    Private Sub RemovePageZeroFromFile(ByVal strPath As String)

        pdfSharp_RemovePageZero_FromFileInPlace(strPath)

        lvwPDFEditing.Tag = "XXX"  ' Make sure I Refresh 

    End Sub


    Private Sub cmdPDFEditing_LoadPDFPage0_Click(sender As Object, e As EventArgs) Handles cmdPDFEditing_LoadPDFPage0.Click

        Dim strFile As String, strPath As String = ""

        If lvwPDFEditing.SelectedItems.Count = 0 Then

            txtErrors.Text = "No file selected!"
            tmrClearError.Enabled = True
            Exit Sub
        End If

        strFile = lvwPDFEditing.SelectedItems(0).Text

        If strFile = lvwPDFEditing.Tag Then Exit Sub

        EnableDisablePDFEditingButtons(False)

        lvwPDFEditing.Enabled = False

        Cursor = Cursors.WaitCursor

        strPath = ProperisePath(txtPath_PDFEditing.Text)

        If pdfSharp_CreateATempPage0(strPath & strFile, "Torrents") Then

            accPDFEditing_Main.LoadFile(ROOT_DRIVE & "\_Torrent\Completed\50 Assorted Magazines\Keep\RemovePageZero\Backups\Temp_PageZeros\Torrents_page0.pdf")

            lvwPDFEditing.Tag = strFile
        End If

        lvwPDFEditing.Enabled = True

        Cursor = Cursors.Default

        EnableDisablePDFEditingButtons(True)

        lblLoadPage0Filename.Text = strFile

    End Sub

    Private Sub cmdBooks_PDFEditing_Click(sender As Object, e As EventArgs) Handles cmdBooks_PDFEditing.Click

        txtPath_PDFEditing.Text = FirstBooksMagsFolder()

        cmdLoad_PDFEditing_Click(Nothing, Nothing)

    End Sub

    Private Sub chkPDFEditing_StopLoad_CheckedChanged(sender As Object, e As EventArgs) Handles chkPDFEditing_StopLoad.CheckedChanged

        mblnStopPDFLoad = True

        chkPDFEditing_StopLoad.Visible = False

    End Sub

    Private Sub lvwPDFEditing_click(sender As Object, e As EventArgs) Handles lvwPDFEditing.Click

        If chkPDFEditing_AutoLoadPage0.Checked Then

            cmdPDFEditing_LoadPDFPage0_Click(Nothing, Nothing)
        End If

    End Sub

    Private Sub tmrClearError_Tick(sender As Object, e As EventArgs) Handles tmrClearError.Tick

        txtErrors.Text = ""
        tmrClearError.Enabled = False

    End Sub

    Private Sub cmdPDFEditing_Load_All_PageZeros_Click(sender As Object, e As EventArgs) Handles cmdPDFEditing_Load_All_PageZeros.Click

        Dim strFile As String, strPath As String = ""
        Dim objItem As ListViewItem, intCount As Integer = 1
        Dim objDir As DirectoryInfo, colFiles() As FileInfo, strPDFName As String = ""

        RemoveAnyPDFEditingPages()

        If lvwPDFEditing.Items.Count = 0 Then

            txtErrors.Text = "No files present!"
            tmrClearError.Enabled = True
            Exit Sub
        End If

        EnableDisablePDFEditingButtons(False)

        lvwPDFEditing.Enabled = False

        strPath = ROOT_DRIVE & "\_Torrent\Completed\50 Assorted Magazines\Keep\RemovePageZero\Backups\AllPageZeros\"

        objDir = New System.IO.DirectoryInfo(strPath)

        colFiles = objDir.GetFiles()

        For Each objFile In colFiles

            My.Computer.FileSystem.DeleteFile(objFile.FullName)
        Next

        mblnStopPDFLoad = False

        chkPDFEditing_StopLoad.Visible = True
        chkPDFEditing_StopLoad.Refresh()

        mintPDFEditing_LineItem = 1
        mintPDFEditing_Y = 5
        mintPDFEditing_PageCount = 1

        For Each objItem In lvwPDFEditing.Items

            strFile = objItem.Text

            Cursor = Cursors.WaitCursor

            strPath = ProperisePath(txtPath_PDFEditing.Text)

            If pdfSharp_CreateATempPage0(strPath & strFile, "ALLPAGEZEROS", intCount, strPDFName) Then

                LoadNextPageZero(strPDFName, RemovePath(strFile))
            Else

                Exit For
            End If

            If mblnStopPDFLoad Then Exit For

            mintPDFEditing_PageCount = mintPDFEditing_PageCount + 1
        Next

        lvwPDFEditing.Enabled = True
        lvwPDFEditing.Tag = ""

        Cursor = Cursors.Default

        EnableDisablePDFEditingButtons(True)

        chkPDFEditing_StopLoad.Visible = False
        chkPDFEditing_StopLoad.Refresh()

    End Sub

    Private Sub LoadNextPageZero(ByVal strPDFName As String, ByVal strRealPDFName As String)

        Dim pdf As New AxAcroPDFLib.AxAcroPDF
        Dim intPDFWidth As Integer, intCount2 As Integer, intPDFHeigth As Integer
        Dim lbl As Label

        intPDFWidth = 200
        intPDFHeigth = 230

        If mintPDFEditing_LineItem = 1 Then

            mintPDFEditing_X = 10

            If mintPDFEditing_PageCount > 2 Then

                mintPDFEditing_Y = mintPDFEditing_Y + 275 ' 250
            End If

            mintPDFEditing_LineItem = mintPDFEditing_LineItem + 1

        ElseIf mintPDFEditing_LineItem = 2 Then

            mintPDFEditing_X = 255  ' Diff is 245 across each time
            mintPDFEditing_Y = mintPDFEditing_Y

            mintPDFEditing_LineItem = mintPDFEditing_LineItem + 1

        ElseIf mintPDFEditing_LineItem = 3 Then

            mintPDFEditing_X = 500
            mintPDFEditing_Y = mintPDFEditing_Y

            mintPDFEditing_LineItem = mintPDFEditing_LineItem + 1

        ElseIf mintPDFEditing_LineItem = 4 Then

            mintPDFEditing_X = 745
            mintPDFEditing_Y = mintPDFEditing_Y

            mintPDFEditing_LineItem = mintPDFEditing_LineItem + 1

        ElseIf mintPDFEditing_LineItem = 5 Then

            mintPDFEditing_X = 990
            mintPDFEditing_Y = mintPDFEditing_Y

            mintPDFEditing_LineItem = 1
        End If

        For intCount2 = 1 To 10

            My.Application.DoEvents()
        Next

        pdf.Name = "PDFName" & mintPDFEditing_PageCount
        pdf.Location = New System.Drawing.Point(mintPDFEditing_X, mintPDFEditing_Y)
        pdf.Size = New System.Drawing.Size(intPDFWidth, intPDFHeigth)
        pdf.Tag = strPDFName

        panPDFEditing.Controls.Add(pdf)

        pdf.LoadFile(strPDFName)

        pdf = Nothing

        If IsOdd(mintPDFEditing_PageCount) Then

            lbl = New Label
            lbl.Name = "lbl" & mintPDFEditing_PageCount
            lbl.Location = New System.Drawing.Point(mintPDFEditing_X, mintPDFEditing_Y + intPDFHeigth + 10)
            lbl.Text = strRealPDFName.Replace(".pdf", "")
            lbl.Width = 220
            lbl.AutoSize = False

            panPDFEditing.Controls.Add(lbl)

            lbl = Nothing
        End If

    End Sub

    Private Sub DisableMagCopierButtons(ByVal blnEnable As Boolean)

        lvwTorrentMags.Enabled = blnEnable
        lvwBooksMags.Enabled = blnEnable

        cmdTorrents_LoadPDF.Enabled = blnEnable And (lvwTorrentMags.Items.Count > 0)
        cmdTorrents_LoadPDFPage0.Enabled = blnEnable And (lvwTorrentMags.Items.Count > 0)
        cmdTorrents_RemovePageZero.Enabled = blnEnable And (lvwTorrentMags.Items.Count > 0)

        cmdTorrents_MoveMags.Enabled = blnEnable And (lvwTorrentMags.Items.Count > 0)
        cmdTorrents_DeleteMag.Enabled = blnEnable And (lvwTorrentMags.Items.Count > 0)
        cmdTorrents_GSCompress.Enabled = blnEnable And (lvwTorrentMags.Items.Count > 0)

        cmdTorrents_MagCleanup.Enabled = blnEnable And (txtMagCopier_TorrentFilename.Text <> "")
        cmdTorrents_RemoveBrackets.Enabled = cmdTorrents_MagCleanup.Enabled

        cmdTorrents_DeleteEmptyFolders.Enabled = blnEnable
        cmdTorrents_IndividualEdit.Enabled = blnEnable And (txtMagCopier_TorrentFilename.Text <> "")

        cmdBooks_LoadPDF.Enabled = blnEnable And (lvwBooksMags.Items.Count > 0)
        cmdBooks_LoadPDFPage0.Enabled = blnEnable And (lvwBooksMags.Items.Count > 0)
        cmdBooks_RemovePageZero.Enabled = blnEnable And (lvwBooksMags.Items.Count > 0)

        cmdBooks_DeleteMag.Enabled = blnEnable And (lvwBooksMags.Items.Count > 0)
        cmdBooks_GSCompress.Enabled = blnEnable And (lvwBooksMags.Items.Count > 0)

        cmdTorrents_TransferFilename.Enabled = blnEnable And (lvwTorrentMags.Items.Count > 0) And (lvwTorrentMags.SelectedItems.Count = 1)
        cmdBooks_TransferFilename.Enabled = blnEnable And (lvwBooksMags.Items.Count > 0) And (lvwBooksMags.SelectedItems.Count = 1)

        cmdBooks_IndividualEdit.Enabled = blnEnable And (txtMagCopier_BooksFilename.Text <> "")

        If Not cmdTorrents_TransferFilename.Enabled Or Not cmdBooks_TransferFilename.Enabled Then

            cmdTorrents_TransferFilename.Enabled = False
            cmdBooks_TransferFilename.Enabled = False
        End If

        Me.Refresh()

    End Sub

    Private Sub cmdcmdPDFEditing_MovePageZero_Click(sender As Object, e As EventArgs) Handles cmdPDFEditing_MovePageZero.Click

        Dim strFile As String

        If lvwPDFEditing.SelectedItems.Count = 0 Then Exit Sub

        Cursor = Cursors.WaitCursor

        strFile = lvwPDFEditing.SelectedItems(0).Text

        If GetPrefix(strFile).ToUpper <> "PDF" Then

            Exit Sub
        End If

        EnableDisablePDFEditingButtons(False)

        pdfSharp_MovePageZero_FromFileInPlace(txtPath_PDFEditing.Text & "\" & strFile)

        lvwPDFEditing.Tag = "XXX"  ' Make sure I Refresh 

        cmdPDFEditing_LoadPDFPage0_Click(Nothing, Nothing)

        Cursor = Cursors.Default

        EnableDisablePDFEditingButtons(True)

    End Sub

    Private Sub cmdLoadCBooksIntoListview_Click(sender As Object, e As EventArgs) Handles cmdLoadCBooksIntoListview.Click

        LoadRecursive("", ROOT_DRIVE & "\Books", False, True)

        lvwFiles.Width = lvwFiles.Width - 290
        accBookTop.Width = 275
        AccBookBottom.Width = accBookTop.Width

        accBookTop.Left = lvwFiles.Left + lvwFiles.Width + 10
        AccBookBottom.Left = accBookTop.Left

        accBookTop.Height = (lvwFiles.Height - 10) / 2
        AccBookBottom.Height = accBookTop.Height

        AccBookBottom.Top = accBookTop.Top + accBookTop.Height + 10

        accBookTop.Visible = True
        AccBookBottom.Visible = True

    End Sub

    Private Sub cmdFiles_NextSelection_Click(sender As Object, e As EventArgs) Handles cmdFiles_NextSelection.Click

        Dim intCount As Integer, objItem As ListViewItem, intCount2 As Integer, objItem2 As ListViewItem

        For intCount = 0 To lvwFiles.SelectedItems.Count - 1

            objItem = lvwFiles.SelectedItems(intCount)

            If objItem.Index > mintLVWFiles_CurrentlySelectedIdex Then

                lvwFiles.EnsureVisible(objItem.Index)

                For intCount2 = intCount + 1 To lvwFiles.SelectedItems.Count - 1

                    objItem2 = lvwFiles.SelectedItems(intCount2)

                    If objItem2.Index > objItem.Index + 1 Then

                        mintLVWFiles_CurrentlySelectedIdex = objItem2.Index

                        Exit For
                    End If
                Next

                Exit For
            End If
        Next

    End Sub

    Private Sub cmdFiles_PreviousSelection_Click(sender As Object, e As EventArgs) Handles cmdFiles_PreviousSelection.Click

        Dim intCount As Integer, objItem As ListViewItem, intCount2 As Integer, objItem2 As ListViewItem

        For intCount = lvwFiles.SelectedItems.Count - 1 To 0 Step -1

            objItem = lvwFiles.SelectedItems(intCount)

            If objItem.Index < mintLVWFiles_CurrentlySelectedIdex Then

                lvwFiles.EnsureVisible(objItem.Index)

                For intCount2 = intCount - 1 To 1 Step -1

                    objItem2 = lvwFiles.SelectedItems(intCount2)

                    If objItem2.Index < objItem.Index - 1 Then

                        mintLVWFiles_CurrentlySelectedIdex = objItem2.Index

                        Exit For
                    End If
                Next

                Exit For
            End If
        Next


    End Sub

    Private Sub tmrClearMessages_Tick(sender As Object, e As EventArgs) Handles tmrClearMessages.Tick

        Select Case mstrMessageType

            Case PDF_EDITING

                Me.Text = My.Application.Info.ProductName
                Me.fraPDFEditing.Text = "PDF Editing"

                My.Application.DoEvents()
                Me.Refresh()
                My.Application.DoEvents()

        End Select

        tmrClearMessages.Enabled = False

        My.Application.DoEvents()
        Me.Refresh()
        My.Application.DoEvents()

    End Sub

    Private Sub cmdTorrents_MoveMags_Click(sender As Object, e As EventArgs) Handles cmdTorrents_MoveMags.Click

        Dim blnNoneChecked As Boolean = True, objItem As ListViewItem, intCount As Integer
        Dim blnMove As Boolean

        For intCount = 0 To lvwTorrentMags.Items.Count - 1

            If lvwTorrentMags.Items(intCount).Checked Then

                blnNoneChecked = False
                Exit For
            End If
        Next

        For Each objItem In lvwTorrentMags.Items

            If objItem.Checked Or blnNoneChecked Then

                blnMove = True

                If My.Computer.FileSystem.FileExists(txtBooksPath_MagCopier.Text & "\" & objItem.SubItems(0).Text) Then

                    If MessageBox.Show("File already exists! Overwrite?", My.Application.Info.ProductName, MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.No Then

                        blnMove = False
                    Else

                        My.Computer.FileSystem.DeleteFile(txtBooksPath_MagCopier.Text & "\" & objItem.SubItems(0).Text)
                    End If

                End If

                If blnMove Then

                    If My.Computer.FileSystem.DirectoryExists(txtBooksPath_MagCopier.Text) Then

                        My.Computer.FileSystem.MoveFile(txtPath_MagCopier.Text & "\" & objItem.SubItems(0).Text, txtBooksPath_MagCopier.Text & "\" & objItem.SubItems(0).Text)
                    Else

                        MessageBox.Show(txtBooksPath_MagCopier.Text & " doesn't exist! Ending")
                        End
                    End If

                End If
            End If
        Next

        cmdLoad_MagCopier_Click(Nothing, Nothing)

        Reset_MagCopier_PDFs()

    End Sub

    Private Sub cmdTorrents_DeleteMag_Click(sender As Object, e As EventArgs) Handles cmdTorrents_DeleteMag.Click

        Dim objItem As ListViewItem

        For Each objItem In lvwTorrentMags.Items

            If objItem.Checked Then My.Computer.FileSystem.DeleteFile(txtPath_MagCopier.Text & "\" & objItem.SubItems(0).Text, FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin)
        Next

        cmdLoad_MagCopier_Click(Nothing, Nothing)

        accTorrentPDF.LoadFile(My.Application.Info.DirectoryPath & "\Blank (Comp).pdf")

    End Sub

    Private Sub cmdBooks_DeleteMag_Click(sender As Object, e As EventArgs) Handles cmdBooks_DeleteMag.Click

        Dim objItem As ListViewItem

        For Each objItem In lvwBooksMags.Items

            If objItem.Checked Then My.Computer.FileSystem.DeleteFile(txtBooksPath_MagCopier.Text & "\" & objItem.SubItems(0).Text, FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin)
        Next

        cmdLoad_MagCopier_Click(Nothing, Nothing)

        accBooksPDF.LoadFile(My.Application.Info.DirectoryPath & "\Blank (Comp).pdf")

    End Sub

    Private Sub cmdTorrents_GSCompress_Click(sender As Object, e As EventArgs) Handles cmdTorrents_GSCompress.Click

        Dim strFile As String, strMessage As String = ""

        If lvwTorrentMags.SelectedItems.Count = 0 Then

            txtErrors.Text = "No file selected!"
            tmrClearError.Enabled = True
            Exit Sub
        End If

        DisableMagCopierButtons(False)

        strFile = ProperisePath(txtPath_MagCopier.Text) & lvwTorrentMags.SelectedItems(0).Text

        If GSCompressFile_CheckSuitable(strFile, strMessage, False) Then

            If GSCompressFile(strFile) Then

                cmdLoad_MagCopier_Click(Nothing, Nothing)
            End If
        Else

            MessageBox.Show(strMessage)
        End If

        DisableMagCopierButtons(True)

    End Sub

    Private Sub cmdBooks_GSCompress_Click(sender As Object, e As EventArgs) Handles cmdBooks_GSCompress.Click

        Dim strFile As String, strMessage As String = ""

        If lvwBooksMags.SelectedItems.Count = 0 Then

            txtErrors.Text = "No file selected!"
            tmrClearError.Enabled = True
            Exit Sub
        End If

        DisableMagCopierButtons(False)

        strFile = ProperisePath(txtBooksPath_MagCopier.Text) & lvwBooksMags.SelectedItems(0).Text

        If GSCompressFile_CheckSuitable(strFile, strMessage, False) Then

            If GSCompressFile(strFile) Then

                cmdLoad_MagCopier_Click(Nothing, Nothing)
            End If
        Else

            MessageBox.Show(strMessage)
        End If

        DisableMagCopierButtons(True)

    End Sub

    Private Sub LoadMagCopier_PossibleDups()

        Dim objItem As ListViewItem, strName As String, objBooksMagsItem As ListViewItem, objAddedItem As ListViewItem
        Dim intPos As Integer, strElements() As String
        Dim intCount As Integer, strTemp As String, strDup As String
        Dim strOriginalName As String = ""

        lvwMagCopier_PossibleDups.Items.Clear()

        If lvwTorrentMags.Items.Count = 0 Then Exit Sub
        If lvwBooksMags.Items.Count = 0 Then Exit Sub

        For Each objItem In lvwTorrentMags.Items

            strTemp = ""
            strName = objItem.Text
            strOriginalName = strName

            intPos = InStr(strName, " - ")

            If intPos > 0 Then

                strName = Mid(strName, intPos + 3).Trim

                strName = RemovePrefix(strName)

                strElements = strName.Split(" ")

                For intCount = 0 To strElements.GetUpperBound(0) - 1

                    If Is3Digitmonth(strElements(intCount)) And IsYear(strElements(intCount + 1), 1990) Then

                        strTemp = strElements(intCount) & " " & strElements(intCount + 1)
                        Exit For
                    End If
                Next

                If strTemp <> "" Then strName = strTemp

                For Each objBooksMagsItem In lvwBooksMags.Items

                    strDup = objBooksMagsItem.Text

                    intPos = InStr(strDup, " - ")

                    If intPos > 0 Then

                        strDup = Mid(strDup, intPos + 3).Trim

                        strDup = RemovePrefix(strDup)
                    Else

                        strDup = RemovePrefix(strDup)
                    End If

                    strName = strName.ToUpper
                    strDup = strDup.ToUpper

                    If InStr(strName, strDup) > 0 Or InStr(strDup, strName) > 0 Then

                        objAddedItem = lvwMagCopier_PossibleDups.Items.Add(strOriginalName)

                        objAddedItem.SubItems.Add(strOriginalName)
                        objAddedItem.SubItems.Add(objBooksMagsItem.Text)
                    End If
                Next
            End If
        Next

    End Sub

    Private Sub cmdTorrents_TransferFilename_Click(sender As Object, e As EventArgs) Handles cmdTorrents_TransferFilename.Click

        Dim strName As String

        If lvwTorrentMags.SelectedItems.Count <> 1 Then Exit Sub
        If lvwBooksMags.SelectedItems.Count <> 1 Then Exit Sub

        strName = lvwTorrentMags.SelectedItems(0).Text

        My.Computer.FileSystem.MoveFile(txtBooksPath_MagCopier.Text & "\" & lvwBooksMags.SelectedItems(0).Text, txtBooksPath_MagCopier.Text & "\" & strName)

        cmdLoad_MagCopier_Click(Nothing, Nothing)

        Reset_MagCopier_PDFs()

    End Sub

    Private Sub cmdBooks_TransferFilename_Click(sender As Object, e As EventArgs) Handles cmdBooks_TransferFilename.Click

        Dim strName As String

        If lvwTorrentMags.SelectedItems.Count <> 1 Then Exit Sub
        If lvwBooksMags.SelectedItems.Count <> 1 Then Exit Sub

        strName = lvwBooksMags.SelectedItems(0).Text

        My.Computer.FileSystem.MoveFile(txtPath_MagCopier.Text & "\" & lvwTorrentMags.SelectedItems(0).Text, txtPath_MagCopier.Text & "\" & strName)

        cmdLoad_MagCopier_Click(Nothing, Nothing)

        Reset_MagCopier_PDFs()

    End Sub

    Private Sub Reset_MagCopier_PDFs()

        accTorrentPDF.LoadFile(My.Application.Info.DirectoryPath & "\Blank (Comp).pdf")
        accBooksPDF.LoadFile(My.Application.Info.DirectoryPath & "\Blank (Comp).pdf")

    End Sub

    Private Sub lvwMagCopier_PossibleDups_Click(sender As Object, e As EventArgs) Handles lvwMagCopier_PossibleDups.Click

        Dim objItem As ListViewItem, intFoundBoth As Integer = 0

        If lvwMagCopier_PossibleDups.SelectedItems.Count <> 1 Then Exit Sub

        For Each objItem In lvwTorrentMags.Items

            If objItem.Text = lvwMagCopier_PossibleDups.SelectedItems(0).SubItems(0).Text Then

                lvwTorrentMags.SelectedItems.Clear()

                intFoundBoth = intFoundBoth + 1
                objItem.Selected = True
                Exit For
            End If
        Next

        For Each objItem In lvwBooksMags.Items

            If objItem.Text = lvwMagCopier_PossibleDups.SelectedItems(0).SubItems(2).Text Then

                lvwBooksMags.SelectedItems.Clear()

                intFoundBoth = intFoundBoth + 1
                objItem.Selected = True
                Exit For
            End If
        Next

        If intFoundBoth = 2 Then

            lvwTorrentMags_DoubleClick(Nothing, Nothing)
            lvwBooksMags_DoubleClick(Nothing, Nothing)
        End If

    End Sub

    Private Sub cmdTorrents_IndividualEdit_Click(sender As Object, e As EventArgs) Handles cmdTorrents_IndividualEdit.Click

        Dim strName As String

        If txtMagCopier_TorrentFilename.Text = "" Then Exit Sub
        If lvwTorrentMags.SelectedItems.Count <> 1 Then Exit Sub

        strName = lvwTorrentMags.SelectedItems(0).Text

        My.Computer.FileSystem.MoveFile(txtPath_MagCopier.Text & "\" & strName, txtPath_MagCopier.Text & "\" & txtMagCopier_TorrentFilename.Text)

        cmdLoad_MagCopier_Click(Nothing, Nothing)

        Reset_MagCopier_PDFs()

    End Sub

    Private Sub EnableIndividualEditButtons()

        cmdTorrents_IndividualEdit.Enabled = txtMagCopier_TorrentFilename.Text <> ""
        cmdBooks_IndividualEdit.Enabled = txtMagCopier_BooksFilename.Text <> ""

    End Sub

    Private Sub cmdBooks_IndividualEdit_Click(sender As Object, e As EventArgs) Handles cmdBooks_IndividualEdit.Click

        Dim strName As String

        If txtMagCopier_BooksFilename.Text = "" Then Exit Sub
        If lvwBooksMags.SelectedItems.Count <> 1 Then Exit Sub

        strName = lvwBooksMags.SelectedItems(0).Text

        My.Computer.FileSystem.MoveFile(txtBooksPath_MagCopier.Text & "\" & strName, txtBooksPath_MagCopier.Text & "\" & txtMagCopier_BooksFilename.Text)

        cmdLoad_MagCopier_Click(Nothing, Nothing)

        Reset_MagCopier_PDFs()

    End Sub

    Sub LoadFiles_AutoBookSort(ByVal strPath As String)

        Dim objItem As ListViewItem, blnAdd As Boolean
        Dim strType As String, strTarget As String

        lvwAutoBookSort_Results.Items.Clear()

        If Not My.Computer.FileSystem.DirectoryExists(strPath) Then Exit Sub

        Dim objDir As New DirectoryInfo(strPath)

        For Each objFile As FileInfo In objDir.GetFiles()

            strType = objFile.Extension.ToLower

            If strType = ".pdf" OrElse strType = ".epub" OrElse strType = ".mobi" Then

                blnAdd = True
            Else

                blnAdd = False
            End If

            If blnAdd Then

                objItem = lvwAutoBookSort_Results.Items.Add(objFile.Name)

                strTarget = AutoSort_GetTarget(objFile.Name)

                objItem.SubItems.Add(strTarget)
            End If
        Next

    End Sub

    Private Function AutoSort_GetTarget(ByVal strFile As String) As String

        Dim intFolderCount As Integer, intBestMatch As Integer, intBestMatchFolderIndex As Integer, intCurrentMatch As Integer

        strFile = RemovePrefix(strFile).ToLower

        strFile = Remove100MostCommonWords(strFile, True)

        For intFolderCount = 1 To mintAutoSort_FolderCount

            intCurrentMatch = GetFolderMatch(strFile, intFolderCount)

            If intCurrentMatch > intBestMatch Then

                intBestMatch = intCurrentMatch
                intBestMatchFolderIndex = intFolderCount
            End If
        Next

        If intBestMatchFolderIndex > 0 Then

            AutoSort_GetTarget = mstrAutoSort_Folders(intBestMatchFolderIndex)
        Else

            AutoSort_GetTarget = ""
        End If

    End Function

    Private Function GetFolderMatch(ByVal strName As String, ByVal intFolderCount As Integer) As Integer

        Dim strElements() As String, intCount As Integer, intElementCount As Integer
        Dim strWord As String, intMatchCount As Integer = 0

        GetFolderMatch = 0

        strElements = strName.Split(" ")

        For intElementCount = strElements.GetLowerBound(0) To strElements.GetUpperBound(0)

            strWord = strElements(intElementCount).ToLower

            If Len(strWord) > 5 Then

                For intCount = 0 To AUTO_SORT_WORD_LIMIT

                    If mstrAutoSort_Words(intFolderCount, intCount) = "" Then

                        GetFolderMatch = intMatchCount
                        Exit Function
                    End If

                    If mstrAutoSort_Words(intFolderCount, intCount) = strWord AndAlso mintAutoSort_WordCount(intFolderCount, intCount) > 1 Then

                        intMatchCount = intMatchCount + mintAutoSort_WordCount(intFolderCount, intCount)
                    End If
                Next
            End If
        Next

        GetFolderMatch = intMatchCount

    End Function

    Private Sub cmdAutoBookSort_Process_Click(sender As Object, e As EventArgs) Handles cmdAutoBookSort_Process.Click

        Cursor = Cursors.WaitCursor

        ProcessBooks()

        Cursor = Cursors.Default

    End Sub

    Private Sub CreateArrays(ByVal strPath As String)

        Dim objDir As DirectoryInfo, d As DirectoryInfo, objSubs() As DirectoryInfo, objSub As DirectoryInfo

        objDir = New DirectoryInfo(strPath)

        For Each d In objDir.GetDirectories()

            New_Autosort_Folder_Element(d.FullName)

            objSubs = d.GetDirectories()

            For Each objSub In objSubs

                AutoBookSort_ProcessSubFolders_Recursive(objSub.FullName)
            Next
        Next

        ReDim Preserve mstrAutoSort_Folders(mintAutoSort_FolderCount - 1)

    End Sub

    Private Function New_Autosort_Folder_Element(ByVal strDirFullName As String) As Boolean

        Dim intCount As Integer

        New_Autosort_Folder_Element = False

        For intCount = 1 To mintAutoSort_FolderCount

            If mstrAutoSort_Folders(intCount) = strDirFullName Then Exit Function
        Next

        mstrAutoSort_Folders(mintAutoSort_FolderCount) = strDirFullName
        mintAutoSort_FolderCount = mintAutoSort_FolderCount + 1

        New_Autosort_Folder_Element = True

    End Function

    Public Sub AutoBookSort_ProcessFolders(ByVal strFrom As String)



    End Sub

    Private Sub AutoBookSort_ProcessSubFolders_Recursive(ByVal strPath As String)

        Dim objDir As DirectoryInfo

        objDir = New DirectoryInfo(strPath)

        New_Autosort_Folder_Element(strPath)

        For Each d In objDir.GetDirectories()

            If New_Autosort_Folder_Element(d.FullName) Then AutoBookSort_ProcessSubFolders_Recursive(d.FullName)
        Next

    End Sub

    Private Sub ProcessBooks()

        Dim strPath As String = ROOT_DRIVE & "\Books"

        Me.Text = APP_NAME

        Cursor = Cursors.WaitCursor

        CreateArrays(txtAutoBookSort_TargetPath.Text)

        AutoSort_GetWords()

        LoadFiles_AutoBookSort(txtAutoBookSort_PathToSort.Text)

    End Sub

    Public Sub AutoSort_GetWords()

        Dim objDir As DirectoryInfo
        Dim strName As String, intCount As Integer, strType As String

        For intCount = 1 To mintAutoSort_FolderCount - 1

            objDir = New DirectoryInfo(mstrAutoSort_Folders(intCount))

            For Each objFile In objDir.GetFiles

                strType = objFile.Extension.ToLower

                If (strType = ".pdf" OrElse strType = ".epub" OrElse strType = ".mobi") Then

                    strName = objFile.Name.ToLower

                    strName = RemovePrefix(strName)

                    strName = Remove100MostCommonWords(strName, True)

                    Process_AutoSort_Source_Name(strName, intCount)
                End If
            Next
        Next

    End Sub

    Private Sub Process_AutoSort_Source_Name(ByVal strName As String, ByVal intFolderIndex As Integer)

        Dim strElements() As String, intCount As Integer
        Dim strWord As String, intWordIndex As Integer

        strElements = strName.Split(" ")

        For intCount = strElements.GetLowerBound(0) To strElements.GetUpperBound(0)

            strWord = strElements(intCount)

            If Len(strWord) > 5 Then

                If AutoSort_IsWordNew(intFolderIndex, strWord, intWordIndex) Then

                    mstrAutoSort_Words(intFolderIndex, intWordIndex) = strWord
                    mintAutoSort_WordCount(intFolderIndex, intWordIndex) = 1
                Else

                    mintAutoSort_WordCount(intFolderIndex, intWordIndex) = mintAutoSort_WordCount(intFolderIndex, intWordIndex) + 1
                End If
            End If
        Next

    End Sub

    Private Function AutoSort_IsWordNew(ByVal intFolderIndex As Integer, ByVal strWord As String, ByRef intWordIndex As Integer) As Boolean

        Dim intCount As Integer

        AutoSort_IsWordNew = True

        For intCount = 0 To AUTO_SORT_WORD_LIMIT

            If strWord = mstrAutoSort_Words(intFolderIndex, intCount) Then

                intWordIndex = intCount
                AutoSort_IsWordNew = False
                Exit Function
            End If

            If mstrAutoSort_Words(intFolderIndex, intCount) = "" Then

                intWordIndex = intCount
                AutoSort_IsWordNew = True
                Exit Function
            End If
        Next

    End Function

    Private Sub cmdMagazineFinderPath_Click(sender As Object, e As EventArgs) Handles cmdMagazineFinderPath.Click

        Me.Text = APP_NAME

        FolderBrowserDialog1.RootFolder = Environment.SpecialFolder.MyComputer

        If txtMagazineFinderPath.Text = "" Then

            FolderBrowserDialog1.SelectedPath = ROOT_DRIVE & "\Books\Mags"
        Else

            FolderBrowserDialog1.SelectedPath = txtMagazineFinderPath.Text
        End If

        If FolderBrowserDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then

            If FolderBrowserDialog1.SelectedPath <> "" Then

                txtMagazineFinderPath.Text = Mid(FolderBrowserDialog1.SelectedPath, 1, 1).ToLower & Mid(FolderBrowserDialog1.SelectedPath, 2)

                cmdMagazineFinderLoadFiles_Click(Nothing, Nothing)

            End If
        End If

        txtMagazineFinderSearchTerm.Text = GetSearchTerm(txtMagazineFinderPath.Text)

    End Sub

    Private Function GetSearchTerm(ByVal strPath As String) As String

        Dim intPos As Integer, strTerm As String = ""

        If strPath = "" Then

            GetSearchTerm = ""
            Exit Function
        End If

        strPath = strPath.Replace(ROOT_DRIVE & "\Books\Mags\", "")

        intPos = InStrRev(strPath, "\")

        If intPos > 0 Then

            strTerm = Mid(strPath, 1, intPos - 1)

            intPos = InStrRev(strTerm, "\")

            If intPos > 0 Then

                strTerm = Mid(strTerm, intPos + 1)
            End If
        Else

            strTerm = strPath
        End If

        ' Some mags dont like the BBC
        If Len(strTerm) > 5 Then

            If Mid(strTerm, 1, 4) = "BBC " Then strTerm = Mid(strTerm, 5)
        End If

        GetSearchTerm = strTerm

    End Function


    Private Sub cmdMagazineFinderProcess_Click(sender As Object, e As EventArgs) Handles cmdMagazineFinderProcess.Click

        Dim strSearch As String, intCount As Integer
        Dim strURL As String = "", strHTML As String = ""
        Dim strPageURLs() As String, strTitles() As String, strName As String = ""
        Dim objItem As ListViewItem, strStatus As String = "", strTargetURL As String = ""
        Dim strFirstBytes As String, blnCategory As Boolean

        If txtMagazineFinderSearchTerm.Text = "" And cboMagazineFinderSearchType.Text = "" Then

            Exit Sub
        End If

        If cboMagazineFinderWebSites.Text = "" Then

            Exit Sub
        End If

        If txtMagazineFinderSearchTerm.Text <> "" Then

            strSearch = txtMagazineFinderSearchTerm.Text

            For intCount = 1 To mintMagazineFinder_SupportedCount

                If cboMagazineFinderWebSites.Text = mstrMagazineFinder_Website(intCount) Then

                    strName = mstrMagazineFinder_Website(intCount)
                    strURL = mstrMagazineFinder_WebsiteURL(intCount)
                End If
            Next

            strURL = strURL.Replace("XXX", strSearch)

            blnCategory = False
        Else

            strSearch = cboMagazineFinderSearchType.Text

            strSearch = strSearch.Replace(" ", "-").Replace("&", "amp")

            Select cboMagazineFinderWebSites.Text

                Case "MagazineLib"

                    Select Case cboMagazineFinderSearchType.Text

                        Case "Food & Cooking", "Science"

                            strName = "MagazineLib"
                            strURL = "https://magazinelib.com/category/" & strSearch & "/"

                        Case "Latest"

                            strName = "MagazineLib"
                            strURL = "https://magazinelib.com/"

                    End Select

                    strURL = strURL.ToLower
            End Select

            blnCategory = True
        End If

        If strURL = "" Then

            Exit Sub
        End If

        strHTML = mobjHTML.GetHTMLofURL(strURL)

        Select Case strName

            Case mstrMagazineFinder_Website(1)

                strPageURLs = Split(strHTML, "<div class=""entry-before-title"">")
                strPageURLs(0) = ""
                strPageURLs(strPageURLs.GetUpperBound(0)) = ""

                ReDim strTitles(strPageURLs.GetUpperBound(0))

                If strTitles.GetUpperBound(0) = 0 Then

                    Exit Sub
                End If

                MagazineLib_CleanupArray(strPageURLs, strTitles, blnCategory)

                lvwMagazineFinderURLs.Items.Clear()

                prgMagazineFinder.Maximum = strTitles.GetUpperBound(0)
                prgMagazineFinder.Value = 0

                For intCount = 1 To strPageURLs.GetUpperBound(0) - 1

                    objItem = lvwMagazineFinderURLs.Items.Add(strTitles(intCount))

                    objItem.SubItems.Add(strPageURLs(intCount))

                    strTargetURL = MagazineLib_GetTargetURL(mobjHTML, strPageURLs(intCount))

                    objItem.SubItems.Add(strTargetURL)
                    objItem.SubItems.Add("")

                    lvwMagazineFinderURLs.Refresh()

                    Me.Text = My.Application.Info.ProductName & " - " & "URL Processing - " & objItem.Text

                    If prgMagazineFinder.Value < prgMagazineFinder.Maximum Then prgMagazineFinder.Value = prgMagazineFinder.Value + 1
                Next

        End Select

        lvwMagazineFinderURLs.Refresh()

        prgMagazineFinder.Value = 0
        prgMagazineFinder.Maximum = lvwMagazineFinderURLs.Items.Count - 1

        For intCount = 0 To lvwMagazineFinderURLs.Items.Count - 1

            Dim bytData(5) As Byte

            objItem = lvwMagazineFinderURLs.Items(intCount)

            strTargetURL = objItem.SubItems(2).Text

            If strTargetURL <> "" Then

                Me.Text = My.Application.Info.ProductName & " - " & "PDF? Processing - " & objItem.Text

                If InStr(objItem.SubItems(1).Text, "/__trashed-") = 0 And Mid(strTargetURL, 1, 4).ToLower = "http" Then

                    strFirstBytes = mobjHTML.GetFirstCharsOfLink(strTargetURL, 4)

                    If Mid(strFirstBytes, 2, 3) = "PDF" Then

                        objItem.SubItems(3).Text = "PDF"
                        objItem.Checked = True
                    End If
                End If
            End If

            If prgMagazineFinder.Value < prgMagazineFinder.Maximum Then prgMagazineFinder.Value = prgMagazineFinder.Value + 1
        Next

        Me.Text = My.Application.Info.ProductName

        lvwMagazineFinderURLs.Refresh()
        prgMagazineFinder.Value = 0

    End Sub



    Private Sub cmdMagazineFinderLoadFiles_Click(sender As Object, e As EventArgs) Handles cmdMagazineFinderLoadFiles.Click

        If txtMagazineFinderPath.Text = "" Then Exit Sub

        Cursor = Cursors.WaitCursor

        LoadFiles_MagazineFinder_Recursive(txtMagazineFinderPath.Text)

        Cursor = Cursors.Default

    End Sub


    Private Sub LoadFiles_MagazineFinder_Recursive(ByVal strPath As String)

        Dim colMyFiles As New colMyFileInfo, objItem As ListViewItem, strFile As String
        Dim objMyFile As clsMyFileInfo, strAllTypes As String = ""
        Dim intCount As Integer

        Me.Text = APP_NAME

        If strPath.Trim = "" Then

            MessageBox.Show("Enter path!")
            Exit Sub
        End If

        Cursor = Cursors.WaitCursor

        mstrLoadType = "LOADRECURSIVE_MAG_FOLDER"

        LoadAllFiles_MagazineFolder_Recursive(strPath, colMyFiles)

        lvwMagazineFinderFiles.Items.Clear()

        For intCount = colMyFiles.Count - 1 To 0 Step -1

            strFile = RemovePath(colMyFiles(intCount).Fullname)

            objItem = lvwMagazineFinderFiles.Items.Add(strFile)
        Next

        My.Application.DoEvents()

        objMyFile = Nothing
        colMyFiles = Nothing
        colMyFiles = New colMyFileInfo


        'Dim objE As New ColumnClickEventArgs(FILES_COL_NAME)
        'lvwFiles_ColumnClick(Nothing, objE)

    End Sub

    Public Sub LoadAllFiles_MagazineFolder_Recursive(ByVal strFrom As String, ByRef colMyFiles As colMyFileInfo)

        Dim objDir As DirectoryInfo, d As DirectoryInfo, objFile As FileInfo, objSubDir As DirectoryInfo
        Dim objMyFile As clsMyFileInfo, strType As String
        Dim blnAdd As Boolean

        If strFrom = "" Then

            MessageBox.Show("No Path!")
            Exit Sub
        End If

        objDir = New DirectoryInfo(strFrom)

        For Each objFile In objDir.GetFiles

            objMyFile = New clsMyFileInfo

            strType = objFile.Extension.ToLower

            If (strType = ".pdf" OrElse strType = ".epub" OrElse strType = ".mobi" And Not chkAllFileTypes.Checked) Or chkAllFileTypes.Checked Then

                blnAdd = True
            Else

                blnAdd = False
            End If

            If blnAdd Then

                objMyFile.Fullname = objFile.FullName
                objMyFile.Size = objFile.Length

                colMyFiles.Add(objMyFile)
            End If
        Next

        For Each d In objDir.GetDirectories()

            For Each objFile In d.GetFiles

                objMyFile = New clsMyFileInfo

                strType = objFile.Extension.ToLower

                If (strType = ".pdf" OrElse strType = ".epub" OrElse strType = ".mobi" And Not chkAllFileTypes.Checked) Or chkAllFileTypes.Checked Then

                    blnAdd = True
                Else

                    blnAdd = False
                End If

                If blnAdd Then

                    objMyFile.Fullname = objFile.FullName
                    objMyFile.Size = objFile.Length


                    colMyFiles.Add(objMyFile)

                End If

                My.Application.DoEvents()
            Next

            For Each objSubDir In d.GetDirectories

                LoadAllFiles_MagazineFolder_Recursive(objSubDir.FullName, colMyFiles)
            Next
        Next

    End Sub

    Private Sub cboMagazineFinderSearchType_KeyDown(sender As Object, e As KeyEventArgs) Handles cboMagazineFinderSearchType.KeyDown, cboMagazineFinderSelectionOptions.KeyDown, cboMagazineFinderWebSites.KeyDown
        e.SuppressKeyPress = True
    End Sub

    Private Sub cboMagazineFinderSearchType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboMagazineFinderSearchType.SelectedIndexChanged

        txtMagazineFinderSearchTerm.Text = ""
        txtMagazineFinderPath.Text = ""

        lvwMagazineFinderFiles.Items.Clear()

    End Sub


    Private Sub cmdMagazineFinderDownload_Click(sender As Object, e As EventArgs) Handles cmdMagazineFinderDownload.Click

        Dim objItem As ListViewItem, strTargetURL As String = "", strName As String

        prgMagazineFinder.Value = 0
        prgMagazineFinder.Maximum = lvwMagazineFinderURLs.Items.Count - 1

        For intCount = 0 To lvwMagazineFinderURLs.Items.Count - 1

            objItem = lvwMagazineFinderURLs.Items(intCount)

            If objItem.Checked Then

                strTargetURL = objItem.SubItems(2).Text
                strName = objItem.Text

                strName = ROOT_DRIVE & "\" & strName & ".pdf"

                If Not My.Computer.FileSystem.FileExists(strName) Then

                    If strTargetURL <> "" Then

                        mobjHTML.GetBinaryFile(strTargetURL, strName)
                    End If
                End If
            End If

            If prgMagazineFinder.Value < prgMagazineFinder.Maximum Then prgMagazineFinder.Value = prgMagazineFinder.Value + 1
        Next

        lvwMagazineFinderURLs.Refresh()
        prgMagazineFinder.Value = 0

    End Sub

    Private Sub cboMagazineFinderWebSites_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboMagazineFinderWebSites.SelectedIndexChanged

    End Sub

    Private Sub cboMagazineFinderSelectionOptions_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboMagazineFinderSelectionOptions.SelectedIndexChanged

        Dim objItem As ListViewItem

        Select Case cboMagazineFinderSelectionOptions.Text

            Case "Select All"

                For Each objItem In lvwMagazineFinderURLs.Items

                    objItem.Checked = True
                Next

            Case "Unselect All"

                For Each objItem In lvwMagazineFinderURLs.Items

                    objItem.Checked = False
                Next

            Case "Invert"

                For Each objItem In lvwMagazineFinderURLs.Items

                    objItem.Checked = Not objItem.Checked
                Next

        End Select

    End Sub

    Private Sub cmdPDFEditing_RemoveFoldersPageZeros_Click(sender As Object, e As EventArgs) Handles cmdPDFEditing_RemoveFoldersPageZeros.Click

        Dim strMessage As String = ""
        Dim objItem As ListViewItem, strInfoMessages As String = ""
        Dim blnDoSelected As Boolean = False, blnDoItem As Boolean = False

        If lvwPDFEditing.Items.Count = 0 Then

            txtErrors.Text = "No file selected!"
            tmrClearError.Enabled = True
            Exit Sub
        End If

        If MessageBox.Show("Are you sure? All been checked?", My.Application.Info.ProductName, MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then

            EnableDisablePDFEditingButtons(False)

            If lvwPDFEditing.SelectedItems.Count > 0 Then

                lvwPDFEditing.SelectedItems.Clear()
            End If

            For Each objItem In lvwPDFEditing.Items

                objItem.Selected = True

                My.Application.DoEvents()
                Me.Refresh()
                My.Application.DoEvents()

                cmdPDFEditing_RemovePageZero_Click(Nothing, Nothing)

                Sleep(1000)

                objItem.Selected = False

                My.Application.DoEvents()
                Me.Refresh()
                My.Application.DoEvents()
            Next

            cmdLoad_PDFEditing_Click(Nothing, Nothing)

            EnableDisablePDFEditingButtons(True)

            PlaySound(ROOT_DRIVE & "\VB.Net\My Projects\_Sounds\CompressionComplete.mp3")

            MessageBox.Show("Finished!")

        End If

    End Sub

    Private Sub mnuListviewRightClick_Opening(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles mnuListviewRightClick.Opening

        If lvwFiles.SelectedItems.Count = 1 Then

            mnuOpenFile.Text = "Open file"

            mnuSwapNamesAndDelete1.Visible = False
            mnuSwapNamesAndDelete2.Visible = False
        End If

        If lvwFiles.SelectedItems.Count = 2 Then

            mnuOpenFile.Text = "Open files"

            mnuSwapNamesAndDelete1.Visible = True
            mnuSwapNamesAndDelete2.Visible = True

            mnuSwapNamesAndDelete1.Text = "Swap names and delete - " & lvwFiles.SelectedItems(0).SubItems(FILES_COL_NAME).Text

            mnuSwapNamesAndDelete2.Text = "Swap names and delete - " & lvwFiles.SelectedItems(1).SubItems(FILES_COL_NAME).Text
        End If

    End Sub

    Private Sub mnuSwapNamesAndDelete1_Click(sender As Object, e As EventArgs) Handles mnuSwapNamesAndDelete1.Click

        Dim strName1 As String = "", strName2 As String = ""
        Dim strPath1 As String = "", strPath2 As String = ""

        strName1 = lvwFiles.SelectedItems(0).SubItems(FILES_COL_NAME).Text

        strName2 = lvwFiles.SelectedItems(1).SubItems(FILES_COL_NAME).Text

        strPath1 = lvwFiles.SelectedItems(0).SubItems(FILES_COL_PATH).Text

        strPath2 = lvwFiles.SelectedItems(1).SubItems(FILES_COL_PATH).Text

        My.Computer.FileSystem.DeleteFile(strPath1 & "\" & strName1, FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin)

        My.Computer.FileSystem.MoveFile(strPath2 & "\" & strName2, strPath1 & "\" & strName1)

    End Sub

    Private Sub mnuSwapNamesAndDelete2_Click(sender As Object, e As EventArgs) Handles mnuSwapNamesAndDelete2.Click

        Dim strName1 As String = "", strName2 As String = ""
        Dim strPath1 As String = "", strPath2 As String = ""

        ' Just swapped values round
        strName1 = lvwFiles.SelectedItems(1).SubItems(FILES_COL_NAME).Text

        strName2 = lvwFiles.SelectedItems(0).SubItems(FILES_COL_NAME).Text

        strPath1 = lvwFiles.SelectedItems(1).SubItems(FILES_COL_PATH).Text

        strPath2 = lvwFiles.SelectedItems(0).SubItems(FILES_COL_PATH).Text

        My.Computer.FileSystem.DeleteFile(strPath1 & "\" & strName1, FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin)

        My.Computer.FileSystem.MoveFile(strPath2 & "\" & strName2, strPath1 & "\" & strName1)

    End Sub

    Private Sub cmdPDFEditing_DelBackups_Click(sender As Object, e As EventArgs) Handles cmdPDFEditing_DelBackups.Click

        Dim objDir As New DirectoryInfo(TORRENT_REMOVEPAGEZERO_BACKUPS)

        For Each objFile As FileInfo In objDir.GetFiles("*.pdf")

            objFile.Delete()
        Next

    End Sub

    Private Sub cmdTorrents_DeleteEmptyFolders_Click(sender As Object, e As EventArgs) Handles cmdTorrents_DeleteEmptyFolders.Click

        EmptyMagSubFolders()

        EmptyMagSubFolders()

    End Sub

    Private Sub EmptyMagSubFolders()

        Dim objDir As New DirectoryInfo(ROOT_DRIVE & "\_Torrent\Completed\_Magazines")

        cmdTorrents_DeleteEmptyFolders.Enabled = False

        For Each objSubDir As DirectoryInfo In objDir.GetDirectories()

            For Each objSubSubDir In objSubDir.GetDirectories

                If objSubSubDir.GetFiles.Count = 0 Then

                    objSubSubDir.Delete()
                End If
            Next

            objSubDir.Refresh()

            If objSubDir.GetDirectories.Count = 0 And objSubDir.GetFiles.Count = 0 Then

                objSubDir.Delete()
            End If
        Next

        objDir = Nothing

        cmdTorrents_DeleteEmptyFolders.Enabled = True

    End Sub

    Private Sub cmdTorrents_MagCleanup_Click(sender As Object, e As EventArgs) Handles cmdTorrents_MagCleanup.Click

        Dim strName As String = "", strTemp As String = ""

        If lvwTorrentMags.SelectedItems.Count = 0 Then Exit Sub

        strName = lvwTorrentMags.SelectedItems(0).Text

        strTemp = FileRenamer_MagazineCleanup(strName, txtPath_MagCopier.Text)

        If strTemp <> "" And strTemp <> strName Then

            My.Computer.FileSystem.MoveFile(txtPath_MagCopier.Text & "\" & strName, txtPath_MagCopier.Text & "\" & strTemp)

            cmdLoad_MagCopier_Click(Nothing, Nothing)
        End If

    End Sub

    Private Sub cmdTorrents_RemoveBrackets_Click(sender As Object, e As EventArgs) Handles cmdTorrents_RemoveBrackets.Click

        Dim strName As String = "", strTemp As String = ""

        If lvwTorrentMags.SelectedItems.Count = 0 Then Exit Sub

        strName = lvwTorrentMags.SelectedItems(0).Text

        strTemp = RemoveBrackets(strName)

        If strTemp <> "" And strTemp <> strName Then

            My.Computer.FileSystem.MoveFile(txtPath_MagCopier.Text & "\" & strName, txtPath_MagCopier.Text & "\" & strTemp)

            cmdLoad_MagCopier_Click(Nothing, Nothing)
        End If

    End Sub

    Private Sub cmdGSCompTab_Path_Click(sender As Object, e As EventArgs) Handles cmdGSCompTab_Path.Click

        Me.Text = APP_NAME

        FolderBrowserDialog1.RootFolder = Environment.SpecialFolder.MyComputer

        If txtGSCompTab_Path.Text = "" Then

            FolderBrowserDialog1.SelectedPath = ROOT_DRIVE & "\Books"
        Else

            FolderBrowserDialog1.SelectedPath = txtGSCompTab_Path.Text
        End If

        If FolderBrowserDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then

            If FolderBrowserDialog1.SelectedPath <> "" Then

                txtGSCompTab_Path.Text = Mid(FolderBrowserDialog1.SelectedPath, 1, 1).ToLower & Mid(FolderBrowserDialog1.SelectedPath, 2)
                LoadFiles_GSCompTab(txtGSCompTab_Path.Text)

                Reset_GCComp()
            End If

        End If

    End Sub

    Private Sub Reset_GCComp()

        Cursor = Cursors.Default
        Me.Text = APP_NAME

        Me.Refresh()

        If lvwGSCompTab_Files.Items.Count = 0 Then

            fraBookManagement.Text = "Book Management"
        Else

            fraBookManagement.Text = "Book Management - Torrent " & lvwGSCompTab_Files.Items.Count & " files"
        End If

    End Sub

    Sub LoadFiles_GSCompTab(ByVal strPath As String)

        Dim objItem As ListViewItem, blnAdd As Boolean

        Me.Text = APP_NAME

        lvwGSCompTab_Files.Items.Clear()

        If strPath.Trim = "" Then

            MessageBox.Show("Enter path!")
            Exit Sub
        End If

        If Not My.Computer.FileSystem.DirectoryExists(strPath) Then Exit Sub

        Dim objDir As New DirectoryInfo(strPath)

        blnAdd = True

        Try

            For Each objFile As FileInfo In objDir.GetFiles("*.pdf")

                objItem = lvwGSCompTab_Files.Items.Add(objFile.FullName)

                strPath = GetPath(objFile.FullName)

                objItem.SubItems.Add(GetFileSizeInMB_UsingSize(objFile.Length))
                objItem.SubItems.Add(objFile.Length)
                objItem.SubItems.Add(strPath)
            Next

        Catch ex As Exception

            MessageBox.Show(ex.Message)
        End Try

        'Dim objE As New ColumnClickEventArgs()

        'lvwGSCompTab_Files_ColumnClick(Nothing, objE)

    End Sub

    Private Sub cmdGSCompTab_Load_Click(sender As Object, e As EventArgs) Handles cmdGSCompTab_Load.Click

        If txtGSCompTab_Path.Text = "" Then Exit Sub

        Cursor = Cursors.WaitCursor

        LoadFiles_GSCompTab(txtGSCompTab_Path.Text)

        Reset_GCComp()

        If mblnLookForFiles Then

            If lvwGSCompTab_Files.Items.Count > 0 Then

                mblnLookForFiles = False
                mblnLookForFilesBackwards = False
            Else

                If mblnLookForFilesBackwards Then

                    ' cmdPDFEditingBack_Click(Nothing, Nothing)
                Else

                    ' cmdPDFEditingForward_Click(Nothing, Nothing)
                End If
            End If
        End If

        fraGSComp.Text = "GS Comp. -  " & lvwGSCompTab_Files.Items.Count & " files"

    End Sub

    Private Sub cmdGSCompTab_LoadRec_Click(sender As Object, e As EventArgs) Handles cmdGSCompTab_LoadRec.Click

        GSCompTab_LoadRecursive(txtGSCompTab_Path.Text, True)

    End Sub

    Private Sub GSCompTab_LoadRecursive(ByVal strPath As String, ByVal blnDoClear As Boolean)

        Dim colMyFiles As New colMyFileInfo, objItem As ListViewItem
        Dim objMyFile As clsMyFileInfo

        Me.Text = APP_NAME

        If strPath.Trim = "" Then

            MessageBox.Show("Enter path!")
            Exit Sub
        End If

        Cursor = Cursors.WaitCursor

        mstrLoadType = "LOADRECURSIVE"

        GSCompTab_LoadAllFilesInFolder_Recursive(strPath, colMyFiles)

        If blnDoClear Then lvwGSCompTab_Files.Items.Clear()

        For Each objMyFile In colMyFiles

            objItem = lvwGSCompTab_Files.Items.Add(objMyFile.Fullname)

            strPath = GetPath(objMyFile.Fullname)

            objItem.SubItems.Add(GetFileSizeInMB_UsingSize(objMyFile.Size))
            objItem.SubItems.Add(objMyFile.Size)
            objItem.SubItems.Add(strPath)

            objItem.SubItems.Add("")
        Next

        My.Application.DoEvents()

        objMyFile = Nothing
        colMyFiles = Nothing
        colMyFiles = New colMyFileInfo

        'Dim objE As New ColumnClickEventArgs(FILES_COL_NAME)
        'lvwFiles_ColumnClick(Nothing, objE)

        Reset_GCComp()

        fraGSComp.Text = "GS Comp. -  " & lvwGSCompTab_Files.Items.Count & " files"

    End Sub

    Public Sub GSCompTab_LoadAllFilesInFolder_Recursive(ByVal strFrom As String, ByRef colMyFiles As colMyFileInfo)

        Dim objDir As DirectoryInfo, d As DirectoryInfo, objFile As FileInfo, objSubDir As DirectoryInfo
        Dim objMyFile As clsMyFileInfo

        If strFrom = "" Then

            MessageBox.Show("No Path!")
            Exit Sub
        End If

        objDir = New DirectoryInfo(strFrom)

        For Each objFile In objDir.GetFiles("*.pdf")

            objMyFile = New clsMyFileInfo

            objMyFile.Fullname = objFile.FullName
            objMyFile.Size = objFile.Length

            colMyFiles.Add(objMyFile)
        Next

        For Each d In objDir.GetDirectories()

            For Each objFile In d.GetFiles("*.pdf")

                objMyFile = New clsMyFileInfo

                objMyFile.Fullname = objFile.FullName
                objMyFile.Size = objFile.Length

                colMyFiles.Add(objMyFile)

                My.Application.DoEvents()
            Next

            For Each objSubDir In d.GetDirectories

                GSCompTab_LoadAllFilesInFolder_Recursive(objSubDir.FullName, colMyFiles)
            Next
        Next

    End Sub

    Private Sub cmdGSCompTab_GSCompress_Click(sender As Object, e As EventArgs) Handles cmdGSCompTab_GSCompress.Click

        Dim strFile As String, strMessage As String = ""
        Dim objItem As ListViewItem, strInfoMessages As String = ""
        Dim blnDoSelected As Boolean = False, blnDoItem As Boolean = False
        Dim intCount As Integer = 0, blnEndLoop As Boolean = False

        If lvwGSCompTab_Files.Items.Count = 0 Then

            txtErrors.Text = "No file selected!"
            tmrClearError.Enabled = True
            Exit Sub
        End If

        txtGSCompTab_Details.Text = ""

        If lvwGSCompTab_Files.SelectedItems.Count > 0 Then

            blnDoSelected = True
        End If

        For Each objItem In lvwGSCompTab_Files.Items

            If blnDoSelected And objItem.Selected Then

                blnDoItem = True

            ElseIf blnDoSelected And Not objItem.Selected Then

                blnDoItem = False
            Else

                blnDoItem = True
            End If

            If blnDoItem Then

                strFile = objItem.Text

                My.Application.DoEvents()

                If GSCompressFile_CheckSuitable(strFile, strMessage, blnEndLoop) Then

                    If blnEndLoop Then Exit For

                    txtGSCompTab_Details.Text = strFile.Replace(txtGSCompTab_Path.Text, "") & " is next" & vbCrLf & txtGSCompTab_Details.Text

                    My.Application.DoEvents()
                    txtGSCompTab_Details.Refresh()

                    My.Application.DoEvents()

                    GSCompressFile(strFile, False, strInfoMessages)

                    My.Application.DoEvents()
                    txtGSCompTab_Details.Refresh()

                    txtGSCompTab_Details.Text = strInfoMessages & vbCrLf & txtGSCompTab_Details.Text

                    txtGSCompTab_Details.Refresh()
                    My.Application.DoEvents()
                Else

                    My.Application.DoEvents()
                    txtGSCompTab_Details.Refresh()

                    If intCount <= 500 Then

                        intCount = intCount + 1
                    Else

                        txtGSCompTab_Details.Text = ""
                        intCount = 1
                    End If

                    txtGSCompTab_Details.Text = strFile.Replace(txtGSCompTab_Path.Text, "") & " is not suitable" & vbCrLf & txtGSCompTab_Details.Text

                    txtGSCompTab_Details.Refresh()
                    My.Application.DoEvents()
                End If

                My.Application.DoEvents()

                txtGSCompTab_Details.Text = txtGSCompTab_Details.Text & vbCrLf

                My.Application.DoEvents()

                txtGSCompTab_Details.Refresh()
            End If
        Next

        cmdGSCompTab_Load_Click(Nothing, Nothing)

        PlaySound(ROOT_DRIVE & "\VB.Net\My Projects\_Sounds\CompressionComplete.mp3")

        MessageBox.Show("Finished!")

    End Sub

    Private Sub cmdePubConvTab_Path_Click(sender As Object, e As EventArgs) Handles cmdePubConvTab_Path.Click

        Me.Text = APP_NAME

        FolderBrowserDialog1.RootFolder = Environment.SpecialFolder.MyComputer

        If txtePubConvTab_Path.Text = "" Then

            FolderBrowserDialog1.SelectedPath = ROOT_DRIVE & "\Books"
        Else

            FolderBrowserDialog1.SelectedPath = txtePubConvTab_Path.Text
        End If

        If FolderBrowserDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then

            If FolderBrowserDialog1.SelectedPath <> "" Then

                txtePubConvTab_Path.Text = Mid(FolderBrowserDialog1.SelectedPath, 1, 1).ToLower & Mid(FolderBrowserDialog1.SelectedPath, 2)
                LoadFiles_ePubConvTab(txtePubConvTab_Path.Text)

                Reset_ePubConv()
            End If

        End If

    End Sub

    Private Sub Reset_ePubConv()

        Cursor = Cursors.Default
        Me.Text = APP_NAME

        Me.Refresh()

        If lvwePubConvTab_Files.Items.Count = 0 Then

            fraBookManagement.Text = "Book Management"
        Else

            fraBookManagement.Text = "Book Management - Torrent " & lvwePubConvTab_Files.Items.Count & " files"
        End If

    End Sub

    Private Sub cmdTorrents_LoadBothPage0s_Click(sender As Object, e As EventArgs) Handles cmdTorrents_LoadBothPage0s.Click

        cmdTorrents_LoadPDFPage0_Click(Nothing, Nothing)

        cmdBooks_LoadPDFPage0_Click(Nothing, Nothing)

    End Sub

    Sub LoadFiles_ePubConvTab(ByVal strPath As String)

        Dim objItem As ListViewItem, blnAdd As Boolean

        Me.Text = APP_NAME

        lvwePubConvTab_Files.Items.Clear()

        If strPath.Trim = "" Then

            MessageBox.Show("Enter path!")
            Exit Sub
        End If

        If Not My.Computer.FileSystem.DirectoryExists(strPath) Then Exit Sub

        Dim objDir As New DirectoryInfo(strPath)

        blnAdd = True

        Try

            For Each objFile As FileInfo In objDir.GetFiles("*.epub")

                objItem = lvwePubConvTab_Files.Items.Add(objFile.FullName)

                strPath = GetPath(objFile.FullName)

                objItem.SubItems.Add(GetFileSizeInMB_UsingSize(objFile.Length))
                objItem.SubItems.Add(objFile.Length)
                objItem.SubItems.Add(strPath)
            Next

        Catch ex As Exception

            MessageBox.Show(ex.Message)
        End Try

        'Dim objE As New ColumnClickEventArgs()

        'lvwePubConvTab_Files_ColumnClick(Nothing, objE)

    End Sub

    Private Sub cmdePubConvTab_Load_Click(sender As Object, e As EventArgs) Handles cmdePubConvTab_Load.Click

        If txtePubConvTab_Path.Text = "" Then Exit Sub

        Cursor = Cursors.WaitCursor

        LoadFiles_ePubConvTab(txtePubConvTab_Path.Text)

        Reset_ePubConv()

        If mblnLookForFiles Then

            If lvwePubConvTab_Files.Items.Count > 0 Then

                mblnLookForFiles = False
                mblnLookForFilesBackwards = False
            Else

                If mblnLookForFilesBackwards Then

                    ' cmdPDFEditingBack_Click(Nothing, Nothing)
                Else

                    ' cmdPDFEditingForward_Click(Nothing, Nothing)
                End If
            End If
        End If

        fraePubConv.Text = "ePub Conversion - " & lvwePubConvTab_Files.Items.Count & " files"

    End Sub

    Private Sub cmdePubConvTab_LoadRec_Click(sender As Object, e As EventArgs) Handles cmdePubConvTab_LoadRec.Click

        ePubConvTab_LoadRecursive(txtePubConvTab_Path.Text, True)

    End Sub

    Private Sub ePubConvTab_LoadRecursive(ByVal strPath As String, ByVal blnDoClear As Boolean)

        Dim colMyFiles As New colMyFileInfo, objItem As ListViewItem
        Dim objMyFile As clsMyFileInfo

        Me.Text = APP_NAME

        If strPath.Trim = "" Then

            MessageBox.Show("Enter path!")
            Exit Sub
        End If

        Cursor = Cursors.WaitCursor

        mstrLoadType = "LOADRECURSIVE"

        ePubConvTab_LoadAllFilesInFolder_Recursive(strPath, colMyFiles)

        If blnDoClear Then lvwePubConvTab_Files.Items.Clear()

        For Each objMyFile In colMyFiles

            objItem = lvwePubConvTab_Files.Items.Add(objMyFile.Fullname)

            strPath = GetPath(objMyFile.Fullname)

            objItem.SubItems.Add(GetFileSizeInMB_UsingSize(objMyFile.Size))
            objItem.SubItems.Add(objMyFile.Size)
            objItem.SubItems.Add(strPath)

            objItem.SubItems.Add("")
        Next

        My.Application.DoEvents()

        objMyFile = Nothing
        colMyFiles = Nothing
        colMyFiles = New colMyFileInfo

        'Dim objE As New ColumnClickEventArgs(FILES_COL_NAME)
        'lvwFiles_ColumnClick(Nothing, objE)

        Reset_ePubConv()

        fraePubConv.Text = "ePub Conversion - " & lvwePubConvTab_Files.Items.Count & " files"

    End Sub

    Public Sub ePubConvTab_LoadAllFilesInFolder_Recursive(ByVal strFrom As String, ByRef colMyFiles As colMyFileInfo)

        Dim objDir As DirectoryInfo, d As DirectoryInfo, objFile As FileInfo, objSubDir As DirectoryInfo
        Dim objMyFile As clsMyFileInfo

        If strFrom = "" Then

            MessageBox.Show("No Path!")
            Exit Sub
        End If

        objDir = New DirectoryInfo(strFrom)

        For Each objFile In objDir.GetFiles("*.epub")

            objMyFile = New clsMyFileInfo

            objMyFile.Fullname = objFile.FullName
            objMyFile.Size = objFile.Length

            colMyFiles.Add(objMyFile)
        Next

        For Each d In objDir.GetDirectories()

            For Each objFile In d.GetFiles("*.epub")

                objMyFile = New clsMyFileInfo

                objMyFile.Fullname = objFile.FullName
                objMyFile.Size = objFile.Length

                colMyFiles.Add(objMyFile)

                My.Application.DoEvents()
            Next

            For Each objSubDir In d.GetDirectories

                ePubConvTab_LoadAllFilesInFolder_Recursive(objSubDir.FullName, colMyFiles)
            Next
        Next

    End Sub

    Private Sub cmdePubConvTab_EpubConv_Click(sender As Object, e As EventArgs) Handles cmdePubConvTab_EpubConv.Click

        Dim strFile As String, strMessage As String = ""
        Dim objItem As ListViewItem, strInfoMessages As String = ""
        Dim blnDoSelected As Boolean = False, blnDoItem As Boolean = False
        Dim strOutput As String = "", blnEndLoop As Boolean

        If lvwePubConvTab_Files.Items.Count = 0 Then

            txtErrors.Text = "No file selected!"
            tmrClearError.Enabled = True
            Exit Sub
        End If

        txtePubConvTab_Details.Text = ""

        If lvwePubConvTab_Files.SelectedItems.Count > 0 Then

            blnDoSelected = True
        End If

        For Each objItem In lvwePubConvTab_Files.Items

            If blnDoSelected And objItem.Selected Then

                blnDoItem = True

            ElseIf blnDoSelected And Not objItem.Selected Then

                blnDoItem = False
            Else

                blnDoItem = True
            End If

            If blnDoItem Then

                strFile = objItem.Text

                My.Application.DoEvents()

                txtePubConvTab_Details.Text = strFile.Replace(txtePubConvTab_Path.Text, "") & " is next" & vbCrLf & txtePubConvTab_Details.Text

                My.Application.DoEvents()
                txtePubConvTab_Details.Refresh()

                My.Application.DoEvents()

                Calibre_epubToPDF_Conversion(strFile, strOutput, False, strInfoMessages)

                If GSCompressFile_CheckSuitable(strOutput, "", blnEndLoop) Then

                    If blnEndLoop Then Exit For

                    If Not GSCompressFile(strOutput, True, strInfoMessages) Then

                        Exit Sub
                    End If
                End If

                My.Application.DoEvents()
                txtePubConvTab_Details.Refresh()

                txtePubConvTab_Details.Text = strInfoMessages & vbCrLf & txtePubConvTab_Details.Text

                txtePubConvTab_Details.Refresh()
                My.Application.DoEvents()
            End If
        Next

        cmdePubConvTab_Load_Click(Nothing, Nothing)

        PlaySound(ROOT_DRIVE & "\VB.Net\My Projects\_Sounds\CompressionComplete.mp3")

        MessageBox.Show("Finished!")

    End Sub


End Class
