Option Strict Off
Option Explicit On
<System.Runtime.InteropServices.ProgId("clsHTMLReader_NET.clsHTMLReader")> Public Class clsHTMLReader
	
	Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Integer)
	
	' PlayWave
	Private Declare Function sndPlaySound Lib "winmm.dll"  Alias "sndPlaySoundA"(ByVal lpszSoundName As String, ByVal uFlags As Integer) As Integer
	
	Const SND_SYNC As Short = &H0s
	Const SND_ASYNC As Short = &H1s
	Const SND_NODEFAULT As Short = &H2s
	Const SND_MEMORY As Short = &H4s
	Const SND_LOOP As Short = &H8s
	Const SND_NOSTOP As Short = &H10s
	' PlayWave
	
	
	Private Const ACCOUNTCODE As String = "ACCBAL"
	Private Const TESTCODE As String = "TEST"
	Private Const LSE_URL As String = "http://www.lse.co.uk/SharePrice.asp?shareprice="
	
	Private Const LSE_MISSING_CHATS_URL As String = "http://www.lse.co.uk/ShareChat.asp?ShareTicker="
	'http://www.lse.co.uk/ShareChat.asp?ShareTicker=LLOY
	Private Const LSE_MISSING_CHATS_PLUS_URL As String = "http://www.lse.co.uk/ShareChat.asp?page=[NUMBER]&ShareTicker="
	
	Private Const III_URL_START As String = "http://www.iii.co.uk/investment/detail%3Fcode%3Dcotn:"
	Private Const III_URL_END As String = ".L%26it%3Dle"
	
	Private Const III_MISSING_CHATS_START_URL As String = "http://www.iii.co.uk/investment/detail/?display=discussion&code=cotn%3A"
	Private Const III_MISSING_CHATS_END_URL As String = ".L&threshold=0&pageno=[NUMBER]&it=le"

    Public Function GetHTMLofURL(ByVal strURL As String) As String

        Dim strHTML As String
        Dim frmInet1 As frmSimpleInet

        On Error GoTo errHandler

        AddAShortDelay()

        frmInet1 = New frmSimpleInet

        strHTML = frmInet1.Inet1.OpenURL(strURL, 0)

        Do Until frmInet1.Inet1.StillExecuting = False

            System.Windows.Forms.Application.DoEvents()

            Sleep(100)

            System.Windows.Forms.Application.DoEvents()
        Loop

        GetHTMLofURL = strHTML

        frmInet1.Close()
        frmInet1 = Nothing

        Exit Function

errHandler:

        frmInet1.Close()
        frmInet1 = Nothing

    End Function

    Public Function GetCurrentPrice(ByVal strCode As String) As Double

        Dim strHTML As String
        Dim lngPos, lngPos2 As Integer
        Dim frmInet1 As frmSimpleInet
        Dim strSPHTML As String

        On Error GoTo errHandler

        AddAShortDelay()

        ' For Testing
151:    If strCode = TESTCODE Then

152:        GetCurrentPrice = CDbl("5")
153:    End If

154:    frmInet1 = New frmSimpleInet

155:    strHTML = frmInet1.Inet1.OpenURL(LSE_URL & strCode, 0)

156:    Do Until frmInet1.Inet1.StillExecuting = False

157:        System.Windows.Forms.Application.DoEvents()

158:        Sleep(100)

            System.Windows.Forms.Application.DoEvents()
159:    Loop

160:    If InStr(1, strHTML, "Login Failed") > 0 Then

161:        GetCurrentPrice = CDbl("-1")
162:        Exit Function
163:    End If

164:    lngPos = InStr(1, strHTML, "class=""SharePriceInfoHeader"">")

165:    strHTML = Mid(strHTML, lngPos, 500)

166:    If (strCode = "BLNX") And Now > CDate(Today & " " & "17:20") Then

167:        strSPHTML = strHTML

168:        lngPos = InStr(1, strSPHTML, "Share Price:</span>")

169:        strSPHTML = Mid(strSPHTML, lngPos, 500)

170:        strSPHTML = Trim(Mid(strSPHTML, Len("Share Price:</span>") + 1))

171:        strSPHTML = Mid(strSPHTML, 1, InStr(1, strSPHTML, "</td>") - 1)

172:        GetCurrentPrice = CDbl(Trim(strSPHTML))

173:        frmInet1.Close()
174:        frmInet1 = Nothing

175:        Exit Function
176:    End If

177:    lngPos = InStr(1, strHTML, "Bid:</span>")

178:    strHTML = Mid(strHTML, lngPos, 500)

179:    strHTML = Trim(Mid(strHTML, Len("Bid:</span>") + 1))

180:    strHTML = Mid(strHTML, 1, InStr(1, strHTML, "</td>") - 1)

181:    GetCurrentPrice = CDbl(Trim(strHTML))

182:    frmInet1.Close()
183:    frmInet1 = Nothing

184:    Exit Function

errHandler:

185:    frmInet1.Close()
186:    frmInet1 = Nothing

187:    PlayWave(My.Application.Info.DirectoryPath & "\compute.wav")

188:    MsgBox(strCode & " " & Err.Number & " " & Err.Description & " " & Erl())

189:    GetCurrentPrice = CDbl("-1")

190:
    End Function

    Private Sub AddAShortDelay()

        Sleep(1001)

    End Sub

    Private Sub PlayWave(ByVal strFileName As String)

        Dim rc As Integer

        rc = sndPlaySound(strFileName, SND_ASYNC)

    End Sub
End Class