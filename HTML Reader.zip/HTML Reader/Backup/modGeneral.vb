Option Strict Off
Option Explicit On
Module modGeneral
	
	Public Sub Main()
		
	End Sub
End Module