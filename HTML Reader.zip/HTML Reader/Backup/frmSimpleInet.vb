Option Strict Off
Option Explicit On
Friend Class frmSimpleInet
	Inherits System.Windows.Forms.Form
	
	Private Sub frmSimpleInet_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Click
		
		Dim objReader As New clsHTMLReader
		Dim strHTML As String
		
		objReader.GetCurrentPrice("ACU")
		objReader.GetCurrentPrice("AMC")
		objReader.GetCurrentPrice("IMTK")
		strHTML = CStr(objReader.GetCurrentPrice("LMT"))
		strHTML = CStr(objReader.GetCurrentPrice("MTV"))
		
		objReader = Nothing
		
		MsgBox(strHTML)
		
	End Sub
End Class