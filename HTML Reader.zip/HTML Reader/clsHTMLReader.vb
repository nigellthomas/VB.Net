Option Strict Off
Option Explicit On

Imports System.Diagnostics.Eventing
Imports System.IO
Imports System.Net
Imports System.Text

<System.Runtime.InteropServices.ProgId("clsHTMLReader_NET.clsHTMLReader")> Public Class clsHTMLReader

    Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Integer)

    ' PlayWave
    Private Declare Function sndPlaySound Lib "winmm.dll" Alias "sndPlaySoundA" (ByVal lpszSoundName As String, ByVal uFlags As Integer) As Integer

    Const SND_SYNC As Short = &H0S
    Const SND_ASYNC As Short = &H1S
    Const SND_NODEFAULT As Short = &H2S
    Const SND_MEMORY As Short = &H4S
    Const SND_LOOP As Short = &H8S
    Const SND_NOSTOP As Short = &H10S
    ' PlayWave


    Private Const ACCOUNTCODE As String = "ACCBAL"
    Private Const TESTCODE As String = "TEST"
    Private Const LSE_URL As String = "http://www.lse.co.uk/SharePrice.asp?shareprice="

    Private Const LSE_MISSING_CHATS_URL As String = "http://www.lse.co.uk/ShareChat.asp?ShareTicker="
    'http://www.lse.co.uk/ShareChat.asp?ShareTicker=LLOY
    Private Const LSE_MISSING_CHATS_PLUS_URL As String = "http://www.lse.co.uk/ShareChat.asp?page=[NUMBER]&ShareTicker="

    Private Const III_URL_START As String = "http://www.iii.co.uk/investment/detail%3Fcode%3Dcotn:"
    Private Const III_URL_END As String = ".L%26it%3Dle"

    Private Const III_MISSING_CHATS_START_URL As String = "http://www.iii.co.uk/investment/detail/?display=discussion&code=cotn%3A"
    Private Const III_MISSING_CHATS_END_URL As String = ".L&threshold=0&pageno=[NUMBER]&it=le"

    Public Function GetHTMLofURL(ByVal strURL As String, Optional ByVal strUsername As String = "", Optional strPassword As String = "") As String

        Dim request As HttpWebRequest
        Dim response As HttpWebResponse
        Dim sr As StreamReader

        Try

            Dim intRnd As Integer, intNum As Integer

            AddAShortDelay()

            System.Windows.Forms.Application.DoEvents()

            Dim r As New Random(TimeOfDay.Second)
            Randomize()

            intRnd = r.Next(10000)

            Sleep(intRnd)

            request = DirectCast(HttpWebRequest.Create(strURL), HttpWebRequest)

            ' Use different user agents - see https://deviceatlas.com/blog/list-of-user-agent-strings#desktop for a full list (may need to keep this up to date

            intNum = intRnd.ToString.Substring(intRnd.ToString.Length - 1)

            Select Case intNum
                Case 0 : request.UserAgent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                Case 1 : request.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, Like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0"
                Case 2 : request.UserAgent = "Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36"
                Case 3 : request.UserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.3.1 Safari/605.1.15"
                Case 4, 5 : request.UserAgent = "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:15.0) Gecko/20100101 Firefox/15.0.1"
                Case 6 : request.UserAgent = "Dalvik/2.1.0 (Linux; U; Android 6.0.1; Nexus Player Build/MMB29T)"
                Case 7 : request.UserAgent = "Mozilla/5.0 (PlayStation; PlayStation 5/2.26) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0 Safari/605.1.15"
                Case 8 : request.UserAgent = "Mozilla/5.0 (PlayStation 4 3.11) AppleWebKit/537.73 (KHTML, like Gecko)"
                Case 9 : request.UserAgent = "Mozilla/5.0 (Windows Phone 10.0; Android 4.2.1; Xbox; Xbox One) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Mobile Safari/537.36 Edge/13.10586"
            End Select

            response = request.GetResponse()

            sr = New StreamReader(response.GetResponseStream())

            Dim responseFromServer As String = sr.ReadToEnd()

            ' Clean up the streams and the response.  
            sr.Close()
            sr.Dispose()
            response.Close()
            response.Dispose()
            request = Nothing

            System.Windows.Forms.Application.DoEvents()

            GetHTMLofURL = responseFromServer

        Catch ex As Exception

            GetHTMLofURL = ""

            request = Nothing
            response = Nothing
        End Try

    End Function

    Public Function GetHTMLofURL1(ByVal strURL As String, Optional ByVal strUsername As String = "", Optional strPassword As String = "") As String

        System.Net.ServicePointManager.Expect100Continue = True
        System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12


        Dim strHTML As String
        ' Create a request for the URL.   
        Dim request As WebRequest = WebRequest.Create(strURL)
        Dim response As WebResponse
        Dim objCred As System.Net.ICredentials

        ' ONLY USE METHOD TO GET TEXT/HTML 

        Try

            AddAShortDelay()

            System.Windows.Forms.Application.DoEvents()

            Sleep(100)

            ' If required by the server, set the credentials.  
            If strUsername = "" And strPassword = "" Then

                request.Credentials = CredentialCache.DefaultCredentials
            Else

                objCred = New NetworkCredential(strUsername, strPassword)

                request.Credentials = objCred
            End If

            ' Get the response.  
            response = request.GetResponse()
            ' Display the status.  
            'Console.WriteLine(CType(response, HttpWebResponse).StatusDescription)
            ' Get the stream containing content returned by the server.  

            Dim dataStream As Stream = response.GetResponseStream()
            ' Open the stream using a StreamReader for easy access.  
            Dim reader As New StreamReader(dataStream)
            ' Read the content.  

            Dim responseFromServer As String = reader.ReadToEnd()
            ' Display the content.  

            strHTML = responseFromServer

            ' Clean up the streams and the response.  
            reader.Close()
            response.Close()

            System.Windows.Forms.Application.DoEvents()

            GetHTMLofURL1 = strHTML

        Catch ex As Exception

            strHTML = ""

            request = Nothing
            response = Nothing
        End Try

    End Function

    Public Function GetFirstCharsOfLink(ByVal strURL As String, ByVal intCount As Integer, Optional ByVal strUsername As String = "", Optional strPassword As String = "") As String

        Dim strHTML As String
        ' Create a request for the URL.   

        If strurl = "" Then Exit Function
        If mid(strurl, 1, 4).tolower <> "http" Then Exit Function

        Dim request As WebRequest = WebRequest.Create(strURL)
        Dim response As WebResponse
        Dim objCred As System.Net.ICredentials
        Dim i As Integer

        Try

            AddAShortDelay()

            System.Windows.Forms.Application.DoEvents()

            Sleep(100)

            ' If required by the server, set the credentials.  
            If strUsername = "" And strPassword = "" Then

                request.Credentials = CredentialCache.DefaultCredentials
            Else

                objCred = New NetworkCredential(strUsername, strPassword)

                request.Credentials = objCred
            End If

            ' Get the response.  
            response = request.GetResponse()
            ' Display the status.  
            'Console.WriteLine(CType(response, HttpWebResponse).StatusDescription)
            ' Get the stream containing content returned by the server.  

            Dim dataStream As Stream = response.GetResponseStream()
            ' Open the stream using a StreamReader for easy access.  
            Dim reader As New StreamReader(dataStream)
            ' Read the content.  

            Dim chrArray(intCount) As Char

            reader.Read(chrArray, 0, intCount)

            GetFirstCharsOfLink = ""

            For i = 0 To chrArray.Length - 1

                GetFirstCharsOfLink = String.Concat(GetFirstCharsOfLink, chrArray(i))
            Next

            ' Clean up the streams and the response.  
            reader.Close()
            response.Close()

            System.Windows.Forms.Application.DoEvents()

        Catch ex As Exception

            strHTML = ""

            request = Nothing
            response = Nothing
        End Try

    End Function

    Public Function GetBinaryFile(ByVal strURL As String, ByVal strFilename As String, Optional ByVal strUsername As String = "", Optional strPassword As String = "") As String

        Dim strHTML As String
        ' Create a request for the URL.   
        Dim request As WebRequest = WebRequest.Create(strURL)
        Dim response As WebResponse
        Dim objCred As System.Net.ICredentials
        Dim objFileWriter As IO.FileStream = Nothing

        Try

            AddAShortDelay()

            System.Windows.Forms.Application.DoEvents()

            Sleep(100)

            ' If required by the server, set the credentials.  
            If strUsername = "" And strPassword = "" Then

                request.Credentials = CredentialCache.DefaultCredentials
            Else

                objCred = New NetworkCredential(strUsername, strPassword)

                request.Credentials = objCred
            End If

            response = request.GetResponse()

            If My.Computer.FileSystem.FileExists(strFilename) Then

                My.Computer.FileSystem.DeleteFile(strFilename, FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin)
            End If

            Dim objReader As IO.Stream = response.GetResponseStream()
            objFileWriter = New IO.FileStream(strFilename, IO.FileMode.Create)

            Dim intLength As Integer
            Dim lBytes(32768) As Byte

            Do

                intLength = objReader.Read(lBytes, 0, lBytes.Length)
                objFileWriter.Write(lBytes, 0, intLength)

            Loop While intLength > 0

            objFileWriter.Close()
            objReader.Close()

            response.Close()
            request = Nothing

            System.Windows.Forms.Application.DoEvents()

        Catch ex As Exception

            If Not IsNothing(objFileWriter) Then objFileWriter.Close()

            MessageBox.Show(ex.ToString)

            request = Nothing
            response = Nothing
        End Try

    End Function


    Private Sub AddAShortDelay()

        Sleep(1001)

    End Sub

    Private Sub PlayWave(ByVal strFileName As String)

        Dim rc As Integer

        rc = sndPlaySound(strFileName, SND_ASYNC)

    End Sub
End Class