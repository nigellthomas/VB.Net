﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load

        Dim objReader As New clsHTMLReader
        Dim strHTML As String

        'strHTML = objReader.GetHTMLofURL("https://freemagazines.top/") & ""

        'MessageBox.Show(Mid(strHTML, 1, 500))

        'strHTML = objReader.GetHTMLofURL("https://www.google.com/search?q=lloy+share+price&client=firefox-b") & ""

        strHTML = objReader.GetHTMLofURL("https://www.imdb.com/title/tt12539916/") & ""

        MessageBox.Show(Mid(strHTML, 1, 50000))

        'objReader.GetFirstCharsOfLink("https://vk.com/doc527052285_594055831?hash=be1dcf64c8c520c345&dl=GQZDGNBSGQ2DGNQ:1618056336:b52b1d84bbd594bd49&api=1&no_preview=1", 4)

        ' objReader.GetBinaryFile("https://vk.com/doc527052285_594055831?hash=be1dcf64c8c520c345&dl=GQZDGNBSGQ2DGNQ:1618056336:b52b1d84bbd594bd49&api=1&no_preview=1", "c:\New Sc.pdf")




    End Sub
End Class
