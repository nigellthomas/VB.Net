﻿Public Class frmOptions

    Private mobjOptions As New clsOptions

    Private Sub frmOptions_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        mobjOptions.LoadOptions()

        txtRoot.Text = mobjOptions.RootFolder

        txtBooks.Text = mobjOptions.Books
        txtMovies.Text = mobjOptions.Movies
        txtMags.Text = mobjOptions.Mags
        txtTV.Text = mobjOptions.TV
        txtProcessed.Text = mobjOptions.Processed
        txtMusic.Text = mobjOptions.Music
        txtPermMagFolder.Text = mobjOptions.PermMagFolder
        txtDeleted.Text = mobjOptions.Deleted

        cmdSave.Enabled = False

    End Sub

    Private Sub cmdSave_Click(sender As System.Object, e As System.EventArgs) Handles cmdSave.Click

        mobjOptions.SaveOptions()

    End Sub

    Private Sub txtTextbox_TextChanged(sender As System.Object, e As System.EventArgs) Handles txtRoot.TextChanged, txtMovies.TextChanged, _
                                                                                               txtMags.TextChanged, txtBooks.TextChanged, _
                                                                                               txtTV.TextChanged, txtProcessed.TextChanged, txtMusic.TextChanged, _
                                                                                               txtPermMagFolder.TextChanged, txtDeleted.TextChanged

        cmdSave.Enabled = True

    End Sub

    Private Sub txtTextbox_Validated(sender As Object, e As System.EventArgs) Handles txtRoot.Validated, txtMovies.Validated, _
                                                                                    txtMags.Validated, txtBooks.Validated, _
                                                                                    txtTV.Validated, txtProcessed.Validated, txtMusic.Validated, _
                                                                                    txtPermMagFolder.Validated, txtDeleted.Validated

        Select Case sender.name.toupper

            Case "TXTROOT" : mobjOptions.RootFolder = txtRoot.Text.Trim
            Case "TXTPROCESSED" : mobjOptions.Processed = txtProcessed.Text.Trim

            Case "TXTBOOKS" : mobjOptions.Books = txtBooks.Text.Trim
            Case "TXTMOVIES" : mobjOptions.Movies = txtMovies.Text.Trim
            Case "TXTMAGS" : mobjOptions.Mags = txtMags.Text.Trim

            Case "TXTMUSIC" : mobjOptions.TV = txtMusic.Text.Trim
            Case "TXTPERMMAGFOLDER" : mobjOptions.PermMagFolder = txtPermMagFolder.Text.Trim

            Case "TXTDELETED" : mobjOptions.Deleted = txtDeleted.Text.Trim

        End Select

    End Sub


End Class