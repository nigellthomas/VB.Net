Imports System.IO

Module modComTorrFilesAndFolders

    Public Function MoveToDeletedUsingPath(ByVal strPath As String, Optional blnMaintainStats As Boolean = True) As Boolean

        Dim strDeletedFilename As String

        strDeletedFilename = ConvertToDeletedFolder(strPath)

        If My.Computer.FileSystem.FileExists(strDeletedFilename) Then

            strDeletedFilename = MakeRandomlyNamedFile(strDeletedFilename)
        End If

        Try

            If blnMaintainStats Then

                mobjStats.Add_File(GetPrefixwithDot(strPath))
            End If

            Try

                My.Computer.FileSystem.MoveFile(strPath, strDeletedFilename)

            Catch ex As Exception

                File.SetAttributes(strPath, Not FileAttributes.ReadOnly)

                My.Computer.FileSystem.MoveFile(strPath, strDeletedFilename)

            End Try

        Catch ex As Exception

            MoveToDeletedUsingPath = False
            Exit Function
        End Try

        MoveToDeletedUsingPath = True

    End Function

    Private Function ConvertToDeletedFolder(ByVal strPath As String) As String

        ConvertToDeletedFolder = strPath.Replace(mobjOptions.RootFolder, mobjOptions.FullPathDeleted).Replace("\\", "\")

    End Function

    Public Sub RemoveReadonlyFromAllFilesInDirectoryAndDelete(ByRef objDir As DirectoryInfo)

        Dim colFiles() As FileInfo, objFile As FileInfo

        colFiles = objDir.GetFiles

        For Each objFile In colFiles

            If objFile.IsReadOnly Then

                File.SetAttributes(objFile.FullName, Not FileAttributes.ReadOnly)

                MoveToDeleted(objFile)
            Else

                MoveToDeleted(objFile)
            End If

        Next

    End Sub

    Public Sub DeleteAnyFiles(d As DirectoryInfo)

        Dim objFile As FileInfo, colFiles() As FileInfo

        colFiles = d.GetFiles

        For Each objFile In colFiles

            If objFile.IsReadOnly Then

                File.SetAttributes(objFile.FullName, Not FileAttributes.ReadOnly)

                MoveToDeleted(objFile)
            Else

                MoveToDeleted(objFile)
            End If
        Next

    End Sub

    Public Function MoveToDeleted(ByRef objFile As FileInfo, Optional blnMaintainStats As Boolean = True, Optional strKnownType As String = "") As Boolean

        Dim strDeletedFolder As String, strDelete As String
        Dim strTo As String, strFrom As String

        strDeletedFolder = GetPath(ConvertToDeletedFolder(objFile.FullName))

        Try

            If blnMaintainStats Then

                mobjStats.Add_File(objFile.Extension, strKnownType)

            End If

            If objFile.IsReadOnly Then

                SetFileToBeNormal_UsingFilePath(objFile.FullName)
            End If

            Try

                If My.Computer.FileSystem.FileExists(strDeletedFolder & objFile.Name) Then

                    My.Computer.FileSystem.DeleteFile(strDeletedFolder & objFile.Name)
                End If

                strFrom = objFile.FullName
                strTo = strDeletedFolder & objFile.Name

                'objFile.MoveTo(strTo)

                My.Computer.FileSystem.MoveFile(strFrom, strTo)

                Delay(1)

                If Not My.Computer.FileSystem.FileExists(strTo) Then

                    MessageBox.Show("MoveToDeleted - Failed to move " & strFrom & " to " & strTo & "! Ending")

                    End
                End If

            Catch ex As Exception

                DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name, "1" & vbCrLf & strDeletedFolder)
                End
            End Try

            Try

                strDelete = GetPath(strFrom)

                If My.Computer.FileSystem.GetDirectoryInfo(strDelete).GetDirectories.Count = 0 And _
                    My.Computer.FileSystem.GetDirectoryInfo(strDelete).GetFiles.Count = 0 Then

                    My.Computer.FileSystem.DeleteDirectory(strDelete, FileIO.DeleteDirectoryOption.ThrowIfDirectoryNonEmpty)
                End If

            Catch ex As Exception

                DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name, "2" & vbCrLf & strDelete)
                End
            End Try

        Catch ex As Exception

            MoveToDeleted = False
            Exit Function
        End Try

        MoveToDeleted = True

    End Function

    Public Sub CheckYearFolderExists(ByVal strPath As String, ByVal strYear As String)

        strPath = ToProperCase(strPath, False)

        If InStr(strPath, "\Bbc ", CompareMethod.Binary) > 0 Then

            strPath = strPath.Replace("\Bbc ", "\BBC ")
        End If

        If Not My.Computer.FileSystem.DirectoryExists(strPath & "\" & strYear) Then

            My.Computer.FileSystem.CreateDirectory(strPath & "\" & strYear)
        End If

        If InStr(strPath, "_Magazines") > 0 Then

            strPath = strPath.Replace(mobjOptions.RootFolder & "_Magazines", ROOT_DRIVE & "\Books\Mags")

            If Not My.Computer.FileSystem.DirectoryExists(strPath & "\" & strYear) Then

                My.Computer.FileSystem.CreateDirectory(strPath & "\" & strYear)
            End If
        End If

    End Sub

    Public Sub CleanupFolders(ByRef objMe As frmMain)

        Dim d As DirectoryInfo
        Dim colFiles() As FileInfo
        Dim objSubDirs() As DirectoryInfo, objSubDir As DirectoryInfo
        Dim objDir As DirectoryInfo

        objDir = New DirectoryInfo(GetRootPath())

        For Each d In objDir.GetDirectories()

            If IsDirectoryToBeProcessed(d, True) Then

                If d.Name = "Tehran.S03E02.1080p.WEB.h264-Kan" Or d.Name = "Tehran.S03E04.1080p.WEB.h264-Kan" Or d.Name = "Tehran.S03E05.1080p.WEB.h264-Kan" Then

                    Dim s As String = ""

                    s = "sretg"
                End If

                Try

                    UpdateScreen(objMe, d.Name)

                    colFiles = d.GetFiles()

                    If Not DeleteCrapfiles(objMe, d, colFiles, True, True) Then

                        objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Deleting crap files - ", d.FullName, " NEEDS MANUAL WORK")

                        objMe.mblnFoundURLFILE = True

                        ' Do Nothing - typically comes from RAR/TGZ files that include
                        ' internet shortcuts files are often badly named and need sorting manually
                    Else

                        d.Refresh()

                        If d.Exists Then

                            ProcessDuplicatedBooks(d)

                            FilesinDirectoryHaveTVStyleStructure(d, True)

                            If d.GetDirectories.Length > 0 Then

                                objSubDirs = d.GetDirectories

                                For Each objSubDir In objSubDirs

                                    colFiles = objSubDir.GetFiles()

                                    DeleteCrapfiles(objMe, objSubDir, colFiles)
                                    ProcessDuplicatedBooks(objSubDir)
                                Next

                            End If
                        End If
                    End If

                Catch ex As Exception

                    MessageBox.Show("CleanupFolders - ex.message - " & ex.Message & " - " & d.FullName)
                    End
                End Try
            End If
        Next

    End Sub

    Public Sub DeleteEmptyFoldersAccountingForSpecialFolders(ByRef objDir As DirectoryInfo)

        Dim d As DirectoryInfo
        Dim colFiles() As FileInfo
        Dim colSubDirs() As DirectoryInfo

        For Each d In objDir.GetDirectories()

            objDir.Refresh()

            If IsDirectoryToBeProcessed(d, True) Then

                Try

                    If d.Name <> ASSORTED_BOOKS_COLLECTION Then

                        d.Refresh()

                        If My.Computer.FileSystem.DirectoryExists(d.FullName) Then

                            Try

                                colFiles = d.GetFiles()

                            Catch ex As Exception

                            End Try

                            If Not colFiles Is Nothing Then

                                If colFiles.Length = 0 Then

                                    colSubDirs = d.GetDirectories()

                                    If colSubDirs.Length = 0 Then

                                        My.Application.DoEvents()

                                        d.Refresh()

                                        Try

                                            d.Delete()

                                            Sleep(100)

                                        Catch ex As Exception

                                        End Try

                                        My.Application.DoEvents()

                                        objDir.Refresh()

                                        If objDir.GetDirectories().Length = 0 And objDir.GetFiles.Length = 0 Then

                                            If IsDirectoryToBeProcessed(objDir, True) Then objDir.Delete()
                                        End If
                                    Else

                                        If My.Computer.FileSystem.DirectoryExists(d.FullName) Then

                                            DeleteEmptyFoldersAccountingForSpecialFolders(d)
                                        End If
                                    End If
                                End If

                            End If

                        End If
                    End If

                Catch notFound As DirectoryNotFoundException

                    ' This is OK

                Catch access As AccessViolationException

                    ' This is OK

                Catch ex As Exception

                    DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

                End Try
            End If
        Next

    End Sub

    Public Sub DeleteAllEmptySubFolders(ByRef objDir As DirectoryInfo, ByVal strTopLevel As String)

        Dim d As DirectoryInfo
        Dim colFiles() As FileInfo
        Dim colSubDirs() As DirectoryInfo

        objDir.Refresh()

        Try

            For Each d In objDir.GetDirectories()

                Sleep(100)

                d.Refresh()

                If My.Computer.FileSystem.DirectoryExists(d.FullName) Then

                    If My.Computer.FileSystem.DirectoryExists(d.FullName) Then

                        If IsDirectoryToBeProcessed(d, True) Then

                            colFiles = d.GetFiles()

                            If colFiles.Length = 0 Then

                                colSubDirs = d.GetDirectories()

                                If colSubDirs.Length = 0 Then

                                    My.Application.DoEvents()

                                    d.Refresh()

                                    If My.Computer.FileSystem.DirectoryExists(d.FullName) Then

                                        Try

                                            d.Delete()

                                        Catch ex As Exception

                                        End Try

                                    Else

                                        d.Refresh()
                                    End If

                                    My.Application.DoEvents()

                                    objDir.Refresh()

                                    If objDir.GetDirectories().Length = 0 And (strTopLevel <> objDir.FullName) Then

                                        Try

                                            objDir.Delete()

                                        Catch ex As Exception

                                        End Try

                                    End If

                                Else

                                    d.Refresh()

                                    If My.Computer.FileSystem.DirectoryExists(d.FullName) Then DeleteAllEmptySubFolders(d, strTopLevel)
                                End If

                            End If

                        End If
                    End If
                End If
            Next

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Public Function ProcessDuplicatedBooks(ByRef d As DirectoryInfo) As Boolean

        Dim objFile As FileInfo, objSubDir As DirectoryInfo

        ' AZW3 - prefer everything!
        For Each objFile In d.GetFiles("*.azw3")

            If My.Computer.FileSystem.FileExists(Replace(objFile.FullName, ".azw3", ".djvu", , , CompareMethod.Text)) Then

                MoveToDeleted(objFile, True, BOOK)
            End If
        Next

        For Each objFile In d.GetFiles("*.azw3")

            If My.Computer.FileSystem.FileExists(Replace(objFile.FullName, ".azw3", ".mobi", , , CompareMethod.Text)) Then

                MoveToDeleted(objFile, True, BOOK)
            End If
        Next

        For Each objFile In d.GetFiles("*.azw3")

            If My.Computer.FileSystem.FileExists(Replace(objFile.FullName, ".azw3", ".epub", , , CompareMethod.Text)) Then

                MoveToDeleted(objFile, True, BOOK)
            End If
        Next

        For Each objFile In d.GetFiles("*.azw3")

            If My.Computer.FileSystem.FileExists(Replace(objFile.FullName, ".azw3", ".pdf", , , CompareMethod.Text)) Then

                MoveToDeleted(objFile, True, BOOK)
            End If
        Next

        ' djvu - Prefer mobi, epub & pdf
        For Each objFile In d.GetFiles("*.djvu")

            If My.Computer.FileSystem.FileExists(Replace(objFile.FullName, ".djvu", ".mobi", , , CompareMethod.Text)) Then

                MoveToDeleted(objFile, True, BOOK)
            End If
        Next

        For Each objFile In d.GetFiles("*.djvu")

            If My.Computer.FileSystem.FileExists(Replace(objFile.FullName, ".djvu", ".epub", , , CompareMethod.Text)) Then

                MoveToDeleted(objFile, True, BOOK)
            End If
        Next

        For Each objFile In d.GetFiles("*.djvu")

            If My.Computer.FileSystem.FileExists(Replace(objFile.FullName, ".djvu", ".pdf", , , CompareMethod.Text)) Then

                MoveToDeleted(objFile, True, BOOK)
            End If
        Next


        ' Mobi - Prefer epub & pdf
        For Each objFile In d.GetFiles("*.mobi")

            If My.Computer.FileSystem.FileExists(Replace(objFile.FullName, ".mobi", ".epub", , , CompareMethod.Text)) Then

                MoveToDeleted(objFile, True, BOOK)
            End If
        Next

        For Each objFile In d.GetFiles("*.mobi")

            If My.Computer.FileSystem.FileExists(Replace(objFile.FullName, ".mobi", ".pdf", , , CompareMethod.Text)) Then

                MoveToDeleted(objFile, True, BOOK)
            End If
        Next

        objFile = Nothing

        ' epub - prefer pdf
        For Each objFile In d.GetFiles("*.epub")

            If My.Computer.FileSystem.FileExists(Replace(objFile.FullName, ".epub", ".pdf", , , CompareMethod.Text)) Then

                MoveToDeleted(objFile, True, BOOK)
            End If
        Next

        objFile = Nothing

        If d.GetDirectories.Length > 0 Then

            For Each objSubDir In d.GetDirectories

                If objSubDir.Name <> mobjOptions.Deleted Then

                    ProcessDuplicatedBooks(objSubDir)
                End If

            Next

        End If

        System.GC.Collect()

    End Function

    Public Function DeleteCrapfiles(ByRef objMe As frmMain, d As DirectoryInfo, colFiles() As FileInfo, Optional ByVal blnCheckFoldersAsWell As Boolean = True,
                                    Optional ByVal blnExitIfFoundURL As Boolean = True) As Boolean

        Dim objFile As FileInfo, objFileTypes As New clsFileTypes
        Dim objSubDir As DirectoryInfo

        DeleteCrapfiles = True

        GetFiletypes(objFileTypes, colFiles, d)

        For Each objFile In colFiles

            If objFile.Extension = ".url" And blnExitIfFoundURL Then

                DeleteCrapfiles = False
                Exit Function
            End If

            If CrapfileByExtension(objFile.Extension) Or CrapFileByName(objFile.Name) Then

                If objFile.IsReadOnly Then

                    SetFileToBeNormal_UsingFilePath(objFile.FullName)

                    UpdateScreen(objMe, "Deleting file by crap extension - " & objFile.Name)
                    MoveToDeleted(objFile)
                Else

                    UpdateScreen(objMe, "Deleting file by crap extension - " & objFile.Name)
                    MoveToDeleted(objFile)
                End If
            End If
        Next

        If objFileTypes.Archive_7z > 0 Then

            UpdateScreen(objMe, "Handling Archives - " & objFileTypes.Archive_7zs)
            HandleArchiveFolder(d, objFileTypes.Archive_7zs, objMe)

        ElseIf objFileTypes.RAR > 0 Then

            DeleteAnySampleFolders(objMe, d)

            ' Extract if one .rar file only
            If objFileTypes.RAR = 1 Then

                UpdateScreen(objMe, "Handling Archives - " & objFileTypes.RARs)
                HandleArchiveFolder(d, objFileTypes.RARs, objMe)
            End If

        End If

        DeleteAnyPictures(d, False)

        If objFileTypes.MovieFilesCount > 0 Then

            UpdateScreen(objMe, "Handling Movie Cleanup - " & d.Name)

            DeleteAnySampleFolders(objMe, d)
            DeleteAnySubFolders(d)
            DeleteAnyScreensFolders(objMe, d)

        End If

        If blnCheckFoldersAsWell Then

            Try

                If My.Computer.FileSystem.DirectoryExists(d.FullName) Then

                    For Each objSubDir In d.GetDirectories

                        If objSubDir.Name <> mobjOptions.Deleted Then

                            DeleteCrapfiles(objMe, objSubDir, objSubDir.GetFiles, True)
                        End If
                    Next
                End If

            Catch ex As Exception

            End Try
        End If

    End Function

    Public Sub DeleteAnySubFolders(ByRef d As DirectoryInfo)

        Dim objSubFile As FileInfo, objSubDir As DirectoryInfo, objSubSubDir As DirectoryInfo
        Dim strPath As String

        For Each objSubDir In d.GetDirectories("Subs")

            strPath = objSubDir.FullName

            For Each objSubFile In objSubDir.GetFiles

                MoveToDeleted(objSubFile)
            Next

            If My.Computer.FileSystem.DirectoryExists(strPath) Then

                For Each objSubSubDir In objSubDir.GetDirectories()

                    objSubSubDir.Delete(True)
                Next

                objSubDir.Delete(True)
            End If
        Next

    End Sub

    Public Sub DeleteAnySampleFolders(ByRef objMe As frmMain, d As DirectoryInfo)

        Dim objSubDir As DirectoryInfo, colFiles() As FileInfo

        For Each objSubDir In d.GetDirectories("Sample")

            DeleteAnyFiles(objSubDir)

            Try

                colFiles = d.GetFiles()

                If colFiles.Length > 0 Then

                    DeleteCrapfiles(objMe, d, colFiles, False)
                End If

                If My.Computer.FileSystem.DirectoryExists(objSubDir.FullName) Then objSubDir.Delete()

            Catch ex As Exception

                'MessageBox.Show("DeleteAnySampleFolders - " & ex.Message & d.FullName)
            End Try

        Next

    End Sub

    Public Sub DeleteAnyScreensFolders(ByRef objMe As frmMain, d As DirectoryInfo)

        Dim objSubDir As DirectoryInfo, colFiles() As FileInfo

        For Each objSubDir In d.GetDirectories("Screens")

            DeleteAnyFiles(objSubDir)

            Try

                colFiles = d.GetFiles()

                If colFiles.Length > 0 Then

                    DeleteCrapfiles(objMe, d, colFiles, False)
                End If

                Try

                    objSubDir.Refresh()

                    If objSubDir.Exists Then objSubDir.Delete()

                Catch ex2 As Exception

                End Try

            Catch ex As Exception

                MessageBox.Show("DeleteAnyScreensFolders - " & ex.Message & d.FullName)
            End Try

        Next

    End Sub

    Private Function IsVideoFile(ByVal strExtension As String) As Boolean

        Select Case strExtension

            Case AVI, WMV, MP4, MKV, MPEG, MPG, M2TS, FLV, ASF : IsVideoFile = True

            Case Else : IsVideoFile = False

        End Select

    End Function

    Public Function IsPicture(ByVal strExt As String) As Boolean

        Select Case strExt

            Case JPEG, JPG, PNG, Bitmap, GIF

                IsPicture = True

            Case Else

                IsPicture = False

        End Select

    End Function

    Public Sub DeleteAnyPictures(d As DirectoryInfo, ByVal blnSubFolder As Boolean)

        Dim objFile As FileInfo, colFiles() As FileInfo
        Dim objSubDir As DirectoryInfo

        If Not My.Computer.FileSystem.DirectoryExists(d.FullName) Then

            Exit Sub
        End If

        Try

            colFiles = d.GetFiles

        Catch ex As Exception

            Exit Sub

        End Try

        For Each objFile In colFiles

            If IsPicture(objFile.Extension.ToUpper) Then

                If objFile.IsReadOnly Then

                    File.SetAttributes(objFile.FullName, Not FileAttributes.ReadOnly)

                    MoveToDeleted(objFile)
                Else

                    MoveToDeleted(objFile)
                End If

            End If
        Next

        If blnSubFolder Then

            Try

                For Each objSubDir In d.GetDirectories

                    If objSubDir.GetDirectories.Length > 0 Then

                        If objSubDir.Name <> mobjOptions.Deleted Then

                            DeleteAnyPictures(objSubDir, True)
                        End If
                    Else

                        DeleteAnyPictures(objSubDir, False)
                    End If
                Next


            Catch ex As Exception

            End Try

        End If

    End Sub



    Public Function GetFileInfo(ByRef colFiles() As FileInfo) As FileInfo

        Dim objFile As FileInfo

        For Each objFile In colFiles


        Next

    End Function

    Public Function UnknownFileType(ByRef d As DirectoryInfo) As Boolean

        Dim objFileTypes As New clsFileTypes, colFiles() As FileInfo

        If Not d.Exists Then

            UnknownFileType = False
            Exit Function
        End If

        colFiles = d.GetFiles()

        GetFiletypes(objFileTypes, colFiles, d)

        mobjStats.Unknown_Count = mobjStats.Unknown_Count + objFileTypes.Unknown

        If objFileTypes.Unknown > 0 Then

            UnknownFileType = True
        Else

            UnknownFileType = False
        End If

        colFiles = Nothing
        objFileTypes = Nothing

    End Function

    Public Function CrapFileByName(ByVal strFileName As String) As Boolean

        strFileName = strFileName.ToUpper().Trim

        Select Case strFileName

            Case "SAMPLE" & AVI, "SAMPLE" & MP4, "SAMPLE" & MKV, "ETRG.MP4"

                Return True

            Case "RARBG_DO_NOT_MIRROR.EXE"

                Return True

            Case Else

                ' bit comet padding
                If strFileName.Length > 18 Then

                    If Mid(strFileName, 1, 18) = "_____PADDING_FILE_" Then

                        If Mid(strFileName, Len(strFileName) - 12) = " OR ABOVE____" Then

                            Return True
                        End If
                    End If
                End If

                Return False

        End Select


    End Function

    Public Function CrapfileByExtension(ByVal strFileExtension As String) As Boolean

        strFileExtension = strFileExtension.ToUpper()

        If InStr(1, CRAP_FILE_EXTENSIONS, strFileExtension & ",") > 0 Then

            CrapfileByExtension = True
        Else

            CrapfileByExtension = False
        End If

    End Function

    Public Function BasicCleanupFilename(ByVal strOriginalFilePath As String) As String

        Dim strOriginalFilename As String, strTempFilename As String, strPrefix As String
        Dim intPos As Integer, strCharL As String, strCharR As String

        Try

            strOriginalFilename = GetFilenameFromPath(strOriginalFilePath)

            strTempFilename = strOriginalFilename.Replace("_", " ")

            strTempFilename = strTempFilename.Replace("�", "-")

            strTempFilename = strTempFilename.Replace(Chr(150), Chr(45))

            strPrefix = GetPrefixwithDot(strTempFilename)
            strTempFilename = RemovePrefix(strTempFilename)
            strTempFilename = strTempFilename.Replace(".", " ")

            strTempFilename = strTempFilename & strPrefix

            strTempFilename = strTempFilename.Replace("[", "(")
            strTempFilename = strTempFilename.Replace("{", "(")

            strTempFilename = strTempFilename.Replace("]", ")")
            strTempFilename = strTempFilename.Replace("}", ")")

            strTempFilename = strTempFilename.Replace("( ", "(")
            strTempFilename = strTempFilename.Replace(" )", ")")

            strTempFilename = strTempFilename.Replace("  ", " ")
            strTempFilename = strTempFilename.Replace("  ", " ")
            strTempFilename = strTempFilename.Replace("  ", " ")

            strTempFilename = strTempFilename.Replace("--", "-")

            intPos = InStr(1, strTempFilename, "-")

            While intPos > 0

                strCharL = Mid(strTempFilename, intPos - 1, 1)

                If strCharL <> " " Then

                    strTempFilename = Mid(strTempFilename, 1, intPos - 1) & " " & Mid(strTempFilename, intPos)
                End If

                intPos = InStr(intPos + 1, strTempFilename, "-")

                If intPos > 0 Then

                    strCharR = Mid(strTempFilename, intPos + 1, 1)

                    If strCharR <> " " Then

                        strTempFilename = Mid(strTempFilename, 1, intPos) & " " & Mid(strTempFilename, intPos + 1)
                    End If

                    intPos = intPos + 1
                End If

                If intPos > 0 Then

                    intPos = InStr(intPos, strTempFilename, "-")
                End If
            End While

            strTempFilename = strTempFilename.Replace(" 720P Hdtv X264 Aac Mvgroup Org", "")
            strTempFilename = strTempFilename.Replace(" Hdtv X264 Aac Mvgroup Org", "")
            strTempFilename = strTempFilename.Replace(" X264 Aac Mvgroup Org", "")
            strTempFilename = strTempFilename.Replace(" Aac Mvgroup Org", "")
            strTempFilename = strTempFilename.Replace("  X264 Aac Mvgroup Forum", "")
            strTempFilename = strTempFilename.Replace("  Aac Mvgroup Forum", "")
            strTempFilename = strTempFilename.Replace("  720P Brrip X264 Yify", "")
            strTempFilename = strTempFilename.Replace("  Pdtv X264 Jive", "")
            strTempFilename = strTempFilename.Replace(" X264", "")
            strTempFilename = strTempFilename.Replace(" 720p", "")
            strTempFilename = strTempFilename.Replace(" 1080p", "")
            strTempFilename = strTempFilename.Replace(" Xvid", "")

            strTempFilename = ToProperCase(strTempFilename, True)

            strTempFilename = CommonCaseReplacements(strTempFilename)

            BasicCleanupFilename = GetPath(strOriginalFilePath) & strTempFilename

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Function

    Public Function ProcessBooksMagsFolder(ByRef objMe As Object) As Boolean

        Dim objDir As DirectoryInfo, d As DirectoryInfo
        Dim strFolderName As String, blnDeleted As Boolean

        ' Smithsonian 
        ' Smithsonian Magazine
        ' Move all folders/files into Smithsonian from Smithsonian Magazine

        Try

            objDir = New DirectoryInfo(ROOT_DRIVE & "\Books\Mags")

            For Each d In objDir.GetDirectories

                blnDeleted = False

                If DoesTextEndIn(d.Name, " Magazine") Then

                    strFolderName = d.Name.Replace(" Magazine", "")

                    If FolderExistsWithName(d, strFolderName) Then

                        MoveFoldersContents(d, strFolderName)

                        DeleteAllEmptySubFolders(d, d.FullName)

                        If d.GetFiles.Count = 0 And d.GetDirectories.Count = 0 Then

                            d.Delete()
                            blnDeleted = True
                        End If
                    End If
                End If

                If Not blnDeleted Then

                    If DoesTextEndIn(d.Name, " Monthly") Then

                        strFolderName = d.Name.Replace(" Monthly", "")

                        If FolderExistsWithName(d, strFolderName) Then

                            MoveFoldersContents(d, strFolderName)

                            DeleteAllEmptySubFolders(d, d.FullName)

                            If d.GetFiles.Count = 0 And d.GetDirectories.Count = 0 Then

                                d.Delete()
                            End If
                        End If
                    End If
                End If

                ' Account for Sky & Telescope and Sky and Telescope
                If Not blnDeleted Then

                    If InStr(d.Name, " and ") > 0 Then

                        strFolderName = d.Name.Replace(" and ", " & ")

                        If FolderExistsWithName(d, strFolderName) Then

                            MoveFoldersContents(d, strFolderName)

                            DeleteAllEmptySubFolders(d, d.FullName)

                            If d.GetFiles.Count = 0 And d.GetDirectories.Count = 0 Then

                                d.Delete()
                            End If
                        End If
                    End If
                End If
            Next

            ProcessBooksMagsFolder = True

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Function

    Public Function RemoveMagazineText(ByVal strFileName As String) As String

        Dim intPos As Integer, strLeftSide As String

        intPos = InStr(strFileName, " -")

        If intPos > 0 Then

            strLeftSide = Mid(strFileName, 1, intPos - 1)

            strLeftSide = strLeftSide.Replace(" Magazine", "")

            RemoveMagazineText = strLeftSide & Mid(strFileName, intPos)
        Else

            RemoveMagazineText = strFileName
        End If

        RemoveMagazineText = RemoveMagazineText.Replace("-", " - ")

        RemoveMagazineText = RemoveMagazineText.Replace("  ", " ")
        RemoveMagazineText = RemoveMagazineText.Replace("  ", " ")
        RemoveMagazineText = RemoveMagazineText.Replace("  ", " ")

    End Function

    Public Function MoveFilesInFolderToAnotherFolder(ByRef objSource As DirectoryInfo, ByRef objDest As DirectoryInfo,
                                                     ByRef objMe As frmMain) As Boolean

        Dim colSourceFiles() As FileInfo, objFile As FileInfo
        Dim strTo As String

        MoveFilesInFolderToAnotherFolder = False

        colSourceFiles = objSource.GetFiles

        For Each objFile In colSourceFiles

            strTo = objDest.FullName & "\" & objFile.Name

            If My.Computer.FileSystem.FileExists(strTo) Then

                If MessageBox.Show("Delete " & objFile.FullName & " due to duplicate (Yes) or stop to manually sort out (No)?", "", MessageBoxButtons.YesNo) = DialogResult.Yes Then

                    objFile.Delete()
                Else

                    End
                End If
            Else

                objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "PreprocessBook - Moving ", objFile.FullName, " to ", strTo)

                Delay(1)

                My.Computer.FileSystem.MoveFile(objFile.FullName, strTo)

                Delay(1)

                If Not My.Computer.FileSystem.FileExists(strTo) Then

                    MessageBox.Show("MoveFilesInFolderToAnotherFolder - File missing - " & strTo)

                    End
                End If
            End If
        Next

        objFile = Nothing
        colSourceFiles = Nothing

        objSource.Refresh()

        If objSource.GetFiles().Count = 0 Then

            objSource.Delete()
        End If

        MoveFilesInFolderToAnotherFolder = True

    End Function

    Public Function MoveFoldersContents(ByRef objDir As DirectoryInfo, ByVal strFolderName As String) As Boolean

        Dim colFiles() As FileInfo, objFile As FileInfo

        colFiles = objDir.GetFiles

        For Each objFile In colFiles

            If Not My.Computer.FileSystem.FileExists(ROOT_DRIVE & "\books\Mags\" & strFolderName & "\" & objFile.Name) Then

                My.Computer.FileSystem.MoveFile(objFile.FullName, ROOT_DRIVE & "\books\Mags\" & strFolderName & "\" & RemoveMagazineText(objFile.Name))
            Else

                objFile.Delete()
            End If
        Next

        For Each objSubDir In objDir.GetDirectories

            MoveFoldersContentssubdir(objSubDir, strFolderName)
        Next

        MoveFoldersContents = True

    End Function

    Private Function MoveFoldersContentsSubDir(ByRef objDir As DirectoryInfo, ByVal strFolderName As String) As Boolean

        Dim colFiles() As FileInfo, objFile As FileInfo

        colFiles = objDir.GetFiles

        For Each objFile In colFiles

            If Not My.Computer.FileSystem.FileExists(ROOT_DRIVE & "\books\Mags\" & strFolderName & "\" & objDir.Name & "\" & objFile.Name) Then

                My.Computer.FileSystem.MoveFile(objFile.FullName, ROOT_DRIVE & "\books\Mags\" & strFolderName & "\" & objDir.Name & "\" & RemoveMagazineText(objFile.Name))
            End If
        Next

        For Each objSubDir In objDir.GetDirectories

            MoveFoldersContentsSubDir(objSubDir, strFolderName)
        Next

        MoveFoldersContentsSubDir = True

    End Function

    Public Function PostProcessMagFolders(ByRef objMe As frmMain) As Boolean

        Dim strRootPath As String
        Dim objDir As DirectoryInfo, d As DirectoryInfo
        Dim objSubDirs As DirectoryInfo()
        Dim intCount As Integer

        Try

            objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "PostProcessMagFolders - Start")

            Delay(1)

            mobjStats.Reset()

            strRootPath = mobjOptions.FullPathMags

            objDir = New DirectoryInfo(strRootPath)

            ' Move files to 'The Womens Weekly Food' from 'The Womens Weekly'

            For Each d In objDir.GetDirectories()

                Select Case d.Name

                    Case "The Womens Weekly"

                        If Not My.Computer.FileSystem.DirectoryExists(objDir.FullName & "The Womens Weekly Food") Then

                            My.Computer.FileSystem.CreateDirectory("The Womens Weekly Food")
                        End If

                        CopyFilesToCorrespondingFolders(objMe, d.FullName, objDir.FullName & "The Womens Weekly Food")

                End Select
            Next

            objDir = Nothing

            objDir = New DirectoryInfo(strRootPath)

            DeleteAllEmptySubFolders(objDir, objDir.FullName)

            objDir = Nothing

            objDir = New DirectoryInfo(strRootPath)

            objSubDirs = objDir.GetDirectories()

            For intCount = 0 To objSubDirs.Count - 1

                d = objSubDirs(intCount)

                If d.GetFiles.Count = 0 And d.GetDirectories.Count = 0 Then

                    d.Delete()
                End If
            Next

            PostProcessMagFolders = True

            objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "PostProcessMagFolders - End")

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

        PostProcessMagFolders = True

    End Function

    Public Function MoveMagFilesToBooksMagsFolder(ByRef objMe As Object, ByRef prgProgressbar As ProgressBar) As Boolean

        Dim strRootPath As String
        Dim strRootCopyToPath As String

        Try

            MoveMagFilesToBooksMagsFolder = False

            mobjStats.Reset()

            strRootPath = mobjOptions.FullPathMags

            strRootCopyToPath = ROOT_DRIVE & "\Books\Mags\"

            HandleAllObjectsInFolder(objMe, "", strRootPath, strRootCopyToPath, "Move", MAG, False, prgProgressbar)

            Dim objDir As New DirectoryInfo(strRootPath)

            DeleteAllEmptySubFolders(objDir, objDir.FullName)

            objDir = Nothing

            MoveMagFilesToBooksMagsFolder = True

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Function

    Public Function MoveTVFilesFromCopyFrom(ByRef objMe As frmMain, ByVal strDrive As String, Optional ByRef prgProgressBar As ProgressBar = Nothing) As Boolean

        Dim strRootPath As String
        Dim strRootCopyToPath As String

        mobjStats.Reset()

        strRootPath = mobjOptions.FullPathTV_CopyFrom & RemovePath(strDrive)

        strRootCopyToPath = strDrive

        HandleAllObjectsInFolder(objMe, "", strRootPath, strRootCopyToPath, "Move", TV, True, prgProgressBar)

        Dim objDir As New DirectoryInfo(strRootPath)

        objDir.Refresh()

        Delay(1)

        DeleteAllEmptySubFolders(objDir, objDir.FullName)

        MoveTVFilesFromCopyFrom = True

    End Function

    Public Function GetBackupDrive(ByVal strDrive As String) As String

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand

        GetDBConnection(ROOT_DRIVE & "\VB.Net\My Projects\Media Manager\bin\Debug\MediaManager.mdb")

        Try

            strSQL = "Select DriveName from tblDrives where drivename like '%" & RemoveDrive(strDrive) & " Backup'"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                drTypes.Read()

                strDrive = Trim(drTypes("Drivename"))
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
        End Try

        CloseOLEConnection(mobjOLEConn)

        GetBackupDrive = strDrive

    End Function

    Public Sub HandleAllObjectsInFolder(ByRef objMe As frmMain, ByRef strTopLevel As String, ByVal strFrom As String, ByVal strTo As String, strType As String, ByVal strFileType As String, _
                                        ByVal blnDoBackup As Boolean, Optional ByRef prgProgressBar As ProgressBar = Nothing)

        Dim objDir As DirectoryInfo, d As DirectoryInfo, objFile As FileInfo
        Dim strToPath As String, strBackupToPath As String, objSubDir As DirectoryInfo

        ' Used in Move TV (ie Do backup) and MoveMags (ie Dont do backup)

        Try

            If strTopLevel = "" Then strTopLevel = strFrom

            If strType = "" Then strType = "COPY"

            strType = strType.ToUpper

            objDir = New DirectoryInfo(strFrom)

        Catch ex As Exception

            DisplayException_Messagebox(ex, "1 - " & System.Reflection.MethodBase.GetCurrentMethod().Name, "strFrom - " & strFrom)

            End
        End Try

        For Each d In objDir.GetDirectories()

            RemoveReadonlyFromAllFilesInDirectory(d)

            For Each objFile In d.GetFiles

                strToPath = strTo & "\" & d.Name & "\" & objFile.Name
                If blnDoBackup Then strBackupToPath = GetBackupDrive(strTo) & "\" & d.Name & "\" & objFile.Name

                My.Application.DoEvents()

                Try

                    If Not My.Computer.FileSystem.FileExists(strToPath) Then

                        mobjStats.Add_File(objFile.Extension, strFileType)

                        UpdateScreen(objMe, ToProperCase(Mid(strType, 1, 3), False) & "ing " & strToPath)

                        prgProgressBar.Maximum = prgProgressBar.Value + 1
                        prgProgressBar.Value = prgProgressBar.Value + 1

                        objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Copying ", objFile.FullName, " to ", strToPath)

                        My.Application.DoEvents()

                        My.Computer.FileSystem.CopyFile(objFile.FullName, strToPath)

                        Delay(1)

                        If Not My.Computer.FileSystem.FileExists(strToPath) Then

                            MessageBox.Show("HandleAllObjectsInFolder (1) - Failed to copy " & objFile.FullName & " to " & strToPath & "! Ending")

                            End
                        End If

                        File.SetAttributes(strToPath, FileAttributes.Normal)
                    Else

                        MessageBox.Show("File present in To path - " & strToPath)
                        End
                    End If

                Catch ex As Exception

                    DisplayException_Messagebox(ex, "2 - " & System.Reflection.MethodBase.GetCurrentMethod().Name, "strToPath - " & strToPath)

                    End
                End Try

                My.Application.DoEvents()

                Try

                    If blnDoBackup Then

                        If Not My.Computer.FileSystem.FileExists(strBackupToPath) Then

                            UpdateScreen(objMe, ToProperCase(Mid(strType, 1, 3), False) & "ing " & strBackupToPath)

                            prgProgressBar.Value = prgProgressBar.Value + 1

                            objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Copying ", objFile.FullName, " to ", strBackupToPath)

                            My.Application.DoEvents()

                            My.Computer.FileSystem.CopyFile(objFile.FullName, strBackupToPath)

                            Delay(1)

                            If Not My.Computer.FileSystem.FileExists(strBackupToPath) Then

                                MessageBox.Show("HandleAllObjectsInFolder (2) - Failed to copy " & objFile.FullName & " to " & strBackupToPath & "! Ending")

                                End
                            End If

                            File.SetAttributes(strBackupToPath, FileAttributes.Normal)
                        Else

                            MessageBox.Show("File present in To path - " & strBackupToPath)
                            End
                        End If
                    End If

                Catch ex As Exception

                    DisplayException_Messagebox(ex, "3 - " & System.Reflection.MethodBase.GetCurrentMethod().Name, "strBackupToPath - " & strBackupToPath)

                    End
                End Try

                My.Application.DoEvents()

                If strType = "MOVE" Then

                    Try

                        UpdateScreen(objMe, "Deleting " & objFile.FullName)

                        My.Application.DoEvents()

                        objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Deleting Source File - ", objFile.FullName)

                        My.Computer.FileSystem.DeleteFile(objFile.FullName, FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin)

                    Catch ex As UnauthorizedAccessException

                        DisplayException_Messagebox(ex, "4 - " & System.Reflection.MethodBase.GetCurrentMethod().Name, "UnauthorizedAccessException - " & objFile.FullName)
                        My.Computer.FileSystem.MoveFile(objFile.FullName, mobjOptions.RootFolder & "_Magazines\_Blocked\" & objFile.Name)

                        End
                    Catch ex As Exception

                        DisplayException_Messagebox(ex, "5 - " & System.Reflection.MethodBase.GetCurrentMethod().Name, "objFile.FullName - " & objFile.FullName)

                        End
                    End Try

                    My.Application.DoEvents()
                End If
            Next

            For Each objSubDir In d.GetDirectories

                HandleAllObjectsInFolder(objMe, strTopLevel, objSubDir.FullName, strTo, strType, strFileType, blnDoBackup, prgProgressBar)
            Next

            Try

                Delay(1)

                If d.GetFiles().Count = 0 And d.GetDirectories().Count = 0 Then

                    d.Delete()
                    d.Refresh()
                End If

            Catch ex As Exception

                DisplayException_Messagebox(ex, "6 - " & System.Reflection.MethodBase.GetCurrentMethod().Name, "d.FullName - " & d.FullName)

                End
            End Try

        Next

        RemoveReadonlyFromAllFilesInDirectory(objDir)

        For Each objFile In objDir.GetFiles

            Try

                strToPath = strTo & Replace(objDir.FullName, strTopLevel, "") & "\" & objFile.Name
                If blnDoBackup Then strBackupToPath = GetBackupDrive(strTo) & Replace(objDir.FullName, strTopLevel, "") & "\" & objFile.Name

                My.Application.DoEvents()

            Catch ex As Exception

                DisplayException_Messagebox(ex, "7 - " & System.Reflection.MethodBase.GetCurrentMethod().Name, "strToPath - " & strToPath & "strBackupToPath - " & strBackupToPath)

                End
            End Try

            If Not My.Computer.FileSystem.FileExists(strToPath) Then

                Try

                    mobjStats.Add_File(objFile.Extension, strFileType)

                    UpdateScreen(objMe, ToProperCase(Mid(strType, 1, 3), False) & "ing " & objFile.FullName)

                    prgProgressBar.Maximum = prgProgressBar.Maximum + 1
                    prgProgressBar.Value = prgProgressBar.Value + 1

                    objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Copying ", objFile.FullName, " to ", strToPath)

                    My.Application.DoEvents()

                    My.Computer.FileSystem.CopyFile(objFile.FullName, strToPath)

                    Delay(1)

                    If Not My.Computer.FileSystem.FileExists(strToPath) Then

                        MessageBox.Show("HandleAllObjectsInFolder (3) - Failed to copy " & objFile.FullName & " to " & strToPath & "! Ending")

                        End
                    End If

                    File.SetAttributes(strToPath, FileAttributes.Normal)

                Catch ex As Exception

                    DisplayException_Messagebox(ex, "8 - " & System.Reflection.MethodBase.GetCurrentMethod().Name, "objFile.FullName - " & objFile.FullName)

                    End
                End Try
            Else

                MessageBox.Show("File present in To path - " & strToPath)
                End
            End If

            ' Function used by MoveTV so copies twice TV6 and TV6 Backup.

            Try

                My.Application.DoEvents()

                If blnDoBackup Then

                    If Not My.Computer.FileSystem.FileExists(strBackupToPath) Then

                        UpdateScreen(objMe, ToProperCase(Mid(strType, 1, 3), False) & "ing " & strBackupToPath)

                        prgProgressBar.Maximum = prgProgressBar.Maximum + 1
                        prgProgressBar.Value = prgProgressBar.Value + 1

                        objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Copying ", objFile.FullName, " to ", strBackupToPath)

                        My.Application.DoEvents()

                        My.Computer.FileSystem.CopyFile(objFile.FullName, strBackupToPath)

                        Delay(1)

                        If Not My.Computer.FileSystem.FileExists(strBackupToPath) Then

                            MessageBox.Show("HandleAllObjectsInFolder (4) - Failed to copy " & objFile.FullName & " to " & strBackupToPath & "! Ending")

                            End
                        End If

                        File.SetAttributes(strBackupToPath, FileAttributes.Normal)
                    Else

                        MessageBox.Show("File present in To path - " & strBackupToPath)
                        End
                    End If
                End If

                My.Application.DoEvents()

            Catch ex As Exception

                DisplayException_Messagebox(ex, "9 - " & System.Reflection.MethodBase.GetCurrentMethod().Name, "objFile.FullName - " & objFile.FullName)

                End
            End Try

            If strType = "MOVE" Then

                Try

                    My.Application.DoEvents()
                    UpdateScreen(objMe, "Deleting " & objFile.FullName)

                    My.Application.DoEvents()

                Catch ex As Exception

                    DisplayException_Messagebox(ex, "10 - " & System.Reflection.MethodBase.GetCurrentMethod().Name, "objFile.FullName - " & objFile.FullName)

                    End
                End Try

                Try

                    objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Deleting Source file - ", objFile.FullName)

                    My.Computer.FileSystem.DeleteFile(objFile.FullName)

                    Delay(1)

                    If My.Computer.FileSystem.FileExists(objFile.FullName) Then

                        MessageBox.Show("HandleAllObjectsInFolder (4) - Failed to delete " & objFile.FullName & "! Ending")

                        End
                    End If

                Catch ex As UnauthorizedAccessException

                    My.Computer.FileSystem.MoveFile(objFile.FullName, mobjOptions.RootFolder & "_Magazines\_Blocked\" & objFile.Name)

                    End
                Catch ex As Exception

                    DisplayException_Messagebox(ex, "11 - " & System.Reflection.MethodBase.GetCurrentMethod().Name, "objFile.FullName - " & objFile.FullName)

                    End
                End Try

                My.Application.DoEvents()
            End If

            Try

                Delay(1)

                If objDir.GetFiles().Count = 0 And objDir.GetDirectories().Count = 0 Then

                    objDir.Delete()
                End If

            Catch ex As Exception

                DisplayException_Messagebox(ex, "12 - " & System.Reflection.MethodBase.GetCurrentMethod().Name, "objDir.FullName - " & objDir.FullName)

                End
            End Try

        Next

    End Sub

    Public Function CleanupFilename(ByVal strFile As String) As String

        Dim strPrefix As String, intPos As Integer

        strPrefix = GetPrefix((strFile))

        strFile = RemovePrefix(strFile)

        strFile = Replace$(strFile, ".", " ")

        intPos = InStr(1, strFile, "-")

        If intPos > 1 Then

            strFile = Mid$(strFile, 1, intPos - 1).Trim
        End If

        CleanupFilename = strFile

    End Function

    Public Function CleanupStandardTVCrapText(ByVal strName As String) As String

        strName = RemoveTextAfterFirstChar(strName, "INTERNAL HDTV")
        strName = RemoveTextAfterFirstChar(strName, "PROPER HDTV")
        strName = RemoveTextAfterFirstChar(strName, "PDTV")
        strName = RemoveTextAfterFirstChar(strName, "hdtv")
        strName = RemoveTextAfterFirstChar(strName, "xvid")
        strName = RemoveTextAfterFirstChar(strName, "480p")
        strName = RemoveTextAfterFirstChar(strName, "612p")
        strName = RemoveTextAfterFirstChar(strName, "720p")
        strName = RemoveTextAfterFirstChar(strName, "1080p")
        strName = RemoveTextAfterFirstChar(strName, "DVDrip")
        strName = RemoveTextAfterFirstChar(strName, "WS PDTV")
        strName = RemoveTextAfterFirstChar(strName, "WEBRip")
        strName = RemoveTextAfterFirstChar(strName, "REPACK")
        strName = RemoveTextAfterFirstChar(strName, "Web X264")
        strName = RemoveTextAfterFirstChar(strName, "Web H264")
        strName = RemoveTextAfterFirstChar(strName, "REAL PROPER")
        strName = RemoveTextAfterFirstChar(strName, "Disc Web - Dl")
        strName = RemoveTextAfterFirstChar(strName, "Web - Dl")
        strName = RemoveTextAfterFirstChar(strName, "Bluray")
        strName = RemoveTextAfterFirstChar(strName, "WebTV")

        strName = strName.Replace(" INTERNAL.avi", ".avi")
        strName = strName.Replace(" INTERNAL.mp4", ".mp4")
        strName = strName.Replace(" INTERNAL.mkv", ".mkv")
        strName = strName.Replace("..mkv", ".mkv")
        strName = strName.Replace("..avi", ".avi")
        strName = strName.Replace("..mp4", ".mp4")

        CleanupStandardTVCrapText = strName

    End Function

    Public Function CleanupFilenameMaintainingPrefix(ByVal strFile As String) As String

        Dim strPrefix As String, intCount As Integer

        strPrefix = GetPrefix((strFile)).ToLower

        strFile = RemovePrefix(strFile)

        strFile = Replace$(strFile, ".", " ")

        If strFile.Length > 0 Then

            strFile = Mid(strFile, 1, 1).ToUpper & Mid(strFile, 2)

            For intCount = 2 To strFile.Length - 1

                If Mid(strFile, intCount - 1, 1) = " " And Mid(strFile, intCount, 1) <> " " Then

                    strFile = Mid(strFile, 1, intCount - 1) & Mid(strFile, intCount, 1).ToUpper & Mid(strFile, intCount + 1)
                End If
            Next
        End If

        strFile = strFile.Replace(" And ", " & ")

        RemoveTextFromStart(strFile, "Dcs ")
        RemoveTextFromStart(strFile, "Marvels ")
        RemoveTextFromStart(strFile, "BBC ")

        strFile = CommonCaseReplacements(strFile)

        CleanupFilenameMaintainingPrefix = strFile & "." & strPrefix

    End Function

    Public Function MagazineNameReplacements(ByVal strFile As String) As String

        strFile = strFile.Replace("(Magazinepub Com)", "")

        strFile = Replace(strFile, "Magazine ", "", 1, -1, CompareMethod.Text)

        strFile = Replace(strFile, "Issue ", "", 1, -1, CompareMethod.Text)

        If TextAllUpper(strFile) Then

            strFile = ToProperCase(strFile, True).Replace("_", " ")
        Else

            strFile = strFile.Replace("_", " ")
        End If

        strFile = strFile.Replace("[", ")")
        strFile = strFile.Replace("]", ")")
        strFile = strFile.Replace("{", "(")
        strFile = strFile.Replace("}", ")")

        strFile = strFile.Replace(",", "")
        strFile = strFile.Replace("'", "")

        strFile = strFile.Replace("January", "Jan")
        strFile = strFile.Replace("February", "Feb")
        strFile = strFile.Replace("March", "Mar")
        strFile = strFile.Replace("April", "Apr")
        strFile = strFile.Replace("June", "Jun")
        strFile = strFile.Replace("July", "Jul")
        strFile = strFile.Replace("August", "Aug")
        strFile = strFile.Replace("September", "Sep")
        strFile = strFile.Replace("October", "Oct")
        strFile = strFile.Replace("November", "Nov")
        strFile = strFile.Replace("December", "Dec")

        strFile = strFile.Replace(" Uk.", " (UK).")
        strFile = strFile.Replace(" UK.", " (UK).")
        strFile = strFile.Replace(" Usa.", " (US).")
        strFile = strFile.Replace(" USA.", " (US).")
        strFile = strFile.Replace(" Us.", " (US).")
        strFile = strFile.Replace(" US.", " (US).")
        strFile = strFile.Replace(" Aus.", " (Aus).")
        strFile = strFile.Replace(" AUS.", " (Aus).")
        strFile = strFile.Replace(" Au.", " (Aus).")
        strFile = strFile.Replace(" In.", " (In).")
        strFile = strFile.Replace(" IN.", " (In).")
        strFile = strFile.Replace(" May.", " (May).")
        strFile = strFile.Replace(" MAY.", " (May).")

        strFile = strFile.Replace(" (Us)", " (US)")
        strFile = strFile.Replace(" (Uk)", " (UK)")

        strFile = strFile.Replace(" Uk ", " (UK) ")
        strFile = strFile.Replace(" Usa ", " (US) ")
        strFile = strFile.Replace(" Us ", " (US) ")

        strFile = strFile.Replace(" Australian Edition ", " (Aus) ")
        strFile = strFile.Replace(" Australian Edition.", " (Aus).")
        strFile = strFile.Replace(" South Africa ", " (ZA) ")
        strFile = strFile.Replace(" South Africa.", " (ZA).")

        strFile = strFile.Replace(" Jan-", " Jan -")
        strFile = strFile.Replace(" Feb-", " Feb -")
        strFile = strFile.Replace(" Mar-", " Mar -")
        strFile = strFile.Replace(" Apr-", " Apr -")
        strFile = strFile.Replace(" May-", " May -")
        strFile = strFile.Replace(" Jun-", " Jun -")
        strFile = strFile.Replace(" Jul-", " Jul -")
        strFile = strFile.Replace(" Aug-", " Aug -")
        strFile = strFile.Replace(" Sep-", " Sep -")
        strFile = strFile.Replace(" Oct-", " Oct -")
        strFile = strFile.Replace(" Nov-", " Nov -")
        strFile = strFile.Replace(" Dec-", " Dec -")

        strFile = strFile.Replace("�", "e")

        strFile = SortOutSomeMagazineReplacementsForMagNameReplacements(strFile)

        strFile = strFile.Replace("  ", " ").Replace("  ", " ")

        ' move any counteries to end
        If InStr(strFile, " (UK)") > 0 Then

            strFile = RemovePrefix(strFile).Replace(" (UK)", " ") & " (UK)" & GetPrefixwithDot(strFile).ToLower
        End If

        If InStr(strFile, " (US)") > 0 Then

            strFile = RemovePrefix(strFile).Replace(" (US)", " ") & " (US)" & GetPrefixwithDot(strFile).ToLower
        End If

        If InStr(strFile, " (Aus)") > 0 Then

            strFile = RemovePrefix(strFile).Replace(" (Aus)", " ") & " (Aus)" & GetPrefixwithDot(strFile).ToLower
        End If

        If InStr(strFile, " (ZA)") > 0 Then

            strFile = RemovePrefix(strFile).Replace(" (ZA)", " ") & " (ZA)" & GetPrefixwithDot(strFile).ToLower
        End If

        If Len(strFile) > 14 Then

            If Mid(strFile, 1, 14).ToUpper = "FOOD & WINE - " Then

                strFile = "Food Wine - " & Mid(strFile, 15)
            End If
        End If

        If Len(strFile) > 16 Then

            If Mid(strFile, 1, 16).ToUpper = "FOOD AND WINE - " Then

                strFile = "Food Wine - " & Mid(strFile, 17)
            End If
        End If

        strFile = strFile.Replace("  ", " ").Replace("  ", " ")

        MagazineNameReplacements = strFile

    End Function

    Public Function CleanupSeriesName(ByVal strSeriesName As String) As String

        strSeriesName = strSeriesName.Trim

        If strSeriesName = "" Then

            Exit Function
        End If

        If Mid(strSeriesName, Len(strSeriesName)) = "-" Then

            strSeriesName = Mid(strSeriesName, 1, Len(strSeriesName) - 1).Trim
        End If

        strSeriesName = strSeriesName.Replace(" And ", " & ")
        strSeriesName = strSeriesName.Replace(" and ", " & ")

        RemoveTextFromStart(strSeriesName, "Dcs ")
        RemoveTextFromStart(strSeriesName, "Marvels ")
        RemoveTextFromStart(strSeriesName, "Bbc ")

        Select Case strSeriesName

            Case "Castle 2009"

                strSeriesName = "Castle"

            Case "Brooklyn Nine"

                strSeriesName = "Brooklyn Nine Nine"

        End Select

        CleanupSeriesName = strSeriesName

    End Function

    Public Function CleanupFolderName(ByVal strFolder As String) As String

        Dim intPos1 As Integer, intPos2 As Integer
        Dim blnRemoveBrackets As Boolean, strTemp As String, strTemp2 As String

        strFolder = Replace$(strFolder, ".", " ").Trim

        If blnRemoveBrackets Then

            ' Square Brackets
            intPos1 = InStr(1, strFolder, "[")
            If intPos1 > 0 Then

                intPos2 = InStr(intPos1 + 1, strFolder, "[")

                If intPos1 > 1 Then

                Else

                    strFolder = Mid(strFolder, intPos2 + 1)
                End If
            End If
        End If

        strFolder = strFolder.Replace("[", "(")
        strFolder = strFolder.Replace("]", ")")

        strTemp = Trim(Mid(strFolder, 1, 1).ToUpper & Mid(strFolder, 2))

        If strTemp <> "" Then

            If Len(strTemp) > 4 Then

                strTemp2 = Trim(Mid(strTemp, Len(strTemp) - 4))

                If IsNumeric(strTemp2) Then

                    If CLng(strTemp2) >= 2010 Then

                        strTemp = Mid(strTemp, 1, Len(strTemp) - 4).Trim
                    End If
                End If
            End If
        End If

        strTemp = Replace(strTemp, "-", " - ")

        strTemp = Replace(strTemp, "  ", " ")

        CleanupFolderName = Trim(strTemp)

    End Function

    Public Function IsDirectoryToBeProcessed(ByRef objDir As DirectoryInfo, ByVal blnIncludeAssortedBooksCollection As Boolean) As Boolean

        If objDir.Name <> BOOKS And objDir.Name <> MAGS And objDir.Name <> MOVIES And objDir.Name <> TV And
           objDir.Name <> PROCESSED And objDir.Name <> MUSIC And objDir.Name <> DELETED And objDir.Name <> "Torrents" And objDir.Name <> "_Torrents" And
           objDir.Name <> "BBC Good Food" And objDir.Name <> "The Brittas Empire" And objDir.Name <> "Sky_and_Telescope" And objDir.Name <> "Dear John (1986) - Complete - DVDRip 576p - BBC Comedy - Ralph Bates - Belinda Lang" And
           objDir.Name <> "50 Assorted Magazines" And objDir.Name <> "Daria (1997) Season 1-5 S01-S05 + Specials (480p DVD x265 HEVC 10bit AAC 2.0 Ghost)" And
           objDir.Name <> "Assorted Books Collection" And objDir.Name <> "50 Assorted Magazines" And
           objDir.Name <> "Prof. Harold J. Tobin - Oceanography Exploring Earth's Final Wilderness" And
           objDir.Name <> "TTC - Oceanography Exploring Earth's Final Wilderness" And objDir.Name <> "Dual Survival" And objDir.Name <> "Epidemiya.S02.2022.WEBRip.1080p" And
           objDir.Name <> "Doctor Who Seasons 1 to 13 Mp4 1080p" And objDir.Name <> "Doctor Who 2005 Specials 720p BluRay x264 [i_c]" And
           objDir.Name <> "[TTC Video] Amanda H. Podany - Ancient Mesopotamia. Life in the Cradle of Civilization" And objDir.Name <> "[TTC Video] Gregory S. Aldrete - The Rise of Rome" And
           objDir.Name <> "TTC Understanding the Quantum World 720p" And
           objDir.Name <> "[TTC Video] Gregory S. Aldrete - History of the Ancient World" And objDir.Name <> "[TTC Video] Robert L. Dise - Ancient Empires before Alexander" And
           objDir.Name <> "TTC - History of Ancient Rome (360p)" And objDir.Name <> "TTC - The Higgs Boson and Beyond" And
           objDir.Name <> "[TTC Video] Steven L. Tuck - Cities of the Ancient World" And
           objDir.Name <> "TTC - Hannibal, Medbay" And objDir.Name <> "The Brittas Empire 1991 S01-S07 Complete 720p WEB-DL HEVC x265 BONE" And objDir.Name <> "Forensic Files" And
           objDir.Name <> "Bloodline Detectives 2020 Seasons 1 to 4 Mixed WEB x264 [i_c]" And
           objDir.Name <> "Le Bureau des L�gendes (The Bureau) - season 1" And objDir.Name <> "Le Bureau des L�gendes (The Bureau) - season 2" And
           objDir.Name <> "Le Bureau des L�gendes (The Bureau) - season 3" And objDir.Name <> "Le Bureau des L�gendes (The Bureau) - season 4" And
           objDir.Name <> "Le Bureau des L�gendes (The Bureau) - season 5" Then

            IsDirectoryToBeProcessed = True
        Else

            IsDirectoryToBeProcessed = False
        End If

    End Function

    Public Function GetFolderTargetForPreProcessing(ByVal strDir As String, ByRef strName As String) As Boolean

        Dim strType As String, intCount As Integer

        strName = strDir

        For intCount = 1 To PRE_PROCESS_TYPE_LIMIT

            Select Case intCount

                Case 1 : strType = PRE_PROCESS_TYPE1
                Case 2 : strType = PRE_PROCESS_TYPE2
                Case 3 : strType = PRE_PROCESS_TYPE3
                Case 4 : strType = PRE_PROCESS_TYPE4
                Case 5 : strType = PRE_PROCESS_TYPE5
                Case 6 : strType = PRE_PROCESS_TYPE6
                Case 7 : strType = PRE_PROCESS_TYPE7
                Case 8 : strType = PRE_PROCESS_TYPE8
                Case 9 : strType = PRE_PROCESS_TYPE9
                Case 10 : strType = PRE_PROCESS_TYPE10
                Case 11 : strType = PRE_PROCESS_TYPE11
                Case 12 : strType = PRE_PROCESS_TYPE12
                Case 13 : strType = PRE_PROCESS_TYPE13
                Case 14 : strType = PRE_PROCESS_TYPE14
                Case 15 : strType = PRE_PROCESS_TYPE15
                Case 16 : strType = PRE_PROCESS_TYPE16
                Case 17 : strType = PRE_PROCESS_TYPE17
                Case 18 : strType = PRE_PROCESS_TYPE18
                Case 19 : strType = PRE_PROCESS_TYPE19
                Case 20 : strType = PRE_PROCESS_TYPE20
                Case 21 : strType = PRE_PROCESS_TYPE21
                Case 22 : strType = PRE_PROCESS_TYPE22
                Case 23 : strType = PRE_PROCESS_TYPE23
                Case 24 : strType = PRE_PROCESS_TYPE24
                Case 25 : strType = PRE_PROCESS_TYPE25
                Case 26 : strType = PRE_PROCESS_TYPE26
                Case 27 : strType = PRE_PROCESS_TYPE27
                Case 28 : strType = PRE_PROCESS_TYPE28
                Case 29 : strType = PRE_PROCESS_TYPE29
                Case 30 : strType = PRE_PROCESS_TYPE30
                Case 31 : strType = PRE_PROCESS_TYPE31
                Case 32 : strType = PRE_PROCESS_TYPE32
                Case 33 : strType = PRE_PROCESS_TYPE33
                Case 34 : strType = PRE_PROCESS_TYPE34
                Case 35 : strType = PRE_PROCESS_TYPE35
                Case 36 : strType = PRE_PROCESS_TYPE36
                Case 37 : strType = PRE_PROCESS_TYPE37
                Case 38 : strType = PRE_PROCESS_TYPE38
                Case 39 : strType = PRE_PROCESS_TYPE39
                Case 40 : strType = PRE_PROCESS_TYPE40
                Case 41 : strType = PRE_PROCESS_TYPE41
                Case 42 : strType = PRE_PROCESS_TYPE42
                Case 43 : strType = PRE_PROCESS_TYPE43
                Case 44 : strType = PRE_PROCESS_TYPE44
                Case 45 : strType = PRE_PROCESS_TYPE45
                Case 46 : strType = PRE_PROCESS_TYPE46
                Case 47 : strType = PRE_PROCESS_TYPE47
                Case 48 : strType = PRE_PROCESS_TYPE48
                Case 49 : strType = PRE_PROCESS_TYPE49
                Case 50 : strType = PRE_PROCESS_TYPE50
                Case 51 : strType = PRE_PROCESS_TYPE51
                Case 52 : strType = PRE_PROCESS_TYPE52

            End Select

            If strName.Length > strType.Length Then

                If Mid(strName, 1, Len(strType)) = strType Then

                    '                                            
                    If InStr(strType.ToUpper, " COOKBOOKS ") > 0 Then

                        strName = PRE_PROCESS_TYPE13

                    ElseIf InStr(strType.ToUpper, "MAGAZINE ") > 0 Or InStr(strType.ToUpper, "MAGAZINES ") > 0 Then

                        strName = PRE_PROCESS_TYPE2

                    ElseIf intCount = 4 Or intCount = 12 Or intCount = 13 Or intCount = 20 Or intCount = 22 Or intCount = 24 Or intCount = 25 Or intCount = 26 Or _
                           intCount = 27 Or intCount = 28 Or intCount = 29 Or intCount = 31 Or intCount = 36 Or intCount = 41 Or intCount = 45 Then

                        ' 20 History Books Collection      20 Assorted Books Collection Pack      Assorted Books Collection - 

                        strName = PRE_PROCESS_TYPE1.Replace("50 ", "")
                    Else

                        strName = strType
                    End If

                    If Mid(strName, Len(strName) - 2, 3) = " - " Then

                        strName = strName.Replace(" - ", "")
                    End If

                    GetFolderTargetForPreProcessing = True
                    Exit Function
                End If
            End If

            ' 20 Cookbooks Collection can be all the text for this one
            If strName.Length = strType.Length And strType = PRE_PROCESS_TYPE3 Then

                If Mid(strName, 1, Len(strType)) = strType Then

                    strName = PRE_PROCESS_TYPE13

                    If Mid(strName, Len(strName) - 2, 3) = " - " Then

                        strName = strName.Replace(" - ", "")
                    End If

                    GetFolderTargetForPreProcessing = True
                    Exit Function
                End If
            End If
        Next

        GetFolderTargetForPreProcessing = False

    End Function

    Public Function IsDirectoryToBePreProcessed(ByRef objDir As DirectoryInfo) As Boolean

        Dim strType As String, strName As String

        For Each objFile In objDir.GetFiles()

            If objFile.Name.ToUpper = "MORE BOOKS AND MAGAZINES.DOCX" Then

                objFile.Delete()
            End If

            If objFile.Name = "More.rar" Then

                objFile.Delete()
            End If

            If objFile.Name = "Message.mp3" Then

                objFile.Delete()
            End If

            If objFile.Name = "Greetings.mp3" Then

                objFile.Delete()
            End If

            If objFile.Name = "@Get More Books & Magazines.txt" Then

                objFile.Delete()
            End If

            If objFile.Name = "Donate Via Paypal QR Code.jpg" Then

                objFile.Delete()
            End If

            If objFile.Name = "Please Consider Making A Donation.docx" Then

                objFile.Delete()
            End If

            If objFile.Name = "[TGx]Downloaded from torrentgalaxy.to .txt" Then

                objFile.Delete()
            End If

            If objFile.Name = "Torrent_downloaded_from_Demonoid.is_.txt" Then

                objFile.Delete()
            End If
        Next

        strName = objDir.Name

        For intCount = 1 To PRE_PROCESS_TYPE_LIMIT

            Select Case intCount

                Case 1 : strType = PRE_PROCESS_TYPE1
                Case 2 : strType = PRE_PROCESS_TYPE2
                Case 3 : strType = PRE_PROCESS_TYPE3
                Case 4 : strType = PRE_PROCESS_TYPE4
                Case 5 : strType = PRE_PROCESS_TYPE5
                Case 6 : strType = PRE_PROCESS_TYPE6
                Case 7 : strType = PRE_PROCESS_TYPE7
                Case 8 : strType = PRE_PROCESS_TYPE8
                Case 9 : strType = PRE_PROCESS_TYPE9
                Case 10 : strType = PRE_PROCESS_TYPE10
                Case 11 : strType = PRE_PROCESS_TYPE11
                Case 12 : strType = PRE_PROCESS_TYPE12
                Case 13 : strType = PRE_PROCESS_TYPE13
                Case 14 : strType = PRE_PROCESS_TYPE14
                Case 15 : strType = PRE_PROCESS_TYPE15
                Case 16 : strType = PRE_PROCESS_TYPE16
                Case 17 : strType = PRE_PROCESS_TYPE17
                Case 18 : strType = PRE_PROCESS_TYPE18
                Case 19 : strType = PRE_PROCESS_TYPE19
                Case 20 : strType = PRE_PROCESS_TYPE20
                Case 21 : strType = PRE_PROCESS_TYPE21
                Case 22 : strType = PRE_PROCESS_TYPE22
                Case 23 : strType = PRE_PROCESS_TYPE23
                Case 24 : strType = PRE_PROCESS_TYPE24
                Case 25 : strType = PRE_PROCESS_TYPE25
                Case 26 : strType = PRE_PROCESS_TYPE26
                Case 27 : strType = PRE_PROCESS_TYPE27
                Case 28 : strType = PRE_PROCESS_TYPE28
                Case 29 : strType = PRE_PROCESS_TYPE29
                Case 30 : strType = PRE_PROCESS_TYPE30
                Case 31 : strType = PRE_PROCESS_TYPE31
                Case 32 : strType = PRE_PROCESS_TYPE32
                Case 33 : strType = PRE_PROCESS_TYPE33
                Case 34 : strType = PRE_PROCESS_TYPE34
                Case 35 : strType = PRE_PROCESS_TYPE35
                Case 36 : strType = PRE_PROCESS_TYPE36
                Case 37 : strType = PRE_PROCESS_TYPE37
                Case 38 : strType = PRE_PROCESS_TYPE38
                Case 39 : strType = PRE_PROCESS_TYPE39
                Case 40 : strType = PRE_PROCESS_TYPE40
                Case 41 : strType = PRE_PROCESS_TYPE41
                Case 42 : strType = PRE_PROCESS_TYPE42
                Case 43 : strType = PRE_PROCESS_TYPE43
                Case 44 : strType = PRE_PROCESS_TYPE44
                Case 45 : strType = PRE_PROCESS_TYPE45
                Case 46 : strType = PRE_PROCESS_TYPE46
                Case 47 : strType = PRE_PROCESS_TYPE47
                Case 48 : strType = PRE_PROCESS_TYPE48
                Case 49 : strType = PRE_PROCESS_TYPE49
                Case 50 : strType = PRE_PROCESS_TYPE50
                Case 51 : strType = PRE_PROCESS_TYPE51
                Case 52 : strType = PRE_PROCESS_TYPE52

            End Select

            If strName.Length > strType.Length Then

                If Mid(strName, 1, Len(strType)) = strType Then

                    strName = strType

                    IsDirectoryToBePreProcessed = True
                    Exit Function
                End If
            End If

            ' 20 Cookbooks Collection can be all the text for this one
            If strName.Length = strType.Length And strType = PRE_PROCESS_TYPE3 Then

                If Mid(strName, 1, Len(strType)) = strType Then

                    strName = strType

                    IsDirectoryToBePreProcessed = True
                    Exit Function
                End If
            End If
        Next

        IsDirectoryToBePreProcessed = False

    End Function

    Public Function GetNextRARFile(ByVal strNextFile As String) As String

        Dim strPrefix As String
        Dim strName As String

        strPrefix = GetPrefixwithDot(strNextFile)
        strName = RemovePrefixAndPath(strNextFile, False)

        If strPrefix = ".TGZ" Then

            GetNextRARFile = ""
            Exit Function
        End If

        If strPrefix = RAR Then

            GetNextRARFile = strName & ".R00"
        Else

            Try

                GetNextRARFile = strName & ".R" & Microsoft.VisualBasic.Compatibility.VB6.Support.Format(strPrefix.Replace(".R", "") + 1, "00")

            Catch ex As Exception

                GetNextRARFile = ""
            End Try

        End If

    End Function

    Public Function DeleteRARFiles(ByVal strFile As String, ByRef objDir As DirectoryInfo) As Boolean

        Dim strNextFile As String, intCount As Integer, blnFileExists As Boolean

        strNextFile = strFile
        intCount = 1

        RemoveReadonlyFromAllFilesInDirectory(objDir)

        Try

            MoveToDeletedUsingPath(strFile)

            blnFileExists = True

            While blnFileExists

                If strNextFile <> "" Then

                    strNextFile = GetNextRARFile(strNextFile)

                    If strNextFile <> "" Then

                        blnFileExists = My.Computer.FileSystem.FileExists(strNextFile)

                        If blnFileExists Then

                            MoveToDeletedUsingPath(strNextFile)
                        End If

                        intCount = intCount + 1
                    Else

                        blnFileExists = False
                    End If
                Else

                    blnFileExists = False
                End If

            End While

        Catch ex As Exception

            MessageBox.Show("DeleteRARFiles - " & ex.Message & vbCrLf & " strNextFile - " & strNextFile)

        End Try

    End Function

    Public Function BackupFiles(ByRef objDir As DirectoryInfo, ByRef colFiles() As FileInfo, ByVal strLocation As String, ByRef objMe As Object) As Boolean

        Dim objFile As FileInfo

        strLocation = EnsureSlashIsOnTheEnd(strLocation)

        For Each objFile In colFiles

            Try

                My.Application.DoEvents()

                objMe.Updatecurrentfile(objFile.Name)

                My.Application.DoEvents()
                objMe.refresh()

                My.Computer.FileSystem.CopyFile(objFile.FullName, strLocation & objFile.Name)

                My.Application.DoEvents()

            Catch ex As Exception

                MessageBox.Show("BackupFiles - " & ex.Message & vbCrLf & " file - " & objFile.FullName)

                Exit Function
            End Try

        Next

        BackupFiles = True

    End Function

    Public Function BackupFolders(ByRef objDir As DirectoryInfo, ByVal strLocation As String, ByRef objMe As Object) As Boolean

        Dim d As DirectoryInfo

        strLocation = EnsureSlashIsOnTheEnd(strLocation)

        For Each d In objDir.GetDirectories()

            If IsDirectoryToBeProcessed(d, True) Then

                Try

                    My.Application.DoEvents()
                    My.Application.DoEvents()
                    objMe.updatecurrentfile(d.Name)
                    My.Application.DoEvents()
                    My.Application.DoEvents()

                    My.Computer.FileSystem.CopyDirectory(d.FullName, strLocation & d.Name)

                    My.Application.DoEvents()
                    My.Application.DoEvents()
                    My.Application.DoEvents()

                Catch ex As Exception

                    MessageBox.Show("BackupFolders - " & ex.Message & vbCrLf & " - d.fullname - " & d.FullName)

                End Try

            End If

        Next

    End Function

    Public Function EnsureSlashIsOnTheEnd(ByVal strLocation As String) As String

        Dim strChar As String

        strLocation = Trim(strLocation)

        If Trim(strLocation) = "" Then

            Return ""
        End If

        strChar = Mid(strLocation, Len(strLocation) - 1, 1)

        If strChar <> "\" Then

            EnsureSlashIsOnTheEnd = strLocation & "\"
        Else

            EnsureSlashIsOnTheEnd = strLocation
        End If

    End Function

    Public Function IsDirectoryAnAssortedMagazineDirectory(ByRef objdir As DirectoryInfo) As Boolean

        IsDirectoryAnAssortedMagazineDirectory = False

        If Mid(objdir.Name.ToUpper, 1, 28) = "ASSORTED MAGAZINES BUNDLE - " Or Mid(objdir.Name.ToUpper, 1, 21) = "ASSORTED MAGAZINES - " Or _
           Mid(objdir.Name.ToUpper, 1, 26) = "ASSORTED MAGAZINES BUNDLE " Or Mid(objdir.Name.ToUpper, 1, 21) = "ASSORTED MAGS BUNDLE " Or _
           Mid(objdir.Name.ToUpper, 1, 21) = "ASSORTED MONTHLY MAGS" Or Mid(objdir.Name.ToUpper, 1, 23) = "ASST MAGAZINES TRUEPDF " Or _
           Mid(objdir.Name.ToUpper, 1, 21) = "50 ASSORTED MAGAZINES" Or Mid(objdir.Name.ToUpper, 1, 22) = "100 ASSORTED MAGAZINES" Or Mid(objdir.Name.ToUpper, 1, 22) = "200 ASSORTED MAGAZINES" Or
           Mid(objdir.Name.ToUpper, 1, 22) = "MAGAZINE COLLECTION - " Then

            IsDirectoryAnAssortedMagazineDirectory = True
        End If

    End Function

    Public Function IsDirectoryTheAssortedBookCollectionDirectory(ByRef objdir As DirectoryInfo) As Boolean

        IsDirectoryTheAssortedBookCollectionDirectory = False

        If objdir.Name.ToUpper = "ASSORTED BOOKS COLLECTION" Then

            IsDirectoryTheAssortedBookCollectionDirectory = True
        End If

    End Function

    Public Function IsDirectory_OneOfThe_Assorted_Book_Collection_Directories(ByRef objDir As DirectoryInfo) As Boolean

        IsDirectory_OneOfThe_Assorted_Book_Collection_Directories = False

        If Mid(objDir.Name.ToUpper, 1, 28) = PRE_PROCESS_TYPE13.ToUpper Then

            IsDirectory_OneOfThe_Assorted_Book_Collection_Directories = True
            Exit Function
        End If





    End Function

    Public Function AssortedDirectoryPresent() As Boolean

        AssortedDirectoryPresent = False

        Try

            Dim d As DirectoryInfo
            Dim objDir As DirectoryInfo

            objDir = New DirectoryInfo(mobjOptions.RootFolder)

            For Each d In objDir.GetDirectories()

                If IsDirectoryToBeProcessed(d, True) Then

                    If IsDirectoryAnAssortedMagazineDirectory(d) Then

                        AssortedDirectoryPresent = True
                        Exit Function
                    End If
                End If
            Next

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Function

    Public Sub CompTorr_AddSizeMarkings(ByVal strFolder As String)

        Dim intSize As Long, objDir As DirectoryInfo, objFile As FileInfo
        Dim strName As String

        intSize = 0
        strName = GetNameOfLastFolderInPath(strFolder)

        If strName = TorrentFolder Then Exit Sub
        If strName = "_TV" Then Exit Sub

        objDir = New DirectoryInfo(strFolder)

        For Each objFile In objDir.GetFiles

            intSize = intSize + objFile.Length

        Next

        strName = SIZE_BEGIN & " " & Microsoft.VisualBasic.Format(intSize / (1024 * 1024), "0.00") & " MB " & SIZE_END & strName

        My.Computer.FileSystem.RenameDirectory(strFolder, strName)

    End Sub

    Public Function CompTorr_AddBytesCountToFolder_Recursive(ByVal strFolder As String) As Integer

        Dim objDir As DirectoryInfo, objFile As FileInfo, intSize As ULong
        Dim strName As String

        strName = GetNameOfLastFolderInPath(strFolder)

        objDir = New DirectoryInfo(strFolder)

        For Each objFile In objDir.GetFiles

            intSize = intSize + objFile.Length

        Next

        If FolderHasSizeMarkings(strFolder) Then

            RemoveSizeMarkings(strFolder)
        End If

        CompTorr_AddSizeMarkings(strFolder)

    End Function

    Public Sub CompTorr_AddBytesCountToFolder(ByVal strFolder As String)

        Dim objDir As DirectoryInfo

        objDir = New DirectoryInfo(strFolder)

        For Each d In objDir.GetDirectories

            CompTorr_AddBytesCountToFolder_Recursive(d.FullName)
        Next

    End Sub

    Public Function ExactDuplicateFiles(ByRef objDir As DirectoryInfo, ByVal strPath1 As String,
                                    ByVal strPath2 As String, ByRef objMe As Object, _
                                    Optional ByVal intBufferSize As Integer = 1000) As Boolean

        RemoveReadonlyFromAllFilesInDirectory(objDir)

        Dim objFile1 As System.IO.FileStream
        Dim objFile2 As System.IO.FileStream

        UpdateScreen(objMe, "Comparing " & strPath1 & " & " & strPath2)

        Try

            objFile1 = IO.File.Open(strPath1, IO.FileMode.Open)

        Catch ex_readonly As System.UnauthorizedAccessException

            MessageBox.Show(strPath1 & " is probably Read Only! Ending for you to sort it!")

            End

        Catch ex As Exception

            Return True
        End Try

        Try

            objFile2 = IO.File.Open(strPath2, IO.FileMode.Open)

        Catch ex_readonly As System.UnauthorizedAccessException

            MessageBox.Show(strPath2 & " is probably Read Only! Ending for you to sort it!")

            End

        Catch ex As Exception

            Return True
        End Try

        Dim blnDifferent As Boolean, intCount As Integer

        blnDifferent = False

        ' Adjust array length for VB array declaration. 
        Dim bytBytes1 = New Byte(intBufferSize - 1) {}
        Dim bytBytes2 = New Byte(intBufferSize - 1) {}

        While objFile1.Read(bytBytes1, 0, intBufferSize) > 0

            objFile2.Read(bytBytes2, 0, intBufferSize)

            For intCount = 0 To intBufferSize - 1

                If bytBytes1(intCount) <> bytBytes2(intCount) Then

                    ExactDuplicateFiles = False

                    objFile1.Close()
                    objFile2.Close()

                    Exit Function
                End If
            Next


        End While

        objFile1.Close()
        objFile2.Close()

        ExactDuplicateFiles = True

    End Function

End Module
