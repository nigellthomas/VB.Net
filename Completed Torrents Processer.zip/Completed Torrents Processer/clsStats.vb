﻿Public Class clsStats

    Public NFO_Count As Integer
    Public TXT_Count As Integer
    Public OPF_Count As Integer
    Public JPEG_Count As Integer
    Public DOC_Count As Integer
    Public SRT_Count As Integer
    Public SUB_Count As Integer
    Public TORRENT_Count As Integer
    Public HTML_Count As Integer
    Public Unknown_Count As Integer

    Public Mags_Count As Integer
    Public Books_Count As Integer
    Public TV_Count As Integer
    Public Movies_Count As Integer
    Public Music_Count As Integer

    Public Dup_Mags_Count As Integer
    Public Dup_Books_Count As Integer
    Public Dup_TV_Count As Integer
    Public Dup_Movies_Count As Integer
    Public Dup_Music_Count As Integer

    Public Sub Reset()

        NFO_Count = 0
        TXT_Count = 0
        OPF_Count = 0
        JPEG_Count = 0
        DOC_Count = 0
        SRT_Count = 0
        SUB_Count = 0
        TORRENT_Count = 0
        HTML_Count = 0
        Unknown_Count = 0

        Mags_Count = 0
        Movies_Count = 0
        TV_Count = 0
        Books_Count = 0
        Music_Count = 0

        Dup_Mags_Count = 0
        Dup_Movies_Count = 0
        Dup_TV_Count = 0
        Dup_Books_Count = 0
        Dup_Music_Count = 0

    End Sub

    Public Sub Add_File(ByVal strType As String, Optional ByVal strKnownType As String = "", Optional ByVal intCount As Integer = 0)

        Dim intNumberToAdd As Integer

        If intCount = 0 Then

            intNumberToAdd = 1
        Else

            intNumberToAdd = intCount
        End If

        If strKnownType <> "" Then

            Select Case strKnownType

                Case MAG : Mags_Count = Mags_Count + intNumberToAdd
                Case BOOK : Books_Count = Books_Count + intNumberToAdd

                Case TV : TV_Count = TV_Count + intNumberToAdd
                Case MOVIES : Movies_Count = Movies_Count + intNumberToAdd

                Case MUSIC : Music_Count = Music_Count + intNumberToAdd

                Case DUP_MAG : Dup_Mags_Count = Dup_Mags_Count + intNumberToAdd
                Case DUP_BOOK : Dup_Books_Count = Dup_Books_Count + intNumberToAdd

                Case DUP_TV : Dup_TV_Count = Dup_TV_Count + intNumberToAdd
                Case DUP_MOVIES : Dup_Movies_Count = Dup_Movies_Count + intNumberToAdd

                Case DUP_MUSIC : Dup_Music_Count = Dup_Music_Count + intNumberToAdd

            End Select

        Else
            Select Case strType.ToUpper

                Case NFO : NFO_Count = NFO_Count + 1
                Case TXT : TXT_Count = TXT_Count + 1
                Case OPF : OPF_Count = OPF_Count + 1
                Case JPEG : JPEG_Count = JPEG_Count + 1
                Case DOC : DOC_Count = DOC_Count + 1
                Case SRT : SRT_Count = SRT_Count + 1
                Case SUBTITLE : SUB_Count = SUB_Count + 1
                Case TORRENT : TORRENT_Count = TORRENT_Count + 1
                Case HTML, HTM : HTML_Count = HTML_Count + 1

            End Select
        End If

    End Sub

End Class
