﻿Module modComTorrProGeneral

    Public MAGAZINE_TITLES As String
    Public MAGAZINE_TITLES_KEEP_PROCESSING As String

    Private mstrPath As String
    Private mblnUpdatedMagazineTitles As Boolean

    Public Sub GetAllVideoTypes()

        AllVideoTypes = AllVideoTypes & AVI & MP4 & WMV & MKV & SRT & MPEG & MPG & M2TS & FLV & ASF

        AllVideoTypes = AllVideoTypes.Replace(".", ",")

        AllVideoTypes = Mid(AllVideoTypes, 2) & ","

    End Sub

    Public Function CommonCaseReplacements(ByVal strTempFilename As String) As String

        strTempFilename = strTempFilename.Replace("Bbc ", "BBC ")
        strTempFilename = strTempFilename.Replace("Pbs ", "PBS ")
        strTempFilename = strTempFilename.Replace("Nova ", "NOVA ")
        strTempFilename = strTempFilename.Replace("Hbo ", "HBO ")

        CommonCaseReplacements = strTempFilename

    End Function

    Public Sub Process_50_Assorted_Magazines_Keep(ByRef objMe As frmMain)

        Dim objDir As New DirectoryInfo(ROOT_DRIVE & "\_Torrent\Completed\50 Assorted Magazines\Keep")
        Dim colFiles As FileInfo(), intCount As Integer
        Dim strNewDest As String

        If objDir.Exists = False Then Exit Sub

        colFiles = objDir.GetFiles()

        strNewDest = ROOT_DRIVE & "\_Torrent\Completed"

        If colFiles.Count > 0 Then

            For intCount = 0 To colFiles.Count - 1

                If My.Computer.FileSystem.FileExists(strNewDest & "\" & colFiles(intCount).Name) Then

                    MessageBox.Show(strNewDest & "\" & colFiles(intCount).Name & " is in two places - ending")
                    End
                End If

                My.Computer.FileSystem.MoveFile(colFiles(intCount).FullName, strNewDest & "\" & colFiles(intCount).Name, False)

                objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Process_50_Assorted_Magazines_Keep - Moving ", colFiles(intCount).Name, " to \Completed")

                Delay(1)

                If Not My.Computer.FileSystem.FileExists(strNewDest & "\" & colFiles(intCount).Name) Then

                    MessageBox.Show("Copying " & strNewDest & "\" & colFiles(intCount).Name & " to Keep seems to have gone wrong! - ending")
                    End
                End If
            Next
        End If

    End Sub

    Public Sub UpdateMagazineTitles()

        Dim intCount As Integer
        Dim strTitles() As String
        Dim strNew As String = ""

        If mblnUpdatedMagazineTitles Then Exit Sub

        ' Update string with titles I want that will be changed later by Processing All

        MAGAZINE_TITLES_KEEP_PROCESSING = MAGAZINE_TITLES_KEEP_PROCESSING & "Air & Space Smithsonian,delicious Australia,New Scientist Australian Edition,EASY COOK,GOOD FOOD,OLIVE,SKY AT NIGHT,COOKING LIGHT BOOKAZINES,"
        MAGAZINE_TITLES_KEEP_PROCESSING = MAGAZINE_TITLES_KEEP_PROCESSING & "Australian Healthy Food Guide,Australian Sky & Telescope,Australian Yoga Journal,BBC Good Food Middle East,delicious UK,New Scientist International Edition,"
        MAGAZINE_TITLES_KEEP_PROCESSING = MAGAZINE_TITLES_KEEP_PROCESSING & "Sainsbury’s Magazine,Sсiеntifiс Аmеricаn Mind,Taste.com.au,The Australian Women’s Weekly Food,Yoga Journal USA,BBC Good Food India,Sсiеntifiс Аmеricаn,Yoga Journal USA,"
        MAGAZINE_TITLES_KEEP_PROCESSING = MAGAZINE_TITLES_KEEP_PROCESSING & "taste.com.au Cookbooks,Easy Food Ireland,Cook’s Country,Eating Well,Australian Gourmet Traveller,BBC Easy Cook UK,Cook's Illustrated,WEIGHT WATCHERS UK,"
        MAGAZINE_TITLES_KEEP_PROCESSING = MAGAZINE_TITLES_KEEP_PROCESSING & "Eatingwell Special Ed.,OM Yoga,BBC Good Food UK,COOKS ILLUSTRATED,THE AUSTRALIAN WOMENS WEEKLY,"

        MAGAZINE_TITLES_KEEP_PROCESSING = MAGAZINE_TITLES_KEEP_PROCESSING.ToUpper

        strTitles = MAGAZINE_TITLES_KEEP_PROCESSING.Split(",")

        For intCount = 0 To strTitles.GetUpperBound(0) - 1

            strNew = strNew & strTitles(intCount).Trim & "," & strTitles(intCount).Trim & " MAGAZINE,"
        Next

        MAGAZINE_TITLES_KEEP_PROCESSING = strNew.ToUpper

        mblnUpdatedMagazineTitles = True

    End Sub

    Public Function IsValidMagazine(ByVal strFileName As String) As Boolean

        Dim intPos As Integer, strTemp As String

        IsValidMagazine = False

        strFileName = strFileName.Replace("_39_s_", "'s ")

        strFileName = strFileName.Replace("'", "")
        strFileName = strFileName.Replace("’", "")
        strFileName = strFileName.Replace("É", "e")

        strFileName = strFileName.ToUpper.Replace("_", " ").Replace(" AMP ", " & ")

        strFileName = strFileName.Replace("  ", " ")

        strTemp = GetTextUpto1stNumeric(strFileName)

        If strTemp <> "" Then

            strTemp = strTemp.Trim

            If InStr(MAGAZINE_TITLES_KEEP_PROCESSING, strTemp & ",") > 0 Then

                IsValidMagazine = True
                Exit Function
            End If
        End If

        intPos = InStr(strFileName, " - ")

        If intPos > 0 Then

            strFileName = Mid(strFileName, 1, intPos).Trim

            If InStr(MAGAZINE_TITLES_KEEP_PROCESSING, strFileName & ",") > 0 Then

                IsValidMagazine = True
                Exit Function
            End If
        End If

        intPos = InStr(strFileName, " – ")

        If intPos > 0 Then

            strFileName = Mid(strFileName, 1, intPos).Trim

            If InStr(MAGAZINE_TITLES_KEEP_PROCESSING, strFileName & ",") > 0 Then

                IsValidMagazine = True
                Exit Function
            End If
        End If

    End Function

    Public Function TryToMatchOnAYearForAMagazine(ByVal strFileName As String) As String

        Dim intPos As Integer, intCount As Integer

        TryToMatchOnAYearForAMagazine = ""

        For intCount = 6 To 0 Step -1

            intPos = InStr(1, strFileName, " " & Year(Now) - intCount & " ")

            If intPos > 0 Then

                TryToMatchOnAYearForAMagazine = Year(Now) - intCount
                Exit Function
            End If

            intPos = InStr(1, strFileName, " " & Year(Now) - intCount & ".pdf")

            If intPos > 0 Then

                TryToMatchOnAYearForAMagazine = Year(Now) - intCount
                Exit Function
            End If
        Next

    End Function

    Public Sub SetRootPath(ByVal strPath As String)

        mstrPath = strPath

    End Sub

    Public Function GetRootPath() As String

        If mstrPath = "" Then

            GetRootPath = mobjOptions.RootFolder
        Else

            GetRootPath = mstrPath
        End If

    End Function

    Public Function GetFullTVPath() As String

        If mstrPath = "" Then

            GetFullTVPath = mobjOptions.FullPathTV
        Else

            GetFullTVPath = mstrPath & "\_TV\"
        End If

    End Function

    Public Function GetFullMoviesPath() As String

        If mstrPath = "" Then

            GetFullMoviesPath = mobjOptions.FullPathMovies
        Else

            GetFullMoviesPath = mstrPath & "\_Movies\"
        End If

    End Function

    Public Function GetFullMagsPath() As String

        If mstrPath = "" Then

            GetFullMagsPath = mobjOptions.FullPathMags
        Else

            GetFullMagsPath = mstrPath & "\_Magazines\"
        End If

    End Function

    Public Function GetFullMusicPath() As String

        If mstrPath = "" Then

            GetFullMusicPath = mobjOptions.FullPathMusic
        Else

            GetFullMusicPath = mstrPath & "\_Music\"
        End If

    End Function

    Public Function GetFullBooksPath() As String

        If mstrPath = "" Then

            GetFullBooksPath = mobjOptions.FullPathBooks
        Else

            GetFullBooksPath = mstrPath & "\_Books\"
        End If

    End Function

    Public Function GetSeasonNumeric(ByVal strSeason As String) As String


        strSeason = strSeason.Replace("Season ", "")

        If strSeason.Length = 1 Then

            strSeason = "0" & strSeason
        End If

        strSeason = "S" & strSeason

        GetSeasonNumeric = strSeason

    End Function

    Public Function UppercaseEForEpisode(ByVal strName As String, ByVal strSeason As String) As String

        Dim strMatch As String, intPos As Integer, intPos2 As Integer

        If strSeason = "" Then

            UppercaseEForEpisode = strName
            Exit Function
        End If

        strMatch = " " & GetSeasonNumeric(strSeason)

        intPos = InStr(strName, strMatch)

        If intPos = 0 Then

            UppercaseEForEpisode = strName

        Else

            intPos2 = InStr(intPos + 1, strName, " ")
            If intPos2 = 0 Then intPos2 = InStr(intPos + 1, strName, ".")

            If intPos2 > 0 Then

                strName = Mid(strName, 1, intPos) & Mid(strName, intPos, intPos2 - intPos).ToUpper.Trim & Mid(strName, intPos2)
            End If

            UppercaseEForEpisode = strName
        End If

    End Function

    Public Function DoesTextEndIn(strText As String, strFindText As String) As Boolean

        Dim strEndText As String, intStart As Integer

        Try

            strText = strText.Trim.ToUpper
            strFindText = strFindText.Trim.ToUpper

            DoesTextEndIn = False

            If strFindText = "" Then

                DoesTextEndIn = False
                Exit Function
            End If

            intStart = Len(strText) - Len(strFindText)

            If intStart <= 0 Then

                DoesTextEndIn = False
                Exit Function
            End If

            strFindText = " " & strFindText

            strEndText = Mid(strText, intStart)

            If strEndText = strFindText Then

                DoesTextEndIn = True
            Else

                DoesTextEndIn = False
            End If

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Function

End Module
