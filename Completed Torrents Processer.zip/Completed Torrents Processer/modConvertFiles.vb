﻿Module modConvertFiles

    Public Function ConvertWavsToMP3(ByRef strFilePath As String, objMe As frmMain) As Boolean

        Dim strCommand As String, strTemp As String

        ConvertWavsToMP3 = False

        If GetPrefixwithDot(strFilePath) <> WAV Then

            Exit Function
        End If

        strTemp = objMe.Text

        objMe.Text = "Converting Wav to Mp3 - " & RemovePath(strFilePath)

        objMe.Refresh()
        My.Application.DoEvents()

        ' Uses  Lame_v3.99.3_for_Windows.exe
        ' http://lame.buanzo.org/#lamewindl

        If My.Computer.Name = HOME_PC Then

            strCommand = "E:\VB.Net (Big Stuff)\Installs for VB.Net Projects\Lame For Audacity\lame.exe"
        Else

            strCommand = ROOT_DRIVE & "\Program Files\Lame For Audacity\lame.exe"
        End If

        If Not My.Computer.FileSystem.FileExists(strCommand) Then

            MessageBox.Show("Lame not installed! Quitting...", My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End
        End If

        Dim objLame As New Process

        With objLame

            .StartInfo.FileName = strCommand
            .StartInfo.Arguments = "-h """ & strFilePath & """ """ & strFilePath.Replace(".wav", ".mp3") & """ "
            .StartInfo.UseShellExecute = False
            .StartInfo.CreateNoWindow = True
            .StartInfo.WindowStyle = ProcessWindowStyle.Hidden

            .StartInfo.RedirectStandardOutput = True
            .Start()
            .WaitForExit()
        End With

        objLame.Close()
        objLame = Nothing

        If Not My.Computer.FileSystem.FileExists(strFilePath.Replace(".wav", ".mp3")) Then

            MessageBox.Show("Problem converting " & strFilePath & " to an .mp3 file! Will end now...", My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End
        End If

        My.Computer.FileSystem.DeleteFile(strFilePath)

        'http://www.thegeekstuff.com/2009/05/sound-exchange-sox-15-examples-to-manipulate-audio-files/#comments

        objMe.Text = strTemp

        objMe.Refresh()
        My.Application.DoEvents()

        ConvertWavsToMP3 = True

    End Function

    Public Sub ProcessFLACFiles(ByRef d As DirectoryInfo, ByRef colFiles As FileInfo(), objMe As frmMain, ByRef blnSubFolder As Boolean)

        Dim objFile As FileInfo, blnSubFolders As Boolean

        For Each objFile In colFiles

            ProcessFLACFile(objFile, objMe)
        Next

        If blnSubFolder Then

            Try

                For Each objSubDir In d.GetDirectories

                    blnSubFolders = objSubDir.GetDirectories.Length > 0

                    ProcessFLACFiles(objSubDir, objSubDir.GetFiles, objMe, blnSubFolders)
                Next

            Catch DirectoryNotFoundException As Exception

            End Try
        End If


    End Sub

    Public Sub ProcessFLACFile(ByRef objFile As FileInfo, objMe As frmMain)

        Dim strCommand As String, strTemp As String
        Dim strName As String

        If GetPrefixwithDot(objFile.Name) <> FLAC Then

            Exit Sub
        End If

        strTemp = objMe.Text
        objMe.Text = "Converting Flac to Wav - " & objFile.Name

        objMe.Refresh()
        My.Application.DoEvents()

        Debug.Print("Converting Flac to Wav - " & objFile.Name)

        If My.Computer.Name = HOME_PC Then

            strCommand = "C:\Program Files (x86)\FLAC Frontend\tools\flac.exe"
        Else

            strCommand = "c:\Program Files\FLAC\Flac.exe"
        End If

        If Not My.Computer.FileSystem.FileExists(strCommand) Then

            MessageBox.Show("Flac not installed! Quitting...", My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End
        End If

        Dim objFlac As New Process

        With objFlac

            .StartInfo.FileName = strCommand
            .StartInfo.Arguments = "-d """ & objFile.FullName & """"
            .StartInfo.UseShellExecute = False
            .StartInfo.CreateNoWindow = True
            .StartInfo.WindowStyle = ProcessWindowStyle.Hidden

            .StartInfo.RedirectStandardOutput = True
            .Start()
            .WaitForExit()
        End With

        objFlac.Close()

        If Not My.Computer.FileSystem.FileExists(objFile.FullName.Replace(".flac", ".wav")) Then

            MessageBox.Show("Problem converting " & objFile.FullName & " to a .wav file! Will end now...", My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End
        End If

        strName = objFile.FullName.Replace(".flac", ".wav")

        MoveToDeleted(objFile, False, FLAC)

        'http://www.thegeekstuff.com/2009/05/sound-exchange-sox-15-examples-to-manipulate-audio-files/#comments

        ConvertWavsToMP3(strName, objMe)

        objMe.Text = strTemp

        objMe.Refresh()
        My.Application.DoEvents()

    End Sub

End Module
