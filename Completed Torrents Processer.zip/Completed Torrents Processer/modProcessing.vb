﻿Imports PdfSharp.SharpZipLib.Zip.Compression

Module modProcessing

    Public mobjOptions As clsOptions
    Public mobjStats As New clsStats
    Public ProcessTime As String
    'Private _nonAlphaNumerics As Boolean

    'Private Property NonAlphaNumerics(strName As String) As Boolean
    '    Get
    '        Return _nonAlphaNumerics
    '    End Get
    '    Set(value As Boolean)
    '        _nonAlphaNumerics = value
    '    End Set
    'End Property

    Public Sub UpdateScreen(ByRef objMe As frmMain, ByVal strName As String)

        Try

            objMe.Refresh()
            My.Application.DoEvents()

            objMe.lblCurrentFile.Text = strName

            objMe.lblNFOCount.Text = mobjStats.NFO_Count
            objMe.lblTXTCount.Text = mobjStats.TXT_Count
            objMe.lblOPFCount.Text = mobjStats.OPF_Count
            objMe.lblJPEGCount.Text = mobjStats.JPEG_Count
            objMe.lblDOCCount.Text = mobjStats.DOC_Count
            objMe.lblSRTCount.Text = mobjStats.SRT_Count
            objMe.lblSubCount.Text = mobjStats.SUB_Count
            objMe.lblTorrentCount.Text = mobjStats.TORRENT_Count
            objMe.lblHTMLCount.Text = mobjStats.HTML_Count

            objMe.lblUnknownCount.Text = mobjStats.Unknown_Count

            objMe.lblMagsCount.Text = mobjStats.Mags_Count
            If mobjStats.Dup_Mags_Count > 0 Then objMe.lblMagsCount.Text = objMe.lblMagsCount.Text & " duplicates - " & mobjStats.Dup_Mags_Count

            objMe.lblMoviesCount.Text = mobjStats.Movies_Count
            If mobjStats.Dup_Movies_Count > 0 Then objMe.lblMoviesCount.Text = objMe.lblMoviesCount.Text & " duplicates - " & mobjStats.Dup_Movies_Count

            objMe.lblBooksCount.Text = mobjStats.Books_Count
            If mobjStats.Dup_Books_Count > 0 Then objMe.lblBooksCount.Text = objMe.lblBooksCount.Text & " duplicates - " & mobjStats.Dup_Books_Count

            objMe.lblTVCount.Text = mobjStats.TV_Count
            If mobjStats.Dup_TV_Count > 0 Then objMe.lblTVCount.Text = objMe.lblTVCount.Text & " duplicates - " & mobjStats.Dup_TV_Count

            objMe.lblMusicCount.Text = mobjStats.Music_Count
            If mobjStats.Dup_Music_Count > 0 Then objMe.lblMusicCount.Text = objMe.lblMusicCount.Text & " duplicates - " & mobjStats.Dup_Music_Count

            objMe.Refresh()
            My.Application.DoEvents()

            objMe.Refresh()

        Catch ex As Exception

        End Try

    End Sub

    Public Function GetAllFilesFromPath(ByVal dir As DirectoryInfo) As String()

        Dim d As Object, strFiles As String
        Dim f As FileInfo, strFilesInPath() As String
        Dim strPath As String

        strFiles = ""

        For Each d In dir.GetFileSystemInfos()

            If (TypeOf (d) Is FileInfo) Then

                f = CType(d, FileInfo)

                strPath = f.FullName

                strFiles = strFiles & strPath & vbCrLf

            Else

                'it must be an directory

            End If
        Next

        strFilesInPath = strFiles.Split(vbCrLf)

        GetAllFilesFromPath = strFilesInPath

    End Function

    Private Function DateInFilename(ByVal strFile As String, ByRef strMonth As String, ByRef strYear As String) As Boolean

        Dim intPos As Integer, strPart As String

        DateInFilename = False

        intPos = InStr(1, strFile, " - ")

        If intPos > 0 Then

            strPart = Mid$(strFile, intPos + 3).Trim

            strPart = RemovePrefix(strPart)

            If MyIsDate(strPart, strMonth, strYear) Then

                Return True
            End If
        End If

    End Function

    Private Function DoWeTreatAsANewMagazine(ByVal strFilename As String, ByRef strMagFolder As String) As Boolean

        Dim intPos As Integer, intResult As Integer

        Try

            DoWeTreatAsANewMagazine = False

            intPos = InStr(strFilename, " - ")

            If intPos = 0 Then

                Return False
            End If

            If Mid(strFilename, 1, intPos) = "Shares Magazine " Then

                Return False
            End If

            strMagFolder = strMagFolder.Replace(" Special Issue", "")
            strMagFolder = strMagFolder.Replace(" Special Issues", "")

            If DateInMagazineFilename(strFilename, "", "") Then

                intResult = MessageBox.Show("Treat as new type of magazine?" & vbCrLf & vbCrLf & "Yes will create a new folder in " & mobjOptions.Mags & vbCrLf & vbCrLf & strMagFolder & vbCrLf & vbCrLf _
                                            & "No will move the file to " & mobjOptions.Books & vbCrLf & vbCrLf & "Cancel will quit program so it can be handled manually" _
                                            & vbCrLf & vbCrLf & "Filename - " & strFilename, My.Application.Info.ProductName, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)

                Select Case intResult

                    Case 6  ' Yes

                        Return True

                    Case 7 ' No

                        Return False

                    Case 2 ' Cancel

                        End

                End Select
            End If

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Function

    Private Function DateInMagazineFilename(ByVal strFile As String, ByRef strMonth As String, ByRef strYear As String) As Boolean

        Dim intPos As Integer, strPart As String

        DateInMagazineFilename = False

        strFile = strFile.ToUpper

        strFile = strFile.Replace(",", "")

        intPos = InStr(1, strFile, " ISSUE ")

        If intPos > 0 Then

            strFile = strFile.Replace(" ISSUE ", " - ")
        End If

        intPos = InStr(1, strFile, " MAGAZINE ")

        If intPos > 0 Then

            strFile = strFile.Replace(" MAGAZINE ", " - ")
        End If

        strFile = strFile.Replace(" - - ", " - ")

        intPos = InStr(1, strFile, " - ")

        If intPos > 0 Then

            strPart = Mid$(strFile, intPos + 3).Trim

            strPart = RemovePrefix(strPart)

            If MyIsDate(strPart, strMonth, strYear) Then

                Return True
            End If
        End If

        ' Two months ie Chickens - Jan - Feb 2019.pdf
        If ProcessDatesWithTwoMonths(strFile, strMonth, strYear) Then

            Return True
        End If

        intPos = InStr(1, strFile, " MAGAZINE ")

        If intPos > 0 Then

            strPart = Mid$(strFile, intPos + 10).Trim

            strPart = RemovePrefix(strPart)

            If MyIsDate(strPart, strMonth, strYear) Then

                Return True
            End If
        End If

        intPos = InStr(1, strFile, " ISSUE ")

        If intPos > 0 Then

            strPart = Mid$(strFile, intPos + 7).Trim

            strPart = RemovePrefix(strPart)

            If MyIsDate(strPart, strMonth, strYear) Then

                Return True
            End If
        End If

    End Function

    ' Two months ie Chickens - Jan - Feb 2019.pdf

    Public Function ProcessDatesWithTwoMonths(ByVal strFile As String, ByRef strMonth As String, ByRef strYear As String) As Boolean

        Dim strMonths(12) As String, intPos As Integer, intCount As Integer
        Dim strSplit() As String, strText As String

        ProcessDatesWithTwoMonths = False

        strMonths(1) = " JAN - FEB "
        strMonths(2) = " FEB - MAR "
        strMonths(3) = " MAR - APR "
        strMonths(4) = " APR - MAY "
        strMonths(5) = " MAY - JUN "
        strMonths(6) = " JUN - JUL "
        strMonths(7) = " JUL - AUG "
        strMonths(8) = " AUG - SEP "
        strMonths(9) = " SEP - OCT "
        strMonths(10) = " OCT - NOV "
        strMonths(11) = " NOV - DEC "
        strMonths(12) = " DEC - JAN "
        For intCount = 1 To 12

            intPos = InStr(strFile, strMonths(intCount))

            If intPos > 0 Then

                strText = Mid(strFile, intPos + Len(strMonths(intCount)))

                strText = RemovePrefix(strText)

                intPos = InStr(strText, " ")

                If intPos > 0 Then

                    strText = Mid(strText, 1, intPos - 1)
                End If

                If IsNumeric(strText) Then

                    strYear = strText
                    strMonth = Mid(Trim(strMonths(intCount)), 1, 3)

                    ProcessDatesWithTwoMonths = True

                    Exit Function
                End If
            End If
        Next

    End Function

    Public Function MyIsDate(ByVal strDate As String, ByRef strMonth As String, ByRef strYear As String) As Boolean

        Dim strItems() As String, intCount As Integer
        Dim strLeft As String, strRight As String

        strMonth = ""
        strYear = ""

        strItems = Split(strDate, " ")

        ' Month only?
        If strItems.GetUpperBound(0) = 0 Then

            If IsMonth(strItems(0)) Then

                strMonth = strItems(0)
                strYear = Now.Year
                Return True
            End If
        End If

        ' Month & Year
        If strItems.GetUpperBound(0) = 1 Then

            If IsMonth(strItems(0)) Then

                If IsNumeric(strItems(1)) Then

                    strMonth = strItems(0)
                    strYear = strItems(1)
                    Return True
                End If
            End If

        End If

        ' Day & Month & Year
        If strItems.GetUpperBound(0) = 2 Then

            If IsNumericDay(strItems(0)) Then

                If IsMonth(strItems(1)) Then

                    If IsYear(strItems(2), 2000) Then

                        strMonth = strItems(1)
                        strYear = strItems(2)

                        Return True
                    End If
                End If

            End If

            If IsMonth(strItems(0)) Then

                If IsYear(strItems(1), 2000) Then

                    strMonth = strItems(0)
                    strYear = strItems(1)
                    Return True
                End If

            End If

            If IsMonth(strItems(0)) Then

                If IsYear(strItems(2), 2000) Then

                    strMonth = strItems(0)
                    strYear = strItems(2)
                    Return True
                End If

            End If

        End If

        ' Day & Month & others
        If strItems.GetUpperBound(0) = 3 Then

            If IsNumericDay(strItems(0)) Then

                If IsMonth(strItems(1)) Then

                    If IsYear(strItems(2), 2000) Then

                        strMonth = strItems(1)
                        strYear = strItems(2)

                        Return True
                    End If
                End If
            End If

            If IsMonth(strItems(0)) Then

                If IsYear(strItems(1), 2000) Then

                    strMonth = ToProperCase(strItems(0), False)
                    strYear = strItems(1)

                    Return True
                End If
            End If

            If IsMonth(strItems(0)) Then

                If IsYear(strItems(2), 2000) Then

                    strMonth = ToProperCase(strItems(0), False)
                    strYear = strItems(2)

                    Return True
                End If
            End If

        End If

        intCount = 0

        If strItems.GetUpperBound(0) > 3 Then

            While intCount < strItems.GetUpperBound(0) - 1

                strLeft = strItems(intCount)
                strRight = strItems(intCount + 1)

                If IsMonth(strLeft) And IsYear(strRight, 2000) Then

                    strMonth = strLeft
                    strYear = strRight

                    Return True
                End If

                intCount = intCount + 1
            End While

        End If

    End Function

    Private Function IsMagazineByInitialStringMatch(ByRef objFile As FileInfo) As Boolean

        Dim strMags() As String, intCount As Integer
        Dim intLength As Integer, strName As String
        Dim strPath As String

        IsMagazineByInitialStringMatch = False

        intLength = objFile.Name.Length
        strName = objFile.Name.ToUpper

        strPath = GetPath(objFile.FullName)

        strMags = MAGAZINE_TITLES.Split(",")

        For intCount = 0 To strMags.GetUpperBound(0)

            If strMags(intCount).Trim <> "" Then

                If strMags(intCount).Length < intLength Then

                    If Mid(strName, 1, strMags(intCount).Length) = strMags(intCount) Then

                        strName = strName.Replace(strMags(intCount), "").Trim

                        If Mid(strName, 1, 1) <> "-" Then

                            strName = ToProperCase(strMags(intCount) & " - " & strName, True)
                        End If

                        objFile.MoveTo(strPath & strName)

                        IsMagazineByInitialStringMatch = True
                        Exit For
                    End If
                End If
            End If
        Next

    End Function

    Public Function IsBookByFilePrefix(ByRef objFile As FileInfo) As Boolean

        Dim strPrefix As String

        IsBookByFilePrefix = False

        strPrefix = GetPrefix(objFile.Name).ToUpper

        Select Case strPrefix

            Case "PDF", "MOBI", "EPUB", "AZW3"

                IsBookByFilePrefix = True

        End Select

    End Function

    Private Function IsMagazine(ByVal strFile As String, ByRef strMagFolder As String, ByRef objFile As FileInfo) As Boolean

        Dim strName As String, intPos As Integer, strReport As String
        Dim MAGAZINE_TITLES_WITHOUT As String

        IsMagazine = False

        intPos = InStr(strFile, " – ")

        If intPos > 0 Then

            strFile = strFile.Replace(" – ", " - ")

            objFile.MoveTo(objFile.DirectoryName & "\" & strFile)
            objFile.Refresh()

            strFile = objFile.Name
        End If

        intPos = InStr(strFile, "’")

        If intPos > 0 Then

            strFile = strFile.Replace("’", "")

            objFile.MoveTo(objFile.DirectoryName & "\" & strFile)
            objFile.Refresh()

            strFile = objFile.Name
        End If

        intPos = InStr(strFile, "'")

        If intPos > 0 Then

            strFile = strFile.Replace("'", "")

            objFile.MoveTo(objFile.DirectoryName & "\" & strFile)
            objFile.Refresh()

            strFile = objFile.Name
        End If

        strFile = strFile.ToUpper

        strName = RemovePath(CleanupMagazineFilename(strFile))

        strMagFolder = ToProperCase(strName, False)

        strName = strName.ToUpper & ","

        If Mid(strName, 1, 4) = "THE " Then strName = Mid(strName, 5)

        MAGAZINE_TITLES_WITHOUT = Replace(MAGAZINE_TITLES, ",", " MAGAZINE ,")

        If NonAlphaNumerics(strName, strReport) Then

            MessageBox.Show("Non alphanumberics found in strName - " & vbCrLf & vbCrLf & strReport & vbCrLf & vbCrLf & strName & vbCrLf & vbCrLf & "strFile - " & objFile.DirectoryName & "\" & strFile & vbCrLf & vbCrLf & "quitting to let you sort it out...", "Problem", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End
        End If

        If NonAlphaNumerics(MAGAZINE_TITLES, strReport) Then

            MessageBox.Show("Non alphanumberics found in MAGAZINE_TITLES - " & vbCrLf & vbCrLf & strReport & vbCrLf & vbCrLf & MAGAZINE_TITLES & vbCrLf & vbCrLf & "quitting to let you sort it out...", "Problem", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End
        End If

        If NonAlphaNumerics(MAGAZINE_TITLES_WITHOUT, strReport) Then

            MessageBox.Show("Non alphanumberics found in MAGAZINE_TITLES_WITHOUT - " & vbCrLf & vbCrLf & strReport & vbCrLf & vbCrLf & MAGAZINE_TITLES_WITHOUT & vbCrLf & vbCrLf & "quitting to let you sort it out...", "Problem", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End
        End If

        If InStr(MAGAZINE_TITLES, strName) > 0 Or InStr(MAGAZINE_TITLES_WITHOUT, strName) > 0 Then

            IsMagazine = True
        Else

            IsMagazine = False
        End If

    End Function

    Public Function NonAlphaNumerics(ByVal strName As String, ByRef strReport As String) As Boolean

        Dim intCount As Integer, strChar As String
        Dim strOKChars As String

        strReport = ""

        If strName = "" Or strName Is Nothing Then Exit Function

        NonAlphaNumerics = True

        strOKChars = ",, ,&,(,),[,],{,},_,#,+,',’,!,É,"

        For intCount = 1 To strName.Length

            strChar = Mid(strName, intCount, 1)

            If Asc(strChar) < 65 Or Asc(strChar) > 90 Then

                If Asc(strChar) < 48 Or Asc(strChar) > 57 Then

                    If InStr(strOKChars, strChar & ",") = 0 Then

                        strReport = "Problem is char - " & strChar & " with an ASCII value of " & Asc(strChar)
                        Exit Function
                    End If
                End If
            End If

        Next

        NonAlphaNumerics = False

    End Function

    Public Function DateInFolderName(ByVal strDirectory As String, ByRef strDate As String) As Boolean

        Dim intPos As Integer, strSearch As String

        strSearch = " - "
        strDate = ""

        If strDirectory = GetRootPath() Then

            Return False
        End If

        intPos = InStr(1, strDirectory, strSearch)

        If intPos = 0 Then

            Return False
        Else

            strDate = Mid(strDirectory, intPos + Len(strSearch)).Trim
            Return True
        End If

    End Function

    Public Sub ProcessFile(ByRef d As DirectoryInfo, ByVal objFile As FileInfo, ByRef objMe As frmMain)

        Dim strPrefix As String
        Dim strSeason As String, strEpisode As String, strSeriesName As String
        Dim strTo As String, blnTV As Boolean, strMagFolder As String

        'objMe = DirectCast(objMe, frmMain)

        strPrefix = objFile.Extension.ToUpper

        Select Case strPrefix

            Case ISO

                strTo = mobjOptions.FullPathTV

                MoveFile(objFile.FullName, strTo & objFile.Name, objMe, True, ISO)

            Case MP3, AC3, M4A

                MoveMusic(objFile, objMe)

            Case WAV

                ConvertWavsToMP3(objFile.FullName, objMe)

            Case FLAC

                ProcessFLACFile(objFile, objMe)

            Case PDF, EPUB, MOBI, AZW3, DJVU, PRC

                FileRenamer_PreprocessPotentialMagazine(objFile)

                If IsMagazine(objFile.Name, strMagFolder, objFile) Then

                    HandleMagazine(objFile, objMe)

                ElseIf IsMagazineByInitialStringMatch(objFile) Then

                    HandleMagazine(objFile, objMe)
                Else

                    If DoWeTreatAsANewMagazine(objFile.Name, strMagFolder) Then

                        HandleMagazine(objFile, objMe)

                        ' Update list of magazine folders
                        FindMagazineTitles()
                    Else

                        MoveBook(objFile, objMe)
                    End If

                End If

            Case AVI, MP4, MKV, WMV, SRT, MPEG, MPG, M2TS, FLV, ASF

                blnTV = False

                ' Try by filename first
                If IsTV_ByFilename(d, objFile, strSeriesName, strSeason, strEpisode) Then

                    blnTV = True
                Else

                    ' Sometimes the name would be like Masterchef.Australia.207.X264-HD.mp4 but folder like Masterchef.Australia.S2E07.X264-HD
                    If IsTV_ByFolderName(d, objFile, strSeriesName, strSeason, strEpisode) Then

                        blnTV = True
                    Else

                        ' Sometimes the name would be like Masterchef.Australia.207.X264-HD.mp4 and be in
                        ' the completed folder not a folder of its own. See if it meets the format
                        ' text . 3 digit number . and then a set of matches ' .PDTV. .HDTV. .ETTV. etc

                        ' so Masterchef.Australia.207.PDTV-HD.mp4 would match
                        'If isTV_Text_Match(d, objFile, strSeriesName, strSeason, strEpisode) Then

                        '   blnTV = True
                        'End If
                    End If
                End If

                If blnTV Then

                    strSeriesName = CleanupSeriesName(strSeriesName)

                    SortOutSeriesNameOnes(strSeriesName, strSeason)

                    MoveTV(objFile, strSeriesName, strSeason, strEpisode, objMe)
                Else

                    MoveMovieFile(objFile, objMe)
                End If

        End Select

    End Sub

    Private Sub SortOutSeriesNameOnes(ByRef strSeriesName As String, ByRef strSeason As String)

        Dim strSeriesNameSplit() As String, strSeasonNameSplit() As String
        Dim intUpperBound As Integer, intCount As Integer

        ' I can have entries like this - the series 2 confuses things - there's an assumption of season 1 somewhere
        ' file =                Coast.Australia.Series.2.3of8.Byron.Bay.720p.HDTV.x264.AAC.MVGroup.org.mp4
        ' strSeriesName =       Coast Australia Series 2
        ' strSeason =           Season 1

        Try

            strSeriesNameSplit = strSeriesName.Split(" ")
            strSeasonNameSplit = strSeason.Split(" ")

            ' Check season 
            If strSeasonNameSplit.GetUpperBound(0) = 1 Then

                If strSeasonNameSplit(0) = "Season" And IsNumeric(strSeasonNameSplit(1)) Then

                    ' If OK check series name
                    intUpperBound = strSeriesNameSplit.GetUpperBound(0)

                    If intUpperBound >= 2 Then

                        If strSeriesNameSplit(intUpperBound - 1) = "Series" And IsNumeric(strSeriesNameSplit(intUpperBound)) And strSeriesNameSplit(intUpperBound) <> "1" Then

                            strSeason = "Season " & strSeriesNameSplit(intUpperBound)

                            strSeriesName = ""

                            For intCount = 0 To intUpperBound - 2

                                strSeriesName = strSeriesName & strSeriesNameSplit(intCount) & " "
                            Next

                            strSeriesName = strSeriesName.Trim
                        End If

                    End If
                End If

            End If

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
        End Try

    End Sub

    Private Sub HandleMagazine(ByVal objFile As FileInfo, ByRef objMe As frmMain)

        Dim strMonth As String, strYear As String, strDate As String
        Dim strFilename As String, strPath As String
        Dim strBefore As String

        strFilename = FileRenamer_MagazineCleanup(objFile.Name, objFile.FullName)

        If strFilename <> objFile.Name Then

            strBefore = objFile.FullName

            strPath = GetPath(objFile.FullName)

            objFile.MoveTo(strPath & strFilename)

            Delay(1)

            If Not My.Computer.FileSystem.FileExists(strPath & strFilename) Then

                MessageBox.Show("HandleMagazine - Failed to move " & strBefore & " to " & strPath & strFilename & "! Ending")

                End
            End If
        End If

        If DateInMagazineFilename(objFile.Name, strMonth, strYear) Then

            MoveMagazine(objFile, True, strMonth, strYear, objMe)
        Else

            If DateInFolderName(objFile.Directory.FullName, strDate) Then

                MoveMagazine(objFile, True, strMonth, strYear, objMe)
            Else

                MoveMagazine(objFile, False, strMonth, strYear, objMe)
            End If
        End If

    End Sub

    Private Function GetSeriesName(ByVal strFileName As String) As String

        Dim intPos As Integer

        strFileName = Replace(strFileName, "_", " ")

        intPos = InStr(1, strFileName, " - ")

        strFileName = strFileName.Replace("  ", " ")
        strFileName = strFileName.Replace("  ", " ")
        strFileName = strFileName.Replace("  ", " ")
        strFileName = strFileName.Replace("  ", " ")
        strFileName = strFileName.Replace("  ", " ")

        If intPos > 0 Then

            GetSeriesName = Mid(strFileName, 1, intPos - 1).Trim

            If Mid(GetSeriesName, Len(GetSeriesName)) = "-" Then

                GetSeriesName = Mid(GetSeriesName, 1, Len(GetSeriesName) - 1)
            End If

            ' Remove any season/episode indicator
            GetSeriesName = RemoveSeasonIndicator(GetSeriesName)

            Exit Function
        End If

    End Function

    Private Function RemoveSeasonIndicator(ByVal strSeriesName As String) As String

        Dim intSPos As Integer, intEPos As Integer

        If TryToFindname_By_Usual_Format_S01E01(strSeriesName, intSPos, intEPos) Then

            If intSPos > 0 Then

                strSeriesName = Mid(strSeriesName, 1, intSPos)
            End If
        End If

        If Mid(strSeriesName, Len(strSeriesName), 1) = "." Then

            strSeriesName = Mid(strSeriesName, 1, Len(strSeriesName) - 1)
        End If

        RemoveSeasonIndicator = strSeriesName.Trim

    End Function

    Private Function IsMiddleString(ByVal strText As String, ByVal strMiddle As String) As Boolean

        Dim intCount As Integer

        strMiddle = strMiddle.ToUpper

        If IsNumeric(Mid(strText, 1, 1)) Then

            strText = " " & Mid(strText, 2)
        End If

        For intCount = 2 To strText.Length - 1

            If IsNumeric(Mid(strText, intCount, 1)) Then

                strText = Mid(strText, 1, intCount - 1) & " " & Mid(strText, intCount + 1)
            End If
        Next

        If IsNumeric(Mid(strText, strText.Length, 1)) Then

            strText = Mid(strText, 1, strText.Length - 1) & " "
        End If

        strText = strText.ToUpper.Trim

        Select Case strText

            Case strMiddle

                Return True

            Case Else : Return False

        End Select

    End Function

    Private Function IsNamedAfterChannel(ByVal strFileName As String, ByRef strSeriesName As String) As Boolean

        Dim str1stFourChars As String, str1stThreeChars As String

        strFileName = strFileName.ToUpper

        strFileName = strFileName.Replace(".", " ")
        strFileName = strFileName.Replace("_", " ")

        IsNamedAfterChannel = False

        If Len(strFileName) < 3 Then

            Exit Function
        End If

        str1stFourChars = Mid(strFileName, 1, 4)

        Select Case str1stFourChars

            Case "BBC ", "PBS ", "CH4 ", "HBO "

                strSeriesName = str1stFourChars.Trim
                IsNamedAfterChannel = True
                Exit Function

        End Select

        str1stThreeChars = Mid(strFileName, 1, 3)

        Select Case str1stThreeChars

            Case "C5 "

                strSeriesName = str1stThreeChars.Trim
                IsNamedAfterChannel = True
                Exit Function

        End Select

    End Function

    Private Function TryToGetUsingHDTVLOLFormat(ByRef d As DirectoryInfo, ByVal strName As String, ByVal strFullPath As String, ByRef intSPos As Integer, ByRef intEPos As Integer, _
                                                ByRef strSeriesName As String) As Boolean

        Dim strSplits() As String, intUpper As Integer, intCount As Integer
        Dim strNewName As String, intLengthBeforeSofSeason As Integer

        TryToGetUsingHDTVLOLFormat = False

        strName = strName.ToUpper

        strSplits = Split(strName, ".")

        intUpper = strSplits.GetUpperBound(0)

        If intUpper > 1 Then

            ' Movie Type
            If InStr(AllVideoTypes, strSplits(intUpper) & ",") > 0 Then

                ' Marker
                If Trim(strSplits(intUpper - 1)) = "HDTV-LOL" Then

                    ' Numeric
                    If IsNumeric(strSplits(intUpper - 2)) Then

                        ' Account for american.odyssey.105.hdtv-lol.mp4
                        If Len(strSplits(intUpper - 2)) = 3 Then

                            strSplits(intUpper - 2) = "0" & strSplits(intUpper - 2)
                        End If

                        ' Add S and E
                        strSplits(intUpper - 2) = "S" & Mid(strSplits(intUpper - 2), 1, 2) & "E" & Mid(strSplits(intUpper - 2), 3)

                        For intCount = 0 To intUpper - 3

                            intLengthBeforeSofSeason = intLengthBeforeSofSeason + Len(strSplits(intCount)) + 1
                        Next

                        For intCount = 0 To intUpper - 1

                            If intCount = intUpper - 1 Then

                                '  hdtv-lol - ignore

                            ElseIf intCount = intUpper - 2 Then

                                strNewName = strNewName & strSplits(intCount) & " "
                            Else

                                strNewName = strNewName & ToProperCase(strSplits(intCount), False) & " "
                            End If
                        Next

                        strNewName = Trim(strNewName) & "." & strSplits(intUpper).ToLower

                        My.Computer.FileSystem.RenameFile(strFullPath, strNewName)

                        d.Refresh()

                        intSPos = intLengthBeforeSofSeason + 1
                        intEPos = intSPos + 3
                    Else

                        TryToGetUsingHDTVLOLFormat = False
                    End If
                End If
            End If
        End If

    End Function

    Private Function TryToGetUsingX_Y(ByVal strName As String, ByRef intSPos As Integer, ByRef intEPos As Integer, _
                                       ByRef strSeriesName As String, ByVal strMiddleString As String) As Boolean

        Dim strSplits() As String, intCount As Integer
        Dim strLeft As String, strRight As String, intCount2 As Integer

        strName = RemovePrefix(strName).Replace(".", " ").Trim
        strName = strName.Replace("_", " ")

        strSplits = strName.Split(" ")

        For intCount = 0 To UBound(strSplits)

            strSplits(intCount) = strSplits(intCount).Trim
        Next

        Try

            If intCount > 1 Then

                For intCount = 1 To UBound(strSplits) - 1

                    If strSplits(intCount).Trim <> "" Then

                        If IsMiddleString(strSplits(intCount), strMiddleString) Then

                            strLeft = GetTextUntil1stNonNumeric(strSplits(intCount))
                            strRight = GetTextfromEndTo1stNonNumeric(strSplits(intCount))

                            If IsNumeric(strLeft) And IsNumeric(strRight) Then

                                strSeriesName = ""

                                For intCount2 = 0 To intCount - 1

                                    strSeriesName = strSeriesName & strSplits(intCount2) & " "
                                Next

                                strSeriesName = Trim(strSeriesName)

                                intSPos = strLeft
                                intEPos = strRight
                                Return True

                            End If
                        End If
                    End If
                Next

            End If

        Catch ex As Exception

            intSPos = 0
            intEPos = 0

        End Try

    End Function

    Public Function IsTV_ByFolderName(ByRef d As DirectoryInfo, ByRef objFile As FileInfo, ByRef strSeriesName As String, ByRef strSeason As String, ByRef strEpisode As String) As Boolean

        Dim strFolderName As String, blnResult As Boolean
        Dim intSPos As Integer, intEPos As Integer, strPrefix As String
        Dim strNewSeason As String

        ' If it's the root folder I can't for anything so exit with a False.
        If d.FullName = mobjOptions.RootFolder Then

            Return False
        End If

        strFolderName = d.Name

        TryToFindname_By_Usual_Format_S01E01(strFolderName, intSPos, intEPos)

        If intSPos > 0 And intEPos > 0 Then

            blnResult = GetDetailsUsing_SposEpos(strSeriesName, d.Name, intSPos, intEPos, strSeason, objFile.Name, strEpisode, False)

            If blnResult Then

                strPrefix = GetPrefixwithDot(objFile.Name)

                strNewSeason = strSeason.Replace("Season ", "")

                If Len(strNewSeason) = 1 Then

                    strNewSeason = "S0" & strNewSeason
                Else

                    strNewSeason = "S" & strNewSeason
                End If

                objFile.MoveTo(objFile.Directory.FullName & "\" & strSeriesName & " " & strNewSeason & strEpisode & strPrefix.ToLower)
                objFile.Refresh()
            End If
        End If

        IsTV_ByFolderName = blnResult

    End Function


    Public Function IsTV_ByFilename(ByRef d As DirectoryInfo, ByRef objFile As FileInfo, ByRef strSeriesName As String, ByRef strSeason As String, ByRef strEpisode As String) As Boolean

        Dim intSPos As Integer, intEPos As Integer
        Dim strName As String
        Dim blnTryToGetUsingXofY As Boolean, blnTryToGetUsingXxY As Boolean

        blnTryToGetUsingXofY = False
        blnTryToGetUsingXxY = False

        strSeason = ""
        strEpisode = ""
        strSeriesName = ""

        strSeriesName = ToProperCase(GetSeriesName(objFile.Name), False)
        strName = objFile.Name.ToUpper

        TryToFindname_By_Usual_Format_S01E01(strName, intSPos, intEPos)

        ' Unable to find in S01E05 format
        ' try Doctor.Who.2005.7x12.Nightmare.In.Silver.HDTV.XviD-AFG
        ' or BBC.Precision.The.Measure.of.All.Things.2of3.Mass.and.Moles.PDTV.x264.AAC.MVGroup.org

        ' If its 7x12 thats Season 7 Episode 12
        ' If its 2of3 thats Season 1 Episode 2
        If intSPos = 0 And intEPos = 0 Then

            blnTryToGetUsingXxY = TryToGetUsingX_Y(objFile.Name, intSPos, intEPos, strSeriesName, "X")
        End If

        If intSPos = 0 And intEPos = 0 Then

            blnTryToGetUsingXofY = TryToGetUsingX_Y(objFile.Name, intSPos, intEPos, strSeriesName, "OF")

            If blnTryToGetUsingXofY Then

                strEpisode = intSPos
                strSeason = "Season 1"

                Return True
            End If
        End If

        ' Finally try to detect a castle.2009.722.hdtv-lol.mp4 format 
        If intSPos = 0 And intEPos = 0 Then

            TryToGetUsingHDTVLOLFormat(d, objFile.Name, objFile.FullName, intSPos, intEPos, strSeriesName)
        End If

        If intSPos = 0 Then

            ' Last chance saloon - is the start of the filename the channel name?
            If IsNamedAfterChannel(objFile.Name, strSeriesName) Then

                Return True
            Else

                Return False
            End If

        End If

        If intEPos = 0 Then

            Return GetDetailsUsing_Epos(strSeriesName, strName, intSPos, intEPos, strSeason, objFile.Name)

        Else

            Return GetDetailsUsing_SposEpos(strSeriesName, strName, intSPos, intEPos, strSeason, objFile.Name, strEpisode, blnTryToGetUsingXxY)

        End If

        Return False

    End Function

    Private Function GetDetailsUsing_SposEpos(ByRef strSeriesName As String, ByRef strName As String, ByRef intSPos As Integer, ByRef intEPos As Integer, _
                                              ByRef strSeason As String, ByRef strObjFile_Fullname As String, ByRef strEpisode As String, ByRef blnTryToGetUsingXxY As Boolean) As Boolean

        GetDetailsUsing_SposEpos = False

        If strSeriesName = "" Then

            strSeriesName = ToProperCase(CleanupFolderName(Mid$(strObjFile_Fullname, 1, intSPos - 1)), False)
        End If

        If Not blnTryToGetUsingXxY Then

            If intEPos > intSPos Then

                strSeason = Mid(strName, intSPos, intEPos - intSPos).Trim
                strSeason = GetFullSeasonName(strObjFile_Fullname, strSeason)
            End If

            strEpisode = Mid(strName, intEPos)

            strEpisode = RemoveTextFrom1StNonNumericAtPosition(strEpisode, 2)
        Else

            strSeason = "Season " & intSPos
            strEpisode = intEPos
        End If

        GetDetailsUsing_SposEpos = True

    End Function

    Private Function GetDetailsUsing_Epos(ByRef strSeriesName As String, ByRef strName As String, ByRef intSPos As Integer, ByRef intEPos As Integer, _
                                          ByRef strSeason As String, ByRef strObjFile_Fullname As String) As Boolean

        GetDetailsUsing_Epos = False

        If strSeriesName = "" Then

            strSeriesName = ToProperCase(CleanupFolderName(Mid$(strObjFile_Fullname, 1, intSPos - 1)), False)

            If strSeriesName <> "" Then

                strSeriesName = ToProperCase(strSeriesName, False)
            End If
        End If

        intEPos = InStr(intSPos + 1, strName, " ")

        If intEPos = 0 Then

            intEPos = InStr(intSPos + 1, strName, ".")
        End If

        If intEPos > intSPos Then

            strSeason = Mid(strName, intSPos, intEPos - intSPos).Trim
            strSeason = GetFullSeasonName(strObjFile_Fullname, strSeason)
        End If

        GetDetailsUsing_Epos = True

    End Function

    Private Function RemoveDate(ByVal strFileName As String) As String

        Dim intPos As Integer, strDate As String, strSearch As String

        strSearch = " - "

        intPos = InStr(1, strFileName, strSearch)

        If intPos > 0 Then

            strDate = RemovePrefix(Mid(strFileName, intPos + Len(strSearch)))

            If MyIsDate(strDate, "", "") Then

                RemoveDate = Mid(strFileName, 1, intPos - 1).Trim
            End If
        End If

    End Function

    Private Function MoveBook(ByVal objFile As FileInfo, ByRef objMe As frmMain) As Boolean

        Dim strName As String, strBooksRootFolder As String
        Dim strTo As String, colFiles() As FileInfo
        Dim objFileAlreadyThere As FileInfo
        Dim strBefore As String, strNewName As String, strPath As String

        strNewName = GeneralCleanup(objFile.Name)

        strNewName = CleanupBook(strNewName)

        If strNewName <> objFile.Name Then

            strPath = objFile.DirectoryName

            strNewName = strNewName.Replace("  ", " ")

            ' Check that filename difference is not only caps
            If My.Computer.FileSystem.FileExists(strPath & "\" & strNewName) And (objFile.Name.ToUpper <> strNewName.ToUpper) Then

                MessageBox.Show("Trying to rename " & objFile.FullName & " to " & strPath & "\" & strNewName & " but that file already exists! Ending for you to sort it out.")
                End
            End If

            objFile.MoveTo(strPath & "\" & strNewName)
        End If

        strBooksRootFolder = mobjOptions.FullPathBooks & "Assorted Books Collection\"
        strTo = strBooksRootFolder & objFile.Name

        If Not My.Computer.FileSystem.FileExists(strTo) Then

            mobjStats.Add_File(objFile.Extension, BOOK)

            strBefore = objFile.FullName

            My.Computer.FileSystem.MoveFile(objFile.FullName, strTo)

            objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Book - Moving ", objFile.FullName, " to ", strTo)

            Delay(1)

            If Not My.Computer.FileSystem.FileExists(strTo) Then

                MessageBox.Show("MoveBook - Failed to move " & strBefore & " to " & strTo & "! Ending")

                End
            End If
        Else

            UpdateScreen(objMe, "Comparing " & objFile.FullName & " & " & strTo)

            If ExactDuplicateFiles(objFile.Directory, objFile.FullName, strTo, objMe) Then

                mobjStats.Add_File(objFile.Extension, DUP_BOOK)

                objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Book - Extact dup - moving to deleted - ", objFile.FullName)

                MoveToDeleted(objFile)
            Else

                ' If not an exact match - name lower sized file with slight name change so ordering will put them together

                Dim objDir As New DirectoryInfo(GetPath(strTo))

                colFiles = objDir.GetFiles(GetFilename(strTo))

                objFileAlreadyThere = colFiles(0)

                If objFile.Length > objFileAlreadyThere.Length Then

                    MoveFile(strTo, strBooksRootFolder & "\" & ModifyFilename(objFile.Name), objMe, True, BOOK)
                    MoveFile(objFile.FullName, strBooksRootFolder & "\" & objFile.Name, objMe, False)
                Else

                    MoveFile(objFile.FullName, strBooksRootFolder & "\" & "\" & ModifyFilename(objFile.Name), objMe, True, BOOK)
                End If

                objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Book - Non extact dup - moving to deleted - ", objFile.FullName)

                mobjStats.Add_File(objFile.Extension, DUP_BOOK)
            End If

        End If

    End Function

    Private Function PreProcessBook(ByVal objFile As FileInfo, ByRef objMe As frmMain) As Boolean

        Dim strName As String, strRootFolder As String
        Dim strTo As String, colFiles() As FileInfo
        Dim objFileAlreadyThere As FileInfo
        Dim strFilename As String, strBefore As String, strPath As String

        strRootFolder = objFile.DirectoryName.Replace(ROOT_DRIVE & "\_Torrent\Completed\", "")

        If Not GetFolderTargetForPreProcessing(strRootFolder, strRootFolder) Then

            MessageBox.Show("Coding problem in GetFolderTargetForPreProcessing! Not handling type correctly. Ending")
            End
        End If

        FileRenamer_PreprocessPotentialMagazine(objFile)

        ' If Magazine apply extra re-naming 
        If strRootFolder & " - " = PRE_PROCESS_TYPE2 Then

            strFilename = FileRenamer_MagazineCleanup(objFile.Name, objFile.FullName)

            If strFilename <> objFile.Name Then

                strBefore = objFile.FullName

                strPath = GetPath(objFile.FullName)

                ' Sometimes it's just the caps thats different - just do the 'move' in that case
                If strFilename.ToUpper = objFile.Name.ToUpper Then

                    objFile.MoveTo(strPath & strFilename)

                    Delay(1)

                    If Not My.Computer.FileSystem.FileExists(strPath & strFilename) Then

                        MessageBox.Show("PreProcessBook - Failed to move " & vbCrLf & strBefore & " to " & vbCrLf & strPath & strFilename & "! Ending")
                        End
                    End If
                Else

                    If My.Computer.FileSystem.FileExists(strPath & strFilename) Then

                        MessageBox.Show("PreProcessBook - Failed to move " & vbCrLf & strBefore & " to " & vbCrLf & strPath & strFilename & vbCrLf & "! File with that name already exists. Ending")
                        End
                    End If

                    objFile.MoveTo(strPath & strFilename)

                    Delay(1)

                    If Not My.Computer.FileSystem.FileExists(strPath & strFilename) Then

                        MessageBox.Show("PreProcessBook - Failed to move " & vbCrLf & strBefore & " to " & vbCrLf & strPath & strFilename & "! Ending")
                        End
                    End If
                End If
            End If
        End If

        strTo = ROOT_DRIVE & "\_Torrent\Completed\" & strRootFolder & "\" & objFile.Name

        If Not My.Computer.FileSystem.FileExists(strTo) Then

            mobjStats.Add_File(objFile.Extension, BOOK)
            objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "PreprocessBook - Moving ", objFile.FullName, " to ", strTo)

            My.Computer.FileSystem.MoveFile(objFile.FullName, strTo)

            Delay(1)

            If Not My.Computer.FileSystem.FileExists(strTo) Then

                MessageBox.Show("File missing - " & strTo)
                End
            End If
        Else

            UpdateScreen(objMe, "Comparing " & objFile.FullName & " & " & strTo)

            If ExactDuplicateFiles(objFile.Directory, objFile.FullName, strTo, objMe) Then

                objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "PreprocessBook - Moving dup. ", objFile.FullName)

                mobjStats.Add_File(objFile.Extension, DUP_BOOK)

                MoveToDeleted(objFile)
            Else

                ' If not an exact match - name lower sized file with slight name change so ordering will put them together

                Dim objDir As New DirectoryInfo(GetPath(strTo))

                colFiles = objDir.GetFiles(GetFilename(strTo))

                objFileAlreadyThere = colFiles(0)

                If objFile.Length > objFileAlreadyThere.Length Then

                    MoveFile(strTo, ROOT_DRIVE & "\_Torrent\Completed\" & strRootFolder & "\" & ModifyFilename(objFile.Name), objMe, True, BOOK)
                    MoveFile(objFile.FullName, ROOT_DRIVE & "\_Torrent\Completed\" & strRootFolder & "\" & objFile.Name, objMe, False)

                    objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "PreprocessBook - Moving Dup ", objFile.FullName, " to ", strTo)
                Else

                    MoveFile(objFile.FullName, ROOT_DRIVE & "\_Torrent\Completed\" & strRootFolder & "\" & "\" & ModifyFilename(objFile.Name), objMe, True, BOOK)

                    objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "PreprocessBook - Moving Dup ", objFile.FullName, " to ", strTo)
                End If

                mobjStats.Add_File(objFile.Extension, DUP_BOOK)
            End If
        End If

        Delay(1)

    End Function

    Private Function GetFullSeasonName(ByVal strFilename As String, ByVal strSeason As String) As String

        Dim intName As Integer, strSeasonAtStart As String

        strSeasonAtStart = strSeason

        Try

            strSeason = strSeason.Trim
            strSeason = strSeason.Replace(".", "")

            If Len(strSeason) = 7 Then

                If Mid(strSeason, 1, 1) = "S" And Mid(strSeason, 4, 1) = "X" And Mid(strSeason, 5, 1) = "E" And IsNumeric(Mid(strSeason, 2, 2)) And IsNumeric(Mid(strSeason, 6, 2)) Then

                    strSeason = strSeason.Replace("X", "")
                End If
            End If

            If InStr(strSeason, "E") > 0 Then

                strSeason = Mid(strSeason, 1, InStr(strSeason, "E") - 1)
            End If

            If Mid(strSeason, 1, 1) = "S" Then

                intName = Replace(strSeason, "S", "")

                GetFullSeasonName = "Season " & intName
            End If

        Catch ex As Exception

            MessageBox.Show("Procedure - GetFullSeasonName - Filename - " & strFilename & " - strSeasonAtStart - " & strSeasonAtStart & " strSeason - " & strSeason & vbCrLf & ex.Message)
            End
        End Try

    End Function

    Private Function MoveMovieFile(ByVal objFile As FileInfo, ByRef objMe As frmMain) As Boolean

        Dim strMovieRootFolder As String
        Dim strTo As String, colFiles() As FileInfo, strName As String
        Dim objFileAlreadyThere As FileInfo, strModifiedName As String, strBefore As String

        strName = objFile.Name

        'strMovieRootFolder = mobjOptions.FullPathMovies

        'strTo = strMovieRootFolder & strName

        strName = CleanupStandardTVCrapText(strName)

        strTo = BasicCleanupFilename(objFile.DirectoryName & "\" & strName)

        strTo = GetFullMoviesPath() & RemovePath(strTo)

        If Not My.Computer.FileSystem.FileExists(strTo) Then

            mobjStats.Add_File(objFile.Extension, MOVIES)

            strBefore = objFile.FullName

            My.Computer.FileSystem.MoveFile(objFile.FullName, strTo)

            Delay(1)

            If Not My.Computer.FileSystem.FileExists(strTo) Then

                MessageBox.Show("MoveMovieFile - 1 - Failed to move " & strBefore & " to " & strTo & "! Ending")

                End
            End If

            objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Movie - Moving ", objFile.FullName, " to ", strTo)
        Else

            If ExactDuplicateFiles(objFile.Directory, objFile.FullName, strTo, objMe) Then

                mobjStats.Add_File(objFile.Extension, DUP_MOVIES)

                MoveToDeleted(objFile)

                objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Movie - Dup. (extact) ", objFile.FullName)
            Else

                ' If not an exact match - name lower sized file with slight name change so ordering will put them together
                ' Jaws.avi 
                ' Jaws_.avi
                Dim objDir As New DirectoryInfo(GetPath(strTo))

                colFiles = objDir.GetFiles(GetFilename(strTo))

                objFileAlreadyThere = colFiles(0)

                strModifiedName = ModifyFilename(objFile.Name)

                If objFile.Length > objFileAlreadyThere.Length Then

                    MoveFile(strTo, strMovieRootFolder & strModifiedName, objMe, True, MOVIES)

                    Delay(1)

                    If Not My.Computer.FileSystem.FileExists(strMovieRootFolder & strModifiedName) Then

                        MessageBox.Show("MoveMovieFile - 2 - Failed to move " & strTo & " to " & strMovieRootFolder & strModifiedName & "! Ending")

                        End
                    End If

                    strBefore = objFile.FullName

                    MoveFile(strBefore, strMovieRootFolder & objFile.Name, objMe, False)

                    Delay(1)

                    If Not My.Computer.FileSystem.FileExists(strMovieRootFolder & objFile.Name) Then

                        MessageBox.Show("MoveMovieFile - 3 - Failed to move " & strBefore & " to " & strMovieRootFolder & objFile.Name & "! Ending")

                        End
                    End If
                Else

                    strBefore = objFile.FullName

                    MoveFile(strBefore, strMovieRootFolder & strModifiedName, objMe, True, MOVIES)

                    Delay(1)

                    If Not My.Computer.FileSystem.FileExists(strMovieRootFolder & strModifiedName) Then

                        MessageBox.Show("MoveMovieFile - 4 - Failed to move " & strBefore & " to " & strMovieRootFolder & strModifiedName & "! Ending")

                        End
                    End If
                End If

                mobjStats.Add_File(objFile.Extension, DUP_MOVIES)

                objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Movie - Dup. (non exact) ", objFile.FullName, " & ", strMovieRootFolder, strModifiedName)
            End If

        End If

    End Function

    Public Function MoveFolder(ByRef objMe As frmMain, ByRef d As DirectoryInfo, colfiles() As FileInfo, ByVal strType As String, intNumber As Integer,
                               ByRef blnFolderDeleted As Boolean) As Boolean

        Dim strTo As String, objFile As FileInfo, strChars As String
        Dim intCount As Integer
        Dim blnIsUnique As Boolean
        Dim strBefore As String, strNewName As String, strPath As String
        Dim objKeep As DirectoryInfo, objSubs() As DirectoryInfo

        Select Case strType

            Case MOVIES

                DeleteCrapfiles(objMe, d, colfiles, True)

                strTo = mobjOptions.FullPathMovies & CleanupFolderName(d.Name)

                If Not My.Computer.FileSystem.DirectoryExists(strTo) Then

                    mobjStats.Add_File("", MOVIES, intNumber)

                    Try

                        My.Computer.FileSystem.MoveDirectory(d.FullName, strTo)

                    Catch ex As Exception

                        MessageBox.Show("MoveFolder - Movies - " & strTo - " - Ex. - " & ex.Message)
                        End
                    End Try

                Else

                    intCount = 1
                    strChars = Space(intCount).Replace(" ", "_")

                    blnIsUnique = False

                    While blnIsUnique = False

                        If Not My.Computer.FileSystem.DirectoryExists(mobjOptions.FullPathMovies & strChars & d.Name) Then

                            blnIsUnique = True
                        Else

                            intCount = intCount + 1
                            strChars = Space(intCount).Replace(" ", "_")
                        End If

                    End While

                    strTo = mobjOptions.FullPathMovies & strChars & d.Name

                    mobjStats.Add_File("", DUP_MOVIES, intNumber)

                    Try

                        My.Computer.FileSystem.MoveDirectory(d.FullName, strTo)

                    Catch ex As Exception

                        Try

                            My.Computer.FileSystem.MoveDirectory(d.FullName, strTo = mobjOptions.FullPathDeleted & d.Name)

                        Catch ex2 As Exception

                            My.Computer.FileSystem.DeleteDirectory(d.FullName, FileIO.DeleteDirectoryOption.DeleteAllContents)

                        End Try

                    End Try

                End If


            Case BOOKS

                DeleteCrapfiles(objMe, d, colfiles, True)

                ProcessDuplicatedBooks(d)

                If IsDirectoryAnAssortedMagazineDirectory(d) Then

                    For Each objFile In colfiles

                        If Not My.Computer.FileSystem.FileExists(mobjOptions.RootFolder & "\" & objFile.Name) Then

                            strBefore = objFile.FullName

                            My.Computer.FileSystem.MoveFile(strBefore, mobjOptions.RootFolder & "\" & objFile.Name)

                            Delay(1)

                            If Not My.Computer.FileSystem.FileExists(mobjOptions.RootFolder & "\" & objFile.Name) Then

                                MessageBox.Show("MoveMagazine - Failed to move " & strBefore & " to " & mobjOptions.RootFolder & "\" & objFile.Name & "! Ending")

                                End
                            End If
                        Else

                            HandleFilesWithSameName(mobjOptions.RootFolder, objFile, mobjOptions.RootFolder & "\" & objFile.Name)
                        End If
                    Next

                    If d.GetDirectories.Count > 0 Then

                        Dim objResponse As System.Windows.Forms.DialogResult

                        objResponse = MessageBox.Show("Need to manually handle sub dirs within " & vbCrLf & vbCrLf & d.FullName & vbCrLf & vbCrLf & "Click Yes to continue after deleting them or no to quit app.", "Delete sub dirs or stop app.", _
                                        MessageBoxButtons.YesNo)

                        If objResponse = DialogResult.No Then End
                    End If

                    d.Delete()

                ElseIf IsDirectoryTheAssortedBookCollectionDirectory(d) Then

                    ' need to move the books to _Books\Assorted Books Collection

                    If Not My.Computer.FileSystem.DirectoryExists(mobjOptions.FullPathBooks & "Assorted Books Collection\") Then

                        My.Computer.FileSystem.CreateDirectory(mobjOptions.FullPathBooks & "Assorted Books Collection\")
                    End If

                    ' Move to Keep
                    objSubs = d.GetDirectories("Keep")

                    If Not objSubs Is Nothing Then

                        d = objSubs(0)

                        colfiles = d.GetFiles()
                    Else

                        ' Only mess with files in \Keep so no problem
                        blnFolderDeleted = True   ' i'm pretending to have deleted it so it doesn't get deleted later

                        MoveFolder = True
                        Exit Function
                    End If

                    For Each objFile In colfiles

                        If IsBookByFilePrefix(objFile) Then

                            strNewName = GeneralCleanup(objFile.Name)

                            strNewName = CleanupBook(strNewName)

                            If strNewName <> objFile.Name Then

                                strPath = objFile.DirectoryName

                                strNewName = strNewName.Replace("  ", " ")

                                objFile.MoveTo(strPath & "\" & strNewName)
                            End If

                            strTo = mobjOptions.FullPathBooks & "Assorted Books Collection\" & objFile.Name

                            Try

                                objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Moving to " & "_Books\Assorted Books Collection\" & objFile.Name)

                                If Not MoveFile_With_Rename_IfIts_Already_There(objFile.FullName, strTo) Then

                                    MessageBox.Show("MoveFolder - MoveFile_With_Rename_IfIts_Already_There - " & strTo)
                                    End
                                End If

                                Delay(1)

                                If Not My.Computer.FileSystem.FileExists(strTo) Then

                                    MessageBox.Show("MoveFolder - File missing - " & strTo)
                                    End
                                End If

                            Catch ex As Exception

                                MessageBox.Show("MoveFolder - ex.message - " & ex.Message & " File - " & strTo)
                                End
                            End Try
                        End If
                    Next

                    blnFolderDeleted = True   ' i'm pretending to have deleted it so it doesn't get deleted later
                Else

                    strTo = mobjOptions.FullPathBooks & CleanupFolderName(d.Name)

                    If Not My.Computer.FileSystem.DirectoryExists(strTo) Then

                        mobjStats.Add_File("", BOOKS, intNumber)

                        Try

                            My.Computer.FileSystem.MoveDirectory(d.FullName, strTo)

                        Catch ex As Exception

                            MessageBox.Show("Move folder - (1) ex. - " & ex.Message & " Folder - " & d.FullName & " - ending")
                            End
                        End Try

                    Else

                        ' Try an alternative
                        strTo = mobjOptions.FullPathBooks & "_" & d.Name

                        If My.Computer.FileSystem.DirectoryExists(strTo) Then

                            MessageBox.Show("Move folder - Dup folder - " & d.FullName & " and " & strTo & " - ending")
                            End
                        End If

                        mobjStats.Add_File("", DUP_BOOK, intNumber)

                        Try

                            My.Computer.FileSystem.MoveDirectory(d.FullName, strTo)

                        Catch ex As Exception

                            MessageBox.Show("Move folder - (2) ex. - " & ex.Message & " Folder - " & d.FullName & " and " & strTo & " - ending")
                            End
                        End Try

                    End If

                End If

            Case MUSIC

                DeleteCrapfiles(objMe, d, colfiles, True)

                CleanupFilesInAFolder(colfiles)

                d.Refresh()

                strTo = mobjOptions.FullPathMusic & CleanupFolderName(d.FullName.Replace(ROOT_DRIVE & "\_Torrent\Completed\", ""))

                If Not My.Computer.FileSystem.DirectoryExists(strTo) Then

                    mobjStats.Add_File("", MUSIC, intNumber)

                    Try

                        My.Computer.FileSystem.MoveDirectory(d.FullName, strTo)

                    Catch ex As Exception

                        MessageBox.Show("Move folder - (3) ex. - " & ex.Message & " Folder - " & d.FullName & " and " & strTo & " - ending")
                        End

                    End Try

                Else

                    strTo = mobjOptions.FullPathMusic & "_" & d.Name

                    mobjStats.Add_File("", DUP_MUSIC, intNumber)

                    Try

                        My.Computer.FileSystem.MoveDirectory(d.FullName, strTo)

                    Catch ex As Exception

                        MessageBox.Show("Move folder - (3) ex. - " & ex.Message & " Folder - " & d.FullName & " and " & strTo & " - ending")
                        End

                    End Try

                End If

        End Select


    End Function

    Private Sub CleanupFilesInAFolder(ByRef colfiles() As FileInfo)

        Dim objFile As FileInfo, strTo As String

        Try

            For Each objFile In colfiles

                strTo = BasicCleanupFilename(objFile.FullName)

                If strTo <> objFile.FullName Then

                    My.Computer.FileSystem.RenameFile(objFile.FullName, RemovePath(strTo & "_"))
                    My.Computer.FileSystem.RenameFile(strTo & "_", RemovePath(strTo))
                End If

            Next

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name, "strTo - " & strTo)

        End Try

    End Sub

    Private Function MoveTV(ByVal objFile As FileInfo, ByVal strSeriesName As String, ByVal strSeason As String, ByVal strEpisode As String, ByRef objMe As frmMain) As Boolean

        Dim strName As String, strTVRootFolder As String
        Dim strTo As String, colFiles() As FileInfo
        Dim objFileAlreadyThere As FileInfo
        Dim strBefore As String, strNewFileName As String

        Try

            MoveTV = False

            If Not My.Computer.FileSystem.FileExists(objFile.FullName) Then

                Exit Function
            End If

            RemoveReadonlyFromFile(objFile)

            strName = objFile.Name

            strTVRootFolder = GetFullTVPath() & strSeriesName

            CheckFolderExists(strTVRootFolder)

            strTo = GetFullTVPath() & strSeriesName & "\" & strSeason

            CheckFolderExists(strTo)

            strName = CleanupFilenameMaintainingPrefix(strName)
            strName = UppercaseEForEpisode(strName, strSeason)

            strName = Replace(strName, "-", " - ")
            strName = Replace(strName, "  ", " ")
            strName = Replace(strName, "–", "-")

            strName = CleanupStandardTVCrapText(strName)

            strTo = GetFullTVPath() & strSeriesName & "\" & strSeason & "\" & strName

            If Not My.Computer.FileSystem.FileExists(strTo) Then

                mobjStats.Add_File(objFile.Extension, TV)

                strBefore = objFile.FullName

                My.Computer.FileSystem.MoveFile(objFile.FullName, strTo)

                objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "TV - Moving ", objFile.FullName, " to ", strTo)

                Delay(1)

                If Not My.Computer.FileSystem.FileExists(strTo) Then

                    MessageBox.Show("MoveTV - Failed to move " & strBefore & " to " & strTo & "! Ending")

                    End
                End If
            Else

                If ExactDuplicateFiles(objFile.Directory, objFile.FullName, strTo, objMe) Then

                    mobjStats.Add_File(objFile.Extension, DUP_TV)

                    MoveToDeleted(objFile)

                    objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "TV - Dup. (extact) ", objFile.FullName)
                Else

                    ' If not an exact match - name bigger sized file with slight name change so ordering will put them together
                    ' The Big Bang Theory - S07E01.TVTeam.avi     Smaller
                    ' The Big Bang Theory - S07E01.TVTeam_.avi    Bigger
                    Dim objDir As New DirectoryInfo(GetPath(strTo))

                    colFiles = objDir.GetFiles(GetFilename(strTo))

                    objFileAlreadyThere = colFiles(0)

                    If objFile.Length > objFileAlreadyThere.Length Then

                        strBefore = objFile.FullName
                        strNewFileName = strTVRootFolder & "\" & strSeason & "\" & ModifyFilename(strName)

                        If My.Computer.FileSystem.FileExists(strNewFileName) Then

                            MessageBox.Show("MoveTV - Non Exact Duplicate 0 - Failed to rename " & strBefore & " to " & strNewFileName & "! A file with that modified name exists! Ending")

                            End
                        End If

                        MoveFile(objFile.FullName, strNewFileName, objMe, False)

                        Delay(1)

                        If Not My.Computer.FileSystem.FileExists(strNewFileName) Then

                            MessageBox.Show("MoveTV - Non Exact Duplicate 2 - Failed to move " & strBefore & " to " & strNewFileName & "! Ending")

                            End
                        End If
                    Else

                        ' Modify file already there
                        strBefore = objFileAlreadyThere.FullName
                        strNewFileName = objFileAlreadyThere.Directory.FullName & "\" & ModifyFilename(objFileAlreadyThere.Name)

                        If My.Computer.FileSystem.FileExists(strNewFileName) Then

                            MessageBox.Show("MoveTV - Non Exact Duplicate 1 - Failed to rename " & strBefore & " to " & strNewFileName & "! A file with that modified name exists! Ending")

                            End
                        End If

                        MoveFile(objFileAlreadyThere.FullName, strNewFileName, objMe, True, TV)

                        Delay(1)

                        If Not My.Computer.FileSystem.FileExists(strNewFileName) Then

                            MessageBox.Show("MoveTV - Non Exact Duplicate 2 - Failed to move " & strBefore & " to " & strNewFileName & "! Ending")

                            End
                        End If

                        ' Now just move the file
                        strBefore = objFile.FullName
                        strNewFileName = strTVRootFolder & "\" & strSeason & "\" & strName

                        MoveFile(objFile.FullName, strNewFileName, objMe, True, TV)

                        Delay(1)

                        If Not My.Computer.FileSystem.FileExists(strNewFileName) Then

                            MessageBox.Show("MoveTV - Non Exact Duplicate 3 - Failed to move " & strBefore & " to " & strNewFileName & "! Ending")

                            End
                        End If

                    End If

                    mobjStats.Add_File(objFile.Extension, DUP_TV)

                    objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "TV - Dup. (non extact) ", objFile.FullName)
                End If

            End If

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Function

    Private Function MoveMusic(ByVal objFile As FileInfo, ByRef objMe As frmMain) As Boolean

        Dim strMusicRootFolder As String
        Dim strTo As String, colFiles() As FileInfo
        Dim objFileAlreadyThere As FileInfo
        Dim strBefore As String

        Try

            strTo = BasicCleanupFilename(objFile.FullName)

            strTo = mobjOptions.FullPathMusic & RemovePath(strTo)

            If Not My.Computer.FileSystem.FileExists(strTo) Then

                strBefore = objFile.FullName

                mobjStats.Add_File(objFile.Extension, MUSIC)

                My.Computer.FileSystem.MoveFile(strBefore, strTo)

                Delay(1)

                If Not My.Computer.FileSystem.FileExists(strTo) Then

                    MessageBox.Show("MoveMusic - Failed to move " & strBefore & " to " & strTo & "! Ending")

                    End
                End If

                objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Music - Moving ", objFile.FullName, " to ", strTo)
            Else

                If ExactDuplicateFiles(objFile.Directory, objFile.FullName, strTo, objMe) Then

                    mobjStats.Add_File(objFile.Extension, DUP_MUSIC)

                    MoveToDeleted(objFile)

                    objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Music - Dup. (extact) ", objFile.FullName)
                Else

                    ' If not an exact match - name lower sized file with slight name change so ordering will put them together

                    Dim objDir As New DirectoryInfo(GetPath(strTo))

                    colFiles = objDir.GetFiles(GetFilename(strTo))

                    objFileAlreadyThere = colFiles(0)

                    If objFile.Length > objFileAlreadyThere.Length Then

                        MoveFile(strTo, strMusicRootFolder & "\" & "\" & ModifyFilename(objFile.Name), objMe, True, MUSIC)
                        MoveFile(objFile.FullName, strMusicRootFolder & "\" & objFile.Name, objMe, False)
                    Else

                        MoveFile(objFile.FullName, strMusicRootFolder & "\" & "\" & ModifyFilename(objFile.Name), objMe, True, MUSIC)
                    End If

                    objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Music - Dup. (non exact) ", objFile.FullName, " & ", strTo)

                    mobjStats.Add_File(objFile.Extension, DUP_MUSIC)
                End If

            End If

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Function

    Private Function HandleMagazineFilesWithSameName(ByVal objFile As FileInfo, ByRef strTo As String,
                                                     ByRef strMagRootFolder As String, ByRef strYear As String,
                                                     ByRef objMe As frmMain) As Boolean

        Dim colFiles() As FileInfo
        Dim objFileAlreadyThere As FileInfo

        'objMe = DirectCast(objMe, frmMain)

        HandleMagazineFilesWithSameName = False

        Try

            If ExactDuplicateFiles(objFile.Directory, objFile.FullName, strTo, objMe) Then

                mobjStats.Add_File(objFile.Extension, DUP_MAG)

                MoveToDeleted(objFile)

                objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Magazine - Dup. (extact) ", objFile.FullName, " to deleted")
            Else

                ' If not an exact match - name higher sized file with slight name change so ordering will put them together
                ' New Scientist - 9 Sept 2013.pdf 
                ' New Scientist - 9 Sept 2013_.pdf
                Dim objDir As New DirectoryInfo(GetPath(strTo))

                colFiles = objDir.GetFiles(GetFilename(strTo))

                objFileAlreadyThere = colFiles(0)

                If objFile.Length < objFileAlreadyThere.Length Then

                    MoveFile(strTo, strMagRootFolder & "\" & strYear & "\" & ModifyFilename(objFile.Name), objMe, True, MAG)
                    MoveFile(objFile.FullName, strMagRootFolder & "\" & strYear & "\" & objFile.Name, objMe, False)
                Else

                    MoveFile(objFile.FullName, strMagRootFolder & "\" & strYear & "\" & ModifyFilename(objFile.Name), objMe, True, MAG)
                End If

                mobjStats.Add_File(objFile.Extension, DUP_MAG)

                objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Magazine - Dup. (non extact) ", objFile.FullName, " & ", strTo)
            End If

        Catch ex As Exception

            MessageBox.Show("Error in HandleMagazineFilesWithSameName() - " & ex.Message)
            MessageBox.Show("Error in HandleMagazineFilesWithSameName() - Need to sort out!")

            End
        End Try

        HandleMagazineFilesWithSameName = True

    End Function

    Private Function MoveMagazine(ByVal objFile As FileInfo, blnDatePresent As Boolean, ByVal strMonth As String, ByVal strYear As String, ByRef objMe As frmMain) As Boolean

        Dim strName As String, strMagRootFolder As String
        Dim strTo As String
        Dim strBefore As String

        'objMe = DirectCast(objMe, frmMain)

        strName = RemovePath(CleanupMagazineFilename(objFile.Name))

        'strName = FileRenamer_MagazineCleanup(strName)

        strMagRootFolder = mobjOptions.FullPathMags & strName

        If Not blnDatePresent Then

            ' Try to find a match on a recent year
            strYear = TryToMatchOnAYearForAMagazine(objFile.Name)

            If strYear = "" Then strYear = Year(Now)

            strTo = strMagRootFolder & "\" & strYear & "\" & MagazineNameReplacements(objFile.Name)
        Else

            strTo = strMagRootFolder & "\" & strYear & "\" & MagazineNameReplacements(objFile.Name)
        End If

        CheckYearFolderExists(strMagRootFolder, strYear)

        CheckYearFolderExists(mobjOptions.PermMagFolder & "\" & strName, strYear)

        If Not My.Computer.FileSystem.FileExists(strTo) Then

            mobjStats.Add_File(objFile.Extension, MAG)

            strBefore = objFile.FullName

            My.Computer.FileSystem.MoveFile(objFile.FullName, strTo)

            objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Magazine - Moving ", objFile.FullName, " to ", strTo)

            Delay(1)

            If Not My.Computer.FileSystem.FileExists(strTo) Then

                MessageBox.Show("MoveMagazine - Failed to move " & strBefore & " to " & strTo & "! Ending")

                End
            End If
        Else

            If Not HandleMagazineFilesWithSameName(objFile, strTo, strMagRootFolder, strYear, objMe) Then

                ' Need to sort out
                MessageBox.Show("Error in HandleMagazineFilesWithSameName() - Need to sort out!")
                End
            End If
        End If

    End Function

    Public Function MoveFile(strFrom As String, ByVal strTo As String, ByRef objMe As frmMain,
                              Optional blnMaintainStats As Boolean = True, _
                              Optional strKnownType As String = "") As Boolean

        Dim strPath As String, strPrefix As String
        Dim objFile As FileInfo, blnDoubleUnderScores As Boolean
        Dim strSingle As String, blnRandom As Boolean, strBeforeRandom As String, strDouble As String

        Try

            If My.Computer.FileSystem.FileExists(strTo) And InStr(strTo, "_.pdf") Then

                strSingle = strTo

                strTo = strTo.Replace("_.pdf", "__.pdf")

                blnDoubleUnderScores = True

                strDouble = strTo
            End If

            If Not My.Computer.FileSystem.FileExists(strTo) Then

                If blnMaintainStats Then

                    mobjStats.Add_File(RemovePath(strTo), strKnownType)
                End If

                My.Computer.FileSystem.MoveFile(strFrom, strTo)

                Delay(1)

                If Not My.Computer.FileSystem.FileExists(strTo) Then

                    MessageBox.Show("MoveFile - File missing (1) - " & strTo)
                    End
                End If

                objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "MoveFile - ", strFrom, " to ", strTo)
            Else

                ' Just stick same random text on end

                blnRandom = True

                strBeforeRandom = strTo

                strPath = GetPath(strTo)
                strPrefix = GetPrefix(strTo)

                strTo = RemovePrefix(RemovePath(strTo))

                strTo = strPath & strTo & RandomText(10) & "." & strPrefix

                If blnMaintainStats Then

                    mobjStats.Add_File(RemovePath(strTo), strKnownType)
                End If

                My.Computer.FileSystem.MoveFile(strFrom, strTo)

                Delay(1)

                If Not My.Computer.FileSystem.FileExists(strTo) Then

                    MessageBox.Show("MoveFile - File missing (1) - " & strTo)
                    End
                End If

                objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "MoveFile - ", strFrom, " to ", strTo)
            End If

            If blnDoubleUnderScores Then

                objFile = New FileInfo(strTo)

                If ExactDuplicateFiles(objFile.Directory, objFile.FullName, strSingle, objMe) Then

                    My.Computer.FileSystem.DeleteFile(objFile.FullName)
                    blnRandom = False   ' deleted the file so make sure dont check below
                End If
            End If

            If blnRandom Then

                objFile = New FileInfo(strTo)

                If ExactDuplicateFiles(objFile.Directory, objFile.FullName, strDouble, objMe) Then

                    My.Computer.FileSystem.DeleteFile(objFile.FullName)
                End If
            End If

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Function

    Public Sub GetFiletypes(ByRef objFileTypes As clsFileTypes, ByRef colFiles() As FileInfo, Optional ByRef d As DirectoryInfo = Nothing)

        Dim objFile As FileInfo, strPrefix As String

        For Each objFile In colFiles

            strPrefix = objFile.Extension.ToUpper

            Select Case strPrefix

                Case NFO : objFileTypes.NFO = objFileTypes.NFO + 1
                Case DAT : objFileTypes.DAT = objFileTypes.DAT + 1
                Case TXT : objFileTypes.TXT = objFileTypes.TXT + 1
                Case OPF : objFileTypes.OPF = objFileTypes.OPF + 1

                Case JPG, JPEG, PNG, BITMAP, GIF

                    objFileTypes.JPG = objFileTypes.JPG + 1
                    objFileTypes.JPGs = objFileTypes.JPGs & objFile.FullName & UNIQUE_SEP

                Case AVI

                    objFileTypes.AVI = objFileTypes.AVI + 1
                    objFileTypes.AVIs = objFileTypes.AVIs & objFile.FullName & UNIQUE_SEP

                Case MP4

                    objFileTypes.MP4 = objFileTypes.MP4 + 1
                    objFileTypes.MP4s = objFileTypes.MP4s & objFile.FullName & UNIQUE_SEP

                Case WMV

                    objFileTypes.WMV = objFileTypes.WMV + 1
                    objFileTypes.WMVs = objFileTypes.WMVs & objFile.FullName & UNIQUE_SEP

                Case ASF

                    objFileTypes.ASF = objFileTypes.ASF + 1
                    objFileTypes.ASFs = objFileTypes.ASFs & objFile.FullName & UNIQUE_SEP

                Case MKV

                    objFileTypes.MKV = objFileTypes.MKV + 1
                    objFileTypes.MKVs = objFileTypes.MKVs & objFile.FullName & UNIQUE_SEP

                Case M2TS

                    objFileTypes.M2tS = objFileTypes.M2tS + 1
                    objFileTypes.M2TSs = objFileTypes.M2TSs & objFile.FullName & UNIQUE_SEP

                Case FLV

                    objFileTypes.FLV = objFileTypes.FLV + 1
                    objFileTypes.FLVs = objFileTypes.FLVs & objFile.FullName & UNIQUE_SEP

                Case MPEG, MPG

                    objFileTypes.MPEG = objFileTypes.MPEG + 1
                    objFileTypes.MPEGs = objFileTypes.MPEGs & objFile.FullName & UNIQUE_SEP

                Case EPUB

                    objFileTypes.EPUB = objFileTypes.EPUB + 1
                    objFileTypes.EPUBs = objFileTypes.EPUBs & objFile.FullName & UNIQUE_SEP

                Case AZW3

                    objFileTypes.AZW3 = objFileTypes.AZW3 + 1
                    objFileTypes.AZW3s = objFileTypes.AZW3s & objFile.FullName & UNIQUE_SEP

                Case MOBI

                    objFileTypes.MOBI = objFileTypes.MOBI + 1
                    objFileTypes.MOBIs = objFileTypes.MOBIs & objFile.FullName & UNIQUE_SEP

                Case PDF

                    objFileTypes.PDF = objFileTypes.PDF + 1
                    objFileTypes.PDFs = objFileTypes.PDFs & objFile.FullName & UNIQUE_SEP

                Case DJVU

                    objFileTypes.DJVU = objFileTypes.DJVU + 1
                    objFileTypes.DJVUs = objFileTypes.DJVUs & objFile.FullName & UNIQUE_SEP

                Case PRC

                    objFileTypes.PRC = objFileTypes.PRC + 1
                    objFileTypes.PRCs = objFileTypes.PRCs & objFile.FullName & UNIQUE_SEP

                Case SRT

                    objFileTypes.SRT = objFileTypes.SRT + 1
                    objFileTypes.SRTs = objFileTypes.SRTs & objFile.FullName & UNIQUE_SEP

                Case RAR, TGZ

                    objFileTypes.RAR = objFileTypes.RAR + 1
                    objFileTypes.RARs = objFileTypes.RARs & objFile.FullName & UNIQUE_SEP

                Case ArchiveType_7z

                    objFileTypes.Archive_7z = objFileTypes.Archive_7z + 1
                    objFileTypes.Archive_7zs = objFileTypes.Archive_7zs & objFile.FullName & UNIQUE_SEP

                Case MP3, M4A

                    objFileTypes.MP3 = objFileTypes.MP3 + 1
                    objFileTypes.MP3s = objFileTypes.MP3s & objFile.FullName & UNIQUE_SEP

                Case FLAC

                    objFileTypes.FLAC = objFileTypes.FLAC + 1
                    objFileTypes.FLACs = objFileTypes.FLACs & objFile.FullName & UNIQUE_SEP

                Case WAV

                    objFileTypes.WAV = objFileTypes.WAV + 1
                    objFileTypes.WAVs = objFileTypes.WAVs & objFile.FullName & UNIQUE_SEP

                Case AC3

                    objFileTypes.AC3 = objFileTypes.AC3 + 1
                    objFileTypes.AC3s = objFileTypes.AC3s & objFile.FullName & UNIQUE_SEP

                Case ISO

                    objFileTypes.ISO = objFileTypes.ISO + 1
                    objFileTypes.ISOs = objFileTypes.ISOs & objFile.FullName & UNIQUE_SEP

                Case Else

                    objFileTypes.Unknown = objFileTypes.Unknown + 1
                    objFileTypes.Unknowns = objFileTypes.Unknowns & objFile.FullName & UNIQUE_SEP

            End Select

        Next

        If Not d Is Nothing Then BooksWithSubfolder(objFileTypes, d)

        If objFileTypes.PDF > 0 Or objFileTypes.MOBI > 0 Or objFileTypes.EPUB > 0 _
             Or objFileTypes.AZW3 > 0 Or objFileTypes.DJVU > 0 Or objFileTypes.PRC > 0 Then

            CalcUniqueBookCount(objFileTypes)
        End If

    End Sub

    Public Function BooksWithSubfolder(ByRef objFileTypes As clsFileTypes, ByRef objDir As DirectoryInfo) As Boolean

        Dim objSubDir As DirectoryInfo

        objDir.Refresh()

        For Each objSubDir In objDir.GetDirectories()

            Try

                If objSubDir.GetFiles("*" & PDF).Length > 0 Or objSubDir.GetFiles("*" & EPUB).Length > 0 Or _
                   objSubDir.GetFiles("*" & MOBI).Length > 0 Or objSubDir.GetFiles("*" & DJVU).Length > 0 Or _
                   objSubDir.GetFiles("*" & AZW3).Length > 0 Or objSubDir.GetFiles("*" & PRC).Length > 0 Then

                    objFileTypes.BooksWithinSubFolder = True
                    BooksWithSubfolder = True
                    Exit Function
                End If

                If objSubDir.GetDirectories.Length > 0 Then

                    BooksWithSubfolder(objFileTypes, objSubDir)
                End If

            Catch ex As Exception

            End Try
        Next


    End Function

    Private Sub CalcUniqueBookCount(objFileTypes As clsFileTypes)

        Dim intCount As Integer, strBook As String

        If Not objFileTypes.PDFs Is Nothing Then objFileTypes.strPDFBooks = objFileTypes.PDFs.Split(UNIQUE_SEP)
        If Not objFileTypes.MOBIs Is Nothing Then objFileTypes.strMOBIBooks = objFileTypes.MOBIs.Split(UNIQUE_SEP)
        If Not objFileTypes.EPUBs Is Nothing Then objFileTypes.strEPUBBooks = objFileTypes.EPUBs.Split(UNIQUE_SEP)
        If Not objFileTypes.AZW3s Is Nothing Then objFileTypes.strAZW3Books = objFileTypes.AZW3s.Split(UNIQUE_SEP)
        If Not objFileTypes.DJVUs Is Nothing Then objFileTypes.strDJVUBooks = objFileTypes.DJVUs.Split(UNIQUE_SEP)
        If Not objFileTypes.PRCs Is Nothing Then objFileTypes.strPRCBooks = objFileTypes.PRCs.Split(UNIQUE_SEP)

        ' PDFs
        If Not objFileTypes.strPDFBooks Is Nothing Then

            For intCount = objFileTypes.strPDFBooks.GetLowerBound(0) To objFileTypes.strPDFBooks.GetUpperBound(0)

                strBook = Trim(objFileTypes.strPDFBooks(intCount))

                If strBook <> "" Then

                    If Not DoesBookExistInAnotherType(objFileTypes, strBook, False, True, True, True, True, True) Then

                        objFileTypes.UniqueBooksCount = objFileTypes.UniqueBooksCount + 1
                    End If
                End If
            Next
        End If

        ' AZW3s
        If Not objFileTypes.strAZW3Books Is Nothing Then

            For intCount = objFileTypes.strAZW3Books.GetLowerBound(0) To objFileTypes.strAZW3Books.GetUpperBound(0)

                strBook = Trim(objFileTypes.strAZW3Books(intCount))

                If strBook <> "" Then

                    If Not DoesBookExistInAnotherType(objFileTypes, strBook, True, True, True, False, True, True) Then

                        objFileTypes.UniqueBooksCount = objFileTypes.UniqueBooksCount + 1
                    End If
                End If
            Next
        End If

        ' MOBIs
        If Not objFileTypes.strMOBIBooks Is Nothing Then

            For intCount = objFileTypes.strMOBIBooks.GetLowerBound(0) To objFileTypes.strMOBIBooks.GetUpperBound(0)

                strBook = Trim(objFileTypes.strMOBIBooks(intCount))

                If strBook <> "" Then

                    If Not DoesBookExistInAnotherType(objFileTypes, strBook, True, False, True, True, True, True) Then

                        objFileTypes.UniqueBooksCount = objFileTypes.UniqueBooksCount + 1
                    End If
                End If
            Next
        End If

        ' EPUBs
        If Not objFileTypes.strEPUBBooks Is Nothing Then

            For intCount = objFileTypes.strEPUBBooks.GetLowerBound(0) To objFileTypes.strEPUBBooks.GetUpperBound(0)

                strBook = Trim(objFileTypes.strEPUBBooks(intCount))

                If strBook <> "" Then

                    If Not DoesBookExistInAnotherType(objFileTypes, strBook, True, True, False, True, True, True) Then

                        objFileTypes.UniqueBooksCount = objFileTypes.UniqueBooksCount + 1
                    End If
                End If
            Next
        End If

        ' PRCs
        If Not objFileTypes.strPRCBooks Is Nothing Then

            For intCount = objFileTypes.strPRCBooks.GetLowerBound(0) To objFileTypes.strPRCBooks.GetUpperBound(0)

                strBook = Trim(objFileTypes.strPRCBooks(intCount))

                If strBook <> "" Then

                    If Not DoesBookExistInAnotherType(objFileTypes, strBook, True, True, True, True, True, False) Then

                        objFileTypes.UniqueBooksCount = objFileTypes.UniqueBooksCount + 1
                    End If
                End If
            Next
        End If

        ' DJVUs
        If Not objFileTypes.strDJVUBooks Is Nothing Then

            For intCount = objFileTypes.strDJVUBooks.GetLowerBound(0) To objFileTypes.strDJVUBooks.GetUpperBound(0)

                strBook = Trim(objFileTypes.strDJVUBooks(intCount))

                If strBook <> "" Then

                    If Not DoesBookExistInAnotherType(objFileTypes, strBook, True, True, True, True, False, True) Then

                        objFileTypes.UniqueBooksCount = objFileTypes.UniqueBooksCount + 1
                    End If
                End If
            Next
        End If

    End Sub

    Private Function DoesBookExistInAnotherType(ByRef objFileTypes As clsFileTypes, ByVal strBook As String, ByVal blnPDF As Boolean, ByVal blnMOBI As Boolean, ByVal blnEPUB As Boolean, _
                                                ByVal blnAZW3 As Boolean, ByVal blnDJVU As Boolean, ByVal blnPRC As Boolean) As Boolean

        ' PDF
        If blnPDF Then

            If Not objFileTypes.strPDFBooks Is Nothing Then

                For intCount = objFileTypes.strPDFBooks.GetLowerBound(0) To objFileTypes.strPDFBooks.GetUpperBound(0)

                    If Trim(objFileTypes.strPDFBooks(intCount)) <> "" Then

                        If strBook = Trim(objFileTypes.strPDFBooks(intCount)) Then

                            Return True
                            Exit Function
                        End If
                    End If
                Next
            End If
        End If

        ' MOBI
        If blnMOBI Then

            If Not objFileTypes.strMOBIBooks Is Nothing Then

                For intCount = objFileTypes.strMOBIBooks.GetLowerBound(0) To objFileTypes.strMOBIBooks.GetUpperBound(0)

                    If Trim(objFileTypes.strMOBIBooks(intCount)) <> "" Then

                        If RemovePrefix(strBook) = RemovePrefix(Trim(objFileTypes.strMOBIBooks(intCount))) Then

                            Return True
                            Exit Function
                        End If
                    End If
                Next
            End If
        End If

        ' EPUB
        If blnEPUB Then

            If Not objFileTypes.strEPUBBooks Is Nothing Then

                For intCount = objFileTypes.strEPUBBooks.GetLowerBound(0) To objFileTypes.strEPUBBooks.GetUpperBound(0)

                    If Trim(objFileTypes.strEPUBBooks(intCount)) <> "" Then

                        If strBook = Trim(objFileTypes.strEPUBBooks(intCount)) Then

                            Return True
                            Exit Function
                        End If
                    End If
                Next
            End If
        End If

        ' AZW3
        If blnAZW3 Then

            If Not objFileTypes.strAZW3Books Is Nothing Then

                For intCount = objFileTypes.strAZW3Books.GetLowerBound(0) To objFileTypes.strAZW3Books.GetUpperBound(0)

                    If Trim(objFileTypes.strAZW3Books(intCount)) <> "" Then

                        If strBook = Trim(objFileTypes.strAZW3Books(intCount)) Then

                            Return True
                            Exit Function
                        End If
                    End If
                Next
            End If
        End If

        ' DJVU
        If blnDJVU Then

            If Not objFileTypes.strDJVUBooks Is Nothing Then

                For intCount = objFileTypes.strDJVUBooks.GetLowerBound(0) To objFileTypes.strDJVUBooks.GetUpperBound(0)

                    If Trim(objFileTypes.strDJVUBooks(intCount)) <> "" Then

                        If strBook = Trim(objFileTypes.strDJVUBooks(intCount)) Then

                            Return True
                            Exit Function
                        End If
                    End If
                Next
            End If
        End If

        ' PRC
        If blnPRC Then

            If Not objFileTypes.strPRCBooks Is Nothing Then

                For intCount = objFileTypes.strPRCBooks.GetLowerBound(0) To objFileTypes.strPRCBooks.GetUpperBound(0)

                    If Trim(objFileTypes.strPRCBooks(intCount)) <> "" Then

                        If strBook = Trim(objFileTypes.strPRCBooks(intCount)) Then

                            Return True
                            Exit Function
                        End If
                    End If
                Next
            End If
        End If

        Return False

    End Function

    Public Function FilesinDirectoryHaveTVStyleStructure(ByRef d As DirectoryInfo, ByVal blnDoSubDirectory As Boolean) As Boolean

        Dim colFiles() As FileInfo, objFile As FileInfo, objSubDir As DirectoryInfo
        Dim strSeriesName As String, strSeason As String, strEpisode As String
        Dim blnFoundATVFile As Boolean

        blnFoundATVFile = False

        colFiles = d.GetFiles()

        For Each objFile In colFiles

            If IsTV_ByFilename(d, objFile, strSeriesName, strSeason, strEpisode) Then

                blnFoundATVFile = True
            End If
        Next

        If blnDoSubDirectory Then

            Try

                For Each objSubDir In d.GetDirectories

                    blnDoSubDirectory = objSubDir.GetDirectories.Length > 0

                    If FilesinDirectoryHaveTVStyleStructure(objSubDir, blnDoSubDirectory) Then

                        blnFoundATVFile = True
                    End If
                Next

            Catch DirectoryNotFoundException As Exception

                blnDoSubDirectory = blnDoSubDirectory
            End Try
        End If

        FilesinDirectoryHaveTVStyleStructure = blnFoundATVFile

    End Function

    Public Sub ProcessFolder(ByRef objMe As frmMain, ByRef d As DirectoryInfo, ByVal blnDoSubDirectory As Boolean)

        Dim objFile As FileInfo, objFileTypes As New clsFileTypes
        Dim colFiles() As FileInfo
        Dim objSubDir As DirectoryInfo, blnSubFolders As Boolean
        Dim blnFolderDeleted As Boolean

        blnFolderDeleted = False

        d.Refresh()

        colFiles = d.GetFiles()

        GetFiletypes(objFileTypes, colFiles, d)

        ' Music
        If objFileTypes.UniqueMusicCount > 0 Then

            ProcessFLACFiles(d, colFiles, objMe, True)

            DeleteAnyPictures(d, blnDoSubDirectory)
            DeleteCrapfiles(objMe, d, colFiles, True)

            ' Refresh
            d.Refresh()
            colFiles = d.GetFiles

            GetFiletypes(objFileTypes, colFiles, d)

            MoveFolder(objMe, d, colFiles, MUSIC, objFileTypes.UniqueMusicCount, False)

        ElseIf objFileTypes.MovieFilesCount > 1 Then

            DeleteAnyPictures(d, blnDoSubDirectory)
            DeleteCrapfiles(objMe, d, colFiles, True)

            If FilesinDirectoryHaveTVStyleStructure(d, True) Then

                colFiles = d.GetFiles()

                For Each objFile In colFiles

                    ProcessFile(d, objFile, objMe)
                Next
            Else

                MoveFolder(objMe, d, colFiles, MOVIES, colFiles.Length, False)
            End If

            blnDoSubDirectory = False

        ElseIf objFileTypes.MovieFilesCount = 1 Then

            ' Movie or TV

            For Each objFile In colFiles

                ProcessFile(d, objFile, objMe)
            Next

            Try

                My.Application.DoEvents()

                Delay(1)

                d.Refresh()

                Delay(1)

                My.Application.DoEvents()

                If d.Exists Then

                    If d.GetFiles.Count = 0 And d.GetDirectories.Count = 0 Then

                        d.Delete()
                        blnDoSubDirectory = False
                        blnFolderDeleted = True
                    End If
                Else

                    ' Empty folder already deleted in ProcessFile above
                    Exit Sub
                End If

            Catch MissingDirex As DirectoryNotFoundException

                ' Do Nothing
                blnDoSubDirectory = False
                blnFolderDeleted = True

            Catch ex As Exception

                DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name & " - General Ex.", d.ToString)

                blnDoSubDirectory = False
                blnFolderDeleted = True

            End Try

        ElseIf objFileTypes.UniqueBooksCount > 1 Or objFileTypes.BooksWithinSubFolder Then

            ' Move Folders with multiple books to maintain folder stucture
            ' except for the assorted mag bundles - move into completed folder and ProcessFile will handle them as magazines
            ' and except for assorted books collection - move to \books\assorted books collection with dup check
            MoveFolder(objMe, d, colFiles, BOOKS, objFileTypes.UniqueBooksCount, blnFolderDeleted)

            blnDoSubDirectory = False
        Else

            If d.Name = ASSORTED_BOOKS_COLLECTION Then Exit Sub ' If there's no files

            For Each objFile In colFiles

                ProcessFile(d, objFile, objMe)
            Next
        End If

        If blnDoSubDirectory Then

            Try

                If d.Name = ASSORTED_BOOKS_COLLECTION Then Exit Sub

                Delay(1)

                My.Application.DoEvents()

                Delay(1)

                d.Refresh()

                My.Application.DoEvents()

                If d.Exists Then

                    For Each objSubDir In d.GetDirectories

                        blnSubFolders = objSubDir.GetDirectories.Length > 0

                        ProcessFolder(objMe, objSubDir, blnSubFolders)
                    Next
                End If

            Catch DirectoryNotFoundException As Exception

            End Try
        End If

        If Not blnFolderDeleted = True Then

            Try

                d.Refresh()

                If d.Exists Then

                    If d.GetFiles.Count = 0 And d.GetDirectories.Count = 0 Then

                        d.Delete()
                    End If
                End If

            Catch ex As Exception

            End Try
        End If

    End Sub

    Public Sub PreProcessFolder(ByRef objMe As frmMain, ByRef d As DirectoryInfo)

        Dim objFile As FileInfo, objFileTypes As New clsFileTypes
        Dim colFiles() As FileInfo, colDirs() As DirectoryInfo
        Dim objSource As DirectoryInfo
        Dim blnFolderDeleted As Boolean

        blnFolderDeleted = False

        For Each objFile In d.GetFiles()

            If objFile.Name = "Please Consider Making A Donation - Thank You!.txt" Then

                objFile.Delete()
            End If

            If objFile.Name = "Consider Making A Donation.txt" Then

                objFile.Delete()
            End If

            If objFile.Name = "MORE BOOKS AND MAGAZINES.docx" Then

                objFile.Delete()
            End If

            If objFile.Name = "Donate - Help Me Keep Uploading.txt" Then

                objFile.Delete()
            End If

            If objFile.Name = "Join Our New Telegram Channel.txt" Then

                objFile.Delete()
            End If

            If objFile.Name = "Donate Via Bitcoin QR Code.jpg" Then

                objFile.Delete()
            End If

            If objFile.Name = "Donate Via Paypal QR Code.png" Then

                objFile.Delete()
            End If

            If GetPrefixWithToUpper(objFile.Name) = "DAT" Then

                objFile.Delete()
            End If

            If objFile.Name = "1. Read me first!.txt" Then

                objFile.Delete()
            End If
        Next

        d.Refresh()

        colFiles = d.GetFiles()

        GetFiletypes(objFileTypes, colFiles, d)

        If objFileTypes.BooksWithinSubFolder Then

            ' Keep these by moving to root
            If My.Computer.FileSystem.DirectoryExists(d.FullName & "\Books") Then

                objSource = New DirectoryInfo(d.FullName & "\Books")

                MoveFilesInFolderToAnotherFolder(objSource, d, objMe)

                objSource = Nothing

                d.Refresh()
            End If

            If My.Computer.FileSystem.DirectoryExists(d.FullName & "\Magazines") Then

                objSource = New DirectoryInfo(d.FullName & "\Magazines")

                MoveFilesInFolderToAnotherFolder(objSource, d, objMe)

                objSource = Nothing

                d.Refresh()
            End If

            ' Now some have Language subfolders - ENG - so Keep
            If My.Computer.FileSystem.DirectoryExists(d.FullName & "\ENG\Magazines") Then

                objSource = New DirectoryInfo(d.FullName & "\ENG\Magazines")

                MoveFilesInFolderToAnotherFolder(objSource, d, objMe)

                objSource = Nothing

                d.Refresh()
            End If

            ' Now some have Language subfolders - DEU - so Delete
            If My.Computer.FileSystem.DirectoryExists(d.FullName & "\DEU\Magazines") Then

                My.Computer.FileSystem.DeleteDirectory(d.FullName & "\DEU\Magazines", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin, FileIO.UICancelOption.ThrowException)

                d.Refresh()
            End If

            If My.Computer.FileSystem.DirectoryExists(d.FullName & "\FRA\Magazines") Then

                My.Computer.FileSystem.DeleteDirectory(d.FullName & "\FRA\Magazines", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin, FileIO.UICancelOption.ThrowException)

                d.Refresh()
            End If

            If My.Computer.FileSystem.DirectoryExists(d.FullName & "\ITA\Magazines") Then

                My.Computer.FileSystem.DeleteDirectory(d.FullName & "\ITA\Magazines", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin, FileIO.UICancelOption.ThrowException)

                d.Refresh()
            End If
        End If

        If My.Computer.FileSystem.DirectoryExists(d.FullName & "\Covers") Then

            Try

                My.Computer.FileSystem.DeleteDirectory(d.FullName & "\Covers", FileIO.DeleteDirectoryOption.DeleteAllContents)

            Catch ex As Exception

                If InStr(ex.Message, "Could not find a part of the path ") > 0 Then

                    MessageBox.Show("One or more files in " & vbCrLf & vbCrLf & d.FullName & "\Covers" & vbCrLf & vbCrLf & " have a length that's too big! Ending process for a manual check")
                Else

                    MessageBox.Show("Files in " & vbCrLf & vbCrLf & d.FullName & "\Covers" & vbCrLf & vbCrLf & " may be set to read only! Ending process for a manual check")
                End If

                End
            End Try
        End If

        d.Refresh()

        colFiles = d.GetFiles()

        For Each objFile In colFiles

            If IsBookByFilePrefix(objFile) Then

                Debug.Print(objFile.FullName)

                PreProcessBook(objFile, objMe)
            End If

            If objFile.Name = "Please Consider Making A Donation.txt" Or objFile.Name = "QR Code For Donations.jpg" Then

                My.Computer.FileSystem.DeleteFile(objFile.FullName, FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.DeletePermanently)
            End If
        Next

        Delay(1)
        My.Application.DoEvents()

        d.Refresh()

        If d.Exists Then

            colFiles = d.GetFiles()
            colDirs = d.GetDirectories()

            If colDirs.Count = 0 And colFiles.Count = 0 Then

                d.Delete()
            End If
        End If

    End Sub

    Public Sub HandleArchiveFolder(ByVal d As DirectoryInfo, ByVal strFile As String, ByRef objMe As frmMain)

        Dim strCommand As String, strPrefix As String

        strFile = Replace(strFile, UNIQUE_SEP, "")
        strPrefix = GetPrefixwithDot(strFile)

        If Not My.Computer.FileSystem.FileExists(strFile) Then

            Exit Sub
        End If

        If strPrefix = RAR Or strPrefix = ArchiveType_7z Or strPrefix = TGZ Then

            strCommand = ROOT_DRIVE & "\program files\winrar\winrar.exe e -O+ """ & strFile & """ """ & GetPath(strFile) & """"

        ElseIf strPrefix = ZIP Then

            strCommand = ROOT_DRIVE & "\program files\winzip\wzunzip.exe -d -o- """ & strFile & """ """ & GetPath(strFile) & """"
        End If

        If strCommand <> "" Then

            objMe.txtAudit.Text = String.Concat(objMe.txtAudit.Text, vbCrLf, "Extracing ", strFile, " in ", d.FullName)

            If Shell(strCommand, AppWinStyle.Hide, True) = 0 Then

                If strPrefix = RAR Or strPrefix = TGZ Then

                    DeleteRARFiles(strFile, d)

                ElseIf strPrefix = ZIP Or strPrefix = ArchiveType_7z Then

                    MoveToDeletedUsingPath(strFile)
                End If

            End If

        End If

    End Sub

    ' Public Function ProperisePath(ByVal strPath As String)

    '    strPath = Trim$(strPath)

    '        If Mid$(strPath, Len(strPath), 1) <> "\" Then strPath = strPath & "\"

    '    ProperisePath = strPath

    'End Function

    Public Sub FindMagazineTitles()

        Dim objMags As New DirectoryInfo(mobjOptions.PermMagFolder), objSubDir As DirectoryInfo
        Dim obj_Mags As New DirectoryInfo(GetFullMagsPath), obj_Mags_SubDir As DirectoryInfo

        Try

            MAGAZINE_TITLES = ""

            If Not System.IO.Directory.Exists(mobjOptions.PermMagFolder) Then

                MessageBox.Show(mobjOptions.PermMagFolder & " doesn't exist!")
                Exit Sub
            End If

            For Each objSubDir In objMags.GetDirectories()

                MAGAZINE_TITLES = MAGAZINE_TITLES & objSubDir.Name.ToUpper.Trim & ","

                If objSubDir.Name.ToUpper.IndexOf("&") > -1 Then

                    MAGAZINE_TITLES = MAGAZINE_TITLES & objSubDir.Name.Trim.ToUpper.Replace(" & ", " AND ").Trim & ","
                End If

                If objSubDir.Name.ToUpper.IndexOf("MAGAZINE") > -1 Then

                    MAGAZINE_TITLES = MAGAZINE_TITLES & objSubDir.Name.Trim.ToUpper.Replace("MAGAZINE", "").Trim & ","
                End If
            Next

            For Each obj_Mags_SubDir In obj_Mags.GetDirectories()

                MAGAZINE_TITLES = MAGAZINE_TITLES & obj_Mags_SubDir.Name.ToUpper.Trim & ","

                If obj_Mags_SubDir.Name.ToUpper.IndexOf("&") > -1 Then

                    MAGAZINE_TITLES = MAGAZINE_TITLES & obj_Mags_SubDir.Name.Trim.ToUpper.Replace(" & ", " AND ").Trim & ","
                End If

                If obj_Mags_SubDir.Name.ToUpper.IndexOf("MAGAZINE") > -1 Then

                    MAGAZINE_TITLES = MAGAZINE_TITLES & obj_Mags_SubDir.Name.Trim.ToUpper.Replace("MAGAZINE", "").Trim & ","
                End If
            Next

            MAGAZINE_TITLES_KEEP_PROCESSING = MAGAZINE_TITLES

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Public Sub CopyStructureFolder(ByRef objMe As frmMain, ByRef d As DirectoryInfo, ByVal blnDoSubDirectory As Boolean, _
                                   ByVal strDir As String)

        Dim objFile As FileInfo, objFileTypes As New clsFileTypes
        Dim colFiles() As FileInfo, strTempDir As String
        Dim objSubDir As DirectoryInfo, blnSubFolders As Boolean

        strTempDir = d.FullName.Replace(mobjOptions.RootFolder, strDir)

        My.Computer.FileSystem.CreateDirectory(strTempDir)

        colFiles = d.GetFiles()

        For Each objFile In colFiles

            My.Computer.FileSystem.OpenTextFileWriter(strTempDir & "\" & objFile.Name, False)
        Next

        If blnDoSubDirectory Then

            Try

                For Each objSubDir In d.GetDirectories

                    blnSubFolders = objSubDir.GetDirectories.Length > 0

                    CopyStructureFolder(objMe, objSubDir, blnSubFolders, strDir)
                Next

            Catch DirectoryNotFoundException As Exception

            End Try
        End If

    End Sub

End Module
