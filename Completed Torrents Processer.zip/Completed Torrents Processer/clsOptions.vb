﻿Public Class clsOptions

    Private mstrRootFolder As String    ' Private Property Declaration
    Private mstrMags as String	' Private Property Declaration
    Private mstrBooks as String	' Private Property Declaration
    Private mstrTV as String	' Private Property Declaration
    Private mstrMovies As String    ' Private Property Declaration
    Private mstrProcessed As String    ' Private Property Declaration
    Private mstrMusic As String  ' Private Property Declaration
    Private mstrDeleted As String  ' Private Property Declaration

    Private mstrFullPathBooks As String
    Private mstrFullPathMovies As String
    Private mstrFullPathTV As String
    Private mstrFullPathMags As String
    Private mstrFullPathProcessed As String
    Private mstrFullPathDeleted As String

    Private mstrRunTimeProcessedLocation As String
    Private mstrFullPathMusic As String
    Private mstrPermMagFolder As String

    Private mstrTV_CopyFrom As String
    
    Public Sub LoadOptions()

        Dim objFileStream As System.IO.StreamReader

        If My.Computer.FileSystem.FileExists(My.Application.Info.DirectoryPath & "\CompletedTorrentsProcessor_Options.txt") Then

            objFileStream = My.Computer.FileSystem.OpenTextFileReader(My.Application.Info.DirectoryPath & "\CompletedTorrentsProcessor_Options.txt")

            RootFolder = objFileStream.ReadLine()

            Movies = objFileStream.ReadLine()
            modComTorrProConsts.MOVIES = Movies
            TV = objFileStream.ReadLine()
            modComTorrProConsts.TV = TV
            Books = objFileStream.ReadLine()
            modComTorrProConsts.BOOKS = Books
            Mags = objFileStream.ReadLine()
            modComTorrProConsts.MAGS = Mags
            Processed = objFileStream.ReadLine()
            modComTorrProConsts.PROCESSED = Processed
            Music = objFileStream.ReadLine()
            modComTorrProConsts.MUSIC = Music
            PermMagFolder = objFileStream.ReadLine()

            Deleted = objFileStream.ReadLine()
            modComTorrProConsts.DELETED = Deleted

            objFileStream.Close()
            objFileStream = Nothing
        Else

            RootFolder = ROOT_DRIVE & "\_Torrents\Completed\"

            Movies = "_Movies"
            TV = "_TV"
            Books = "_Books"
            Mags = "_Magazines"
            Music = "_Music"
            Processed = "_Processed"
            Deleted = "_Deleted"

            PermMagFolder = ROOT_DRIVE & "\Books\Mags"

            modComTorrProConsts.MOVIES = Movies
            modComTorrProConsts.TV = TV
            modComTorrProConsts.BOOKS = Books
            modComTorrProConsts.MAGS = Mags
            modComTorrProConsts.PROCESSED = Processed
            modComTorrProConsts.MUSIC = Music
            modComTorrProConsts.DELETED = Deleted
        End If

    End Sub

    Public Sub SaveOptions()

        Dim objFileStreamWriter As System.IO.StreamWriter

        If My.Computer.FileSystem.FileExists(My.Application.Info.DirectoryPath & "\CompletedTorrentsProcessor_Options.txt") Then

            My.Computer.FileSystem.DeleteFile(My.Application.Info.DirectoryPath & "\CompletedTorrentsProcessor_Options.txt")
        End If

        objFileStreamWriter = New System.IO.StreamWriter(My.Application.Info.DirectoryPath & "\CompletedTorrentsProcessor_Options.txt")

        objFileStreamWriter.WriteLine(RootFolder)

        objFileStreamWriter.WriteLine(Movies)
        objFileStreamWriter.WriteLine(TV)
        objFileStreamWriter.WriteLine(Books)
        objFileStreamWriter.WriteLine(Mags)
        objFileStreamWriter.WriteLine(Processed)
        objFileStreamWriter.WriteLine(Music)
        objFileStreamWriter.WriteLine(PermMagFolder)
        objFileStreamWriter.WriteLine(Deleted)

        objFileStreamWriter.Close()
        objFileStreamWriter = Nothing

    End Sub

    Public Property Processed() As String
        Get
            Processed = mstrProcessed
        End Get

        Set(ByVal Value As String)
            Try
                mstrProcessed = Value
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public Property RootFolder() As String
        Get
            RootFolder = mstrRootFolder
        End Get

        Set(ByVal Value As String)
            Try
                mstrRootFolder = Value
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public Property Music() As String
        Get
            Music = mstrMusic
        End Get

        Set(ByVal Value As String)
            Try
                mstrMusic = Value
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public Property Mags() As String
        Get
            Mags = mstrMags
        End Get

        Set(ByVal Value As String)
            Try
                mstrMags = Value
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public Property Books() As String
        Get
            Books = mstrBooks
        End Get

        Set(ByVal Value As String)
            Try
                mstrBooks = Value
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public Property TV() As String
        Get
            TV = mstrTV
        End Get

        Set(ByVal Value As String)
            Try
                mstrTV = Value

            Catch ex As Exception

            End Try
        End Set
    End Property

    Public Property Movies() As String
        Get
            Movies = mstrMovies
        End Get

        Set(ByVal Value As String)
            Try
                mstrMovies = Value
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public Property Deleted() As String
        Get
            Deleted = mstrDeleted
        End Get

        Set(ByVal Value As String)
            Try
                mstrDeleted = Value
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public Property PermMagFolder() As String
        Get
            PermMagFolder = mstrPermMagFolder
        End Get

        Set(ByVal Value As String)
            Try
                mstrPermMagFolder = Value
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public ReadOnly Property FullPathTV() As String
        Get
            FullPathTV = mstrRootFolder & "\" & mstrTV & "\"
        End Get

    End Property

    Public ReadOnly Property FullPathTV_CopyFrom() As String
        Get
            FullPathTV_CopyFrom = mstrRootFolder & "\" & mstrTV & TV_COPY_FROM
        End Get

    End Property

    Public ReadOnly Property FullPathMags() As String
        Get
            FullPathMags = mstrRootFolder & "\" & mstrMags & "\"
        End Get
    End Property

    Public ReadOnly Property FullPathMovies() As String
        Get
            FullPathMovies = mstrRootFolder & "\" & mstrMovies & "\"
        End Get

    End Property

    Public ReadOnly Property FullPathDeleted() As String
        Get
            FullPathDeleted = mstrRootFolder & "\" & mstrDeleted & "\"
        End Get

    End Property

    Public ReadOnly Property FullPathMusic() As String
        Get
            FullPathMusic = mstrRootFolder & "\" & mstrMusic & "\"
        End Get

    End Property

    Public ReadOnly Property FullPathBooks() As String
        Get
            FullPathBooks = mstrRootFolder & "\" & mstrBooks & "\"
        End Get

    End Property

    Public ReadOnly Property FullPathProcessed() As String
        Get
            FullPathProcessed = mstrRootFolder & "\" & mstrProcessed & "\"
        End Get

    End Property

    Public Property RunTimeProcessedLocation() As String
        Get
            RunTimeProcessedLocation = mstrRunTimeProcessedLocation
        End Get

        Set(ByVal Value As String)
            Try
                mstrRunTimeProcessedLocation = Value
            Catch ex As Exception

            End Try
        End Set
    End Property

End Class
