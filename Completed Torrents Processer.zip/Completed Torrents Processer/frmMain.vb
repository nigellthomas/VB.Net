﻿Imports Microsoft.VisualBasic.Compatibility.VB6

Public Class frmMain

    Public mblnFoundURLFILE As Boolean = False

    Private Sub mnuExit_Click(sender As System.Object, e As System.EventArgs) Handles mnuExit.Click

        Me.Close()

        End

    End Sub

    Private Sub mnuOptions_Click(sender As System.Object, e As System.EventArgs) Handles mnuOptions.Click

        frmOptions.ShowDialog()

        frmOptions.Close()

        mobjOptions.LoadOptions()

    End Sub

    Private Sub cmdClose_Click(sender As System.Object, e As System.EventArgs) Handles cmdClose.Click

        Me.Close()

        End

    End Sub

    Private Function CheckFolders(ByVal blnBackup As Boolean) As Boolean

        Try

            ProcessTime = Format(Now, "DD MMM YYYY HHNNSS")

            If Not My.Computer.FileSystem.DirectoryExists(mobjOptions.RootFolder) Then

                If MessageBox.Show("Root Folder Doesn't Exist! Create it?", My.Application.Info.ProductName, MessageBoxButtons.YesNo) = vbYes Then

                    CheckFolderExists(mobjOptions.RootFolder)
                Else

                    Return False
                End If
            End If

            If Not My.Computer.FileSystem.DirectoryExists(RemoveLastCharacter(mobjOptions.FullPathDeleted)) Then

                CheckFolderExists(RemoveLastCharacter(mobjOptions.FullPathDeleted))
            End If

            If Not My.Computer.FileSystem.DirectoryExists(RemoveLastCharacter(mobjOptions.FullPathTV)) Then

                If MessageBox.Show("TV Folder Doesn't Exist! Create it?", My.Application.Info.ProductName, MessageBoxButtons.YesNo) = vbYes Then

                    CheckFolderExists(RemoveLastCharacter(mobjOptions.FullPathTV))
                Else

                    Return False
                End If
            End If

            If Not My.Computer.FileSystem.DirectoryExists(RemoveLastCharacter(mobjOptions.FullPathMovies)) Then

                If MessageBox.Show("Movies Folder Doesn't Exist! Create it?", My.Application.Info.ProductName, MessageBoxButtons.YesNo) = vbYes Then

                    CheckFolderExists(RemoveLastCharacter(mobjOptions.FullPathMovies))
                Else

                    Return False
                End If
            End If

            If Not My.Computer.FileSystem.DirectoryExists(mobjOptions.FullPathMovies & "_Movies") Then

                If MessageBox.Show("The Movies _Movies Folder Doesn't Exist! Create it?", My.Application.Info.ProductName, MessageBoxButtons.YesNo) = vbYes Then

                    CheckFolderExists(mobjOptions.FullPathMovies & "_Movies")
                Else

                    Return False
                End If
            End If

            If Not My.Computer.FileSystem.DirectoryExists(RemoveLastCharacter(mobjOptions.FullPathMusic)) Then

                If MessageBox.Show("Music Folder Doesn't Exist! Create it?", My.Application.Info.ProductName, MessageBoxButtons.YesNo) = vbYes Then

                    CheckFolderExists(mobjOptions.FullPathMusic)
                Else

                    Return False
                End If
            End If

            If Not My.Computer.FileSystem.DirectoryExists(RemoveLastCharacter(mobjOptions.FullPathBooks)) Then

                If MessageBox.Show("Book Folder Doesn't Exist! Create it?", My.Application.Info.ProductName, MessageBoxButtons.YesNo) = vbYes Then

                    CheckFolderExists(RemoveLastCharacter(mobjOptions.FullPathBooks))
                Else

                    Return False
                End If
            End If


            If Not My.Computer.FileSystem.DirectoryExists(RemoveLastCharacter(mobjOptions.FullPathMags)) Then

                If MessageBox.Show("Magazine Folder Doesn't Exist! Create it?", My.Application.Info.ProductName, MessageBoxButtons.YesNo) = vbYes Then

                    CheckFolderExists(RemoveLastCharacter(mobjOptions.FullPathMags))
                Else

                    Return False
                End If
            End If

            If Not My.Computer.FileSystem.DirectoryExists(RemoveLastCharacter(mobjOptions.FullPathProcessed)) Then

                If MessageBox.Show("Processed Folder Doesn't Exist! Create it?", My.Application.Info.ProductName, MessageBoxButtons.YesNo) = vbYes Then

                    CheckFolderExists(RemoveLastCharacter(mobjOptions.FullPathProcessed))
                Else

                    Return False
                End If
            End If

            If blnBackup Then

                mobjOptions.RunTimeProcessedLocation = mobjOptions.FullPathProcessed & ProcessTime

                CheckFolderExists(mobjOptions.RunTimeProcessedLocation)
            End If

            Return True

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Function

    Private Sub DisplayButtons(ByVal blnEnable As Boolean)

        cmdProcess.Enabled = blnEnable
        cmdProcessTV.Enabled = blnEnable
        cmdMoveTV.Enabled = blnEnable
        cboDrives.Enabled = blnEnable
        cmdMoveMags.Enabled = blnEnable
        cmdCopyStructure.Enabled = blnEnable
        cmdProcessCopiedStruct.Enabled = blnEnable
        cmdProcessCopiedStruct.Enabled = blnEnable
        cmdPreProcess.Enabled = blnEnable
        cmdMoveTVWithDelay.Enabled = blnEnable
        cboTimes.Enabled = blnEnable
        cmdProcessMags.Enabled = blnEnable

        cmdPostProcess.Enabled = blnEnable
        cmdRemovePageZero.Enabled = blnEnable

        cboDrives.Enabled = blnEnable

        Me.Refresh()

    End Sub

    Private Sub cmdProcess_Click(sender As System.Object, e As System.EventArgs) Handles cmdProcess.Click

        Dim blnBackup As Boolean

        txtAudit.Text = ""
        mblnFoundURLFILE = False

        'MessageBox.Show("If Magazine Monitor is running Suspend Monitoring now!" & vbCrLf & vbCrLf & "When running it conflicts with the Process!")

        Me.Cursor = Cursors.WaitCursor
        DisplayButtons(False)

        mobjStats.Reset()

        'strCompletedPath = New DirectoryInfo("D:\temp\11 Feb 2016 11_07")

        'MessageBox.Show("I'm losing files!, Don't use without fixing.")
        'End

        blnBackup = False

        RemoveMarkingsFromDeletedFolders()

        If AssortedDirectoryPresent() Then

            If MessageBox.Show(String.Concat("Have you manually done all the Assorted Magazines Bundles folders? ", vbCrLf, vbCrLf,
                               "Click No to stop the process."), My.Application.Info.ProductName, _
                               MessageBoxButtons.YesNo, MessageBoxIcon.Question) = System.Windows.Forms.DialogResult.No Then

                Me.Cursor = Cursors.Default
                DisplayButtons(True)
                Exit Sub
            End If
        End If

        If cmdShowAudit.Text = ">>" Then

            cmdShowAudit_Click(Nothing, Nothing)

            My.Application.DoEvents()
        End If

        If Not CheckFolders(blnBackup) Then

            Me.Cursor = Cursors.Default
            DisplayButtons(True)

            Exit Sub
        End If

        If Not ProcessFiles(blnBackup) Then

            UpdateScreen(Me, "")

            Me.Cursor = Cursors.Default
            DisplayButtons(True)

            Exit Sub
        End If

        If Not ProcessFolders(blnBackup) Then

            UpdateScreen(Me, "")

            Me.Cursor = Cursors.Default
            DisplayButtons(True)
            Exit Sub
        End If

        ' Call ProcessFiles a second time - this is because
        ' it will handle any assorted bundle magazines that have been moved into the 
        ' completed folder by ProcessFolders

        txtAudit.Text = String.Concat(txtAudit.Text, vbCrLf, "Calling processfiles a second time")

        If Not ProcessFiles(blnBackup) Then

            UpdateScreen(Me, "")

            Me.Cursor = Cursors.Default
            DisplayButtons(True)

            Exit Sub
        End If

        PostProcessMagFolders(Me)

        ProcessDeletedFolders()

        MessageBox.Show("Need to continue with ProcessSlightlyMangledFoldersInMagazines() & ProcessSlightlyMangledFoldersInTV() Commented out ATM")
        'ProcessSlightlyMangledFoldersInMagazines()

        'ProcessSlightlyMangledFoldersInTV()

        UpdateScreen(Me, "Done!")

        Me.Cursor = Cursors.Default
        DisplayButtons(True)

        PlaySound(ROOT_DRIVE & "\VB.Net\My Projects\_Sounds\transference_complete.wav")

        If mblnFoundURLFILE = True Then

            MessageBox.Show("Internet shortcut file(s) found - Needs manual handling...!")
        End If

    End Sub

    Private Function ProcessSlightlyMangledFoldersInMagazines() As Boolean

        Dim objDir As DirectoryInfo, objSubDir As DirectoryInfo

        ProcessSlightlyMangledFoldersInMagazines = False

        objDir = New DirectoryInfo(mobjOptions.RootFolder & "\" & MAGS)

        For Each objSubDir In objDir.GetDirectories()

            If NeedsAdjusting(objSubDir.Name) Then

                AdjustFolder(objSubDir.FullName)
            End If
        Next

        ProcessSlightlyMangledFoldersInMagazines = True

    End Function

    Private Function AdjustFolder(ByVal strFullName As String) As Boolean

        Dim intPos As Integer, strUnadjustedName As String, strAdjustedName As String
        Dim strPath As String
        Dim objSource As DirectoryInfo, objDest As DirectoryInfo

        AdjustFolder = False

        strUnadjustedName = GetLastLevel(strFullName)
        strPath = strFullName.Replace(strUnadjustedName, "")

        If InStr(strUnadjustedName, " And ") > 0 Then

            strAdjustedName = strUnadjustedName.Replace(" And ", " & ")

            If Not My.Computer.FileSystem.DirectoryExists(strPath & strAdjustedName) Then

                My.Computer.FileSystem.CreateDirectory(strPath & strAdjustedName)
            End If

            objSource = New DirectoryInfo(strFullName)
            objDest = New DirectoryInfo(strPath & strAdjustedName)

            If Not MoveFolderAndSubFoldersContents_WithDupCheck(objSource, objDest, " And ", " & ", Me) Then

                MessageBox.Show("Error with MoveFolderAndSubFoldersContents_WithDupCheck - ", objSource.Name & " And to & ")
                Exit Function
            End If
        End If





        AdjustFolder = True

    End Function

    Public Function MoveFolderAndSubFoldersContents_WithDupCheck(ByRef objSource As DirectoryInfo, ByRef objDest As DirectoryInfo,
                                                                 strFind As String, strReplace As String,
                                                                 ByRef objMe As frmMain) As Boolean

        Dim colFiles() As FileInfo, objFile As FileInfo
        Dim strSourcePath As String, strDestPath As String
        Dim objDestSubFolder As DirectoryInfo
        Dim strAdjustedName As String, strTo As String

        colFiles = objSource.GetFiles

        strSourcePath = objSource.FullName & "\"
        strDestPath = objDest.FullName & "\"

        For Each objFile In colFiles

            strAdjustedName = objFile.Name.Replace(strFind, strReplace)

            strTo = strDestPath & strAdjustedName

            If Not My.Computer.FileSystem.FileExists(strTo) Then

                Try
                    Me.txtAudit.Text = String.Concat(Me.txtAudit.Text, vbCrLf, "Moving - ", objFile.FullName.Replace(ROOT_DRIVE & "\_Torrent\Completed\", ""), " to ", strTo.Replace(ROOT_DRIVE & "\_Torrent\Completed\", ""))

                    My.Computer.FileSystem.MoveFile(objFile.FullName, strTo)

                    Delay(1)

                    If Not My.Computer.FileSystem.FileExists(strTo) Then

                        MessageBox.Show("MoveFolderAndSubFoldersContents_WithDupCheck - File missing (1) - " & strFind & " - " & strReplace & " - " & strTo)
                        End
                    End If

                Catch ex As Exception

                    MessageBox.Show("MoveFolderAndSubFoldersContents_WithDupCheck - File missing (2) - " & strFind & " - " & strReplace & " - " & strTo & "Ex. - " & ex.Message)
                    End
                End Try
            Else

                ' Dup Found

                Me.txtAudit.Text = String.Concat(Me.txtAudit.Text, vbCrLf, "Moving - ", objFile.FullName.Replace(ROOT_DRIVE & "\_Torrent\Completed\", ""), " to ", strTo.Replace(ROOT_DRIVE & "\_Torrent\Completed\", ""))

                If Not MoveFile_With_Rename_IfIts_Already_There(objFile.FullName, strTo) Then

                    MessageBox.Show("MoveFolderAndSubFoldersContents_WithDupCheck - File missing (3) - " & strFind & " - " & strReplace & " - " & strTo)
                    End
                End If

                Delay(1)

                If Not My.Computer.FileSystem.FileExists(strTo) Then

                    MessageBox.Show("MoveFolderAndSubFoldersContents_WithDupCheck - File missing (4) - " & strFind & " - " & strReplace & " - " & strTo)
                    End
                End If

            End If
        Next

        For Each objSubDir In objSource.GetDirectories

            If Not My.Computer.FileSystem.DirectoryExists(strDestPath & objSubDir.Name) Then

                My.Computer.FileSystem.CreateDirectory(strDestPath & objSubDir.Name)
            End If

            objDestSubFolder = New DirectoryInfo(strDestPath & objSubDir.Name)

            MoveFolderAndSubFoldersContents_WithDupCheck(objSubDir, objDestSubFolder, strFind, strReplace, objMe)
        Next

        If objSource.GetFiles().Count = 0 And objSource.GetDirectories().Count = 0 Then

            objSource.Delete()
        End If

        MoveFolderAndSubFoldersContents_WithDupCheck = True

    End Function

    Private Function NeedsAdjusting(ByVal strSubDir As String) As Boolean

        Dim intPos As Integer, strPart As String

        NeedsAdjusting = False

        If InStr(strSubDir, " And ") > 0 Then

            NeedsAdjusting = True
            Exit Function
        End If

        If InStr(strSubDir, " Amp ") > 0 Then

            NeedsAdjusting = True
            Exit Function
        End If

        intPos = InStr(strSubDir, " No ")

        If intPos > 0 Then

            strPart = Mid(strSubDir, intPos).Trim

            If IsNumeric(strPart) Then

                NeedsAdjusting = True
                Exit Function
            End If
        End If

    End Function

    Private Function ProcessSlightlyMangledFoldersInTV() As Boolean



    End Function

    Public Sub RemoveMarkingsFromDeletedFolders()

        Dim objDir As DirectoryInfo

        objDir = New DirectoryInfo(mobjOptions.RootFolder & "\" & DELETED)

        Me.Text = String.Concat(My.Application.Info.ProductName, " - Removing Size from deleted folders")

        RemoveSizeMarkingsFromFolder(objDir.FullName)

        Me.Text = My.Application.Info.ProductName

    End Sub

    Public Sub ProcessDeletedFolders()

        Dim objDir As DirectoryInfo

        txtAudit.Text = String.Concat(txtAudit.Text, vbCrLf, "Processing deleted folders - Adding Sizes")

        objDir = New DirectoryInfo(DELETED)

        Me.Text = String.Concat(My.Application.Info.ProductName, " - Adding Size to deleted folders")

        AddSizeMarkingsToFolder(mobjOptions.FullPathDeleted)

        Me.Text = My.Application.Info.ProductName

    End Sub

    Public Function ProcessFolders(ByVal blnBackup As Boolean) As Boolean

        Dim d As DirectoryInfo
        Dim objDir As DirectoryInfo
        Dim strCompletedPath As String

        strCompletedPath = GetRootPath()

        objDir = New DirectoryInfo(strCompletedPath)

        If blnBackup Then

            If Not BackupFolders(objDir, mobjOptions.RunTimeProcessedLocation, Me) Then Exit Function
        End If

        Me.Text = String.Concat(My.Application.Info.ProductName, " - Cleaning up Folders")

        CleanupFolders(Me)

        Me.Text = My.Application.Info.ProductName

        objDir.Refresh()

        If My.Computer.FileSystem.GetFiles("E:\_Torrent\Completed\50 Assorted Magazines\Keep").Count > 0 Or My.Computer.FileSystem.GetFiles("E:\_Torrent\Completed\Assorted Books Collection\Keep").Count > 0 Then

            If MessageBox.Show("Process the Keep folders of Assorted Mags/Books?", My.Application.Info.ProductName, MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then

                Process_50_Assorted_Magazines_Keep(Me)
            End If
        End If

        For Each d In objDir.GetDirectories()

            If IsDirectoryToBeProcessed(d, True) Then

                If Not UnknownFileType(d) Then

                    UpdateScreen(Me, d.Name)

                    Debug.Print(d.Name)

                    ProcessFolder(Me, d, True)
                End If

            End If
        Next

        objDir = New DirectoryInfo(strCompletedPath)

        If objDir.Name <> "Torrents" Then

            My.Application.DoEvents()
            DeleteEmptyFoldersAccountingForSpecialFolders(objDir)
            My.Application.DoEvents()
            DeleteEmptyFoldersAccountingForSpecialFolders(objDir)
            My.Application.DoEvents()
        End If

        UpdateScreen(Me, objDir.Name)

        ProcessFolders = True

    End Function

    Public Function PreProcessFolders() As Boolean

        Dim d As DirectoryInfo
        Dim objDir As DirectoryInfo
        Dim strCompletedPath As String
        Dim objDirs() As DirectoryInfo
        Dim intCount As Integer

        strCompletedPath = GetRootPath()

        objDir = New DirectoryInfo(strCompletedPath)

        Me.Text = My.Application.Info.ProductName

        objDir.Refresh()

        objDirs = objDir.GetDirectories()

        For intCount = 0 To objDirs.Count - 1

            d = objDirs(intCount)

            If IsDirectoryToBePreProcessed(d) Then

                If Not UnknownFileType(d) Then

                    UpdateScreen(Me, d.Name)

                    Debug.Print(d.Name)

                    PreProcessFolder(Me, d)
                End If
            End If
        Next

        objDir = New DirectoryInfo(strCompletedPath)

        If objDir.Name <> "Torrents" Then

            My.Application.DoEvents()
            DeleteEmptyFoldersAccountingForSpecialFolders(objDir)
            My.Application.DoEvents()
            DeleteEmptyFoldersAccountingForSpecialFolders(objDir)
            My.Application.DoEvents()
        End If

        UpdateScreen(Me, objDir.Name)

        PreProcessFolders = True

    End Function

    Private Function ProcessAssortedMagazineKeepFolderForUnwantedPDFs() As Boolean

        Dim objDir As DirectoryInfo
        Dim strPath As String
        Dim objFiles() As FileInfo
        Dim intCount As Integer, strTo As String = ""
        Dim strFilename As String, strOrginalFilename As String

        strPath = GetRootPath()

        ' Default location for assorted magazines 
        strPath = strPath & "\" & PRE_PROCESS_TYPE2.Replace(" - ", "")

        objDir = New DirectoryInfo(strPath)

        If Not My.Computer.FileSystem.DirectoryExists(objDir.FullName & "\Delete - Unwanted") Then

            My.Computer.FileSystem.CreateDirectory(objDir.FullName & "\Delete - Unwanted")
        End If

        If Not My.Computer.FileSystem.DirectoryExists(objDir.FullName & "\Keep\RemovePageZero") Then

            My.Computer.FileSystem.CreateDirectory(objDir.FullName & "\Keep\RemovePageZero")
        End If

        objFiles = objDir.GetFiles()

        UpdateMagazineTitles()

        For intCount = 0 To objFiles.Count - 1

            strOrginalFilename = objFiles(intCount).Name

            ' Keeping file so apply some basic cleanup
            strFilename = BasicCleanupFilename(objFiles(intCount).FullName)

            strFilename = RemovePath(strFilename)

            strFilename = MagazineNameReplacements(strFilename)

            If strFilename.ToLower <> strOrginalFilename.ToLower Then

                strFilename = objFiles(intCount).DirectoryName & "\" & strFilename

                If My.Computer.FileSystem.FileExists(strFilename) Then

                    If Not MoveFile_With_Rename_IfIts_Already_There(objFiles(intCount).FullName, strFilename) Then

                        MessageBox.Show("ProcessAssortedMagazineKeepFolderForUnwantedPDFs - MoveFile_With_Rename_IfIts_Already_There (1) - " & strFilename)
                        ProcessAssortedMagazineKeepFolderForUnwantedPDFs = False
                        Exit Function
                    End If

                    Delay(1)

                Else
                    objFiles(intCount).MoveTo(strFilename)
                    objFiles(intCount).Refresh()
                End If
            End If

            UpdateScreen(Me, "Examining Keep" & objFiles(intCount).FullName.Replace(strPath, ""))

            Me.Text = "Examining Keep" & objFiles(intCount).FullName.Replace(strPath, "")
            Me.Refresh()

            If Not IsValidMagazine(objFiles(intCount).Name) Then

                strTo = objFiles(intCount).Directory.FullName & "\Delete - Unwanted\" & RemovePath(objFiles(intCount).FullName)

                Me.txtAudit.Text = String.Concat(Me.txtAudit.Text, vbCrLf, "Moving to delete - Unwanted - ", objFiles(intCount).Name)

                If Not MoveFile_With_Rename_IfIts_Already_There(objFiles(intCount).FullName, strTo) Then

                    MessageBox.Show("ProcessAssortedMagazineKeepFolderForUnwantedPDFs - MoveFile_With_Rename_IfIts_Already_There (2) - " & strTo)
                    ProcessAssortedMagazineKeepFolderForUnwantedPDFs = False
                    Exit Function
                End If

                Delay(1)

                UpdateScreen(Me, "Deleting " & objFiles(intCount).FullName)

                If Not My.Computer.FileSystem.FileExists(strTo) Then

                    MessageBox.Show("ProcessAssortedMagazineKeepFolderForUnwantedPDFs - File missing - " & strTo)
                    End
                End If
            End If
        Next

        objDir = New DirectoryInfo(strPath)

        UpdateScreen(Me, objDir.Name)

        Me.Text = "Completed Torrents"

        ProcessAssortedMagazineKeepFolderForUnwantedPDFs = True

    End Function

    Private Function ProcessAssortedMagazine_DeleteUnwanted_Folder_For_Miss_Named_PDFs() As Boolean

        Dim objDir As DirectoryInfo
        Dim strPath As String
        Dim objFiles() As FileInfo
        Dim intCount As Integer
        Dim strFilename As String, strOrginalFilename As String
        Dim strTitles() As String, strTitlesNoSpaces() As String, intTitleCount As Integer, strFilenameUpper As String
        Dim strMatch As String, strReplacement As String, strTarget As String, blnMatched As Boolean, strEnd As String
        Dim strPrefix As String
        Dim strFrom1 As String = "", strTo1 As String = "", strFrom2 As String = "", strTo2 As String = ""

        strPath = GetRootPath()

        ' Default location for assorted magazines 
        strPath = strPath & "\" & PRE_PROCESS_TYPE2.Replace(" - ", "") & "\Delete - Unwanted"

        objDir = New DirectoryInfo(strPath)

        objFiles = objDir.GetFiles()

        UpdateMagazineTitles()

        strTitles = MAGAZINE_TITLES_KEEP_PROCESSING.Split(",")

        strTitlesNoSpaces = MAGAZINE_TITLES_KEEP_PROCESSING.Split(",")

        For intTitleCount = 0 To strTitlesNoSpaces.GetUpperBound(0) - 1

            strTitlesNoSpaces(intTitleCount) = strTitlesNoSpaces(intTitleCount).Replace(" ", "")
        Next

        For intCount = 0 To objFiles.Count - 1

            UpdateScreen(Me, "Examining " & objFiles(intCount).FullName.Replace(ROOT_DRIVE & "\_Torrent\Completed\", ""))

            Me.Text = "Examining " & objFiles(intCount).FullName.Replace(ROOT_DRIVE & "\_Torrent\Completed\", "")
            Me.Refresh()

            blnMatched = False
            strEnd = ""
            strFrom1 = ""
            strTo1 = ""
            strFrom2 = ""
            strTo2 = ""

            strOrginalFilename = objFiles(intCount).Name

            strFilename = objFiles(intCount).FullName

            strFilename = RemovePath(strFilename)

            strFilenameUpper = strFilename.ToUpper

            ' Check for a dash

            If InStr(strFilename, "-") = 0 Then

                For intTitleCount = 0 To strTitles.GetUpperBound(0) - 1

                    If DoesFileNameStartWith(strFilenameUpper, strTitles(intTitleCount)) Then

                        strMatch = strTitles(intTitleCount).ToUpper

                        strReplacement = strMatch

                        strFilename = strFilename.ToUpper.Replace(strMatch, strReplacement)

                        strPrefix = GetPrefix(strFilename).ToLower

                        strFilename = RemovePrefix(strFilename)

                        strFilename = ProperiseCase(strFilename)

                        If Mid(strFilename, 1, 4) = "Bbc " Then

                            strFilename = "BBC " & Mid(strFilename, 4)
                        End If

                        strFilename = strFilename & "." & strPrefix

                        strFilename = Mid(strFilename, 1, Len(strReplacement) + 1) & " - " & Mid(strFilename, Len(strReplacement) + 2)

                        blnMatched = True
                        Exit For
                    End If
                Next
            End If

            If Not blnMatched Then

                ' Check for a dash with no spaces

                If InStr(strFilename, "-") = 0 Then

                    For intTitleCount = 0 To strTitlesNoSpaces.GetUpperBound(0) - 1

                        If DoesFileNameStartWith(strFilenameUpper, strTitlesNoSpaces(intTitleCount)) Then

                            Select Case strTitlesNoSpaces(intTitleCount)

                                Case "OMYOGA"

                                    strReplacement = "Yoga Journal"
                                    strEnd = " (Om)"

                                    strFrom1 = "magazine"
                                    strTo1 = ""

                                    strFrom2 = "Magazine"
                                    strTo2 = ""

                                Case Else

                                    strReplacement = ProperiseCase(strTitles(intTitleCount))

                            End Select

                            strFilename = strReplacement & " - " & Mid(strFilename, Len(strTitlesNoSpaces(intTitleCount)) + 1)

                            If strEnd <> "" Then

                                strPrefix = GetPrefixwithDot(strFilename).ToLower

                                strFilename = RemovePrefix(strFilename)

                                strFilename = strFilename & strEnd & strPrefix
                            End If

                            If strFrom1 <> "" Then

                                strFilename = strFilename.Replace(strFrom1, strTo1)
                            End If

                            If strFrom2 <> "" Then

                                strFilename = strFilename.Replace(strFrom2, strTo2)
                            End If

                            blnMatched = True
                            Exit For
                        End If
                    Next
                End If
            End If

            If blnMatched Then

                strFilename = strFilename.Replace("  ", " ")

                If strFilename.ToLower <> strOrginalFilename.ToLower Then

                    UpdateScreen(Me, "Moving " & strFilename)

                    Me.Text = "Moving " & strFilename
                    Me.Refresh()

                    ' Move back to D:\_Torrent\Completed\50 Assorted Magazines for processing again
                    strTarget = ROOT_DRIVE & "\_Torrent\Completed\50 Assorted Magazines\" & strFilename

                    If My.Computer.FileSystem.FileExists(strTarget) Then

                        If Not MoveFile_With_Rename_IfIts_Already_There(objFiles(intCount).FullName, strTarget) Then

                            MessageBox.Show("ProcessAssortedMagazine_DeleteUnwanted_Folder_For_Miss_Named_PDFs - MoveFile_With_Rename_IfIts_Already_There - " & strTarget)
                            ProcessAssortedMagazine_DeleteUnwanted_Folder_For_Miss_Named_PDFs = False
                            Exit Function
                        End If

                        Delay(1)

                    Else

                        objFiles(intCount).MoveTo(strTarget)
                        objFiles(intCount).Refresh()
                    End If
                End If
            End If
        Next

        UpdateScreen(Me, objDir.Name)

        Me.Text = "Completed Torrents"

        ProcessAssortedMagazine_DeleteUnwanted_Folder_For_Miss_Named_PDFs = True

    End Function

    Public Function ProcessAssortedBooksFolderForUndownloadedEpubs() As Boolean

        Dim objDir As DirectoryInfo
        Dim strPath As String
        Dim objFiles() As FileInfo
        Dim intCount As Integer, strTo As String = "", strFileName As String = ""

        strPath = GetRootPath()

        ' Default location for assorted books collection
        strPath = strPath & "\" & PRE_PROCESS_TYPE13.Replace(" - ", "")

        objDir = New DirectoryInfo(strPath)

        Me.Text = My.Application.Info.ProductName

        objDir.Refresh()

        If Not My.Computer.FileSystem.DirectoryExists(objDir.FullName & "\Keep") Then

            My.Computer.FileSystem.CreateDirectory(objDir.FullName & "\Keep")
        End If

        If Not My.Computer.FileSystem.DirectoryExists(objDir.FullName & "\Delete - Undownloaded") Then

            My.Computer.FileSystem.CreateDirectory(objDir.FullName & "\Delete - Undownloaded")
        End If

        objFiles = objDir.GetFiles()

        For intCount = 0 To objFiles.Count - 1

            strFileName = objFiles(intCount).FullName

            UpdateScreen(Me, "Examining " & strFileName.Replace(ROOT_DRIVE & "\_Torrent\Completed\", ""))

            Me.Text = "Examining " & strFileName.Replace(ROOT_DRIVE & "\_Torrent\Completed\", "")
            Me.Refresh()

            If GetPrefix(strFileName).ToLower = "epub" Then

                'If ValidEpubUsing_64bitonly(objFiles(intCount).FullName, ROOT_DRIVE & "\VB.Net\My Projects\_Tools\epubmeta.exe") Then
                ' If ValidEpubUsing_epubReader(objFiles(intCount).FullName) Then

                If GetPercentOfZerosInFile(strFileName) < ZEROS_LIMIT_EPUB And HasTheZipMagicNumbers(strFileName) Then

                    ' Keeping file so apply some basic cleanup
                    strFileName = BasicCleanupFilename(strFileName)

                    objFiles(intCount).MoveTo(strFileName)

                    strTo = objFiles(intCount).Directory.FullName & "\Keep\" & RemovePath(strFileName)

                    Me.txtAudit.Text = String.Concat(Me.txtAudit.Text, vbCrLf, "Moving to Keep - ", objFiles(intCount).Name)

                    If Not MoveFile_With_Rename_IfIts_Already_There(strFileName, strTo) Then

                        MessageBox.Show("ProcessAssortedBooksFolderForUndownloadedEpubs - MoveFile_With_Rename_IfIts_Already_There (1) - " & strTo)
                        End
                    End If

                    Delay(1)

                    UpdateScreen(Me, "Keeping " & strFileName)
                Else

                    strTo = objFiles(intCount).Directory.FullName & "\Delete - Undownloaded\" & RemovePath(strFileName)

                    Me.txtAudit.Text = String.Concat(Me.txtAudit.Text, vbCrLf, "Moving to delete - Undownloaded - ", objFiles(intCount).Name)

                    If Not MoveFile_With_Rename_IfIts_Already_There(strFileName, strTo) Then

                        MessageBox.Show("ProcessAssortedBooksFolderForUndownloadedEpubs - MoveFile_With_Rename_IfIts_Already_There (2) - " & strTo)
                        End
                    End If

                    Delay(1)

                    UpdateScreen(Me, "Deleting " & strFileName)
                End If

                If Not My.Computer.FileSystem.FileExists(strTo) Then

                    MessageBox.Show("File missing - ProcessAssortedBooksFolderForUndownloadedEpubs - " & strTo)
                    End
                End If
            End If

            If GetPrefix(strFileName).ToLower = "pdf" Then

                If GetPercentOfZerosInFile(objFiles(intCount).FullName) < ZEROS_LIMIT_PDF And HasThePDFMagicNumbers(objFiles(intCount).FullName) Then

                    strTo = objFiles(intCount).Directory.FullName & "\Keep\" & RemovePath(strFileName)

                    Me.txtAudit.Text = String.Concat(Me.txtAudit.Text, vbCrLf, "Moving to Keep - ", objFiles(intCount).Name)

                    If Not MoveFile_With_Rename_IfIts_Already_There(strFileName, strTo) Then

                        MessageBox.Show("ProcessAssortedBooksFolderForUndownloadedEpubs - MoveFile_With_Rename_IfIts_Already_There (3 (pdf)) - " & strTo)
                        End
                    End If

                    Delay(1)

                    UpdateScreen(Me, "Keeping " & strFileName)
                Else

                    strTo = objFiles(intCount).Directory.FullName & "\Delete - Undownloaded\" & RemovePath(strFileName)

                    Me.txtAudit.Text = String.Concat(Me.txtAudit.Text, vbCrLf, "Moving to delete - Undownloaded - ", objFiles(intCount).Name)

                    If Not MoveFile_With_Rename_IfIts_Already_There(strFileName, strTo) Then

                        MessageBox.Show("ProcessAssortedBooksFolderForUndownloadedEpubs - MoveFile_With_Rename_IfIts_Already_There (4 (pdf)) - " & strTo)
                        End
                    End If

                    Delay(1)

                    UpdateScreen(Me, "Deleting " & strFileName)
                End If

                If Not My.Computer.FileSystem.FileExists(strTo) Then

                    MessageBox.Show("File missing - ProcessAssortedBooksFolderForUndownloadedEpubs (PDF) - " & strTo)
                    End
                End If
            End If
        Next

        objDir = New DirectoryInfo(strPath)

        UpdateScreen(Me, objDir.Name)

        Me.Text = "Completed Torrents"

        ProcessAssortedBooksFolderForUndownloadedEpubs = True

    End Function

    Public Function ProcessAssortedMagazineFolderForUndownloadedPDFs(ByVal strTargetFolder As String) As Boolean

        Dim objDir As DirectoryInfo
        Dim strPath As String
        Dim objFiles() As FileInfo
        Dim intCount As Integer, strTo As String = "", blnCheckUnwanted As Boolean = False

        If strTargetFolder = "" Then

            strPath = GetRootPath()

            ' Default location for assorted magazines
            strPath = strPath & "\" & PRE_PROCESS_TYPE2.Replace(" - ", "")

            objDir = New DirectoryInfo(strPath)

            If Not My.Computer.FileSystem.DirectoryExists(objDir.FullName & "\Keep") Then

                My.Computer.FileSystem.CreateDirectory(objDir.FullName & "\Keep")
            End If

            If Not My.Computer.FileSystem.DirectoryExists(objDir.FullName & "\Delete - Undownloaded") Then

                My.Computer.FileSystem.CreateDirectory(objDir.FullName & "\Delete - Undownloaded")
            End If
        Else

            strPath = strTargetFolder

            objDir = New DirectoryInfo(strPath)

            blnCheckUnwanted = True
        End If

        Me.Text = My.Application.Info.ProductName

        objDir.Refresh()

        objFiles = objDir.GetFiles()

        For intCount = 0 To objFiles.Count - 1

            UpdateScreen(Me, "Examining (1) " & objFiles(intCount).FullName.Replace(ROOT_DRIVE & "\_Torrent\Completed\", ""))

            Me.Text = "Examining (1) " & objFiles(intCount).FullName.Replace(ROOT_DRIVE & "\_Torrent\Completed\", "")
            Me.Refresh()

            If GetPercentOfZerosInFile(objFiles(intCount).FullName) < ZEROS_LIMIT_PDF And HasThePDFMagicNumbers(objFiles(intCount).FullName) Then

                ' If this test is OK do nothing but file may still be moved to Keep in type 2 underneath
            Else

                strTo = objFiles(intCount).Directory.FullName & "\Delete - Undownloaded\" & RemovePath(objFiles(intCount).FullName)

                Me.txtAudit.Text = String.Concat(Me.txtAudit.Text, vbCrLf, "Moving to delete - Undownloaded - ", objFiles(intCount).Name)

                If Not MoveFile_With_Rename_IfIts_Already_There(objFiles(intCount).FullName, strTo) Then

                    MessageBox.Show("ProcessAssortedMagazineFolderForUndownloadedPDFs - MoveFile_With_Rename_IfIts_Already_There (1) - " & strTo)
                    End
                End If

                Delay(1)

                UpdateScreen(Me, "Deleting " & objFiles(intCount).FullName)

                If Not My.Computer.FileSystem.FileExists(strTo) Then

                    MessageBox.Show("ProcessAssortedMagazineFolderForUndownloadedPDFs - File missing (1 - 2) - " & strTo)
                    End
                End If
            End If
        Next

        objDir.Refresh()
        objFiles = objDir.GetFiles()

        ' Second Method - Exe sometimes crashes will hardly downloaded files
        For intCount = 0 To objFiles.Count - 1

            UpdateScreen(Me, "Examining (2) " & objFiles(intCount).FullName.Replace(ROOT_DRIVE & "\_Torrent\Completed\", ""))

            Me.Text = "Examining (2) " & objFiles(intCount).FullName.Replace(ROOT_DRIVE & "\_Torrent\Completed\", "")
            Me.Refresh()

            If ValidPDF(objFiles(intCount).FullName, ROOT_DRIVE & "\VB.Net\My Projects\_Tools\PDFInfo.exe") Then

                ' Normal run - move to keep
                If Not blnCheckUnwanted Then

                    strTo = objFiles(intCount).Directory.FullName & "\Keep\" & RemovePath(objFiles(intCount).FullName)

                    Me.txtAudit.Text = String.Concat(Me.txtAudit.Text, vbCrLf, "Moving to Keep - ", objFiles(intCount).Name)

                    If Not MoveFile_With_Rename_IfIts_Already_There(objFiles(intCount).FullName, strTo) Then

                        MessageBox.Show("ProcessAssortedMagazineFolderForUndownloadedPDFs - MoveFile_With_Rename_IfIts_Already_There (2) - " & strTo)
                        End
                    End If

                    Delay(1)

                    UpdateScreen(Me, "Keeping " & objFiles(intCount).FullName)

                    If Not My.Computer.FileSystem.FileExists(strTo) Then

                        MessageBox.Show("ProcessAssortedMagazineFolderForUndownloadedPDFs - File missing (2 - 1) - " & strTo)
                        End
                    End If
                Else

                    ' In this case I just do nothing
                End If
            Else

                strTo = objFiles(intCount).Directory.FullName & "\Delete - Undownloaded\" & RemovePath(objFiles(intCount).FullName)

                Me.txtAudit.Text = String.Concat(Me.txtAudit.Text, vbCrLf, "Moving to delete - Undownloaded - ", objFiles(intCount).Name)

                If Not MoveFile_With_Rename_IfIts_Already_There(objFiles(intCount).FullName, strTo) Then

                    MessageBox.Show("ProcessAssortedMagazineFolderForUndownloadedPDFs - MoveFile_With_Rename_IfIts_Already_There (3) - " & strTo)
                    End
                End If

                Delay(1)

                UpdateScreen(Me, "Deleting " & objFiles(intCount).FullName)

                If Not My.Computer.FileSystem.FileExists(strTo) Then

                    MessageBox.Show("ProcessAssortedMagazineFolderForUndownloadedPDFs - File missing (2 - 2) - " & strTo)
                    End
                End If
            End If
        Next

        objDir = New DirectoryInfo(strPath)

        UpdateScreen(Me, objDir.Name)

        Me.Text = "Completed Torrents"

        ProcessAssortedMagazineFolderForUndownloadedPDFs = True

    End Function

    Public Function ProcessFiles(ByVal blnBackup As Boolean) As Boolean

        Dim objDir As DirectoryInfo, intCount As Integer
        Dim objFile As FileInfo, colFiles() As FileInfo
        Dim strCompletedFolder As String

        strCompletedFolder = GetRootPath()

        objDir = New DirectoryInfo(strCompletedFolder)

        colFiles = objDir.GetFiles()

        If blnBackup Then

            If Not BackupFiles(objDir, colFiles, mobjOptions.RunTimeProcessedLocation, Me) Then Exit Function
        End If

        DeleteCrapfiles(Me, objDir, colFiles, False)

        intCount = 0

        objDir.Refresh()
        colFiles = objDir.GetFiles()

        For Each objFile In colFiles

            UpdateScreen(Me, objFile.Name)

            Debug.Print(objFile.Name)

            ProcessFile(objDir, objFile, Me)

            Me.Show()
        Next

        ProcessFiles = True

    End Function

    Private Sub frmMain_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        Dim intCount As Integer

        'If MessageBox.Show("Run from Code." & vbCrLf & vbCrLf & "Set every type of Exception to Thrown = unchecked - User Handled = Checked." & vbCrLf & vbCrLf & "DEBUG -> EXCEPTIONS... Menu" & vbCrLf & vbCrLf & "Do I need to break?", My.Application.Info.ProductName, _
        '       MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

        'Me.Cursor = Cursors.Default
        'End
        'End If

        Try

            UpdateCurrentFile("")

            mobjOptions = New clsOptions

            mobjOptions.LoadOptions()

            CheckFolders(False)

            FindMagazineTitles()

            GetAllVideoTypes()

            LoadTVDrives()

            For intCount = 5 To 45 Step +5

                cboTimes.Items.Add(intCount)
            Next

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
        End Try

        Me.Width = 411
        Me.Height = 497

    End Sub

    Public Sub UpdateCurrentFile(ByVal strName As String)

        Try

            lblCurrentFile.Text = strName
            Me.Refresh()

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Function EnsureFoldersExists() As Boolean

        If Not My.Computer.FileSystem.DirectoryExists(mobjOptions.FullPathTV) Then

            MessageBox.Show("TV Folder Doesn't Exist!", My.Application.Info.ProductName, MessageBoxButtons.OK)
            Return False
        End If

        If Not My.Computer.FileSystem.DirectoryExists(mobjOptions.FullPathTV_CopyFrom) Then

            MessageBox.Show("TV Copy From Folder Doesn't Exist!", My.Application.Info.ProductName, MessageBoxButtons.OK)
            Return False
        End If

        If Not My.Computer.FileSystem.DirectoryExists(mobjOptions.FullPathTV_CopyFrom & "TV") Then

            My.Computer.FileSystem.CreateDirectory(mobjOptions.FullPathTV_CopyFrom & "TV")
        End If

        If Not My.Computer.FileSystem.DirectoryExists(mobjOptions.FullPathTV_CopyFrom & "TV 2") Then

            My.Computer.FileSystem.CreateDirectory(mobjOptions.FullPathTV_CopyFrom & "TV 2")
        End If

        If Not My.Computer.FileSystem.DirectoryExists(mobjOptions.FullPathTV_CopyFrom & "TV 3") Then

            My.Computer.FileSystem.CreateDirectory(mobjOptions.FullPathTV_CopyFrom & "TV 3")
        End If

        If Not My.Computer.FileSystem.DirectoryExists(mobjOptions.FullPathTV_CopyFrom & "TV 4") Then

            My.Computer.FileSystem.CreateDirectory(mobjOptions.FullPathTV_CopyFrom & "TV 4")
        End If

        Return True

    End Function

    Private Function GetDriveFolder(ByRef d As DirectoryInfo) As String

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand, strFolder As String, intPos As Integer
        Dim strReturn As String, strName As String

        GetDriveFolder = ""

        Try

            strName = ParseTextForSQL(d.Name.Replace(" ", "%"))

            strSQL = String.Concat("Select DriveName, Foldername from tblDriveContents where Foldername like '%", strName, "%'")

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    strFolder = Trim(drTypes("Foldername") & "").Replace(drTypes("Drivename"), "")

                    If strFolder <> "" Then

                        If Mid(strFolder, 1, 1) = "\" Then

                            strFolder = Mid(strFolder, 2)
                        End If

                        intPos = InStr(1, strFolder, "\")

                        If intPos > 0 Then

                            strFolder = Mid(strFolder, 1, intPos - 1)
                        End If

                    End If

                    If d.Name.ToUpper = strFolder.ToUpper Then

                        strReturn = drTypes("Drivename").replace("Backup", "").trim

                        intPos = InStr(1, strReturn, "\")

                        If intPos > 0 Then

                            strReturn = Mid(strReturn, intPos + 1)
                        End If

                        CloseOLECommand(comTypes)
                        CloseDataReader(drTypes)

                        Return strReturn
                    End If
                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

            Return ""

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
        End Try

    End Function

    Private Function GetCopyFromFolder(ByVal strFolder As String, ByVal strDriveFolder As String) As String

        Dim strFolderTemp As String, intPos As Integer
        Dim strName As String

        Try

            strFolderTemp = strFolder

            intPos = InStrRev(strFolderTemp, "\")

            If intPos > 0 Then

                strName = Mid(strFolderTemp, intPos)
                strFolderTemp = Mid(strFolderTemp, 1, intPos - 1)

                strFolderTemp = strFolderTemp & TV_COPY_FROM

                strFolderTemp = strFolderTemp & strDriveFolder & strName

                Return strFolderTemp
            End If

            Return ""

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Function

    Private Function GetCopyPath(ByVal strFullName As String, strTo As String) As String

        Dim intPos As Integer, strName As String

        intPos = InStrRev(strTo, "\")

        If intPos > 0 Then

            intPos = InStrRev(strTo, "\")
            strName = Mid(strTo, intPos + 1)
        Else

            Return ""
        End If

        intPos = InStrRev(strFullName, "\" & strName & "\")

        strFullName = Mid(strFullName, intPos + Len("\" & strName & "\"))

        strTo = strTo & "\" & strFullName

        Return strTo

    End Function

    Private Function GetCopyPathForTV(ByVal strFullName As String, strTo As String) As String

        Dim intPos As Integer, strName As String

        intPos = InStrRev(strTo, "\")

        If intPos > 0 Then

            intPos = InStrRev(strTo, "\")
            strName = Mid(strTo, intPos + 1)
        Else

            Return ""
        End If

        intPos = InStrRev(strFullName, "\" & strName & "\")

        strFullName = Mid(strFullName, intPos + Len("\" & strName & "\"))

        strFullName = strFullName.Replace("  ", " ")

        strFullName = strFullName.Replace(" INTERNAL.avi", ".avi")
        strFullName = strFullName.Replace(" INTERNAL.mp4", ".mp4")
        strFullName = strFullName.Replace(" INTERNAL.mkv", ".mkv")

        strFullName = strFullName.Replace("_.api", ".avi")
        strFullName = strFullName.Replace("_.mp4", ".mp4")
        strFullName = strFullName.Replace("_.mkv", ".mkv")

        strTo = strTo & "\" & strFullName

        Return strTo

    End Function

    Private Function MoveTVFiles(ByRef d As DirectoryInfo, ByVal strTo As String) As Boolean

        Dim objFile As FileInfo, objSubDir As DirectoryInfo
        Dim strCopyName As String, objDir As DirectoryInfo
        Dim colFiles() As FileInfo
        Dim objFileAlreadyThere As FileInfo

        Try

            For Each objFile In d.GetFiles()

                strCopyName = GetCopyPathForTV(objFile.FullName, strTo)

                If Not My.Computer.FileSystem.FileExists(strCopyName) Then

                    mobjStats.Add_File(objFile.Extension, TV)

                    Me.txtAudit.Text = String.Concat(Me.txtAudit.Text, vbCrLf, "Moving TV - ", objFile.FullName, " to ", strCopyName)

                    UpdateScreen(Me, "")

                    My.Computer.FileSystem.MoveFile(objFile.FullName, strCopyName)

                    Delay(1)

                    If Not My.Computer.FileSystem.FileExists(strCopyName) Then

                        MessageBox.Show("MoveTVFiles - Failed to move " & strTo & " to " & strCopyName & "! Ending")
                        End
                    End If
                Else

                    Try

                        If ExactDuplicateFiles(objFile.Directory, objFile.FullName, strCopyName, Me) Then

                            mobjStats.Add_File(objFile.Extension, DUP_TV)

                            MoveToDeleted(objFile)

                            txtAudit.Text = String.Concat(txtAudit.Text, vbCrLf, "Move TV - Dup. (extact) ", objFile.FullName, " to deleted")
                        Else

                            ' If not an exact match - keep smaller sized file as long as its not too small (100K) 
                            Dim objCopyNameDir As New DirectoryInfo(GetPath(strCopyName))

                            colFiles = objCopynameDir.GetFiles(GetFilename(strCopyName))

                            objFileAlreadyThere = colFiles(0)

                            If objFile.Length < objFileAlreadyThere.Length And objFile.Length <= 100000 Then

                                MessageBox.Show("Problem - File -" & objFile.FullName & " is too small to overwrite current file in Drive TV folder. Ending for manual sort out")
                                End

                            ElseIf objFile.Length < objFileAlreadyThere.Length And objFile.Length > 100000 Then

                                MoveToDeleted(objFileAlreadyThere, False, "")

                                My.Computer.FileSystem.MoveFile(objFile.FullName, strCopyName)

                                Delay(1)

                                If Not My.Computer.FileSystem.FileExists(strCopyName) Then

                                    MessageBox.Show("MoveTVFiles (2) - Failed to move " & strTo & " to " & strCopyName & "! Ending")
                                    End
                                End If
                            Else

                                MoveToDeleted(objFile, False, "")

                                Delay(1)
                            End If

                            mobjStats.Add_File(objFile.Extension, DUP_TV)

                            Me.txtAudit.Text = String.Concat(Me.txtAudit.Text, vbCrLf, "TV - Dup. (non extact) ", objFile.FullName, " & ", strCopyName)
                        End If

                    Catch ex As Exception

                        MessageBox.Show("Error in MoveTVFiles(FilesWithSameName) - " & ex.Message)
                        MessageBox.Show("Error in MoveTVFiles(FilesWithSameName) - Need to sort out! Ending")

                        End
                    End Try

                    Delay(1)

                    'If objDir.GetFiles().Count = 0 And objDir.GetDirectories().Count = 0 Then

                    'Try

                    'objDir.Delete()

                    'Catch ex As Exception

                    '        DisplayException_Messagebox(ex, "3 - " & System.Reflection.MethodBase.GetCurrentMethod().Name)
                    '       End

                    'End Try
                    'End If
                End If
            Next

        Catch ex As Exception

            DisplayException_Messagebox(ex, "1 - " & System.Reflection.MethodBase.GetCurrentMethod().Name)
            End
        End Try

        Delay(1)

        Try

            If My.Computer.FileSystem.DirectoryExists(d.FullName) Then

                If d.GetDirectories.Count > 0 Then

                    For Each objSubDir In d.GetDirectories

                        MoveTVFiles(objSubDir, strTo)
                    Next
                End If

                Delay(1)
                d.Refresh()

                If d.GetFiles.Count = 0 And d.GetDirectories.Count = 0 Then

                    d.Delete()
                    d.Refresh()
                End If

            End If

        Catch NotFound As DirectoryNotFoundException

            ' OK

        Catch ex As Exception

            DisplayException_Messagebox(ex, "2 - " & System.Reflection.MethodBase.GetCurrentMethod().Name)
            End

        End Try

        MoveTVFiles = True

    End Function

    Private Sub cmdProcessTV_Click(sender As System.Object, e As System.EventArgs) Handles cmdProcessTV.Click

        Dim d As DirectoryInfo, strDriveFolder As String
        Dim objDir As DirectoryInfo, strToFolder As String

        txtAudit.Text = ""

        Me.Cursor = Cursors.WaitCursor

        DisplayButtons(False)

        mobjStats.Reset()

        GetDBConnection(ROOT_DRIVE & "\VB.Net\My Projects\Media Manager\bin\Debug\MediaManager.mdb")

        If Not EnsureFoldersExists() Then

            Me.Cursor = Cursors.Default
            DisplayButtons(True)
            Exit Sub
        End If

        If cmdShowAudit.Text = ">>" Then

            cmdShowAudit_Click(Nothing, Nothing)

            My.Application.DoEvents()
        End If

        Try

            objDir = New DirectoryInfo(mobjOptions.FullPathTV)

            For Each d In objDir.GetDirectories()

                If d.Name <> TV_COPY_FROM.Replace("\", "") Then

                    strDriveFolder = GetDriveFolder(d)

                    If strDriveFolder = "" Then strDriveFolder = "None"

                    If strDriveFolder <> "" Then

                        strToFolder = GetCopyFromFolder(d.FullName, strDriveFolder)

                        If strToFolder <> "" Then

                            UpdateCurrentFile(strToFolder)

                            Me.Refresh()
                            My.Application.DoEvents()

                            Try

                                If Not MoveTVFiles(d, strToFolder) Then

                                    MessageBox.Show("Problem moving " & d.FullName & " Ending")
                                    End
                                End If

                            Catch ex As Exception

                                DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                                End
                            End Try

                            Me.Refresh()
                            My.Application.DoEvents()
                        End If
                    End If
                End If
            Next

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name & "Pass 1")
            End
        End Try

        Try

            objDir = New DirectoryInfo(mobjOptions.FullPathTV)

            For Each d In objDir.GetDirectories()

                If d.Name <> TV_COPY_FROM.Replace("\", "") Then

                    Delay(1)
                    d.Refresh()

                    If d.GetFiles.Count = 0 And d.GetDirectories.Count = 0 Then

                        d.Delete()
                    End If

                End If

            Next

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name & "Pass 2 - remove empty folders")
            End
        End Try

        Me.Cursor = Cursors.Default
        DisplayButtons(True)

        CloseOLEConnection(mobjOLEConn)

        UpdateCurrentFile("")

        PlaySound(ROOT_DRIVE & "\VB.Net\My Projects\_Sounds\transference_complete.wav")

        UpdateScreen(Me, "Done!")

    End Sub

    Private Sub cmdMoveTV_Click(sender As System.Object, e As System.EventArgs) Handles cmdMoveTV.Click

        Dim intFileCount As Integer, strPath As String
        Dim blnFoundBackup As Boolean = False
        Dim objItem As Object

        txtAudit.Text = ""

        If cboDrives.Text = "" Then

            Exit Sub
        End If

        If InStr(cboDrives.Text, "Backup") <> 0 Then

            MessageBox.Show("Can't start using a backup drive!")
            Exit Sub
        End If

        DisplayButtons(False)

        strPath = mobjOptions.FullPathTV_CopyFrom & RemovePath(cboDrives.Text)

        GetCountOfAllFilesInFolder_Recursive(strPath, intFileCount)

        If Not IsDriveConnected(cboDrives.Text) Then

            MessageBox.Show(cboDrives.Text & " isn't connected.", My.Application.Info.ProductName)

            DisplayButtons(True)
            Exit Sub
        End If

        If Not IsDriveConnected(GetBackupDrive(cboDrives.Text)) Then

            MessageBox.Show(GetBackupDrive(cboDrives.Text) & " isn't connected.", My.Application.Info.ProductName)

            DisplayButtons(True)
            Exit Sub
        End If

        If cmdShowAudit.Text = ">>" Then

            cmdShowAudit_Click(Nothing, Nothing)

            My.Application.DoEvents()
        End If

        prgProgress.Visible = True

        ' Account for backups
        intFileCount = (intFileCount * 2) + 10

        prgProgress.Value = 0
        prgProgress.Minimum = 0
        prgProgress.Maximum = intFileCount

        MoveTVFilesFromCopyFrom(Me, cboDrives.Text, prgProgress)

        DisplayButtons(True)

        PlaySound(ROOT_DRIVE & "\VB.Net\My Projects\_Sounds\transference_complete.wav")

        prgProgress.Visible = False

        UpdateScreen(Me, "Done!")

    End Sub

    Private Sub LoadTVDrives()

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand, strDrive As String

        GetDBConnection(ROOT_DRIVE & "\VB.Net\My Projects\Media Manager\bin\Debug\MediaManager.mdb")

        Try

            strSQL = "Select DriveName from tblDrives where (drivename like '%TV%' and drivename not like '% Backup%') Order by DriveName"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    strDrive = Trim(drTypes("Drivename"))

                    If IsDriveConnected(strDrive) Then

                        cboDrives.Items.Add(strDrive)
                    End If
                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
        End Try

        CloseOLEConnection(mobjOLEConn)

    End Sub

    Private Sub cmdMoveMags_Click(sender As System.Object, e As System.EventArgs) Handles cmdMoveMags.Click

        Try

            txtAudit.Text = ""

            If cmdShowAudit.Text = ">>" Then

                cmdShowAudit_Click(Nothing, Nothing)

                My.Application.DoEvents()
            End If

            DisplayButtons(False)

            prgProgress.Value = 0
            prgProgress.Maximum = 1

            MoveMagFilesToBooksMagsFolder(Me, prgProgress)

            ProcessBooksMagsFolder(Me)

            DisplayButtons(True)

            PlaySound(ROOT_DRIVE & "\VB.Net\My Projects\_Sounds\transference_complete.wav")

            UpdateScreen(Me, "Done!")

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub mnuToDo_Click(sender As Object, e As EventArgs) Handles mnuToDo.Click

        Dim objToDo As New frmToDoList

        objToDo.DisplayToDos()

        objToDo.Show()

    End Sub

    Private Sub cmdCopyStructure_Click(sender As Object, e As EventArgs) Handles cmdCopyStructure.Click

        Dim strDir As String

        ' Copies structure of current completed folder to a folder in temp
        ' Copies of files are created as zero sized
        ' Allowing me to process this folder with 'Process Copied' to check any code changes without causing damage to the normal completed folders

        Me.Cursor = Cursors.WaitCursor
        DisplayButtons(False)

        strDir = ROOT_DRIVE & "\temp\" & Format(Now, "dd MMM yyyy HH mm")

        UpdateScreen(Me, "")

        If Not CopyStructureFolders(strDir) Then

            Me.Cursor = Cursors.Default
            DisplayButtons(True)
            Exit Sub
        End If

        If Not CopyStructureFiles(strDir) Then

            Me.Cursor = Cursors.Default
            DisplayButtons(True)
            Exit Sub
        End If

        My.Computer.FileSystem.CreateDirectory(strDir & "\_Deleted")
        My.Computer.FileSystem.CreateDirectory(strDir & "\_Movies")
        My.Computer.FileSystem.CreateDirectory(strDir & "\_Music")

        Me.Cursor = Cursors.Default
        DisplayButtons(True)

        Me.Text = My.Application.Info.ProductName & " - " & strDir

    End Sub

    Public Function CopyStructureFiles(ByVal strDir As String) As Boolean

        Dim objDir As DirectoryInfo
        Dim objFile As FileInfo, colFiles() As FileInfo

        Me.Text = My.Application.Info.ProductName & " - Copying Files"

        objDir = New DirectoryInfo(mobjOptions.RootFolder)

        colFiles = objDir.GetFiles()

        For Each objFile In colFiles

            My.Computer.FileSystem.OpenTextFileWriter(strDir & "\" & objFile.Name, False)

            Me.Show()
        Next

        CopyStructureFiles = True

    End Function

    Public Function CopyStructureFolders(ByVal strDir As String) As Boolean

        Dim d As DirectoryInfo
        Dim objDir As DirectoryInfo

        Me.Text = My.Application.Info.ProductName & " - Copying Folder Structure"

        objDir = New DirectoryInfo(mobjOptions.RootFolder)

        For Each d In objDir.GetDirectories()

            If IsDirectoryToBeProcessed(d, True) Or (d.Name = "_Books" Or d.Name = "_TV" Or d.Name = "_Magazines") Then

                modProcessing.CopyStructureFolder(Me, d, True, strDir)
            End If
        Next

        CopyStructureFolders = True

    End Function

    Private Sub cmdProcessCopiedStruct_Click(sender As Object, e As EventArgs) Handles cmdProcessCopiedStruct.Click

        Dim blnBackup As Boolean, strCompletedPath As String

        Me.Cursor = Cursors.WaitCursor
        DisplayButtons(False)

        mobjStats.Reset()

        strCompletedPath = InputBox("Path in D:\temp to use", "Enter Full Path", "")

        If strCompletedPath = "" Then Exit Sub

        SetRootPath(strCompletedPath)

        blnBackup = False

        If Not ProcessFiles(blnBackup) Then

            UpdateScreen(Me, "")

            Me.Cursor = Cursors.Default
            DisplayButtons(True)

            Exit Sub
        End If

        If Not ProcessFolders(blnBackup) Then

            UpdateScreen(Me, "")

            Me.Cursor = Cursors.Default
            DisplayButtons(True)
            Exit Sub
        End If

        ' Call ProcessFiles a second time - this is because
        ' it will handle any assorted bundle magazines that have been moved into the 
        ' completed folder by ProcessFolders
        If Not ProcessFiles(blnBackup) Then

            UpdateScreen(Me, "")

            Me.Cursor = Cursors.Default
            DisplayButtons(True)

            Exit Sub
        End If

        UpdateScreen(Me, "Done!")

        Me.Cursor = Cursors.Default
        DisplayButtons(True)

        PlaySound(ROOT_DRIVE & "\VB.Net\My Projects\_Sounds\transference_complete.wav")

    End Sub

    Private Sub cmdPreProcess_Click(sender As Object, e As EventArgs) Handles cmdPreProcess.Click

        txtAudit.Text = ""

        'MessageBox.Show("If Magazine Monitor is running - Suspend Monitoring now!" & vbCrLf & vbCrLf & "When running it conflicts with the Process!")

        If cmdShowAudit.Text = ">>" Then

            cmdShowAudit_Click(Nothing, Nothing)

            My.Application.DoEvents()
        End If

        Me.Cursor = Cursors.WaitCursor
        DisplayButtons(False)

        mobjStats.Reset()

        If Not PreProcessFolders() Then

            UpdateScreen(Me, "")

            Me.Cursor = Cursors.Default
            DisplayButtons(True)
            Exit Sub
        End If

        ' Need two goes for folders with PDFs in Books subfolder
        If Not PreProcessFolders() Then

            UpdateScreen(Me, "")

            Me.Cursor = Cursors.Default
            DisplayButtons(True)
            Exit Sub
        End If

        UpdateScreen(Me, "Done!")

        Me.Cursor = Cursors.Default
        DisplayButtons(True)

        PlayWave(ROOT_DRIVE & "\VB.Net\My Projects\_Sounds\transference_complete.wav")

    End Sub

    Private Sub cmdMoveTVWithDelay_Click(sender As Object, e As EventArgs) Handles cmdMoveTVWithDelay.Click

        Dim dtmDate As Date

        If cboTimes.SelectedItem & "" = "" Then

            MessageBox.Show("Need the delay")
            Exit Sub
        End If

        dtmDate = DateAdd(DateInterval.Minute, cboTimes.SelectedItem, Now)

        Me.Text = "Completed Torrents Processor - starting at " & Format(dtmDate, "hh:mm")

        While Now < dtmDate

            My.Application.DoEvents()
        End While

        cmdMoveTV_Click(Nothing, Nothing)

    End Sub

    Private Sub cmdProcessMags_Click(sender As Object, e As EventArgs) Handles cmdProcessMags.Click

        txtAudit.Text = ""

        Me.Cursor = Cursors.WaitCursor
        DisplayButtons(False)

        mobjStats.Reset()

        If cmdShowAudit.Text = ">>" Then

            cmdShowAudit_Click(Nothing, Nothing)

            My.Application.DoEvents()
        End If

        If Not ProcessAssortedMagazineKeepFolderForUnwantedPDFs() Then

            UpdateScreen(Me, "")

            Me.Cursor = Cursors.Default
            DisplayButtons(True)
            Exit Sub
        End If

        If Not ProcessAssortedMagazineFolderForUndownloadedPDFs("") Then

            UpdateScreen(Me, "")

            Me.Cursor = Cursors.Default
            DisplayButtons(True)
            Exit Sub
        End If

        ' Process the unwanted mags folder so that any that are undownloaded are moved to there
        If Not ProcessAssortedMagazineFolderForUndownloadedPDFs(ROOT_DRIVE & "\_Torrent\Completed\50 Assorted Magazines\Delete - Unwanted") Then

            UpdateScreen(Me, "")

            Me.Cursor = Cursors.Default
            DisplayButtons(True)
            Exit Sub
        End If

        If Not ProcessAssortedBooksFolderForUndownloadedEpubs() Then

            UpdateScreen(Me, "")

            Me.Cursor = Cursors.Default
            DisplayButtons(True)
            Exit Sub
        End If

        UpdateScreen(Me, "Done!")

        Me.Cursor = Cursors.Default
        DisplayButtons(True)

        PlaySound(ROOT_DRIVE & "\VB.Net\My Projects\_Sounds\transference_complete.wav")

    End Sub

    Private Sub cmdShowAudit_Click(sender As Object, e As EventArgs) Handles cmdShowAudit.Click

        If cmdShowAudit.Text = ">>" Then

            Me.Width = 1400
            cmdShowAudit.Text = "<<"
        Else

            Me.Width = 411
            cmdShowAudit.Text = ">>"
        End If

    End Sub

    Private Sub frmMain_Resize(sender As Object, e As EventArgs) Handles Me.Resize

        txtAudit.Width = Me.Width - 423
        txtAudit.Height = Me.Height - 142

    End Sub

    Private Sub txtAudit_TextChanged(sender As Object, e As EventArgs) Handles txtAudit.TextChanged

        Dim lngLen As Long

        lngLen = Len(txtAudit.Text)

        If lngLen < 10 Then Exit Sub

        txtAudit.Select(lngLen - 1, lngLen)
        txtAudit.ScrollToCaret()

    End Sub

    Private Sub cmdRemovePageZero_Click(sender As Object, e As EventArgs) Handles cmdRemovePageZero.Click

        Dim objDir As DirectoryInfo, intCount As Integer
        Dim objFile As FileInfo, colFiles() As FileInfo
        Dim strKeepFolder As String, strFolder As String

        If MessageBox.Show("All PDFs been checked?", My.Application.Info.ProductName, MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.No Then

            Exit Sub
        End If

        strFolder = GetRootPath()

        strKeepFolder = strFolder & "\50 Assorted Magazines\Keep"

        objDir = New DirectoryInfo(strFolder & "\50 Assorted Magazines\Keep\RemovePageZero")

        colFiles = objDir.GetFiles()

        intCount = 1

        For Each objFile In colFiles

            UpdateScreen(Me, "Processing " & intCount & " of " & colFiles.Count & " - " & objFile.Name)

            Debug.Print(objFile.Name)

            pdfSharp_RemovePageZero_CompletedTorrentsProcesser(objFile.DirectoryName, objFile.Name, "")

            Me.Show()

            intCount = intCount + 1
        Next

        UpdateScreen(Me, "Finished - backups made...")

    End Sub

    Private Sub cmdPostProcess_Click(sender As Object, e As EventArgs) Handles cmdPostProcess.Click

        txtAudit.Text = ""

        Me.Cursor = Cursors.WaitCursor
        DisplayButtons(False)

        mobjStats.Reset()

        If cmdShowAudit.Text = ">>" Then

            cmdShowAudit_Click(Nothing, Nothing)

            My.Application.DoEvents()
        End If

        If Not ProcessAssortedMagazine_DeleteUnwanted_Folder_For_Miss_Named_PDFs() Then

            UpdateScreen(Me, "")

            Me.Cursor = Cursors.Default
            DisplayButtons(True)
            Exit Sub
        End If

        UpdateScreen(Me, "Done!")

        Me.Cursor = Cursors.Default
        DisplayButtons(True)

        PlaySound(ROOT_DRIVE & "\VB.Net\My Projects\_Sounds\transference_complete.wav")


    End Sub
End Class
