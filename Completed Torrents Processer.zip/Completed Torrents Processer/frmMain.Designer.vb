﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.lblCurrentFile = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuToDo = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOptions = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.cmdProcess = New System.Windows.Forms.Button()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.cmdShowAudit = New System.Windows.Forms.Button()
        Me.lblMusicCount = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lblTorrentCount = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblSubCount = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblSRTCount = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblHTMLCount = New System.Windows.Forms.Label()
        Me.lblDOCCount = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblUnknownCount = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblJPEGCount = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblOPFCount = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblTXTCount = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblNFOCount = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblTVCount = New System.Windows.Forms.Label()
        Me.lblBooksCount = New System.Windows.Forms.Label()
        Me.lblMagsCount = New System.Windows.Forms.Label()
        Me.lblMoviesCount = New System.Windows.Forms.Label()
        Me.lblMags = New System.Windows.Forms.Label()
        Me.lblTV = New System.Windows.Forms.Label()
        Me.lblBooks = New System.Windows.Forms.Label()
        Me.lblMovies = New System.Windows.Forms.Label()
        Me.cmdProcessTV = New System.Windows.Forms.Button()
        Me.cmdMoveTV = New System.Windows.Forms.Button()
        Me.cboDrives = New System.Windows.Forms.ComboBox()
        Me.cmdMoveMags = New System.Windows.Forms.Button()
        Me.prgProgress = New System.Windows.Forms.ProgressBar()
        Me.cmdCopyStructure = New System.Windows.Forms.Button()
        Me.cmdProcessCopiedStruct = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.cmdPreProcess = New System.Windows.Forms.Button()
        Me.cmdMoveTVWithDelay = New System.Windows.Forms.Button()
        Me.cmdProcessMags = New System.Windows.Forms.Button()
        Me.cmdRemovePageZero = New System.Windows.Forms.Button()
        Me.cmdPostProcess = New System.Windows.Forms.Button()
        Me.cboTimes = New System.Windows.Forms.ComboBox()
        Me.txtAudit = New System.Windows.Forms.TextBox()
        Me.StatusStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblCurrentFile, Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 448)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(870, 22)
        Me.StatusStrip1.TabIndex = 0
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'lblCurrentFile
        '
        Me.lblCurrentFile.Name = "lblCurrentFile"
        Me.lblCurrentFile.Size = New System.Drawing.Size(65, 17)
        Me.lblCurrentFile.Text = "CurrentFile"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(119, 17)
        Me.ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Visible = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(870, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuToDo, Me.mnuOptions, Me.ToolStripMenuItem1, Me.mnuExit})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(37, 20)
        Me.mnuFile.Text = "&File"
        '
        'mnuToDo
        '
        Me.mnuToDo.Name = "mnuToDo"
        Me.mnuToDo.Size = New System.Drawing.Size(116, 22)
        Me.mnuToDo.Text = "To Do"
        '
        'mnuOptions
        '
        Me.mnuOptions.Name = "mnuOptions"
        Me.mnuOptions.Size = New System.Drawing.Size(116, 22)
        Me.mnuOptions.Text = "&Options"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(113, 6)
        '
        'mnuExit
        '
        Me.mnuExit.Name = "mnuExit"
        Me.mnuExit.Size = New System.Drawing.Size(116, 22)
        Me.mnuExit.Text = "E&xit"
        '
        'cmdProcess
        '
        Me.cmdProcess.Location = New System.Drawing.Point(7, 287)
        Me.cmdProcess.Name = "cmdProcess"
        Me.cmdProcess.Size = New System.Drawing.Size(95, 25)
        Me.cmdProcess.TabIndex = 0
        Me.cmdProcess.Text = "Process All"
        Me.cmdProcess.UseVisualStyleBackColor = True
        '
        'cmdClose
        '
        Me.cmdClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdClose.Location = New System.Drawing.Point(765, 420)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Size = New System.Drawing.Size(95, 25)
        Me.cmdClose.TabIndex = 11
        Me.cmdClose.Text = "Close"
        Me.cmdClose.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cmdShowAudit)
        Me.GroupBox1.Controls.Add(Me.lblMusicCount)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Controls.Add(Me.lblTVCount)
        Me.GroupBox1.Controls.Add(Me.lblBooksCount)
        Me.GroupBox1.Controls.Add(Me.lblMagsCount)
        Me.GroupBox1.Controls.Add(Me.lblMoviesCount)
        Me.GroupBox1.Controls.Add(Me.lblMags)
        Me.GroupBox1.Controls.Add(Me.lblTV)
        Me.GroupBox1.Controls.Add(Me.lblBooks)
        Me.GroupBox1.Controls.Add(Me.lblMovies)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 31)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(393, 246)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Completed Torrents Processor"
        '
        'cmdShowAudit
        '
        Me.cmdShowAudit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdShowAudit.Location = New System.Drawing.Point(342, 75)
        Me.cmdShowAudit.Name = "cmdShowAudit"
        Me.cmdShowAudit.Size = New System.Drawing.Size(33, 28)
        Me.cmdShowAudit.TabIndex = 19
        Me.cmdShowAudit.TabStop = False
        Me.cmdShowAudit.Text = ">>"
        Me.ToolTip1.SetToolTip(Me.cmdShowAudit, "Show/Hide audit")
        Me.cmdShowAudit.UseVisualStyleBackColor = True
        '
        'lblMusicCount
        '
        Me.lblMusicCount.AutoSize = True
        Me.lblMusicCount.Location = New System.Drawing.Point(74, 75)
        Me.lblMusicCount.Name = "lblMusicCount"
        Me.lblMusicCount.Size = New System.Drawing.Size(13, 13)
        Me.lblMusicCount.TabIndex = 11
        Me.lblMusicCount.Text = "0"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(24, 75)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(38, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Music:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lblTorrentCount)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.lblSubCount)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.lblSRTCount)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.lblHTMLCount)
        Me.GroupBox2.Controls.Add(Me.lblDOCCount)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.lblUnknownCount)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.lblJPEGCount)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.lblOPFCount)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.lblTXTCount)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.lblNFOCount)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Location = New System.Drawing.Point(27, 104)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(348, 130)
        Me.GroupBox2.TabIndex = 9
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Crap Files"
        '
        'lblTorrentCount
        '
        Me.lblTorrentCount.AutoSize = True
        Me.lblTorrentCount.Location = New System.Drawing.Point(212, 78)
        Me.lblTorrentCount.Name = "lblTorrentCount"
        Me.lblTorrentCount.Size = New System.Drawing.Size(13, 13)
        Me.lblTorrentCount.TabIndex = 28
        Me.lblTorrentCount.Text = "0"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(167, 78)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(41, 13)
        Me.Label10.TabIndex = 27
        Me.Label10.Text = "Torrent"
        '
        'lblSubCount
        '
        Me.lblSubCount.AutoSize = True
        Me.lblSubCount.Location = New System.Drawing.Point(140, 78)
        Me.lblSubCount.Name = "lblSubCount"
        Me.lblSubCount.Size = New System.Drawing.Size(13, 13)
        Me.lblSubCount.TabIndex = 26
        Me.lblSubCount.Text = "0"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(95, 78)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(29, 13)
        Me.Label12.TabIndex = 25
        Me.Label12.Text = "SUB"
        '
        'lblSRTCount
        '
        Me.lblSRTCount.AutoSize = True
        Me.lblSRTCount.Location = New System.Drawing.Point(66, 78)
        Me.lblSRTCount.Name = "lblSRTCount"
        Me.lblSRTCount.Size = New System.Drawing.Size(13, 13)
        Me.lblSRTCount.TabIndex = 24
        Me.lblSRTCount.Text = "0"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(21, 78)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(29, 13)
        Me.Label14.TabIndex = 23
        Me.Label14.Text = "SRT"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(212, 50)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(13, 13)
        Me.Label9.TabIndex = 22
        Me.Label9.Text = "0"
        '
        'lblHTMLCount
        '
        Me.lblHTMLCount.AutoSize = True
        Me.lblHTMLCount.Location = New System.Drawing.Point(167, 50)
        Me.lblHTMLCount.Name = "lblHTMLCount"
        Me.lblHTMLCount.Size = New System.Drawing.Size(37, 13)
        Me.lblHTMLCount.TabIndex = 21
        Me.lblHTMLCount.Text = "HTML"
        '
        'lblDOCCount
        '
        Me.lblDOCCount.AutoSize = True
        Me.lblDOCCount.Location = New System.Drawing.Point(140, 50)
        Me.lblDOCCount.Name = "lblDOCCount"
        Me.lblDOCCount.Size = New System.Drawing.Size(13, 13)
        Me.lblDOCCount.TabIndex = 20
        Me.lblDOCCount.Text = "0"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(95, 50)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(30, 13)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = "DOC"
        '
        'lblUnknownCount
        '
        Me.lblUnknownCount.AutoSize = True
        Me.lblUnknownCount.Location = New System.Drawing.Point(95, 104)
        Me.lblUnknownCount.Name = "lblUnknownCount"
        Me.lblUnknownCount.Size = New System.Drawing.Size(13, 13)
        Me.lblUnknownCount.TabIndex = 18
        Me.lblUnknownCount.Text = "0"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(21, 104)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(53, 13)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "Unknown"
        '
        'lblJPEGCount
        '
        Me.lblJPEGCount.AutoSize = True
        Me.lblJPEGCount.Location = New System.Drawing.Point(211, 28)
        Me.lblJPEGCount.Name = "lblJPEGCount"
        Me.lblJPEGCount.Size = New System.Drawing.Size(13, 13)
        Me.lblJPEGCount.TabIndex = 16
        Me.lblJPEGCount.Text = "0"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(167, 28)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(34, 13)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "JPEG"
        '
        'lblOPFCount
        '
        Me.lblOPFCount.AutoSize = True
        Me.lblOPFCount.Location = New System.Drawing.Point(140, 28)
        Me.lblOPFCount.Name = "lblOPFCount"
        Me.lblOPFCount.Size = New System.Drawing.Size(13, 13)
        Me.lblOPFCount.TabIndex = 14
        Me.lblOPFCount.Text = "0"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(95, 28)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(28, 13)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "OPF"
        '
        'lblTXTCount
        '
        Me.lblTXTCount.AutoSize = True
        Me.lblTXTCount.Location = New System.Drawing.Point(66, 50)
        Me.lblTXTCount.Name = "lblTXTCount"
        Me.lblTXTCount.Size = New System.Drawing.Size(13, 13)
        Me.lblTXTCount.TabIndex = 12
        Me.lblTXTCount.Text = "0"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(21, 50)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(28, 13)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "TXT"
        '
        'lblNFOCount
        '
        Me.lblNFOCount.AutoSize = True
        Me.lblNFOCount.Location = New System.Drawing.Point(66, 28)
        Me.lblNFOCount.Name = "lblNFOCount"
        Me.lblNFOCount.Size = New System.Drawing.Size(13, 13)
        Me.lblNFOCount.TabIndex = 10
        Me.lblNFOCount.Text = "0"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(21, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "NFO"
        '
        'lblTVCount
        '
        Me.lblTVCount.AutoSize = True
        Me.lblTVCount.Location = New System.Drawing.Point(283, 26)
        Me.lblTVCount.Name = "lblTVCount"
        Me.lblTVCount.Size = New System.Drawing.Size(13, 13)
        Me.lblTVCount.TabIndex = 7
        Me.lblTVCount.Text = "0"
        '
        'lblBooksCount
        '
        Me.lblBooksCount.AutoSize = True
        Me.lblBooksCount.Location = New System.Drawing.Point(283, 50)
        Me.lblBooksCount.Name = "lblBooksCount"
        Me.lblBooksCount.Size = New System.Drawing.Size(13, 13)
        Me.lblBooksCount.TabIndex = 6
        Me.lblBooksCount.Text = "0"
        '
        'lblMagsCount
        '
        Me.lblMagsCount.AutoSize = True
        Me.lblMagsCount.Location = New System.Drawing.Point(74, 50)
        Me.lblMagsCount.Name = "lblMagsCount"
        Me.lblMagsCount.Size = New System.Drawing.Size(13, 13)
        Me.lblMagsCount.TabIndex = 5
        Me.lblMagsCount.Text = "0"
        '
        'lblMoviesCount
        '
        Me.lblMoviesCount.AutoSize = True
        Me.lblMoviesCount.Location = New System.Drawing.Point(74, 26)
        Me.lblMoviesCount.Name = "lblMoviesCount"
        Me.lblMoviesCount.Size = New System.Drawing.Size(13, 13)
        Me.lblMoviesCount.TabIndex = 4
        Me.lblMoviesCount.Text = "0"
        '
        'lblMags
        '
        Me.lblMags.AutoSize = True
        Me.lblMags.Location = New System.Drawing.Point(24, 50)
        Me.lblMags.Name = "lblMags"
        Me.lblMags.Size = New System.Drawing.Size(36, 13)
        Me.lblMags.TabIndex = 3
        Me.lblMags.Text = "Mags:"
        '
        'lblTV
        '
        Me.lblTV.AutoSize = True
        Me.lblTV.Location = New System.Drawing.Point(226, 26)
        Me.lblTV.Name = "lblTV"
        Me.lblTV.Size = New System.Drawing.Size(24, 13)
        Me.lblTV.TabIndex = 2
        Me.lblTV.Text = "TV:"
        '
        'lblBooks
        '
        Me.lblBooks.AutoSize = True
        Me.lblBooks.Location = New System.Drawing.Point(226, 50)
        Me.lblBooks.Name = "lblBooks"
        Me.lblBooks.Size = New System.Drawing.Size(40, 13)
        Me.lblBooks.TabIndex = 1
        Me.lblBooks.Text = "Books:"
        '
        'lblMovies
        '
        Me.lblMovies.AutoSize = True
        Me.lblMovies.Location = New System.Drawing.Point(24, 26)
        Me.lblMovies.Name = "lblMovies"
        Me.lblMovies.Size = New System.Drawing.Size(44, 13)
        Me.lblMovies.TabIndex = 0
        Me.lblMovies.Text = "Movies:"
        '
        'cmdProcessTV
        '
        Me.cmdProcessTV.Location = New System.Drawing.Point(7, 317)
        Me.cmdProcessTV.Name = "cmdProcessTV"
        Me.cmdProcessTV.Size = New System.Drawing.Size(95, 25)
        Me.cmdProcessTV.TabIndex = 3
        Me.cmdProcessTV.Text = "Process TV"
        Me.cmdProcessTV.UseVisualStyleBackColor = True
        '
        'cmdMoveTV
        '
        Me.cmdMoveTV.Location = New System.Drawing.Point(7, 348)
        Me.cmdMoveTV.Name = "cmdMoveTV"
        Me.cmdMoveTV.Size = New System.Drawing.Size(95, 25)
        Me.cmdMoveTV.TabIndex = 6
        Me.cmdMoveTV.Text = "Move TV"
        Me.cmdMoveTV.UseVisualStyleBackColor = True
        '
        'cboDrives
        '
        Me.cboDrives.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDrives.FormattingEnabled = True
        Me.cboDrives.Location = New System.Drawing.Point(108, 350)
        Me.cboDrives.Name = "cboDrives"
        Me.cboDrives.Size = New System.Drawing.Size(90, 21)
        Me.cboDrives.TabIndex = 7
        '
        'cmdMoveMags
        '
        Me.cmdMoveMags.Location = New System.Drawing.Point(7, 410)
        Me.cmdMoveMags.Name = "cmdMoveMags"
        Me.cmdMoveMags.Size = New System.Drawing.Size(95, 25)
        Me.cmdMoveMags.TabIndex = 10
        Me.cmdMoveMags.Text = "Move Mags"
        Me.cmdMoveMags.UseVisualStyleBackColor = True
        '
        'prgProgress
        '
        Me.prgProgress.Location = New System.Drawing.Point(200, 350)
        Me.prgProgress.Name = "prgProgress"
        Me.prgProgress.Size = New System.Drawing.Size(196, 23)
        Me.prgProgress.TabIndex = 11
        Me.prgProgress.Visible = False
        '
        'cmdCopyStructure
        '
        Me.cmdCopyStructure.Location = New System.Drawing.Point(108, 317)
        Me.cmdCopyStructure.Name = "cmdCopyStructure"
        Me.cmdCopyStructure.Size = New System.Drawing.Size(145, 25)
        Me.cmdCopyStructure.TabIndex = 4
        Me.cmdCopyStructure.Text = "Copy Structure - Completed"
        Me.ToolTip1.SetToolTip(Me.cmdCopyStructure, "Creates a copy of completed in temp to check code changes")
        Me.cmdCopyStructure.UseVisualStyleBackColor = True
        '
        'cmdProcessCopiedStruct
        '
        Me.cmdProcessCopiedStruct.Location = New System.Drawing.Point(259, 317)
        Me.cmdProcessCopiedStruct.Name = "cmdProcessCopiedStruct"
        Me.cmdProcessCopiedStruct.Size = New System.Drawing.Size(128, 25)
        Me.cmdProcessCopiedStruct.TabIndex = 5
        Me.cmdProcessCopiedStruct.Text = "Process Copied"
        Me.ToolTip1.SetToolTip(Me.cmdProcessCopiedStruct, "Runs Process All on a folder in temp (created with Copy Stucture)")
        Me.cmdProcessCopiedStruct.UseVisualStyleBackColor = True
        '
        'cmdPreProcess
        '
        Me.cmdPreProcess.Location = New System.Drawing.Point(108, 287)
        Me.cmdPreProcess.Name = "cmdPreProcess"
        Me.cmdPreProcess.Size = New System.Drawing.Size(90, 25)
        Me.cmdPreProcess.TabIndex = 1
        Me.cmdPreProcess.Text = "Pre Process"
        Me.ToolTip1.SetToolTip(Me.cmdPreProcess, "Account for folders like 50 Assorted Books Collection Set-18 by copying files all" &
        " into the same folder")
        Me.cmdPreProcess.UseVisualStyleBackColor = True
        '
        'cmdMoveTVWithDelay
        '
        Me.cmdMoveTVWithDelay.Location = New System.Drawing.Point(7, 379)
        Me.cmdMoveTVWithDelay.Name = "cmdMoveTVWithDelay"
        Me.cmdMoveTVWithDelay.Size = New System.Drawing.Size(95, 25)
        Me.cmdMoveTVWithDelay.TabIndex = 8
        Me.cmdMoveTVWithDelay.Text = "TV with delay"
        Me.ToolTip1.SetToolTip(Me.cmdMoveTVWithDelay, "Move TV with a delay")
        Me.cmdMoveTVWithDelay.UseVisualStyleBackColor = True
        '
        'cmdProcessMags
        '
        Me.cmdProcessMags.Location = New System.Drawing.Point(203, 287)
        Me.cmdProcessMags.Name = "cmdProcessMags"
        Me.cmdProcessMags.Size = New System.Drawing.Size(85, 25)
        Me.cmdProcessMags.TabIndex = 2
        Me.cmdProcessMags.Text = "Process"
        Me.ToolTip1.SetToolTip(Me.cmdProcessMags, "Account for fact that not all mags/books are downloaded and split them into Keep " &
        "and  Delete folders")
        Me.cmdProcessMags.UseVisualStyleBackColor = True
        '
        'cmdRemovePageZero
        '
        Me.cmdRemovePageZero.Location = New System.Drawing.Point(259, 379)
        Me.cmdRemovePageZero.Name = "cmdRemovePageZero"
        Me.cmdRemovePageZero.Size = New System.Drawing.Size(128, 25)
        Me.cmdRemovePageZero.TabIndex = 19
        Me.cmdRemovePageZero.Text = "Remove Page Zero"
        Me.ToolTip1.SetToolTip(Me.cmdRemovePageZero, "Removes first page from ALL mags in 50 Assorted Magazines\Keep\RemovePageZero")
        Me.cmdRemovePageZero.UseVisualStyleBackColor = True
        '
        'cmdPostProcess
        '
        Me.cmdPostProcess.Location = New System.Drawing.Point(292, 287)
        Me.cmdPostProcess.Name = "cmdPostProcess"
        Me.cmdPostProcess.Size = New System.Drawing.Size(85, 25)
        Me.cmdPostProcess.TabIndex = 3
        Me.cmdPostProcess.Text = "Post Process"
        Me.ToolTip1.SetToolTip(Me.cmdPostProcess, "In 50 Assorted Magazines\Delete - Unwanted there may be files that aren't quite n" &
        "amed right. For example 'All About Space No 84 2018'  this is missing a dash so " &
        "its not seen as a mag")
        Me.cmdPostProcess.UseVisualStyleBackColor = True
        '
        'cboTimes
        '
        Me.cboTimes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTimes.FormattingEnabled = True
        Me.cboTimes.Location = New System.Drawing.Point(108, 379)
        Me.cboTimes.Name = "cboTimes"
        Me.cboTimes.Size = New System.Drawing.Size(82, 21)
        Me.cboTimes.TabIndex = 9
        '
        'txtAudit
        '
        Me.txtAudit.Location = New System.Drawing.Point(405, 34)
        Me.txtAudit.Multiline = True
        Me.txtAudit.Name = "txtAudit"
        Me.txtAudit.ReadOnly = True
        Me.txtAudit.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtAudit.Size = New System.Drawing.Size(455, 355)
        Me.txtAudit.TabIndex = 18
        Me.txtAudit.TabStop = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.cmdClose
        Me.ClientSize = New System.Drawing.Size(870, 470)
        Me.Controls.Add(Me.cmdPostProcess)
        Me.Controls.Add(Me.cmdRemovePageZero)
        Me.Controls.Add(Me.txtAudit)
        Me.Controls.Add(Me.cmdProcessMags)
        Me.Controls.Add(Me.cboTimes)
        Me.Controls.Add(Me.cmdMoveTVWithDelay)
        Me.Controls.Add(Me.cmdPreProcess)
        Me.Controls.Add(Me.cmdProcessCopiedStruct)
        Me.Controls.Add(Me.cmdCopyStructure)
        Me.Controls.Add(Me.prgProgress)
        Me.Controls.Add(Me.cmdMoveMags)
        Me.Controls.Add(Me.cboDrives)
        Me.Controls.Add(Me.cmdMoveTV)
        Me.Controls.Add(Me.cmdProcessTV)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cmdProcess)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MinimumSize = New System.Drawing.Size(411, 497)
        Me.Name = "frmMain"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.Text = "Completed Torrents Processor - Remove all seeding Torrents!"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents mnuFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuOptions As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmdProcess As System.Windows.Forms.Button
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lblTV As System.Windows.Forms.Label
    Friend WithEvents lblBooks As System.Windows.Forms.Label
    Friend WithEvents lblMovies As System.Windows.Forms.Label
    Friend WithEvents lblTVCount As System.Windows.Forms.Label
    Friend WithEvents lblBooksCount As System.Windows.Forms.Label
    Friend WithEvents lblMagsCount As System.Windows.Forms.Label
    Friend WithEvents lblMoviesCount As System.Windows.Forms.Label
    Friend WithEvents lblMags As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents lblNFOCount As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblTXTCount As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblJPEGCount As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lblOPFCount As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lblCurrentFile As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblMusicCount As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lblUnknownCount As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents lblTorrentCount As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lblSubCount As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents lblSRTCount As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents lblHTMLCount As System.Windows.Forms.Label
    Friend WithEvents lblDOCCount As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents cmdProcessTV As System.Windows.Forms.Button
    Friend WithEvents cmdMoveTV As System.Windows.Forms.Button
    Friend WithEvents cboDrives As System.Windows.Forms.ComboBox
    Friend WithEvents cmdMoveMags As System.Windows.Forms.Button
    Friend WithEvents prgProgress As System.Windows.Forms.ProgressBar
    Friend WithEvents mnuToDo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmdCopyStructure As System.Windows.Forms.Button
    Friend WithEvents cmdProcessCopiedStruct As System.Windows.Forms.Button
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents cmdPreProcess As System.Windows.Forms.Button
    Friend WithEvents cmdMoveTVWithDelay As Button
    Friend WithEvents cboTimes As ComboBox
    Friend WithEvents cmdProcessMags As System.Windows.Forms.Button
    Friend WithEvents txtAudit As TextBox
    Friend WithEvents cmdShowAudit As Button
    Friend WithEvents cmdRemovePageZero As System.Windows.Forms.Button
    Friend WithEvents cmdPostProcess As System.Windows.Forms.Button
End Class
