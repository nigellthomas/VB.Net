﻿Public Class clsFileTypes

    ' Crap
    Public NFO As Integer
    Public TXT As Integer
    Public OPF As Integer

    ' Movies
    Private mintMovieFilesCount As Integer  ' Private Property Declaration
    Private mintMKV As Integer  ' Private Property Declaration
    Private mintMP4 As Integer  ' Private Property Declaration
    Private mintAVI As Integer  ' Private Property Declaration
    Private mintWMV As Integer  ' Private Property Declaration
    Public SRT As Integer
    Private mintMPEG As Integer  ' Private Property Declaration
    Private mintM2TS As Integer  ' Private Property Declaration
    Private mintFLV As Integer  ' Private Property Declaration
    Private mintASF As Integer  ' Private Property Declaration

    ' Books
    Public UniqueBooksCount As Integer
    Public BooksWithinSubFolder As Boolean
    Public PDF As Integer
    Public EPUB As Integer
    Public MOBI As Integer
    Public AZW3 As Integer
    Public DJVU As Integer
    Public PRC As Integer

    Public PDFs As String
    Public EPUBs As String
    Public MOBIs As String
    Public AZW3s As String
    Public DJVUs As String
    Public PRCs As String

    ' Music
    Public UniqueMusicCount As Integer
    Private mintMP3 As Integer
    Private mintFLAC As Integer
    Private mintWAV As Integer
    Private mintAC3 As Integer

    Public MP3s As String
    Public FLACs As String
    Public WAVs As String
    Public AC3s As String

    Public ISO As Integer
    Public ISOs As String

    ' FileNames
    Public AVIs As String
    Public MP4s As String
    Public WMVs As String
    Public MKVs As String
    Public MPEGs As String
    Public M2TSs As String
    Public FLVs As String
    Public ASFs As String

    Public JPGs As String
    Public SRTs As String

    Public RAR As Integer
    Public RARs As String
    Public Archive_7z As Integer
    Public Archive_7zs As String

    Private mintJPG As Integer  ' Private Property Declaration

    Private mintUnknown As Integer  ' Private Property Declaration
    Public Unknowns As String

    Public DAT As Integer

    Public strPDFBooks() As String
    Public strMOBIBooks() As String
    Public strEPUBBooks() As String
    Public strAZW3Books() As String
    Public strDJVUBooks() As String
    Public strPRCBooks() As String

    Public Property ASF() As Integer
        Get
            ASF = mintASF
        End Get

        Set(ByVal Value As Integer)
            Try
                mintASF = Value
                mintMovieFilesCount = mintMovieFilesCount + 1
            Catch ex As Exception

            End Try
        End Set
    End Property
    
    Public Property MPEG() As Integer
        Get
            MPEG = mintMPEG
        End Get

        Set(ByVal Value As Integer)
            Try
                mintMPEG = Value
                mintMovieFilesCount = mintMovieFilesCount + 1
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public Property FLV() As Integer
        Get
            FLV = mintflv
        End Get

        Set(ByVal Value As Integer)
            Try
                mintflv = Value
                mintMovieFilesCount = mintMovieFilesCount + 1
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public Property M2tS() As Integer
        Get
            M2tS = mintM2TS
        End Get

        Set(ByVal Value As Integer)
            Try
                mintM2TS = Value
                mintMovieFilesCount = mintMovieFilesCount + 1
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public Property WMV() As Integer
        Get
            WMV = mintWMV
        End Get

        Set(ByVal Value As Integer)
            Try
                mintWMV = Value
                mintMovieFilesCount = mintMovieFilesCount + 1
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public Property JPG() As Integer
        Get
            JPG = mintJPG
        End Get

        Set(ByVal Value As Integer)
            Try
                mintJPG = Value
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public Property MP4() As Integer
        Get
            MP4 = mintMP4
        End Get

        Set(ByVal Value As Integer)
            Try
                mintMP4 = Value
                mintMovieFilesCount = mintMovieFilesCount + 1
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public Property AVI() As Integer
        Get
            AVI = mintAVI
        End Get

        Set(ByVal Value As Integer)
            Try
                mintAVI = Value
                mintMovieFilesCount = mintMovieFilesCount + 1
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public ReadOnly Property MovieFilesCount() As Integer
        Get
            MovieFilesCount = mintMovieFilesCount
        End Get

    End Property

    Public Property MKV() As Integer
        Get
            MKV = mintMKV
        End Get

        Set(ByVal Value As Integer)
            Try
                mintMKV = Value
                mintMovieFilesCount = mintMovieFilesCount + 1
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public Property Unknown() As Integer
        Get
            Unknown = mintUnknown
        End Get

        Set(ByVal Value As Integer)
            Try
                mintUnknown = Value
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public Property MP3() As Integer
        Get
            MP3 = mintMP3
        End Get

        Set(ByVal Value As Integer)
            Try
                mintMP3 = Value
                UniqueMusicCount = UniqueMusicCount + 1
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public Property AC3() As Integer
        Get
            AC3 = mintAC3
        End Get

        Set(ByVal Value As Integer)
            Try
                mintAC3 = Value
                UniqueMusicCount = UniqueMusicCount + 1
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public Property FLAC() As Integer
        Get
            FLAC = mintFLAC
        End Get

        Set(ByVal Value As Integer)
            Try
                mintFLAC = Value
                UniqueMusicCount = UniqueMusicCount + 1
            Catch ex As Exception

            End Try
        End Set
    End Property

    Public Property WAV() As Integer
        Get
            WAV = mintWAV
        End Get

        Set(ByVal Value As Integer)
            Try
                mintWAV = Value
                UniqueMusicCount = UniqueMusicCount + 1
            Catch ex As Exception

            End Try
        End Set
    End Property

End Class
