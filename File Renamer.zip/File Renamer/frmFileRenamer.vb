﻿Imports System
Imports System.IO
Imports Janus.Windows.GridEX

Public Class frmFileRenamer

    Private mobjColumn_Files As ColumnHeader

    Private mstrLoadType As String = ""

    Private Const COL_NAME As Integer = 0
    Private mstrLastExtension As String = ""

    Private mblnStopFireOnContents As Boolean = False

    Private Sub frmFileRenamer_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        lblMessage.Text = ""

        LoadOperations(lstOperations)

        LoadContentOptions()

        txtPath.Text = My.Settings.LastPath

        txtPath.Items.Add(txtPath.Text)

        cmdUpdFilesApplyProposedFilenames.Enabled = False

    End Sub

    Private Sub lstOperations_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstOperations.SelectedIndexChanged

        Dim strPath As String

        txtUpdFilenamesHelp.Text = ""
        txtCurrentFilename.ReadOnly = True

        cboOperation1.Visible = False
        lblOperationCombo1.Visible = False

        cboOperation2.Visible = False
        lblOperationCombo2.Visible = False

        If lstOperations.SelectedItems(0).ToString = "" Then

            cmdUpdFilesUpdateFilenamesInListview.Enabled = False
            cmdUpdFilesApplyProposedFilenames.Enabled = False

            fraOperations.Text = "Operations"

            Exit Sub
        Else

            cmdUpdFilesUpdateFilenamesInListview.Enabled = True

            fraOperations.Text = "Operations - " & lstOperations.SelectedItems(0).ToString
        End If

        Select Case lstOperations.SelectedItems(0).ToString

            Case OPERATION_SORT_OUT_1x01

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes " & vbCrLf & vbCrLf & "Reunion 1x01.mkv " & vbCrLf & vbCrLf & "To " & vbCrLf & vbCrLf & "Reunion S01E01.mkv"

                cmdUpdateListview.Visible = False

            Case OPERATION_SORT_OUT_1OF3

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes " & vbCrLf & vbCrLf & "BBC Art Of Scandinavia 1of3 Dark Night Of The Soul.mkv " & vbCrLf & vbCrLf & "To " & vbCrLf & vbCrLf & "BBC Art Of Scandinavia S01E01 Dark Night Of The Soul.mkv"

                cmdUpdateListview.Visible = False

            Case OPERATION_SORT_OUT_3_DIGIT_SEASONS_AT_END

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes Allo Allo 410.avi To Allo Allo S04E10.avi" & vbCrLf & vbCrLf & "Run Gen. Cleanup so season indicator Is last text On the right - Doesn't work otherwise" & vbCrLf & vbCrLf & "Use Change 1st numeric to season format"

                cmdUpdateListview.visible = False

            Case OPERATION_CHANGE_NUMERIC_TO_3_DIGIT_SEASON

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes " & vbCrLf & vbCrLf & "Allo Allo 410 - Episode Name.avi to " & vbCrLf & vbCrLf & "Allo Allo S04E10 - Episode Name.avi" & vbCrLf & vbCrLf & "Looks for 1st 3 digit number."

                cmdUpdateListview.visible = False

            Case OPERATION_GEN_CLEANUP_AND_REMOVE_TEXT_AFTER_HDTV

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Runs General Cleanup and then Remove Test After HDTV etc."

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.visible = False

            Case OPERATION_INDIVIDUAL_EDIT

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Allows you to manually update a single filename to take care of oddball ones"

                txtCurrentFilename.ReadOnly = False
                txtCurrentFilename.Refresh()

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.visible = False

            Case OPERATION_GENERAL_CLEANUP, OPERATION_APPLY_PROPERISE_CASE, OPERATION_REMOVE_BRACKETS, OPERATION_REMOVE_BRACKETS_FROM_END, OPERATION_CLEANUP_BRACKETS

                txtUpdFilenamesHelp.Text = ""

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.Visible = False

            Case OPERATION_TEXT_REPLACEMENT_HDTV

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Removal of fixed strings like " & vbCrLf & vbCrLf & "FiNAL.FASTSUB.VOSTFR.HDTV.XviD -F4ST" _
                                         & vbCrLf & "KVCD.by.TinPusher(TUS.Release)" _
                                         & vbCrLf & "WS.PDTV.XviD -RAWNiTRO" _
                                         & vbCrLf & "iNTERNAL.DVDRip.XviD -RAWNiTRO"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.visible = False

            Case OPERATION_TEXT_REPLACEMENT_WITH_MINOR_CLEANUP, OPERATION_TEXT_REPLACEMENT_WITHOUT_MINOR_CLEANUP

                lblOperationLabel1.Text = "Replace"
                lblOperationLabel2.Text = "With"

                lblOperationLabel1.Visible = True
                lblOperationLabel2.Visible = True

                lblOperationLabel2.Left = txtOperationTextbox2.Left
                lblOperationLabel2.Top = lblOperationLabel1.Top

                txtOperationTextbox1.Visible = True
                txtOperationTextbox2.Visible = True

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Straight forward replacement of 'abc' with 'xyz'." & vbCrLf & vbCrLf & "Sometimes you will need WITHOUT Minor Cleanup - to do the change Sql Server to SQL Server etc."

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.visible = False

            Case OPERATION_REMOVE_TEXT_AFTER_CUSTOM_TEXT

                lblOperationLabel1.Text = "Text"

                lblOperationLabel1.Visible = True
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = True
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Find 1st instance of user defined text and remove it and all text after"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.visible = False

            Case OPERATION_REMOVE_CURRENT_TITLES

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "1000 Ways To Die S01E03 wrong title.mp4 " & vbCrLf & vbCrLf & " becomes " & vbCrLf & vbCrLf & " 1000 Ways To Die S01E03.mp4" _
                                         & vbCrLf & vbCrLf & " ready for the correct title to be applied using 'Apply Titles'"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.visible = False

            Case OPERATION_MOVE_BRACKETS_TO_END

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Healthy Food Guide (Aus) - Apr 2020.pdf" & vbCrLf & vbCrLf & " becomes " & vbCrLf & vbCrLf & "Healthy Food Guide - Apr 2020 (Aus).pdf"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.Visible = False

            Case OPERATION_APPLY_TITLES

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Apply episode titles from Seasons tab." & vbCrLf & vbCrLf & "May need to run Remove Current Titles first."

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.visible = False

            Case OPERATION_REMOVE_TEXT_AFTER_HDTV

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Finds text like HDTV in 1000 Ways To Die S01E03 HDTV 480p XVid.api and changes name to 1000 Ways To Die S01E03.api. " & vbCrLf & vbCrLf & "Assumes general cleanup has been run to get rid of any '.'"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.visible = False

            Case OPERATION_REVERSE_NAMES

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Reverse the filenames around a 'dash' character Rockin' - Quo.mp3 to Quo - Rockin'.mp3"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.visible = False

            Case OPERATION_BOOK_CLEANUP

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Removes 'The' and 'A' from start after applying a general cleanup"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.Visible = False

            Case OPERATION_REMOVE_NUMERICS

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Remove any numerics from the filenames"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.visible = False

            Case OPERATION_REMOVE_1ST_NUMERIC

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Remove 1st numeric from the filenames"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.Visible = False

            Case OPERATION_MARK_AS_COMPRESSED

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Careful!" & vbCrLf & vbCrLf & "Changes all or selected files from say Vb.pdf to Vb (Comp).pdf" &
                                           vbCrLf & vbCrLf & "Use Filter listview by text to pick out files with _compressed" &
                                           vbCrLf & vbCrLf & "Use   *_compressed*   and then   * (Comp)* "

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.Visible = False

            Case OPERATION_MAGAZINE_CLEANUP

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Applies a set of steps for magazines"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.visible = False

            Case OPERATION_ENSURE_ALL_FILES_NAMED_AFTER_FOLDER

                lblOperationLabel1.Text = "Folder Name"
                lblOperationLabel2.Text = "The path used assumes it follows the magazine format - All About History\2016 etc."

                lblOperationLabel1.Visible = True
                lblOperationLabel2.Visible = True

                lblOperationLabel2.Left = lblOperationLabel1.Left
                lblOperationLabel2.Top = lblOperationLabel1.Top + 55

                txtOperationTextbox1.Visible = True
                txtOperationTextbox2.Visible = False

                strPath = GetNameOfLastButOneFolderInPath(txtPath.Text)

                txtOperationTextbox1.Text = Mid(strPath, 1, InStr(strPath, "\") - 1)

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Use for magazines for example " & vbCrLf & vbCrLf & "AAS - No 20.pdf becomes All About Space - No 20.pdf" _
                                         & vbCrLf & vbCrLf & "All About Space No 21.pdf becomes All About Space - No 21.pdf"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.visible = False

            Case OPERATION_RENAME_PDFS_BASED_ON_INTERNAL_DETAILS

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Updates filenames of .PDFs based on the <dc:creator> & <dc:title> tags within the PDFs"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.visible = False

            Case OPERATION_RENAME_MOBIS_BASED_ON_INTERNAL_DETAILS

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Updates filenames of .MOBIs. Only the bookname can be updated." & vbCrLf & vbCrLf & "Find <html> and go backwards until a non zero char is found, then carry on until a 00 char is found." & vbCrLf & vbCrLf & "You can have 00 00 00 Title<html> or 00 00 00 Title 00 00 00<html>"

                chkCheckBox1.Visible = True
                chkCheckBox1.Text = "Author First in Title? ie Peter Benchley - Jaws.mobi or Jaws - Peter Benchley.mobi"

                chkCheckBox1.Top = txtCurrentFilename.Top + 30

                chkCheckBox2.Visible = True
                chkCheckBox2.Text = "Authors Name in Titles? ie jaw.mobi or The Bib.mobi"

                chkCheckBox2.Top = chkCheckBox1.Top + 20

                cmdUpdateListview.visible = False

            Case OPERATION_ADD_TEXT_TO_START

                lblOperationLabel1.Text = "Text"

                lblOperationLabel1.Visible = True
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = True
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Adds text from the Start of a filename"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False
                cmdUpdateListview.Visible = False

            Case OPERATION_ADD_TEXT_TO_END

                lblOperationLabel1.Text = "Text"

                lblOperationLabel1.Visible = True
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = True
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Adds text to the end of a filename"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False
                cmdUpdateListview.Visible = False

            Case OPERATION_REMOVE_TEXT_FROM_START

                lblOperationLabel1.Text = "Text"

                lblOperationLabel1.Visible = True
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = True
                txtOperationTextbox2.Visible = False

                If txtOperationTextbox1.Text = "" Then txtOperationTextbox1.Text = "The "

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Removes text from the Start of a filename. " & vbCrLf & "Useful for books to remove the 'The ' from the bookname so that potential duplicates are easier to find. i.e. From 'The Selfish Gene.pdf' to 'Selfish Gene.pdf'"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.visible = False

            Case OPERATION_FILTER_BY_TEXT

                lblOperationLabel1.Text = "Text"

                lblOperationLabel1.Visible = True
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = True
                txtOperationTextbox2.Visible = False

                txtOperationTextbox1.Text = ""

                cmdUpdateListview.Visible = True
                cmdUpdateListview.Left = txtOperationTextbox1.Left + txtOperationTextbox1.Width + 10
                cmdUpdateListview.Top = txtOperationTextbox1.Top

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Only show in the listview the files that match the text." & vbCrLf & vbCrLf & "Patterns - " & vbCrLf & "?	Any single character" & vbCrLf & "*	Zero or more characters" & vbCrLf & "#	Any single digit (0–9)" & vbCrLf & "[ charlist ]	Any single character in charlist" & vbCrLf & "[! charlist ]	Any single character not in charlist"

                chkCheckBox1.Visible = True
                chkCheckBox1.Top = txtOperationTextbox1.Top + 30
                chkCheckBox1.Left = txtOperationTextbox1.Left
                chkCheckBox1.Text = "Name removed items?"

                chkCheckBox2.Visible = False

            Case OPERATION_SORT_OUT_3_DIGIT_SEASONS_AT_END

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Removes text from the 1st numeric found (if present)"

                cmdUpdateListview.Visible = False

            Case OPERATION_SORT_MMMDDYYY_FORMAT

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes " & vbCrLf & vbCrLf & "Raspi - Jan 25 2017.pdf" & vbCrLf & vbCrLf & "to" & vbCrLf & vbCrLf & "Raspi - 25 Jan 2017.pdf"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

            Case OPERATION_REMOVE_DD_FROM_DD_MMM_YYYY_DATE

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes " & vbCrLf & vbCrLf & "Astronomy - 1 Jul 2020.pdf" & vbCrLf & vbCrLf & "to" & vbCrLf & vbCrLf & "Astronomy - Jul 2020.pdf"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

            Case OPERATION_CHANGE_MM_YYYY_TO_MMM_YYYY

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes " & vbCrLf & vbCrLf & "BBC Sky At Night - 01 2018.pdf" & vbCrLf & vbCrLf & "to" & vbCrLf & vbCrLf & "BBC Sky At Night - Jan 2018.pdf"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

            Case OPERATION_CHANGE_YYYY_MM_TO_MMM_YYYY

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes " & vbCrLf & vbCrLf & "Super Food Ideas - 2015 09.pdf" & vbCrLf & vbCrLf & "to" & vbCrLf & vbCrLf & "Super Food Ideas - Sep 2015.pdf"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

            Case OPERATION_CHANGE_YYYYMM_TO_MMM_YYYY

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes " & vbCrLf & vbCrLf & "Taste of Home - 201711.pdf" & vbCrLf & vbCrLf & "to" & vbCrLf & vbCrLf & "Taste of Home - Nov 2017.pdf"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

            Case OPERATION_CHANGE_YYYY_MM_DD_TO_DD_MMM_YYYY

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes " & vbCrLf & vbCrLf & "New Scientist - 2008 12 13.pdf" & vbCrLf & vbCrLf & "to" & vbCrLf & vbCrLf & "New Scientist - 13 Dec 2008.pdf"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

            Case OPERATION_CHANGE_YYYY_MM_MM_TO_MMM_MMM_YYYY

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes " & vbCrLf & vbCrLf & "Taste Of Home Simple Delicious -  2016 08 09.pdf" & vbCrLf & "Taste Of Home Simple Delicious -  2017 12 2018 01.pdf" & vbCrLf & vbCrLf & "to" & vbCrLf & vbCrLf &
                                          "Taste Of Home Simple Delicious - Aug 2016 & Sep 2016.pdf" & vbCrLf & "Taste Of Home Simple Delicious - Dec 2017 & Jan 2018.pdf"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

            Case OPERATION_CHANGE_YYYY_DASH_MM_DASH_DD_TO_MMM_YYYY

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes " & vbCrLf & vbCrLf & "2022 - 04 - 01 Delicious.pdf" & vbCrLf & vbCrLf & "to" & vbCrLf & vbCrLf & "Delicious - Apr 2022.pdf"
                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

            Case OPERATION_NO_SPACE_CHANGE_YYYY_DASH_MM_DASH_DD_TO_MMM_YYYY

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes " & vbCrLf & vbCrLf & "2022 - 04 - 01Delicious.pdf" & vbCrLf & vbCrLf & "to" & vbCrLf & vbCrLf & "Delicious - Apr 2022.pdf"
                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

            Case OPERATION_MOVE_YYYY_MM_DD_TO_RIGHT

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes " & vbCrLf & vbCrLf & "2020 11 28 New Scientist.pdf" & vbCrLf & vbCrLf & "to" & vbCrLf & vbCrLf & "New Scientist - 28 Nov 2020.pdf"
                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

            Case OPERATION_NO_SPACE_MOVE_YYYY_MM_DD_TO_RIGHT

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes " & vbCrLf & vbCrLf & "2020 11 28New Scientist.pdf" & vbCrLf & vbCrLf & "to" & vbCrLf & vbCrLf & "New Scientist - 28 Nov 2020.pdf"
                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

            Case OPERATION_CHANGE_YYYY_MM_DD_TO_MMM_YYYY

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes " & vbCrLf & vbCrLf & "2020 04 01 Astronomy.pdf" & vbCrLf & vbCrLf & "to" & vbCrLf & vbCrLf & "Astronomy - Apr 2020.pdf"
                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

            Case OPERATION_NO_SPACE_CHANGE_YYYY_MM_DD_TO_MMM_YYYY

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes " & vbCrLf & vbCrLf & "2020 04 01Astronomy.pdf" & vbCrLf & vbCrLf & "to" & vbCrLf & vbCrLf & "Astronomy - Apr 2020.pdf"
                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

            Case OPERATION_DELETE_FIRST_X_CHARS

                lblOperationLabel1.Text = "Number of chars"

                lblOperationLabel1.Visible = True
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = True
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Remove chars at start of filename"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.Visible = False

            Case OPERATION_MOVE_COMPRESSED_TO_COMPRESSED_FOLDER

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Moves all the compressed files " & vbNewLine & vbNewLine & "i.e. with ' (Comp) ' or '(Comp).' " & vbNewLine & vbNewLine & "to a sub folder called 'Comp'." & vbNewLine & "If a file is already there process stops!"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

            Case OPERATION_MOVE_MATCHING_FILES_TO_SUBFOLDER

                lblOperationLabel1.Text = "Matching Text"

                lblOperationLabel1.Visible = True
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = True
                txtOperationTextbox2.Visible = False

                txtOperationTextbox1.Text = ""

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False
                cmdUpdateListview.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Moves the matching files to a sub folder named with the matching text - Matching (ABC) etc. " & vbCrLf & vbCrLf & "Matching text is required"

            Case OPERATION_COPY_FOLDER_STRUCTURE

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Copies the selected folder and its subs (no files) to a specified location"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

            Case OPERATION_COPY_BOOKS_FOLDERS_CONTENTS

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Copy the folders and files (zero sized) for Books folders to another location. Useful for finding dups on work PC. Folders are " & vbCrLf & vbCrLf &
                                          ROOT_DRIVE & "Torrents\Completed" & vbCrLf & ROOT_DRIVE & "Books"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

            Case OPERATION_DELETE_FILES_OF_TYPE

                lblOperationLabel1.Text = "Prefix(es)"

                lblOperationLabel1.Visible = True
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = True
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Find all the files of the specified prefixes in a comma sep. list, " & vbCrLf & "if more than one (.epub, mobi), in the folder above and, optionally sub folders, and deletes them (to recycle bin)."

                chkCheckBox1.Visible = True
                chkCheckBox1.Top = txtOperationTextbox1.Top + 30
                chkCheckBox1.Left = txtOperationTextbox1.Left
                chkCheckBox1.Text = "Do sub folders?"

                chkCheckBox2.Visible = False

                cmdUpdateListview.Visible = False

            Case OPERATION_DELETE_EMPTY_SUBFOLDERS

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Delete any sub folders without any files"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.Visible = False

            Case OPERATION_MOVE_FILES

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Moves files within any sub folders to the selected path" & vbCrLf & "Deletes any empty sub folders" & vbCrLf & vbCrLf & "If a file with the same name already exists there - it's ignored"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.Visible = False

            Case OPERATION_ADD_FILE_COUNT

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Adds the count of files to the folder name (and any sub folders) in the folder above"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.Visible = False

            Case OPERATION_REMOVE_FILE_COUNT

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Removes the count of files - assumed to be the last element of the name - after adding via the Add option"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.Visible = False

            Case OPERATION_CREATE_FILE_LISTING

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Creates a file listing in a text file called " & FILELISTING_FILENAME & " in the folder above. Does all subfolders."

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.Visible = False

            Case OPERATION_ADD_FILE_SIZES

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Adds the size of the file to all files in folder."

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.Visible = False

            Case OPERATION_REMOVE_FILE_SIZES

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Removes the file sizes." & vbCrLf & vbCrLf & "Assumed to be the last bracket on each file name."

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.Visible = False

            Case OPERATION_MOVE_FILES_INTO_SUBFOLDERS_BY_YEAR

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Moves files into sub folders based on a year in the name." & vbCrLf & vbCrLf _
                                         & "BBC Easy Cook 05 2012.pdf" & vbCrLf _
                                         & "BBC Easy Cook - May 2012.pdf" & vbCrLf _
                                         & "BBC Easy Cook - 05 (2012).pdf" & vbCrLf & vbCrLf _
                                         & " to \2012"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.Visible = False

            Case OPERATION_REPLACE_CHARACTERS_X_TIMES

                lblOperationLabel1.Text = "Find"
                lblOperationLabel2.Text = "Replace"
                lblOperationCombo1.Text = "How many times?"
                lblOperationCombo2.Text = "Starting at match?"

                lblOperationLabel1.Visible = True
                lblOperationLabel2.Visible = True

                txtOperationTextbox1.Visible = True
                txtOperationTextbox2.Visible = True

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Replace the characters X with Y that many times starting at a particular match. So you could replace the second '_' once in " & vbCrLf & vbCrLf & "BBC_Good Food_March_2015_UK.pdf " & vbCrLf & vbCrLf &
                                            "To get " & vbCrLf & vbCrLf & "BBC_Good Food - March_2015_UK.pdf" & vbCrLf & vbCrLf & "which makes it suitable for 'Magazine Format' to sort out properly"

                chkCheckBox1.Visible = False
                chkCheckBox2.Visible = False

                cmdUpdateListview.Visible = False

                cboOperation1.Width = 50

                cboOperation1.Items.Clear()

                cboOperation1.Items.Add("1")
                cboOperation1.Items.Add("2")
                cboOperation1.Items.Add("3")
                cboOperation1.Items.Add("4")
                cboOperation1.Items.Add("5")
                cboOperation1.Items.Add("6")
                cboOperation1.Items.Add("7")
                cboOperation1.Items.Add("8")
                cboOperation1.Items.Add("9")
                cboOperation1.Items.Add("10")

                cboOperation1.SelectedIndex = 0

                cboOperation2.Width = 50

                cboOperation2.Items.Clear()

                cboOperation2.Items.Add("1")
                cboOperation2.Items.Add("2")
                cboOperation2.Items.Add("3")
                cboOperation2.Items.Add("4")
                cboOperation2.Items.Add("5")

                cboOperation2.SelectedIndex = 0

                lblOperationCombo1.Left = lblOperationLabel1.Left
                lblOperationCombo1.Top = lblOperationLabel1.Top + 60

                cboOperation1.Left = lblOperationCombo1.Left + lblOperationCombo1.Width + 10
                cboOperation1.Top = lblOperationCombo1.Top - 5

                cboOperation1.Visible = True
                lblOperationCombo1.Visible = True

                lblOperationCombo2.Left = lblOperationLabel2.Left
                lblOperationCombo2.Top = lblOperationLabel2.Top + 60

                cboOperation2.Left = lblOperationCombo2.Left + lblOperationCombo2.Width + 10
                cboOperation2.Top = lblOperationCombo2.Top - 5

                cboOperation2.Visible = True
                lblOperationCombo2.Visible = True

        End Select

    End Sub

    Private Sub lvwFiles_ColumnClick(sender As Object, e As ColumnClickEventArgs) Handles lvwUpdatefilenames.ColumnClick

        ' Get the new sorting column.
        Dim objListview As ListView, objColumnHeader As ColumnHeader

        objListview = lvwUpdatefilenames
        objColumnHeader = mobjColumn_Files

        Dim new_sorting_column As ColumnHeader = objListview.Columns(e.Column)

        ' Figure out the new sorting order.
        Dim sort_order As System.Windows.Forms.SortOrder

        If objColumnHeader Is Nothing Then

            ' New column. Sort ascending.
            sort_order = SortOrder.Ascending
        Else

            ' See if this is the same column.
            If new_sorting_column.Equals(objColumnHeader) Then

                ' Same column. Switch the sort order.
                If objColumnHeader.Text.EndsWith(" >") Then

                    sort_order = SortOrder.Descending
                Else

                    sort_order = SortOrder.Ascending
                End If
            Else

                ' New column. Sort ascending.
                sort_order = SortOrder.Ascending
            End If

            ' Remove the old sort indicator.
            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, Len(objColumnHeader.Text) - 2)
        End If

        ' Display the new sort order.
        objColumnHeader = new_sorting_column

        If Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " >" Or Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " <" Then

            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, objColumnHeader.Text.Length - 2)
        End If

        If sort_order = SortOrder.Ascending Then

            objColumnHeader.Text = objColumnHeader.Text & " >"
        Else

            objColumnHeader.Text = objColumnHeader.Text & " <"
        End If

        mobjColumn_Files = objColumnHeader

        ' Create a comparer.
        objListview.ListViewItemSorter = New ListViewComparer(e.Column, sort_order)

        ' Sort.
        objListview.Sort()

    End Sub


    Private Sub cmdPath_Click(sender As Object, e As EventArgs) Handles cmdPath.Click

        Dim strPath As String = "", blnExit As Boolean = False

        strPath = txtPath.Text

        If txtPath.Text = "" Then

            ' Do Nothing
        Else

            If My.Computer.FileSystem.DirectoryExists(strPath) Then blnExit = True

            While (Not My.Computer.FileSystem.DirectoryExists(strPath)) Or blnExit = False

                strPath = RemoveOneLevelAndSlash(strPath)

                If SlashCount(strPath) = 1 Then blnExit = True

            End While

            txtPath.Text = strPath
        End If

        FolderBrowserDialog1.RootFolder = Environment.SpecialFolder.MyComputer

        If txtPath.Text = "" Then

            FolderBrowserDialog1.SelectedPath = ROOT_DRIVE & ""
        Else

            FolderBrowserDialog1.SelectedPath = txtPath.Text
        End If

        If FolderBrowserDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then

            If FolderBrowserDialog1.SelectedPath <> "" Then

                txtPath.Text = Mid(FolderBrowserDialog1.SelectedPath, 1, 1).ToLower & Mid(FolderBrowserDialog1.SelectedPath, 2)
                LoadFiles(txtPath.Text)
            End If

        End If

    End Sub

    Private Sub AddToList(ByVal strPath As String)

        If strPath = "" Then Exit Sub

        If Mid(strPath, Len(strPath)) = "\" Then

            strPath = Mid(strPath, 1, Len(strPath) - 1)
        End If

        For Each objItem In txtPath.Items

            If objItem.ToString = strPath Then Exit Sub
        Next

        txtPath.Items.Add(strPath)

    End Sub

    Sub LoadFiles(ByVal strPath As String, Optional ByVal strExtension As String = "", Optional ByVal strContents As String = "")

        Dim objDir As New DirectoryInfo(strPath), objItem As ListViewItem, blnAdd As Boolean
        Dim strType As String, strAllTypes As String, strUniqueTypes() As String, intCount As Integer
        Dim blnShownHiddenFilesWarning As Boolean = False, intHiddenFilesCount As Integer = 0

        mstrLoadType = "LOADFILES"

        AddToList(strPath)

        lvwUpdatefilenames.Items.Clear()

        cmdUpdFilesUpdateFilenamesInListview.Enabled = True
        cmdUpdFilesRevertToOriginalNames.Enabled = True
        cmdUpdFilesRemoveSelectionsinGrid.Enabled = True
        cmdUpdFilesRemoveItemFromGrid.Enabled = True

        txtMagReview.Text = ""
        chkReviewMagFolder.Checked = False

        If strExtension = "" Then

            strExtension = "*.*"
        Else

            strExtension = "*" & strExtension
        End If

        Try

            For Each objFile As FileInfo In objDir.GetFiles(strExtension)

                If FileHasAttributeFlag(objFile, FileAttributes.Hidden) And strPath.ToLower <> ROOT_DRIVE & "" Then

                    If Not blnShownHiddenFilesWarning Then

                        MessageBox.Show("At least 1 hidden file found! Filename - " & vbCrLf & vbCrLf & objFile.Name, My.Application.Info.ProductName, MessageBoxButtons.OK)

                        blnShownHiddenFilesWarning = True
                        intHiddenFilesCount = 1
                    Else

                        intHiddenFilesCount = intHiddenFilesCount + 1
                    End If
                End If

                    blnAdd = True

                    If strContents <> "" Then

                        Select Case strContents

                            Case CONTENTS_HAVE_BRACKETS

                                If InStr(objFile.Name, "(") > 0 Or InStr(objFile.Name, "<") > 0 Or InStr(objFile.Name, "[") > 0 Or InStr(objFile.Name, "{") > 0 Then

                                    blnAdd = True
                                Else

                                    blnAdd = False
                                End If

                            Case CONTENTS_DONT_HAVE_BRACKETS

                                If InStr(objFile.Name, "(") = 0 And InStr(objFile.Name, "<") = 0 And InStr(objFile.Name, "[") = 0 And InStr(objFile.Name, "{") = 0 Then

                                    blnAdd = True
                                Else

                                    blnAdd = False
                                End If

                            Case CONTENTS_HAVE_AT_ONE_NUMERIC

                                If objFile.Name <> RemoveNumericCharacters(objFile.Name) Then

                                    blnAdd = True
                                Else

                                    blnAdd = False
                                End If

                            Case CONTENTS_NO_NUMERICS

                                If objFile.Name = RemoveNumericCharacters(objFile.Name) Then

                                    blnAdd = True
                                Else

                                    blnAdd = False
                                End If

                            Case CONTENTS_STARTS_WITH_THE

                                If DoesFileNameStartWith(objFile.Name, "The ") Then

                                    blnAdd = True
                                Else

                                    blnAdd = False
                                End If

                            Case CONTENTS_HAS_A_SINGLE_QUOTE

                                If GetCountOfCharacterInText(objFile.Name, "'") > 0 Then

                                    blnAdd = True
                                Else

                                    blnAdd = False
                                End If

                        End Select

                    End If

                If blnAdd And strPath.ToLower = ROOT_DRIVE & "" Then

                    Select Case objFile.Name.ToLower

                        Case ".rnd", "autoexec.bat", "config.sys", "hiberfil.sys", "msdos.sys", "io.sys", "pagefile.sys" : blnAdd = False
                    End Select
                End If

                    If blnAdd Then

                        objItem = lvwUpdatefilenames.Items.Add(objFile.Name)

                        strType = objFile.Extension

                        If InStr(strAllTypes, strType & ",", CompareMethod.Text) = 0 Then

                            strAllTypes = strAllTypes & strType & ","
                        End If

                        objItem.SubItems.Add(strType)
                        objItem.SubItems.Add(objFile.Name)
                        objItem.SubItems.Add(objFile.Length)
                        If chkShowModifiedDate.Checked Then objItem.SubItems.Add(objFile.LastWriteTime)
                    End If
            Next

        Catch ex As Exception

            MessageBox.Show(ex.Message)
        End Try

        UpdateFilenamesSelectionCount()

        strUniqueTypes = Split(strAllTypes, ",")

        cboUniqueTypes.Items.Clear()

        For intCount = strUniqueTypes.GetLowerBound(0) To strUniqueTypes.GetUpperBound(0)

            cboUniqueTypes.Items.Add(strUniqueTypes(intCount))
        Next

        Dim objE As New ColumnClickEventArgs(COL_NAME)
        lvwFiles_ColumnClick(Nothing, objE)

        Me.Text = My.Application.Info.ProductName & " - " & lvwUpdatefilenames.Items.Count & " file(s)"

        mstrLastExtension = strExtension

        If intHiddenFilesCount > 0 Then

            MessageBox.Show("Total of " & intHiddenFilesCount & " hidden files found!")
        End If

    End Sub

    Private Sub UpdateFilenamesSelectionCount()

        lvwUpdatefilenames.Columns(0).Text = "Name on Disk - " & lvwUpdatefilenames.SelectedItems.Count & " selected"

        If lvwUpdatefilenames.SelectedItems.Count = 0 Then txtCurrentFilename.Text = ""

    End Sub

    Private Sub LoadContentOptions()

        cboContents.Items.Add("")
        cboContents.Items.Add(CONTENTS_HAVE_BRACKETS)
        cboContents.Items.Add(CONTENTS_DONT_HAVE_BRACKETS)
        cboContents.Items.Add(CONTENTS_HAVE_AT_ONE_NUMERIC)
        cboContents.Items.Add(CONTENTS_NO_NUMERICS)
        cboContents.Items.Add(CONTENTS_STARTS_WITH_THE)
        cboContents.Items.Add(CONTENTS_HAS_A_SINGLE_QUOTE)

    End Sub

    Private Sub Form1_Resize(sender As Object, e As EventArgs) Handles MyBase.Resize

        If Me.Width < 1250 Then Me.Width = 1250
        If Me.Height < 800 Then Me.Height = 800

        fraFrame.Width = Me.Width - 35
        fraFrame.Height = Me.Height - 90

        lvwUpdatefilenames.Width = fraFrame.Width - 25
        lvwUpdatefilenames.Height = fraFrame.Height - 370

        lblTypeFilter.Top = lvwUpdatefilenames.Top + lvwUpdatefilenames.Height + 15
        cboUniqueTypes.Top = lblTypeFilter.Top - 5

        lblFilterBy.Top = lblTypeFilter.Top
        cboContents.Top = cboUniqueTypes.Top

        lblMessageLabel.Top = lblTypeFilter.Top
        lblMessage.Top = lblMessageLabel.Top

        fraOperations.Left = lvwUpdatefilenames.Left
        fraOperations.Width = lvwUpdatefilenames.Width - 10
        fraOperations.Top = lvwUpdatefilenames.Top + lvwUpdatefilenames.Height + 35
        fraOperations.Height = 268

        lstOperations.Height = 220

        If chkShowModifiedDate.Checked = True Then

            lvwUpdatefilenames.Columns(COL_UPDATEFILE_MODIFIEDDATE).Width = 120

            lvwUpdatefilenames.Columns(COL_UPDATEFILE_DISKFILENAME).Width = ((lvwUpdatefilenames.Width - (lvwUpdatefilenames.Columns(COL_UPDATEFILE_FILETYPE).Width + lvwUpdatefilenames.Columns(COL_UPDATEFILE_MODIFIEDDATE).Width)) - 85) / 2
        Else

            lvwUpdatefilenames.Columns(COL_UPDATEFILE_MODIFIEDDATE).Width = 0

            lvwUpdatefilenames.Columns(COL_UPDATEFILE_DISKFILENAME).Width = ((lvwUpdatefilenames.Width - lvwUpdatefilenames.Columns(COL_UPDATEFILE_FILETYPE).Width) - 85) / 2
        End If

        lvwUpdatefilenames.Columns(COL_UPDATEFILE_PROPOSEDNAME).Width = lvwUpdatefilenames.Columns(COL_UPDATEFILE_DISKFILENAME).Width

        cmdUpdFilesUpdateFilenamesInListview.Top = fraOperations.Height - 30
        cmdUpdFilesRevertToOriginalNames.Top = cmdUpdFilesUpdateFilenamesInListview.Top
        cmdUpdFilesApplyProposedFilenames.Top = cmdUpdFilesUpdateFilenamesInListview.Top
        cmdUpdFilesRemoveSelectionsinGrid.Top = cmdUpdFilesUpdateFilenamesInListview.Top
        cmdUpdFilesRemoveItemFromGrid.Top = cmdUpdFilesUpdateFilenamesInListview.Top

        fraOperations.Width = fraFrame.Width - 25

        txtCurrentFilename.Width = fraOperations.Width - 610
        txtUpdFilenamesHelp.Left = txtCurrentFilename.Left + txtCurrentFilename.Width + 10

        chkSpecialFeatures.Top = txtUpdFilenamesHelp.Top + txtUpdFilenamesHelp.Height + 12
        chkReviewMagFolder.Top = chkSpecialFeatures.Top

        chkSpecialFeatures.Left = txtUpdFilenamesHelp.Left
        chkReviewMagFolder.Left = chkSpecialFeatures.Left + chkSpecialFeatures.Width + 35

        txtMagReview.Top = txtUpdFilenamesHelp.Top + txtUpdFilenamesHelp.Height - txtMagReview.Height + 1
        txtMagReview.Left = txtUpdFilenamesHelp.Left - txtMagReview.Width - 10

        cmdCopyAllItems.Left = chkSpecialFeatures.Left + 30
        cmdCopyAllItems.Top = chkSpecialFeatures.Top + 25

        cmdUpdFilesApplyProposedFilenames.Left = txtUpdFilenamesHelp.Left


        chkShowModifiedDate.Left = cboRecursiveFilter.Left + cboRecursiveFilter.Width + 20

        cmdClose.Left = Me.Width - 115
        cmdClose.Top = Me.Height - 75

    End Sub

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click

        Me.Close()

    End Sub

    Private Sub cmdUpdFilesUpdateFilenamesInListview_Click(sender As Object, e As EventArgs) Handles cmdUpdFilesUpdateFilenamesInListview.Click

        Dim blnReloadListview As Boolean, strTemp As String = ""

        If lstOperations.SelectedItems(0).ToString = "" Then Exit Sub

        lvwUpdatefilenames.Tag = ""

        Cursor = Cursors.WaitCursor

        cmdUpdFilesUpdateFilenamesInListview.Enabled = False

        Select Case lstOperations.SelectedItems(0).ToString

            Case OPERATION_SORT_OUT_1OF3

                Op_Sort_Out_1Of3(lvwUpdatefilenames, txtPath.Text)

            Case OPERATION_SORT_OUT_1x01

                Op_Sort_Out_1x01(lvwUpdatefilenames)

            Case OPERATION_SORT_OUT_3_DIGIT_SEASONS_AT_END

                Op_3_Digit_Seasons(lvwUpdatefilenames)

            Case OPERATION_CHANGE_NUMERIC_TO_3_DIGIT_SEASON

                Op_Change_Numeric_To_3_Digit_Season(lvwUpdatefilenames)

            Case OPERATION_REMOVE_TEXT_AFTER_CUSTOM_TEXT

                Op_Remove_Text_After_Custom_Text(lvwUpdatefilenames, txtOperationTextbox1.Text)

            Case OPERATION_GEN_CLEANUP_AND_REMOVE_TEXT_AFTER_HDTV

                Op_GeneralCleanup(lvwUpdatefilenames, Me)

                Op_RemoveTextAfterlist(lvwUpdatefilenames)

                Op_GeneralCleanup(lvwUpdatefilenames, Me)

            Case OPERATION_INDIVIDUAL_EDIT

                Op_IndividualEdit(lvwUpdatefilenames, txtCurrentFilename)

            Case OPERATION_CLEANUP_BRACKETS

                Op_Cleanup_Brackets(lvwUpdatefilenames)

            Case OPERATION_GENERAL_CLEANUP

                Op_GeneralCleanup(lvwUpdatefilenames, Me)

            Case OPERATION_TEXT_REPLACEMENT_WITH_MINOR_CLEANUP

                If txtOperationTextbox1.Text = "" Then

                    Reset()

                    MessageBox.Show("No from text!")

                    cmdUpdFilesUpdateFilenamesInListview.Enabled = True
                    Exit Sub
                End If

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2)

                Op_MinorCleanup(lvwUpdatefilenames)

            Case OPERATION_TEXT_REPLACEMENT_WITHOUT_MINOR_CLEANUP

                If txtOperationTextbox1.Text = "" Then

                    Reset()

                    MessageBox.Show("No from text!")
                    cmdUpdFilesUpdateFilenamesInListview.Enabled = True
                    Exit Sub
                End If

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2)

            Case OPERATION_TEXT_REPLACEMENT_HDTV

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "FiNAL.FASTSUB.VOSTFR.HDTV.XviD -F4ST")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "KVCD.by.TinPusher(TUS.Release)")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "WS.PDTV.XviD -RAWNiTRO")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "iNTERNAL.DVDRip.XviD -RAWNiTRO")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "FiNAL FASTSUB VOSTFR HDTV XviD -F4ST")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "KVCD by TinPusher(TUS Release)")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "WS PDTV XviD -RAWNiTRO")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "iNTERNAL DVDRip XviD -RAWNiTRO")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "PDTV.XviD.MP3.MVGroup.org")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "720p.HDTV.x264 -IMMERSE")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "PROPER.HDTV.XviD-2HD")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "PDTV XviD MP3 MVGroup org")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "720p HDTV x264 -IMMERSE")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "PROPER HDTV XviD-2HD")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "REPACK HDTV x264-KILLERS")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "REPACK.HDTV.XviD-AFG")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "REPACK HDTV XviD-AFG")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD-AFG", "")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD-AFG", "")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD AFG", "")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "hdtv x264-killers")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "480p HDTV x264-mSD")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV x264 - KILLERS")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "hdtv x264-mtg")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "Hdtv – Norite")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "480p HDTV x264-mSD")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "480p HDTV X264 – MSD")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "dvdrip.xvid -sfm")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "WEBRip XviD - FUM")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "WEBRip XVID-SaM[ettv]")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV x264 - DUKES")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV x264 - MiNDTHEGAP")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD -LOL.[VTV]")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD -REFiLL.[VTV]")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD -LOL [VTV]")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD -REFiLL [VTV]")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD-SPASTiKUS-")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD-SPASTiKUS-")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV x264 127MB-AureliA")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "[PLEASE SHARE]")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD -k3n")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD -FoV")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD -SYS")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD-2HD")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD -XII")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD -aAF")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "DVDrip.XviD -XEROS")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "hdtv.xvid -bia")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "hdtv.xvid -fum")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "WS.TVRip.x264 [mR12]")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "PDTV.x264.JIVE")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "Web -DL.x264.JIVE")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD -k3n")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD -FoV")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD -SYS")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD-2HD")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD -XII")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD -aAF")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "DVDrip XviD -XEROS")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "hdtv xvid -bia")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "hdtv xvid -fum")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "WS TVRip x264 [mR12]")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "PDTV x264 JIVE")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "Web -DL x264 JIVE")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "dvdrip.xvid")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "dvdrip.xvid -nodlabs")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "dvdrip xvid")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "dvdrip xvid -nodlabs")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV x264 - FoV")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "[Norwegian-FunFun]")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "XviD AC3 MVGroup org")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "hdtv xvid - nosegment")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "[ettv]")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, Current)")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "REPACK")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "Sno")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "Xvid")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "X264 RB58")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "1080p HEVC X265 - MeGusta[EZTVx To]")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "1080p HEVC X265 - MeGusta")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "Web H264 - Deflate[Ettv]")


                Op_MinorCleanup(lvwUpdatefilenames)

            Case OPERATION_REMOVE_TEXT_AFTER_HDTV

                Op_RemoveTextAfterlist(lvwUpdatefilenames)

            Case OPERATION_REMOVE_CURRENT_TITLES

                Op_RemoveCurrentTitles(lvwUpdatefilenames)

            Case OPERATION_APPLY_PROPERISE_CASE

                Op_ProperiseCase(lvwUpdatefilenames)

            Case OPERATION_MOVE_BRACKETS_TO_END

                Op_MoveBracketsToEnd(lvwUpdatefilenames)

            Case OPERATION_REMOVE_BRACKETS

                Op_RemoveBrackets(lvwUpdatefilenames)

            Case OPERATION_REMOVE_BRACKETS_FROM_END

                Op_RemoveBracketsFromEnd(lvwUpdatefilenames)

            Case OPERATION_REVERSE_NAMES

                Op_ReverseNames(lvwUpdatefilenames)

            Case OPERATION_REMOVE_NUMERICS

                Op_RemoveNumerics(lvwUpdatefilenames)

            Case OPERATION_REMOVE_1ST_NUMERIC

                Op_Remove1stNumeric(lvwUpdatefilenames)

            Case OPERATION_MAGAZINE_CLEANUP

                Op_MagazineCleanup(lvwUpdatefilenames)

            Case OPERATION_BOOK_CLEANUP

                Op_BookCleanup(lvwUpdatefilenames)

            Case OPERATION_COPY_LISTVIEW_TO_TEXTFILE

                Op_Copy_Listview_To_Textfile(lvwUpdatefilenames, txtPath.Text)

            Case OPERATION_ENSURE_ALL_FILES_NAMED_AFTER_FOLDER

                Op_EnsureFilesNamedAfterFolder(txtOperationTextbox1.Text, lvwUpdatefilenames)

            Case OPERATION_RENAME_PDFS_BASED_ON_INTERNAL_DETAILS

                Op_Rename_PDFs(Me, txtPath.Text, lvwUpdatefilenames)

            Case OPERATION_RENAME_MOBIS_BASED_ON_INTERNAL_DETAILS

                Op_Rename_MOBIs(Me, txtPath.Text, lvwUpdatefilenames, chkCheckBox1.Checked = True, chkCheckBox2.Checked = True)

            Case OPERATION_ADD_TEXT_TO_START

                Op_Add_Text_To_Start(lvwUpdatefilenames, txtOperationTextbox1)

            Case OPERATION_REMOVE_TEXT_FROM_START

                Op_Remove_Text_From_Start(lvwUpdatefilenames, txtOperationTextbox1)

            Case OPERATION_ADD_TEXT_TO_END

                Op_Add_Text_To_End(lvwUpdatefilenames, txtOperationTextbox1)

            Case OPERATION_FILTER_BY_TEXT

                Reset()

                MessageBox.Show("Use Update Listview button!")
                txtOperationTextbox1.Focus()

                cmdUpdFilesUpdateFilenamesInListview.Enabled = True

                Exit Sub

            Case OPERATION_SORT_MMMDDYYY_FORMAT

                Op_Sort_MMMDDYYYY_Format(lvwUpdatefilenames)

            Case OPERATION_REMOVE_DD_FROM_DD_MMM_YYYY_DATE

                Op_Remove_DD_From_DD_MMM_YYYY_Date(lvwUpdatefilenames)

            Case OPERATION_CHANGE_MM_YYYY_TO_MMM_YYYY

                Op_Change_MM_YYYY_Date_To_MMM_YYYY_Date(lvwUpdatefilenames)

            Case OPERATION_CHANGE_YYYY_MM_TO_MMM_YYYY

                Op_Change_YYYY_MM_Date_To_MMM_YYYY_Date(lvwUpdatefilenames)

            Case OPERATION_CHANGE_YYYYMM_TO_MMM_YYYY

                Op_Change_YYYYMM_Date_To_MMM_YYYY_Date(lvwUpdatefilenames)

            Case OPERATION_CHANGE_YYYY_MM_DD_TO_DD_MMM_YYYY

                Op_Change_YYYY_MM_DD_To_DD_MMM_YYYY(lvwUpdatefilenames)

            Case OPERATION_CHANGE_YYYY_MM_MM_TO_MMM_MMM_YYYY

                Op_Change_YYYY_MM_MM_To_MMM_MMM_YYYY(lvwUpdatefilenames)

            Case OPERATION_MOVE_YYYY_MM_DD_TO_RIGHT

                Op_Change_Move_YYYY_MM_DD_To_Right(lvwUpdatefilenames)

            Case OPERATION_NO_SPACE_MOVE_YYYY_MM_DD_TO_RIGHT

                Op_No_Space_Change_Move_YYYY_MM_DD_To_Right(lvwUpdatefilenames)

            Case OPERATION_CHANGE_YYYY_MM_DD_TO_MMM_YYYY

                Op_Change_YYYY_MM_DD_To_MMM_YYYY(lvwUpdatefilenames)

            Case OPERATION_NO_SPACE_CHANGE_YYYY_MM_DD_TO_MMM_YYYY

                Op_No_Space_Change_YYYY_MM_DD_To_MMM_YYYY(lvwUpdatefilenames)

            Case OPERATION_CHANGE_YYYY_DASH_MM_DASH_DD_TO_MMM_YYYY

                Op_Change_YYYY_DASH_MM_DASH_DD_To_MMM_YYYY(lvwUpdatefilenames)

            Case OPERATION_NO_SPACE_CHANGE_YYYY_DASH_MM_DASH_DD_TO_MMM_YYYY

                Op_No_Space_Change_YYYY_DASH_MM_DASH_DD_To_MMM_YYYY(lvwUpdatefilenames)

            Case OPERATION_REMOVE_INITIAL_NUMERICS

                Op_RemoveInitialNumerics(lvwUpdatefilenames)

            Case OPERATION_MARK_AS_COMPRESSED

                Op_MarkAsCompressed(lvwUpdatefilenames)

            Case OPERATION_MOVE_COMPRESSED_TO_COMPRESSED_FOLDER

                Op_MoveCompressed(txtPath.Text, lvwUpdatefilenames, Me)

                blnReloadListview = True

            Case OPERATION_MOVE_MATCHING_FILES_TO_SUBFOLDER

                Op_MoveMatching(txtPath.Text, lvwUpdatefilenames, txtOperationTextbox1.Text)

                blnReloadListview = True

            Case OPERATION_DELETE_FIRST_X_CHARS

                If txtOperationTextbox1.Text = "" Then

                    Reset()

                    MessageBox.Show("Need a number of chars")
                    cmdUpdFilesUpdateFilenamesInListview.Enabled = True
                    Exit Sub
                End If

                If Not IsNumeric(txtOperationTextbox1.Text) Then

                    Reset()

                    MessageBox.Show("Need a number of chars")
                    cmdUpdFilesUpdateFilenamesInListview.Enabled = True
                    Exit Sub
                End If

                Op_Remove_First_X_Chars(lvwUpdatefilenames, txtOperationTextbox1.Text)

            Case OPERATION_COPY_FOLDER_STRUCTURE

                Op_CopyFolderStruture(txtPath.Text)

            Case OPERATION_COPY_BOOKS_FOLDERS_CONTENTS

                Op_Copy_FolderAndFiles()

            Case OPERATION_REMOVE_TEXT_FROM_1ST_NUMERIC

                Op_RemoveTextFrom1stNumeric(lvwUpdatefilenames)

            Case OPERATION_DELETE_FILES_OF_TYPE

                If txtPath.Text = "" Then

                    Reset()

                    MessageBox.Show("Path needed!")
                    txtPath.Focus()
                    cmdUpdFilesUpdateFilenamesInListview.Enabled = True
                    Exit Sub
                End If

                If txtOperationTextbox1.Text = "" Then

                    Reset()

                    MessageBox.Show("Prefix(es) needed!")
                    txtOperationTextbox1.Focus()
                    cmdUpdFilesUpdateFilenamesInListview.Enabled = True
                    Exit Sub
                End If

                Op_DeleteAllFilesWithPrefixes(txtPath.Text, txtOperationTextbox1.Text, chkCheckBox1.Checked)

            Case OPERATION_DELETE_EMPTY_SUBFOLDERS

                Op_DeleteAnyEmptySubFolders(txtPath.Text)

            Case OPERATION_MOVE_FILES

                Op_MoveFiles(txtPath.Text)

                blnReloadListview = True

            Case OPERATION_MOVE_FILES_INTO_SUBFOLDERS_BY_YEAR

                Op_MoveFilesIntoSubFoldersByYear(txtPath.Text)

                blnReloadListview = True

            Case OPERATION_ADD_FILE_COUNT

                Op_AddFileCount(txtPath.Text, strTemp)

                If strTemp <> "" Then txtPath.Text = strTemp

                blnReloadListview = True

            Case OPERATION_REMOVE_FILE_COUNT

                Op_RemoveFileCount(txtPath.Text, strTemp)

                If strTemp <> "" Then txtPath.Text = strTemp

                blnReloadListview = True

            Case OPERATION_CREATE_FILE_LISTING

                Op_CreateFileListing(txtPath.Text)

                blnReloadListview = True

            Case OPERATION_REPLACE_CHARACTERS_X_TIMES

                Op_ReplaceCharactersXTimes(lvwUpdatefilenames, txtOperationTextbox1.Text, txtOperationTextbox2.Text, _
                                           cboOperation1.SelectedItem.ToString, cboOperation2.SelectedItem.ToString)

            Case OPERATION_ADD_FILE_SIZES

                Op_Add_File_Sizes(txtPath.Text)

                blnReloadListview = True

            Case OPERATION_REMOVE_FILE_SIZES

                Op_Remove_File_Sizes(txtPath.Text)

                blnReloadListview = True

        End Select

        cmdUpdFilesUpdateFilenamesInListview.Enabled = True

        UpdateCurrentFilename()

        lvwUpdatefilenames.Focus()

        Reset()

        If blnReloadListview Then

            cmdLoad_Click(Nothing, Nothing)
        End If

        If lvwUpdatefilenames.Tag <> "" Then

            cmdUpdFilesApplyProposedFilenames.Enabled = True

            lvwUpdatefilenames.Tag = ""
        End If

    End Sub

    Private Sub Reset()

        Cursor = Cursors.Default
        Me.Text = "File Renamer"

        Me.Refresh()

    End Sub

    Private Sub UpdateCurrentFilename()

        If lvwUpdatefilenames.SelectedItems.Count >= 1 Then

            txtCurrentFilename.Text = lvwUpdatefilenames.SelectedItems(0).SubItems(COL_UPDATEFILE_PROPOSEDNAME).Text
        Else

            If lvwUpdatefilenames.Items.Count >= 1 Then


                txtCurrentFilename.Text = lvwUpdatefilenames.Items(0).SubItems(COL_UPDATEFILE_PROPOSEDNAME).Text
            Else

                txtCurrentFilename.Text = ""
            End If
        End If

        UpdateFilenamesSelectionCount()

    End Sub

    Private Sub cboUniqueTypes_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboUniqueTypes.SelectedIndexChanged

        LoadFiles(txtPath.Text, cboUniqueTypes.SelectedItem & "", cboContents.SelectedItem & "")

    End Sub

    Private Sub cmdUpdFilesRevertToOriginalNames_Click(sender As Object, e As EventArgs) Handles cmdUpdFilesRevertToOriginalNames.Click

        Op_RestoreFilenames(lvwUpdatefilenames)

        UpdateFilenamesSelectionCount()

    End Sub

    Private Sub RemoveSelectionsFromGrid(ByRef lvwListview As ListView)

        lvwListview.SelectedItems.Clear()

        UpdateFilenamesSelectionCount()

    End Sub

    Private Sub cmdRemoveSelectionsinGrid_Click(sender As Object, e As EventArgs) Handles cmdUpdFilesRemoveSelectionsinGrid.Click

        RemoveSelectionsFromGrid(lvwUpdatefilenames)

    End Sub

    Private Sub cmdRemoveItemFromGrid_Click(sender As Object, e As EventArgs) Handles cmdUpdFilesRemoveItemFromGrid.Click

        Try

            If lvwUpdatefilenames.SelectedItems.Count = 0 Then

                DisplayMessage("No selected items!")
            Else

                lvwUpdatefilenames.Items(lvwUpdatefilenames.SelectedItems(0).Index).Remove()
            End If

        Catch ex As Exception

        End Try

        UpdateFilenamesSelectionCount()

    End Sub

    Private Sub DisplayMessage(ByVal strMessage As String, Optional ByVal blnUseTimer As Boolean = True)

        lblMessage.Text = strMessage
        ToolTip1.SetToolTip(lblMessage, strMessage)

        If blnUseTimer Then Timer1.Enabled = True

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick

        lblMessage.Text = ""
        Timer1.Enabled = False

    End Sub

    Private Sub txtPath_TextChanged(sender As Object, e As EventArgs) Handles txtPath.TextChanged

        My.Settings.LastPath = txtPath.Text

        cmdLoad.Enabled = (txtPath.Text.Trim <> "")

    End Sub

    Private Sub cmdUpdFilesApplyProposedFilenames_Click(sender As Object, e As EventArgs) Handles cmdUpdFilesApplyProposedFilenames.Click

        Dim strPath As String, objItem As ListViewItem
        Dim strFromFileName As String, strToFileName As String, strFiles As String = ""
        Dim arrFiles() As String, blnFoundAtLeast1 As Boolean, intCount As Integer
        Dim strNewFilename As String, strNewPrefix As String
        Dim intResult As Integer, strOriginalNames As String = "", arrOriginalNames() As String

        If mstrLoadType <> "LOADFILES" Then

            MessageBox.Show("You need to load the files using Load Files for this to work!")
            Exit Sub
        End If

        cmdUpdFilesApplyProposedFilenames.Enabled = False
        Me.Cursor = Cursors.WaitCursor

        strPath = txtPath.Text

        ' Check that proposed filenames are all unique
        For Each objItem In lvwUpdatefilenames.Items

            strFiles = strFiles & objItem.SubItems(COL_UPDATEFILE_PROPOSEDNAME).Text & "*"
            strOriginalNames = strOriginalNames & objItem.SubItems(COL_UPDATEFILE_DISKFILENAME).Text & "*"
        Next

        arrFiles = Split(strFiles, "*")
        arrOriginalNames = Split(strOriginalNames, "*")

        For intCount = arrFiles.GetLowerBound(0) To arrFiles.GetUpperBound(0) - 1

            If arrFiles(intCount) = arrFiles(intCount + 1) Then

                cmdUpdFilesApplyProposedFilenames.Enabled = False

                blnFoundAtLeast1 = True

                intResult = MsgBox("There are at least two files that will be named " & vbCrLf & vbCrLf & arrFiles(intCount) & vbCrLf & arrOriginalNames(intCount) & vbCrLf & vbCrLf &
                                   "Quit to sort out (Yes)," & vbCrLf & "continue to see next problem (No) or " & vbCrLf & " ignore and rename file to be unique later (Cancel)?" & vbCrLf & vbCrLf & "Reload to enable the 'Update Filenames on Disk' button",
                                    MsgBoxStyle.YesNoCancel, My.Application.Info.ProductName & " - No files updated")

                If intResult = MsgBoxResult.Yes Then

                    Me.Cursor = Cursors.Default
                    Exit Sub

                ElseIf intResult = MsgBoxResult.Cancel Then

                    blnFoundAtLeast1 = False

                    Me.Cursor = Cursors.Default
                    Exit For
                End If
            End If
        Next

        If blnFoundAtLeast1 Then

            Me.Cursor = Cursors.Default
            Exit Sub
        End If

        strPath = strPath & "\"

        For Each objItem In lvwUpdatefilenames.Items

            strFromFileName = objItem.SubItems(COL_UPDATEFILE_DISKFILENAME).Text
            strToFileName = objItem.SubItems(COL_UPDATEFILE_PROPOSEDNAME).Text

            If (strFromFileName <> strToFileName) And strToFileName <> "" Then

                Try

                    DisplayMessage("Renaming " & strFromFileName & " to " & strToFileName, False)

                    If strFromFileName.ToLower = strToFileName.ToLower Then

                        My.Computer.FileSystem.RenameFile(strPath & strFromFileName, strToFileName & "_")
                        My.Computer.FileSystem.RenameFile(strPath & strToFileName & "_", strToFileName)
                    Else

                        If My.Computer.FileSystem.FileExists(strPath & strToFileName) Then

                            strNewFilename = RemovePrefix(arrFiles(intCount + 1))
                            strNewPrefix = GetPrefix(arrFiles(intCount + 1))

                            strToFileName = GetNewFilename(txtPath.Text, strNewFilename, strNewPrefix)
                        End If

                        My.Computer.FileSystem.RenameFile(strPath & strFromFileName, strToFileName)
                    End If

                Catch exFile As FileNotFoundException

                    MessageBox.Show("File " & strFromFileName & " not found! Quiiting process")

                Catch ex As Exception

                    DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name & " - 1st File", "strFromFileName - " & strFromFileName)
                End Try
            End If
        Next

        If mstrLastExtension <> "*.* then" Then

            LoadFiles(strPath, mstrLastExtension)
        Else

            LoadFiles(strPath, cboUniqueTypes.SelectedText)
        End If

        Me.Cursor = Cursors.Default

        DisplayMessage("", False)

    End Sub

    Private Sub mnuDeleteFiles_Click(sender As Object, e As EventArgs) Handles mnuDeleteFiles.Click

        Dim intCount As Integer, strPath As String

        If lvwUpdatefilenames.SelectedItems.Count > 0 Then

            For intCount = 0 To lvwUpdatefilenames.SelectedItems.Count - 1

                strPath = txtPath.Text & "\" & lvwUpdatefilenames.SelectedItems(intCount).SubItems(COL_UPDATEFILE_DISKFILENAME).Text

                Try
                    Me.Text = "Deleting - " & strPath

                    My.Computer.FileSystem.DeleteFile(strPath)

                    My.Application.DoEvents()

                Catch ex As Exception

                    DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name, "strPath = " & strPath & " - intCount = " & intCount)
                End Try

            Next

        End If

        Me.Text = "File Renamer"

        cmdLoad_Click(Nothing, Nothing)

    End Sub

    Private Sub mnuRemoveHiddenFlag_Click(sender As Object, e As EventArgs) Handles mnuRemoveHiddenFlag.Click

        Dim intCount As Integer, strPath As String, objFile As FileInfo

        If lvwUpdatefilenames.SelectedItems.Count > 0 Then

            For intCount = 0 To lvwUpdatefilenames.SelectedItems.Count - 1

                strPath = txtPath.Text & "\" & lvwUpdatefilenames.SelectedItems(intCount).SubItems(COL_UPDATEFILE_DISKFILENAME).Text

                Try
                    Me.Text = "Removing hidden - " & strPath

                    objFile = New FileInfo(strPath)

                    objFile.Attributes = FileAttributes.Normal

                    My.Application.DoEvents()

                Catch ex As Exception

                    DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name, "strPath = " & strPath & " - intCount = " & intCount)
                End Try

            Next

        End If

        Me.Text = "File Renamer"

        cmdLoad_Click(Nothing, Nothing)

    End Sub

    Private Sub lvwUpdatefilenames_MouseClick(sender As Object, e As MouseEventArgs) Handles lvwUpdatefilenames.MouseClick

        Dim p As New Point, C As Windows.Forms.Cursor

        C = Cursors.Default

        p = New Point(Windows.Forms.Cursor.Position.X, Windows.Forms.Cursor.Position.Y)

        If e.Button = Windows.Forms.MouseButtons.Right Then

            mnuListviewRightClick.Tag = sender.name
            mnuListviewRightClick.Show(p)

        End If

    End Sub

    Private Sub lvwUpdatefilenames_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvwUpdatefilenames.SelectedIndexChanged

        UpdateCurrentFilename()

    End Sub

    Public Sub Op_Move_Files_Into_Subfolders_By_Year(ByVal objMe As frmFileRenamer, ByVal strPath As String, ByRef lvwUpdatefilenames As ListView)

        Dim objItem As ListViewItem, strName As String
        Dim blnSelected As Boolean, blnDoSelected As Boolean

        If lvwUpdatefilenames.SelectedItems.Count > 0 Then

            blnDoSelected = True
        End If

        For Each objItem In lvwUpdatefilenames.Items

            If blnDoSelected Then

                If objItem.Selected Then

                    blnSelected = True
                Else

                    blnSelected = False
                End If
            Else

                blnSelected = True
            End If

            If blnSelected Then

                strName = objItem.SubItems(COL_UPDATEFILE_PROPOSEDNAME).Text

                strName = GetInternalNameOfPDF(strPath & "\" & strName, objMe)

                objItem.SubItems(COL_UPDATEFILE_PROPOSEDNAME).Text = strName

                lvwUpdatefilenames.Refresh()
                objMe.Refresh()

                My.Application.DoEvents()
            End If

        Next

        lvwUpdatefilenames.Refresh()

        objMe.fraFrame.Text = "File Renamer"

    End Sub

    Public Sub Op_Rename_PDFs(ByVal objMe As frmFileRenamer, ByVal strPath As String, ByRef lvwUpdatefilenames As ListView)

        Dim objItem As ListViewItem, strName As String
        Dim blnSelected As Boolean, blnDoSelected As Boolean

        If lvwUpdatefilenames.SelectedItems.Count > 0 Then

            blnDoSelected = True
        End If

        For Each objItem In lvwUpdatefilenames.Items

            If blnDoSelected Then

                If objItem.Selected Then

                    blnSelected = True
                Else

                    blnSelected = False
                End If
            Else

                blnSelected = True
            End If

            If blnSelected Then

                strName = objItem.SubItems(COL_UPDATEFILE_PROPOSEDNAME).Text

                strName = GetInternalNameOfPDF(strPath & "\" & strName, objMe)

                objItem.SubItems(COL_UPDATEFILE_PROPOSEDNAME).Text = strName

                lvwUpdatefilenames.Refresh()
                objMe.Refresh()

                My.Application.DoEvents()
            End If

        Next

        lvwUpdatefilenames.Refresh()

        objMe.fraframe.text = "File Renamer"

    End Sub

    Public Sub Op_Rename_MOBIs(ByVal objMe As frmFileRenamer, ByVal strPath As String, ByRef lvwUpdatefilenames As ListView, _
                               ByVal blnAuthorFirst As Boolean, ByVal blnAuthorInTitle As Boolean)

        Dim objItem As ListViewItem, strName As String
        Dim blnSelected As Boolean, blnDoSelected As Boolean

        If lvwUpdatefilenames.SelectedItems.Count > 0 Then

            blnDoSelected = True
        End If

        For Each objItem In lvwUpdatefilenames.Items

            If blnDoSelected Then

                If objItem.Selected Then

                    blnSelected = True
                Else

                    blnSelected = False
                End If
            Else

                blnSelected = True
            End If

            If blnSelected Then

                strName = objItem.SubItems(COL_UPDATEFILE_PROPOSEDNAME).Text

                strName = GetInternalNameOfMOBI(strPath & "\" & strName, blnAuthorFirst, blnAuthorInTitle, objMe)

                objItem.SubItems(COL_UPDATEFILE_PROPOSEDNAME).Text = strName

                lvwUpdatefilenames.Refresh()
                objMe.Refresh()

                My.Application.DoEvents()
            End If

        Next

        lvwUpdatefilenames.Refresh()

        objMe.fraFrame.Text = "File Renamer"

    End Sub

    Private Sub cmdCopyAllItems_MouseEnter(sender As Object, e As EventArgs) Handles cmdCopyAllItems.MouseEnter

        txtUpdFilenamesHelp.Text = "Copy all items (Root and all subfolders) to a folder (named with a ' - file renamer copy' on the end so 'c:\Books\History' becomes 'c:\Books\History - file renamer copy') so that I can find likely duplicates by sorting by name in Explorer. (Files are zero sized)."

    End Sub

    Private Sub cmdCopyAllItems_MouseLeave(sender As Object, e As EventArgs) Handles cmdCopyAllItems.MouseLeave

        txtUpdFilenamesHelp.Text = ""

    End Sub

    Private Sub cmdCopyAllItems_Click(sender As Object, e As EventArgs) Handles cmdCopyAllItems.Click

        Dim objDir As DirectoryInfo, strPath As String

        objDir = New DirectoryInfo(txtPath.Text)

        If txtPath.Text = "" Then

            MessageBox.Show("No path!")
            Exit Sub
        End If

        strPath = txtPath.Text & " - file renamer copy"

        If My.Computer.FileSystem.DirectoryExists(strPath) Then

            My.Computer.FileSystem.DeleteDirectory(strPath, FileIO.DeleteDirectoryOption.DeleteAllContents)

            My.Application.DoEvents()
        End If

        My.Application.DoEvents()
        My.Computer.FileSystem.CreateDirectory(strPath)
        My.Application.DoEvents()

        Processfolder(objDir, strPath)

        MessageBox.Show("Finished!")

    End Sub

    Private Sub Processfolder(ByRef objdir As DirectoryInfo, ByVal strRootPath As String)

        Dim objFiles() As FileInfo, strPath As String, strFullname As String

        objFiles = objdir.GetFiles()

        For Each f In objFiles

            strFullname = GetPath(f.FullName.ToUpper)

            strFullname = strFullname.Replace(ROOT_DRIVE & "", "").Replace(ROOT_DRIVE & "", "")

            strFullname = strFullname.Replace("\", "-")

            strPath = Mid(strRootPath & "\" & f.Name & "   -    " & strFullname, 1, 259)

            My.Computer.FileSystem.OpenTextFileWriter(strPath, False)
        Next

        For Each d In objdir.GetDirectories()

            Processfolder(d, strRootPath)
        Next


    End Sub

    Private Sub chkSpecialFeatures_CheckedChanged(sender As Object, e As EventArgs) Handles chkSpecialFeatures.CheckedChanged

        cmdCopyAllItems.Visible = chkSpecialFeatures.Checked

    End Sub

    Private Sub cmdLoad_Click(sender As Object, e As EventArgs) Handles cmdLoad.Click

        If cboContents.SelectedIndex = -1 Then

            mblnStopFireOnContents = True
            cboContents.SelectedIndex = 0
            mblnStopFireOnContents = False
        Else

            cboContents.SelectedIndex = 0
        End If

        LoadFiles(txtPath.Text)

    End Sub

    Private Sub cmdUpdateListview_Click(sender As Object, e As EventArgs) Handles cmdUpdateListview.Click

        Dim objItem As ListViewItem
        Dim strText As String
        Dim intCount As Integer

        strText = txtOperationTextbox1.Text.ToLower

        Select Case lstOperations.SelectedItems(0).ToString

            Case OPERATION_FILTER_BY_TEXT

                If txtOperationTextbox1.Text.Trim = "" Then

                    MessageBox.Show("Nothing to filter by")
                    Exit Sub
                End If

                For Each objItem In lvwUpdatefilenames.Items

                    If objItem.Text.ToLower Like strText = False Then

                        If chkCheckBox1.Checked = True Then

                            MessageBox.Show(objItem.Text & " removed!")
                        End If

                        objItem.Remove()
                        intCount = intCount + 1
                    End If

                Next

                MessageBox.Show(intCount & " items removed")
        End Select

    End Sub

    Private Sub cmdPrev_Click(sender As Object, e As EventArgs) Handles cmdPrev.Click

        Dim objFolder As New DirectoryInfo(txtPath.Text)
        Dim strFolders() As DirectoryInfo
        Dim strPath As String, strNextPath As String

        strFolders = objFolder.GetDirectories()

        If strFolders.Length = 0 Then

            strPath = RemoveOneLevelAndSlash(txtPath.Text)

            Dim objParentFolder As New DirectoryInfo(strPath)

            strNextPath = FindPrevFolder(objParentFolder.FullName, txtPath.Text)

            If strNextPath <> "" Then

                txtPath.Text = strNextPath
                cmdLoad_Click(Nothing, Nothing)

            Else

                strPath = RemoveOneLevelAndSlash(objParentFolder.FullName)

                strNextPath = FindPrevFolder(strPath, objParentFolder.FullName)

                If strNextPath <> "" Then

                    txtPath.Text = strNextPath
                    cmdLoad_Click(Nothing, Nothing)

                Else

                    strPath = RemoveOneLevelAndSlash(objParentFolder.FullName)

                    strNextPath = FindPrevFolder(strPath, objParentFolder.FullName)

                End If

            End If
        Else

            txtPath.Text = strFolders(0).FullName
            cmdLoad_Click(Nothing, Nothing)
        End If


    End Sub

    Private Sub cboContents_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboContents.SelectedIndexChanged

        If mblnStopFireOnContents = False Then LoadFiles(txtPath.Text, cboUniqueTypes.SelectedItem & "", cboContents.SelectedItem & "")

    End Sub

    Private Sub cmdNext_Click(sender As Object, e As EventArgs) Handles cmdNext.Click

        Dim objFolder As New DirectoryInfo(txtPath.Text)
        Dim strFolders() As DirectoryInfo
        Dim strPath As String, strNextPath As String

        strFolders = objFolder.GetDirectories()

        If strFolders.Length = 0 Then

            strPath = RemoveOneLevelAndSlash(txtPath.Text)

            Dim objParentFolder As New DirectoryInfo(strPath)

            strNextPath = FindNextFolder(objParentFolder.FullName, txtPath.Text)

            If strNextPath <> "" Then

                txtPath.Text = strNextPath
                cmdLoad_Click(Nothing, Nothing)

            Else

                strPath = RemoveOneLevelAndSlash(objParentFolder.FullName)

                strNextPath = FindNextFolder(strPath, objParentFolder.FullName)

                If strNextPath <> "" Then

                    txtPath.Text = strNextPath
                    cmdLoad_Click(Nothing, Nothing)

                Else

                    strPath = RemoveOneLevelAndSlash(objParentFolder.FullName)

                    strNextPath = FindNextFolder(strPath, objParentFolder.FullName)

                End If

            End If
        Else

            txtPath.Text = strFolders(0).FullName
            cmdLoad_Click(Nothing, Nothing)
        End If

    End Sub

    Private Sub cmdLoadRecursive_Click(sender As Object, e As EventArgs) Handles cmdLoadRecursive.Click

        Dim colMyFiles As New colMyFileInfo, objItem As ListViewItem, strFile As String
        Dim objMyFile As clsMyFileInfo, strType As String, strAllTypes As String, strTypes() As String
        Dim intCount As Integer
        Dim intPos As Integer

        cboContents.SelectedIndex = 0

        mstrLoadType = "LOADFILESRECURSIVE"

        Cursor = Cursors.WaitCursor

        LoadAllFilesInFolder_Recursive(txtPath.Text, colMyFiles, cboRecursiveFilter.Text.ToUpper)

        lvwUpdatefilenames.Items.Clear()

        For Each objMyFile In colMyFiles

            strFile = RemovePath(objMyFile.Fullname)

            objItem = lvwUpdatefilenames.Items.Add(objMyFile.Fullname)

            strType = GetPrefix(strFile)

            If InStr(strAllTypes, strType & ",", CompareMethod.Text) = 0 Then

                strAllTypes = strAllTypes & strType & ","
            End If

            objItem.SubItems.Add(strType)
            objItem.SubItems.Add(strFile)
            objItem.SubItems.Add(objMyFile.Size)
            If chkShowModifiedDate.Checked Then objItem.SubItems.Add(objMyFile.ModifiedDate)
        Next

        strTypes = Split(strAllTypes, ",")

        cboRecursiveFilter.Items.Clear()

        intPos = 1

        For intCount = strTypes.GetLowerBound(0) To strTypes.GetUpperBound(0)

            cboRecursiveFilter.Items.Add(strTypes(intCount))

            Me.Text = "File Renamer" & Space(intPos).Replace(" ", ".")
            Me.Refresh()
        Next

        Dim objE As New ColumnClickEventArgs(COL_NAME)
        lvwFiles_ColumnClick(Nothing, objE)

        Reset()

        Me.Text = My.Application.Info.ProductName & " - " & lvwUpdatefilenames.Items.Count & " file(s)"

    End Sub

    Public Sub LoadAllFilesInFolder_Recursive(ByVal strFrom As String, ByRef colMyFiles As colMyFileInfo, ByVal strPrefix As String)

        Dim objDir As DirectoryInfo, d As DirectoryInfo, objFile As FileInfo, objSubDir As DirectoryInfo
        Dim objMyFile As clsMyFileInfo

        objDir = New DirectoryInfo(strFrom)

        For Each objFile In objDir.GetFiles

            objMyFile = New clsMyFileInfo

            objMyFile.Fullname = objFile.FullName
            objMyFile.Size = objFile.Length
            objMyFile.ModifiedDate = objFile.LastWriteTime

            If strPrefix <> "" Then

                If GetPrefix(objFile.Name).ToUpper = strPrefix Then

                    colMyFiles.Add(objMyFile)
                End If
            Else

                colMyFiles.Add(objMyFile)
            End If
        Next

        For Each d In objDir.GetDirectories()

            For Each objFile In d.GetFiles

                objMyFile = New clsMyFileInfo

                objMyFile.Fullname = objFile.FullName
                objMyFile.Size = objFile.Length
                objMyFile.ModifiedDate = objFile.LastWriteTime

                If strPrefix <> "" Then

                    If GetPrefix(objFile.Name).ToUpper = strPrefix Then

                        colMyFiles.Add(objMyFile)
                    End If
                Else

                    colMyFiles.Add(objMyFile)
                End If

                My.Application.DoEvents()
            Next

            For Each objSubDir In d.GetDirectories

                LoadAllFilesInFolder_Recursive(objSubDir.FullName, colMyFiles, strPrefix)
            Next
        Next

    End Sub

    Private Sub cboRecursiveFilter_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboRecursiveFilter.SelectedIndexChanged

        cmdLoadRecursive_Click(Nothing, Nothing)

    End Sub

    Private Sub chkReviewMagFolder_CheckedChanged(sender As Object, e As EventArgs) Handles chkReviewMagFolder.CheckedChanged

        txtMagReview.Visible = chkReviewMagFolder.Checked

        If chkReviewMagFolder.Checked Then

            ProcessMags()
        End If

    End Sub

    Private Sub ProcessMags()

        Dim objItem As ListViewItem, strName As String
        Dim blnSelected As Boolean, blnDoSelected As Boolean
        Dim intPos As Integer, strSeason As String
        Dim strLeftPart As String, strPrefix As String
        Dim strParts() As String, intCount As Integer, blnProcessed As Boolean

        Dim intJan As Integer, intFeb As Integer
        Dim intMar As Integer, intApr As Integer
        Dim intMay As Integer, intJun As Integer
        Dim intJul As Integer, intAug As Integer
        Dim intSep As Integer, intOct As Integer
        Dim intNov As Integer, intDec As Integer

        Dim blnJan As Boolean, blnFeb As Boolean
        Dim blnMar As Boolean, blnApr As Boolean
        Dim blnMay As Boolean, blnJun As Boolean
        Dim blnJul As Boolean, blnAug As Boolean
        Dim blnSep As Boolean, blnOct As Boolean
        Dim blnNov As Boolean, blnDec As Boolean

        txtMagReview.Text = ""

        If lvwUpdatefilenames.SelectedItems.Count > 0 Then

            blnDoSelected = True
        End If

        For Each objItem In lvwUpdatefilenames.Items

            If blnDoSelected Then

                If objItem.Selected Then

                    blnSelected = True
                Else

                    blnSelected = False
                End If
            Else

                blnSelected = True
            End If

            If blnSelected Then

                blnProcessed = True

                strName = objItem.SubItems(COL_UPDATEFILE_DISKFILENAME).Text

                strParts = Split(strName, " ")

                For intCount = 0 To strParts.Count - 1

                    If Is3Digitmonth(strParts(intCount)) Then

                        Select Case strParts(intCount).ToUpper

                            Case "JAN" : intJan = intJan + 1
                            Case "FEB" : intFeb = intFeb + 1
                            Case "MAR" : intMar = intMar + 1
                            Case "APR" : intApr = intApr + 1
                            Case "MAY" : intMay = intMay + 1
                            Case "JUN" : intJun = intJun + 1
                            Case "JUL" : intJul = intJul + 1
                            Case "AUG" : intAug = intAug + 1
                            Case "SEP" : intSep = intSep + 1
                            Case "OCT" : intOct = intOct + 1
                            Case "NOV" : intNov = intNov + 1
                            Case "DEC" : intDec = intDec + 1

                        End Select

                    End If

                    If IsMonth_4CharsOrFull(strParts(intCount)) Then

                        Select Case strParts(intCount).ToUpper

                            Case "JANU" : intJan = intJan + 1
                            Case "FEBU" : intFeb = intFeb + 1
                            Case "MARC" : intMar = intMar + 1
                            Case "APRI" : intApr = intApr + 1
                            Case "MAY" : intMay = intMay + 1
                            Case "JUNE" : intJun = intJun + 1
                            Case "JULY" : intJul = intJul + 1
                            Case "AUGU" : intAug = intAug + 1
                            Case "SEPT" : intSep = intSep + 1
                            Case "OCTO" : intOct = intOct + 1
                            Case "NOVE" : intNov = intNov + 1
                            Case "DECE" : intDec = intDec + 1

                            Case "JANUARY" : intJan = intJan + 1
                            Case "FEBRUARY" : intFeb = intFeb + 1
                            Case "MARCH" : intMar = intMar + 1
                            Case "APRIL" : intApr = intApr + 1
                            Case "MAY" : intMay = intMay + 1
                            Case "JUNE" : intJun = intJun + 1
                            Case "JULY" : intJul = intJul + 1
                            Case "AUGUST" : intAug = intAug + 1
                            Case "SEPTEMBER" : intSep = intSep + 1
                            Case "OCTOBER" : intOct = intOct + 1
                            Case "NOVEMBER" : intNov = intNov + 1
                            Case "DECEMBER" : intDec = intDec + 1

                        End Select

                    End If
                Next
            End If
        Next

        If blnProcessed Then

            If intJan = 0 Then

                txtMagReview.Text = txtMagReview.Text & "Jan missing" & vbCrLf

            ElseIf intJan = 2 Then

                txtMagReview.Text = txtMagReview.Text & "Jan appears twice" & vbCrLf
            End If

            If intFeb = 0 Then

                txtMagReview.Text = txtMagReview.Text & "Feb missing" & vbCrLf

            ElseIf intFeb = 2 Then

                txtMagReview.Text = txtMagReview.Text & "Feb appears twice" & vbCrLf
            End If

            If intMar = 0 Then

                txtMagReview.Text = txtMagReview.Text & "Mar missing" & vbCrLf

            ElseIf intMar = 2 Then

                txtMagReview.Text = txtMagReview.Text & "Mar appears twice" & vbCrLf
            End If

            If intApr = 0 Then

                txtMagReview.Text = txtMagReview.Text & "Apr missing" & vbCrLf

            ElseIf intApr = 2 Then

                txtMagReview.Text = txtMagReview.Text & "Apr appears twice" & vbCrLf
            End If

            If intMay = 0 Then

                txtMagReview.Text = txtMagReview.Text & "May missing" & vbCrLf

            ElseIf intMay = 3 Then

                txtMagReview.Text = txtMagReview.Text & "May appears twice?" & vbCrLf
            End If

            If intJun = 0 Then

                txtMagReview.Text = txtMagReview.Text & "Jun missing" & vbCrLf

            ElseIf intJun = 2 Then

                txtMagReview.Text = txtMagReview.Text & "Jun appears twice" & vbCrLf
            End If

            If intJul = 0 Then

                txtMagReview.Text = txtMagReview.Text & "Jul missing" & vbCrLf

            ElseIf intJul = 2 Then

                txtMagReview.Text = txtMagReview.Text & "Jul appears twice" & vbCrLf
            End If

            If intAug = 0 Then

                txtMagReview.Text = txtMagReview.Text & "Aug missing" & vbCrLf

            ElseIf intAug = 2 Then

                txtMagReview.Text = txtMagReview.Text & "Aug appears twice" & vbCrLf
            End If

            If intSep = 0 Then

                txtMagReview.Text = txtMagReview.Text & "Sep missing" & vbCrLf

            ElseIf intSep = 2 Then

                txtMagReview.Text = txtMagReview.Text & "Sep appears twice" & vbCrLf
            End If

            If intOct = 0 Then

                txtMagReview.Text = txtMagReview.Text & "Oct missing" & vbCrLf

            ElseIf intOct = 2 Then

                txtMagReview.Text = txtMagReview.Text & "Oct appears twice" & vbCrLf
            End If

            If intNov = 0 Then

                txtMagReview.Text = txtMagReview.Text & "Nov missing" & vbCrLf

            ElseIf intNov = 2 Then

                txtMagReview.Text = txtMagReview.Text & "Nov appears twice" & vbCrLf
            End If

            If intDec = 0 Then

                txtMagReview.Text = txtMagReview.Text & "Dec missing" & vbCrLf

            ElseIf intDec = 2 Then

                txtMagReview.Text = txtMagReview.Text & "Dec appears twice" & vbCrLf
            End If
        End If

    End Sub

    Private Sub chkShowModifiedDate_CheckedChanged(sender As Object, e As EventArgs) Handles chkShowModifiedDate.CheckedChanged

        Form1_Resize(Nothing, Nothing)

    End Sub
End Class
