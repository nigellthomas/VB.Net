﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFileRenamer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmFileRenamer))
        Me.fraFrame = New System.Windows.Forms.GroupBox()
        Me.chkShowModifiedDate = New System.Windows.Forms.CheckBox()
        Me.txtPath = New System.Windows.Forms.ComboBox()
        Me.cboRecursiveFilter = New System.Windows.Forms.ComboBox()
        Me.cmdLoadRecursive = New System.Windows.Forms.Button()
        Me.cboContents = New System.Windows.Forms.ComboBox()
        Me.lblFilterBy = New System.Windows.Forms.Label()
        Me.cmdNext = New System.Windows.Forms.Button()
        Me.cmdPrev = New System.Windows.Forms.Button()
        Me.cmdLoad = New System.Windows.Forms.Button()
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.lblMessageLabel = New System.Windows.Forms.Label()
        Me.cboUniqueTypes = New System.Windows.Forms.ComboBox()
        Me.lblTypeFilter = New System.Windows.Forms.Label()
        Me.lvwUpdatefilenames = New System.Windows.Forms.ListView()
        Me.colNameOnDisk = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colTypeOnDisk = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colProposedName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colSize = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colModDate = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.mnuListviewRightClick = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnuDeleteFiles = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuRemoveHiddenFlag = New System.Windows.Forms.ToolStripMenuItem()
        Me.fraOperations = New System.Windows.Forms.GroupBox()
        Me.cmdUpdFilesApplyProposedFilenames = New System.Windows.Forms.Button()
        Me.lblOperationCombo2 = New System.Windows.Forms.Label()
        Me.cboOperation2 = New System.Windows.Forms.ComboBox()
        Me.lblOperationCombo1 = New System.Windows.Forms.Label()
        Me.cboOperation1 = New System.Windows.Forms.ComboBox()
        Me.chkReviewMagFolder = New System.Windows.Forms.CheckBox()
        Me.cmdUpdateListview = New System.Windows.Forms.Button()
        Me.chkSpecialFeatures = New System.Windows.Forms.CheckBox()
        Me.chkCheckBox2 = New System.Windows.Forms.CheckBox()
        Me.cmdCopyAllItems = New System.Windows.Forms.Button()
        Me.chkCheckBox1 = New System.Windows.Forms.CheckBox()
        Me.txtUpdFilenamesHelp = New System.Windows.Forms.TextBox()
        Me.cmdUpdFilesRemoveItemFromGrid = New System.Windows.Forms.Button()
        Me.cmdUpdFilesUpdateFilenamesInListview = New System.Windows.Forms.Button()
        Me.cmdUpdFilesRemoveSelectionsinGrid = New System.Windows.Forms.Button()
        Me.txtCurrentFilename = New System.Windows.Forms.TextBox()
        Me.cmdUpdFilesRevertToOriginalNames = New System.Windows.Forms.Button()
        Me.txtOperationTextbox2 = New System.Windows.Forms.TextBox()
        Me.txtOperationTextbox1 = New System.Windows.Forms.TextBox()
        Me.lblOperationLabel2 = New System.Windows.Forms.Label()
        Me.lblOperationLabel1 = New System.Windows.Forms.Label()
        Me.lstOperations = New System.Windows.Forms.ListBox()
        Me.txtMagReview = New System.Windows.Forms.TextBox()
        Me.cmdPath = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.fraFrame.SuspendLayout()
        Me.mnuListviewRightClick.SuspendLayout()
        Me.fraOperations.SuspendLayout()
        Me.SuspendLayout()
        '
        'fraFrame
        '
        Me.fraFrame.Controls.Add(Me.chkShowModifiedDate)
        Me.fraFrame.Controls.Add(Me.txtPath)
        Me.fraFrame.Controls.Add(Me.cboRecursiveFilter)
        Me.fraFrame.Controls.Add(Me.cmdLoadRecursive)
        Me.fraFrame.Controls.Add(Me.cboContents)
        Me.fraFrame.Controls.Add(Me.lblFilterBy)
        Me.fraFrame.Controls.Add(Me.cmdNext)
        Me.fraFrame.Controls.Add(Me.cmdPrev)
        Me.fraFrame.Controls.Add(Me.cmdLoad)
        Me.fraFrame.Controls.Add(Me.lblMessage)
        Me.fraFrame.Controls.Add(Me.lblMessageLabel)
        Me.fraFrame.Controls.Add(Me.cboUniqueTypes)
        Me.fraFrame.Controls.Add(Me.lblTypeFilter)
        Me.fraFrame.Controls.Add(Me.lvwUpdatefilenames)
        Me.fraFrame.Controls.Add(Me.fraOperations)
        Me.fraFrame.Controls.Add(Me.cmdPath)
        Me.fraFrame.Controls.Add(Me.Label1)
        Me.fraFrame.Location = New System.Drawing.Point(12, 12)
        Me.fraFrame.Name = "fraFrame"
        Me.fraFrame.Size = New System.Drawing.Size(1138, 705)
        Me.fraFrame.TabIndex = 0
        Me.fraFrame.TabStop = False
        Me.fraFrame.Text = "File Renamer"
        '
        'chkShowModifiedDate
        '
        Me.chkShowModifiedDate.AutoSize = True
        Me.chkShowModifiedDate.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkShowModifiedDate.Location = New System.Drawing.Point(1068, 15)
        Me.chkShowModifiedDate.Name = "chkShowModifiedDate"
        Me.chkShowModifiedDate.Size = New System.Drawing.Size(122, 17)
        Me.chkShowModifiedDate.TabIndex = 32
        Me.chkShowModifiedDate.Text = "Show Modified Date"
        Me.ToolTip1.SetToolTip(Me.chkShowModifiedDate, "Show Modified Date in column of listview")
        Me.chkShowModifiedDate.UseVisualStyleBackColor = True
        '
        'txtPath
        '
        Me.txtPath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPath.FormattingEnabled = True
        Me.txtPath.Location = New System.Drawing.Point(50, 30)
        Me.txtPath.Name = "txtPath"
        Me.txtPath.Size = New System.Drawing.Size(677, 21)
        Me.txtPath.TabIndex = 31
        '
        'cboRecursiveFilter
        '
        Me.cboRecursiveFilter.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cboRecursiveFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboRecursiveFilter.FormattingEnabled = True
        Me.cboRecursiveFilter.Location = New System.Drawing.Point(961, 15)
        Me.cboRecursiveFilter.Name = "cboRecursiveFilter"
        Me.cboRecursiveFilter.Size = New System.Drawing.Size(101, 21)
        Me.cboRecursiveFilter.TabIndex = 30
        '
        'cmdLoadRecursive
        '
        Me.cmdLoadRecursive.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdLoadRecursive.Location = New System.Drawing.Point(854, 19)
        Me.cmdLoadRecursive.Name = "cmdLoadRecursive"
        Me.cmdLoadRecursive.Size = New System.Drawing.Size(101, 28)
        Me.cmdLoadRecursive.TabIndex = 29
        Me.cmdLoadRecursive.TabStop = False
        Me.cmdLoadRecursive.Text = "Load Recursive"
        Me.cmdLoadRecursive.UseVisualStyleBackColor = True
        '
        'cboContents
        '
        Me.cboContents.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboContents.FormattingEnabled = True
        Me.cboContents.Location = New System.Drawing.Point(323, 504)
        Me.cboContents.Name = "cboContents"
        Me.cboContents.Size = New System.Drawing.Size(147, 21)
        Me.cboContents.TabIndex = 28
        '
        'lblFilterBy
        '
        Me.lblFilterBy.AutoSize = True
        Me.lblFilterBy.Location = New System.Drawing.Point(274, 507)
        Me.lblFilterBy.Name = "lblFilterBy"
        Me.lblFilterBy.Size = New System.Drawing.Size(43, 13)
        Me.lblFilterBy.TabIndex = 27
        Me.lblFilterBy.Text = "Filter by"
        '
        'cmdNext
        '
        Me.cmdNext.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdNext.Location = New System.Drawing.Point(996, 42)
        Me.cmdNext.Name = "cmdNext"
        Me.cmdNext.Size = New System.Drawing.Size(29, 18)
        Me.cmdNext.TabIndex = 26
        Me.cmdNext.TabStop = False
        Me.cmdNext.Text = "->"
        Me.cmdNext.UseVisualStyleBackColor = True
        '
        'cmdPrev
        '
        Me.cmdPrev.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdPrev.Location = New System.Drawing.Point(961, 42)
        Me.cmdPrev.Name = "cmdPrev"
        Me.cmdPrev.Size = New System.Drawing.Size(29, 18)
        Me.cmdPrev.TabIndex = 25
        Me.cmdPrev.TabStop = False
        Me.cmdPrev.Text = "<-"
        Me.cmdPrev.UseVisualStyleBackColor = True
        '
        'cmdLoad
        '
        Me.cmdLoad.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdLoad.Enabled = False
        Me.cmdLoad.Location = New System.Drawing.Point(768, 30)
        Me.cmdLoad.Name = "cmdLoad"
        Me.cmdLoad.Size = New System.Drawing.Size(51, 19)
        Me.cmdLoad.TabIndex = 24
        Me.cmdLoad.TabStop = False
        Me.cmdLoad.Text = "Load"
        Me.cmdLoad.UseVisualStyleBackColor = True
        '
        'lblMessage
        '
        Me.lblMessage.AutoSize = True
        Me.lblMessage.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMessage.Location = New System.Drawing.Point(567, 510)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(57, 13)
        Me.lblMessage.TabIndex = 18
        Me.lblMessage.Text = "Message"
        '
        'lblMessageLabel
        '
        Me.lblMessageLabel.AutoSize = True
        Me.lblMessageLabel.Location = New System.Drawing.Point(511, 510)
        Me.lblMessageLabel.Name = "lblMessageLabel"
        Me.lblMessageLabel.Size = New System.Drawing.Size(50, 13)
        Me.lblMessageLabel.TabIndex = 16
        Me.lblMessageLabel.Text = "Message"
        '
        'cboUniqueTypes
        '
        Me.cboUniqueTypes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboUniqueTypes.FormattingEnabled = True
        Me.cboUniqueTypes.Location = New System.Drawing.Point(107, 504)
        Me.cboUniqueTypes.Name = "cboUniqueTypes"
        Me.cboUniqueTypes.Size = New System.Drawing.Size(159, 21)
        Me.cboUniqueTypes.TabIndex = 15
        '
        'lblTypeFilter
        '
        Me.lblTypeFilter.AutoSize = True
        Me.lblTypeFilter.Location = New System.Drawing.Point(15, 507)
        Me.lblTypeFilter.Name = "lblTypeFilter"
        Me.lblTypeFilter.Size = New System.Drawing.Size(86, 13)
        Me.lblTypeFilter.TabIndex = 14
        Me.lblTypeFilter.Text = "Filter by FileType"
        '
        'lvwUpdatefilenames
        '
        Me.lvwUpdatefilenames.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colNameOnDisk, Me.colTypeOnDisk, Me.colProposedName, Me.colSize, Me.colModDate})
        Me.lvwUpdatefilenames.ContextMenuStrip = Me.mnuListviewRightClick
        Me.lvwUpdatefilenames.FullRowSelect = True
        Me.lvwUpdatefilenames.GridLines = True
        Me.lvwUpdatefilenames.HideSelection = False
        Me.lvwUpdatefilenames.Location = New System.Drawing.Point(18, 63)
        Me.lvwUpdatefilenames.Name = "lvwUpdatefilenames"
        Me.lvwUpdatefilenames.Size = New System.Drawing.Size(937, 435)
        Me.lvwUpdatefilenames.TabIndex = 13
        Me.lvwUpdatefilenames.UseCompatibleStateImageBehavior = False
        Me.lvwUpdatefilenames.View = System.Windows.Forms.View.Details
        '
        'colNameOnDisk
        '
        Me.colNameOnDisk.Text = "Name on Disk"
        Me.colNameOnDisk.Width = 150
        '
        'colTypeOnDisk
        '
        Me.colTypeOnDisk.Text = "Type"
        '
        'colProposedName
        '
        Me.colProposedName.Text = "Proposed Name"
        '
        'colSize
        '
        Me.colSize.Text = "Size"
        '
        'colModDate
        '
        Me.colModDate.Text = "Modified Date"
        Me.colModDate.Width = 0
        '
        'mnuListviewRightClick
        '
        Me.mnuListviewRightClick.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuDeleteFiles, Me.mnuRemoveHiddenFlag})
        Me.mnuListviewRightClick.Name = "mnuRightClick"
        Me.mnuListviewRightClick.Size = New System.Drawing.Size(173, 48)
        '
        'mnuDeleteFiles
        '
        Me.mnuDeleteFiles.Name = "mnuDeleteFiles"
        Me.mnuDeleteFiles.Size = New System.Drawing.Size(172, 22)
        Me.mnuDeleteFiles.Text = "Delete File(s)"
        '
        'mnuRemoveHiddenFlag
        '
        Me.mnuRemoveHiddenFlag.Name = "mnuRemoveHiddenFlag"
        Me.mnuRemoveHiddenFlag.Size = New System.Drawing.Size(172, 22)
        Me.mnuRemoveHiddenFlag.Text = "Remove Hidden Flag"
        '
        'fraOperations
        '
        Me.fraOperations.Controls.Add(Me.cmdUpdFilesApplyProposedFilenames)
        Me.fraOperations.Controls.Add(Me.lblOperationCombo2)
        Me.fraOperations.Controls.Add(Me.cboOperation2)
        Me.fraOperations.Controls.Add(Me.lblOperationCombo1)
        Me.fraOperations.Controls.Add(Me.cboOperation1)
        Me.fraOperations.Controls.Add(Me.chkReviewMagFolder)
        Me.fraOperations.Controls.Add(Me.cmdUpdateListview)
        Me.fraOperations.Controls.Add(Me.chkSpecialFeatures)
        Me.fraOperations.Controls.Add(Me.chkCheckBox2)
        Me.fraOperations.Controls.Add(Me.cmdCopyAllItems)
        Me.fraOperations.Controls.Add(Me.chkCheckBox1)
        Me.fraOperations.Controls.Add(Me.txtUpdFilenamesHelp)
        Me.fraOperations.Controls.Add(Me.cmdUpdFilesRemoveItemFromGrid)
        Me.fraOperations.Controls.Add(Me.cmdUpdFilesUpdateFilenamesInListview)
        Me.fraOperations.Controls.Add(Me.cmdUpdFilesRemoveSelectionsinGrid)
        Me.fraOperations.Controls.Add(Me.txtCurrentFilename)
        Me.fraOperations.Controls.Add(Me.cmdUpdFilesRevertToOriginalNames)
        Me.fraOperations.Controls.Add(Me.txtOperationTextbox2)
        Me.fraOperations.Controls.Add(Me.txtOperationTextbox1)
        Me.fraOperations.Controls.Add(Me.lblOperationLabel2)
        Me.fraOperations.Controls.Add(Me.lblOperationLabel1)
        Me.fraOperations.Controls.Add(Me.lstOperations)
        Me.fraOperations.Controls.Add(Me.txtMagReview)
        Me.fraOperations.Location = New System.Drawing.Point(18, 532)
        Me.fraOperations.Name = "fraOperations"
        Me.fraOperations.Size = New System.Drawing.Size(893, 167)
        Me.fraOperations.TabIndex = 12
        Me.fraOperations.TabStop = False
        Me.fraOperations.Text = "Operations"
        '
        'cmdUpdFilesApplyProposedFilenames
        '
        Me.cmdUpdFilesApplyProposedFilenames.Enabled = False
        Me.cmdUpdFilesApplyProposedFilenames.Location = New System.Drawing.Point(700, 83)
        Me.cmdUpdFilesApplyProposedFilenames.Name = "cmdUpdFilesApplyProposedFilenames"
        Me.cmdUpdFilesApplyProposedFilenames.Size = New System.Drawing.Size(145, 25)
        Me.cmdUpdFilesApplyProposedFilenames.TabIndex = 15
        Me.cmdUpdFilesApplyProposedFilenames.Text = "Update Filenames on Disk"
        Me.cmdUpdFilesApplyProposedFilenames.UseVisualStyleBackColor = True
        '
        'lblOperationCombo2
        '
        Me.lblOperationCombo2.AutoSize = True
        Me.lblOperationCombo2.Location = New System.Drawing.Point(468, 132)
        Me.lblOperationCombo2.Name = "lblOperationCombo2"
        Me.lblOperationCombo2.Size = New System.Drawing.Size(39, 13)
        Me.lblOperationCombo2.TabIndex = 32
        Me.lblOperationCombo2.Text = "Label5"
        Me.lblOperationCombo2.Visible = False
        '
        'cboOperation2
        '
        Me.cboOperation2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboOperation2.FormattingEnabled = True
        Me.cboOperation2.Location = New System.Drawing.Point(495, 129)
        Me.cboOperation2.Name = "cboOperation2"
        Me.cboOperation2.Size = New System.Drawing.Size(147, 21)
        Me.cboOperation2.TabIndex = 31
        Me.cboOperation2.Visible = False
        '
        'lblOperationCombo1
        '
        Me.lblOperationCombo1.AutoSize = True
        Me.lblOperationCombo1.Location = New System.Drawing.Point(372, 117)
        Me.lblOperationCombo1.Name = "lblOperationCombo1"
        Me.lblOperationCombo1.Size = New System.Drawing.Size(39, 13)
        Me.lblOperationCombo1.TabIndex = 30
        Me.lblOperationCombo1.Text = "Label5"
        Me.lblOperationCombo1.Visible = False
        '
        'cboOperation1
        '
        Me.cboOperation1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboOperation1.FormattingEnabled = True
        Me.cboOperation1.Location = New System.Drawing.Point(437, 114)
        Me.cboOperation1.Name = "cboOperation1"
        Me.cboOperation1.Size = New System.Drawing.Size(147, 21)
        Me.cboOperation1.TabIndex = 29
        Me.cboOperation1.Visible = False
        '
        'chkReviewMagFolder
        '
        Me.chkReviewMagFolder.AutoSize = True
        Me.chkReviewMagFolder.Location = New System.Drawing.Point(658, 118)
        Me.chkReviewMagFolder.Name = "chkReviewMagFolder"
        Me.chkReviewMagFolder.Size = New System.Drawing.Size(121, 17)
        Me.chkReviewMagFolder.TabIndex = 25
        Me.chkReviewMagFolder.Text = "Review Mag. Folder"
        Me.chkReviewMagFolder.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chkReviewMagFolder.UseVisualStyleBackColor = True
        '
        'cmdUpdateListview
        '
        Me.cmdUpdateListview.Location = New System.Drawing.Point(331, 132)
        Me.cmdUpdateListview.Name = "cmdUpdateListview"
        Me.cmdUpdateListview.Size = New System.Drawing.Size(158, 25)
        Me.cmdUpdateListview.TabIndex = 24
        Me.cmdUpdateListview.Text = "Update Listview"
        Me.cmdUpdateListview.UseVisualStyleBackColor = True
        '
        'chkSpecialFeatures
        '
        Me.chkSpecialFeatures.AutoSize = True
        Me.chkSpecialFeatures.Location = New System.Drawing.Point(730, 118)
        Me.chkSpecialFeatures.Name = "chkSpecialFeatures"
        Me.chkSpecialFeatures.Size = New System.Drawing.Size(168, 17)
        Me.chkSpecialFeatures.TabIndex = 23
        Me.chkSpecialFeatures.Text = "Make Special Features Visible"
        Me.chkSpecialFeatures.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chkSpecialFeatures.UseVisualStyleBackColor = True
        '
        'chkCheckBox2
        '
        Me.chkCheckBox2.AutoSize = True
        Me.chkCheckBox2.Location = New System.Drawing.Point(244, 137)
        Me.chkCheckBox2.Name = "chkCheckBox2"
        Me.chkCheckBox2.Size = New System.Drawing.Size(81, 17)
        Me.chkCheckBox2.TabIndex = 22
        Me.chkCheckBox2.Text = "CheckBox2"
        Me.chkCheckBox2.UseVisualStyleBackColor = True
        Me.chkCheckBox2.Visible = False
        '
        'cmdCopyAllItems
        '
        Me.cmdCopyAllItems.Location = New System.Drawing.Point(762, 148)
        Me.cmdCopyAllItems.Name = "cmdCopyAllItems"
        Me.cmdCopyAllItems.Size = New System.Drawing.Size(99, 25)
        Me.cmdCopyAllItems.TabIndex = 23
        Me.cmdCopyAllItems.Text = "Copy All Items"
        Me.ToolTip1.SetToolTip(Me.cmdCopyAllItems, "Copy all items to a folder so that I can find likely duplicates ")
        Me.cmdCopyAllItems.UseVisualStyleBackColor = True
        Me.cmdCopyAllItems.Visible = False
        '
        'chkCheckBox1
        '
        Me.chkCheckBox1.AutoSize = True
        Me.chkCheckBox1.Location = New System.Drawing.Point(244, 114)
        Me.chkCheckBox1.Name = "chkCheckBox1"
        Me.chkCheckBox1.Size = New System.Drawing.Size(81, 17)
        Me.chkCheckBox1.TabIndex = 21
        Me.chkCheckBox1.Text = "CheckBox1"
        Me.chkCheckBox1.UseVisualStyleBackColor = True
        Me.chkCheckBox1.Visible = False
        '
        'txtUpdFilenamesHelp
        '
        Me.txtUpdFilenamesHelp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtUpdFilenamesHelp.Location = New System.Drawing.Point(730, 20)
        Me.txtUpdFilenamesHelp.Multiline = True
        Me.txtUpdFilenamesHelp.Name = "txtUpdFilenamesHelp"
        Me.txtUpdFilenamesHelp.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtUpdFilenamesHelp.Size = New System.Drawing.Size(340, 150)
        Me.txtUpdFilenamesHelp.TabIndex = 20
        '
        'cmdUpdFilesRemoveItemFromGrid
        '
        Me.cmdUpdFilesRemoveItemFromGrid.Location = New System.Drawing.Point(515, 83)
        Me.cmdUpdFilesRemoveItemFromGrid.Name = "cmdUpdFilesRemoveItemFromGrid"
        Me.cmdUpdFilesRemoveItemFromGrid.Size = New System.Drawing.Size(158, 25)
        Me.cmdUpdFilesRemoveItemFromGrid.TabIndex = 19
        Me.cmdUpdFilesRemoveItemFromGrid.Text = "Remove Item From Grid"
        Me.cmdUpdFilesRemoveItemFromGrid.UseVisualStyleBackColor = True
        '
        'cmdUpdFilesUpdateFilenamesInListview
        '
        Me.cmdUpdFilesUpdateFilenamesInListview.Location = New System.Drawing.Point(6, 83)
        Me.cmdUpdFilesUpdateFilenamesInListview.Name = "cmdUpdFilesUpdateFilenamesInListview"
        Me.cmdUpdFilesUpdateFilenamesInListview.Size = New System.Drawing.Size(162, 25)
        Me.cmdUpdFilesUpdateFilenamesInListview.TabIndex = 8
        Me.cmdUpdFilesUpdateFilenamesInListview.Text = "Update Filenames in Listview"
        Me.cmdUpdFilesUpdateFilenamesInListview.UseVisualStyleBackColor = True
        '
        'cmdUpdFilesRemoveSelectionsinGrid
        '
        Me.cmdUpdFilesRemoveSelectionsinGrid.Location = New System.Drawing.Point(349, 83)
        Me.cmdUpdFilesRemoveSelectionsinGrid.Name = "cmdUpdFilesRemoveSelectionsinGrid"
        Me.cmdUpdFilesRemoveSelectionsinGrid.Size = New System.Drawing.Size(158, 25)
        Me.cmdUpdFilesRemoveSelectionsinGrid.TabIndex = 17
        Me.cmdUpdFilesRemoveSelectionsinGrid.Text = "Remove Selections in Grid"
        Me.cmdUpdFilesRemoveSelectionsinGrid.UseVisualStyleBackColor = True
        '
        'txtCurrentFilename
        '
        Me.txtCurrentFilename.Location = New System.Drawing.Point(244, 20)
        Me.txtCurrentFilename.Name = "txtCurrentFilename"
        Me.txtCurrentFilename.ReadOnly = True
        Me.txtCurrentFilename.Size = New System.Drawing.Size(475, 20)
        Me.txtCurrentFilename.TabIndex = 16
        '
        'cmdUpdFilesRevertToOriginalNames
        '
        Me.cmdUpdFilesRevertToOriginalNames.Location = New System.Drawing.Point(176, 83)
        Me.cmdUpdFilesRevertToOriginalNames.Name = "cmdUpdFilesRevertToOriginalNames"
        Me.cmdUpdFilesRevertToOriginalNames.Size = New System.Drawing.Size(166, 25)
        Me.cmdUpdFilesRevertToOriginalNames.TabIndex = 14
        Me.cmdUpdFilesRevertToOriginalNames.Text = "Restore Filenames in Listview"
        Me.cmdUpdFilesRevertToOriginalNames.UseVisualStyleBackColor = True
        '
        'txtOperationTextbox2
        '
        Me.txtOperationTextbox2.Location = New System.Drawing.Point(463, 83)
        Me.txtOperationTextbox2.Name = "txtOperationTextbox2"
        Me.txtOperationTextbox2.Size = New System.Drawing.Size(210, 20)
        Me.txtOperationTextbox2.TabIndex = 13
        Me.txtOperationTextbox2.Visible = False
        '
        'txtOperationTextbox1
        '
        Me.txtOperationTextbox1.Location = New System.Drawing.Point(242, 83)
        Me.txtOperationTextbox1.Name = "txtOperationTextbox1"
        Me.txtOperationTextbox1.Size = New System.Drawing.Size(210, 20)
        Me.txtOperationTextbox1.TabIndex = 12
        Me.txtOperationTextbox1.Visible = False
        '
        'lblOperationLabel2
        '
        Me.lblOperationLabel2.AutoSize = True
        Me.lblOperationLabel2.Location = New System.Drawing.Point(460, 61)
        Me.lblOperationLabel2.Name = "lblOperationLabel2"
        Me.lblOperationLabel2.Size = New System.Drawing.Size(39, 13)
        Me.lblOperationLabel2.TabIndex = 11
        Me.lblOperationLabel2.Text = "Label5"
        Me.lblOperationLabel2.Visible = False
        '
        'lblOperationLabel1
        '
        Me.lblOperationLabel1.AutoSize = True
        Me.lblOperationLabel1.Location = New System.Drawing.Point(239, 61)
        Me.lblOperationLabel1.Name = "lblOperationLabel1"
        Me.lblOperationLabel1.Size = New System.Drawing.Size(39, 13)
        Me.lblOperationLabel1.TabIndex = 10
        Me.lblOperationLabel1.Text = "Label4"
        Me.lblOperationLabel1.Visible = False
        '
        'lstOperations
        '
        Me.lstOperations.FormattingEnabled = True
        Me.lstOperations.Location = New System.Drawing.Point(6, 20)
        Me.lstOperations.Name = "lstOperations"
        Me.lstOperations.Size = New System.Drawing.Size(232, 160)
        Me.lstOperations.TabIndex = 18
        '
        'txtMagReview
        '
        Me.txtMagReview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMagReview.Location = New System.Drawing.Point(762, 37)
        Me.txtMagReview.Multiline = True
        Me.txtMagReview.Name = "txtMagReview"
        Me.txtMagReview.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtMagReview.Size = New System.Drawing.Size(233, 60)
        Me.txtMagReview.TabIndex = 27
        Me.txtMagReview.Visible = False
        '
        'cmdPath
        '
        Me.cmdPath.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdPath.Location = New System.Drawing.Point(733, 30)
        Me.cmdPath.Name = "cmdPath"
        Me.cmdPath.Size = New System.Drawing.Size(29, 19)
        Me.cmdPath.TabIndex = 10
        Me.cmdPath.TabStop = False
        Me.cmdPath.Text = "..."
        Me.cmdPath.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Path"
        '
        'cmdClose
        '
        Me.cmdClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdClose.Location = New System.Drawing.Point(878, 723)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Size = New System.Drawing.Size(89, 27)
        Me.cmdClose.TabIndex = 1
        Me.cmdClose.Text = "Close"
        Me.cmdClose.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        Me.Timer1.Interval = 5000
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.Visible = True
        '
        'frmFileRenamer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1162, 751)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.fraFrame)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmFileRenamer"
        Me.Text = "File Renamer"
        Me.fraFrame.ResumeLayout(False)
        Me.fraFrame.PerformLayout()
        Me.mnuListviewRightClick.ResumeLayout(False)
        Me.fraOperations.ResumeLayout(False)
        Me.fraOperations.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents fraFrame As System.Windows.Forms.GroupBox
    Friend WithEvents cmdPath As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents fraOperations As System.Windows.Forms.GroupBox
    Friend WithEvents txtUpdFilenamesHelp As System.Windows.Forms.TextBox
    Friend WithEvents cmdUpdFilesRemoveItemFromGrid As System.Windows.Forms.Button
    Friend WithEvents cmdUpdFilesUpdateFilenamesInListview As System.Windows.Forms.Button
    Friend WithEvents cmdUpdFilesRemoveSelectionsinGrid As System.Windows.Forms.Button
    Friend WithEvents txtCurrentFilename As System.Windows.Forms.TextBox
    Friend WithEvents cmdUpdFilesApplyProposedFilenames As System.Windows.Forms.Button
    Friend WithEvents cmdUpdFilesRevertToOriginalNames As System.Windows.Forms.Button
    Friend WithEvents txtOperationTextbox2 As System.Windows.Forms.TextBox
    Friend WithEvents txtOperationTextbox1 As System.Windows.Forms.TextBox
    Friend WithEvents lblOperationLabel2 As System.Windows.Forms.Label
    Friend WithEvents lblOperationLabel1 As System.Windows.Forms.Label
    Friend WithEvents lstOperations As System.Windows.Forms.ListBox
    Friend WithEvents lvwUpdatefilenames As System.Windows.Forms.ListView
    Friend WithEvents colNameOnDisk As System.Windows.Forms.ColumnHeader
    Friend WithEvents colTypeOnDisk As System.Windows.Forms.ColumnHeader
    Friend WithEvents colProposedName As System.Windows.Forms.ColumnHeader
    Friend WithEvents cboUniqueTypes As System.Windows.Forms.ComboBox
    Friend WithEvents lblTypeFilter As System.Windows.Forms.Label
    Friend WithEvents lblMessageLabel As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents lblMessage As System.Windows.Forms.Label
    Friend WithEvents chkCheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents chkCheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents cmdCopyAllItems As System.Windows.Forms.Button
    Friend WithEvents chkSpecialFeatures As System.Windows.Forms.CheckBox
    Friend WithEvents cmdLoad As System.Windows.Forms.Button
    Friend WithEvents cmdUpdateListview As System.Windows.Forms.Button
    Friend WithEvents mnuListviewRightClick As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mnuDeleteFiles As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmdNext As System.Windows.Forms.Button
    Friend WithEvents cmdPrev As System.Windows.Forms.Button
    Friend WithEvents cboContents As System.Windows.Forms.ComboBox
    Friend WithEvents lblFilterBy As System.Windows.Forms.Label
    Friend WithEvents NotifyIcon1 As System.Windows.Forms.NotifyIcon
    Friend WithEvents cmdLoadRecursive As System.Windows.Forms.Button
    Friend WithEvents cboRecursiveFilter As System.Windows.Forms.ComboBox
    Friend WithEvents colSize As System.Windows.Forms.ColumnHeader
    Friend WithEvents txtPath As System.Windows.Forms.ComboBox
    Friend WithEvents chkReviewMagFolder As System.Windows.Forms.CheckBox
    Friend WithEvents txtMagReview As System.Windows.Forms.TextBox
    Friend WithEvents colModDate As System.Windows.Forms.ColumnHeader
    Friend WithEvents chkShowModifiedDate As System.Windows.Forms.CheckBox
    Friend WithEvents cboOperation1 As System.Windows.Forms.ComboBox
    Friend WithEvents lblOperationCombo1 As System.Windows.Forms.Label
    Friend WithEvents lblOperationCombo2 As System.Windows.Forms.Label
    Friend WithEvents cboOperation2 As System.Windows.Forms.ComboBox
    Friend WithEvents mnuRemoveHiddenFlag As System.Windows.Forms.ToolStripMenuItem

End Class
