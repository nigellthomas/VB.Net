VERSION 5.00
Begin VB.Form frmMain 
   AutoRedraw      =   -1  'True
   Caption         =   "Internet Cache Sniffer"
   ClientHeight    =   6405
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   10980
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   6405
   ScaleWidth      =   10980
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command2 
      Caption         =   "&Find"
      Height          =   315
      Left            =   10110
      TabIndex        =   7
      Top             =   60
      Width           =   735
   End
   Begin VB.TextBox Text2 
      Height          =   315
      Left            =   6645
      TabIndex        =   5
      Text            =   ".mp3"
      Top             =   60
      Width           =   3465
   End
   Begin VB.ListBox List1 
      Height          =   2790
      Left            =   60
      Sorted          =   -1  'True
      TabIndex        =   4
      Top             =   420
      Width           =   10785
   End
   Begin VB.CommandButton Command1 
      Caption         =   "&Print"
      Height          =   510
      Left            =   9285
      TabIndex        =   3
      Top             =   5745
      Width           =   1560
   End
   Begin VB.TextBox Text1 
      BeginProperty Font 
         Name            =   "Microsoft Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2295
      Left            =   60
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   2
      Top             =   3345
      Width           =   10785
   End
   Begin VB.ComboBox Combo1 
      Height          =   315
      Left            =   60
      TabIndex        =   0
      Text            =   "Combo1"
      Top             =   60
      Width           =   2310
   End
   Begin VB.Label Label2 
      Alignment       =   1  'Right Justify
      Caption         =   "Contains Text:"
      Height          =   255
      Left            =   5445
      TabIndex        =   6
      Top             =   90
      Width           =   1155
   End
   Begin VB.Label Label1 
      Height          =   255
      Left            =   2445
      TabIndex        =   1
      Top             =   90
      Width           =   2865
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Enum EntryType
    etNormalEntry = &H1
    etEditedEntry = &H8
    etTrackOffLineEntry = &H10
    etTrackOnLineEntry = &H20
    etStickyEntry = &H40
    etSparseEntry = &H10000
    etCookieEntry = &H100000
    etURLHistoryEntry = &H200000
End Enum

Private Const DEFAULT_CACHE_FILTER      As Long = etNormalEntry Or _
                                                  etEditedEntry Or _
                                                  etTrackOffLineEntry Or _
                                                  etTrackOnLineEntry Or _
                                                  etStickyEntry Or _
                                                  etSparseEntry Or _
                                                  etCookieEntry Or _
                                                  etURLHistoryEntry
                                            
Private mobjCacheFiles                  As clsCacheFiles

Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Private EXE_PATH As String
Private Const APP_NAME = "MP3TurboMate.exe"

Private Declare Function GetComputerName Lib "kernel32" Alias "GetComputerNameA" _
                          (ByVal lpbuffer As String, nSize As Long) As Long
                          
Dim mobjFSO As FileSystemObject
                          
'****************************************************************************
'  Name         : GetComputersName
'  Description  :
'  Parameters   : None
'  Returns      : String
'  Author       :
'  Date         : 11 Nov 2000
'****************************************************************************

Private Function GetComputersName() As String
     
Dim strName As String, lngLen As Long

    strName = "                       "
    
    lngLen = Len(strName)
    
    If GetComputerName(strName, lngLen) = False Then
    
        GetComputersName = ""
        
    Else
        
        GetComputersName = Mid$(strName, 1, lngLen)
    End If

End Function

Private Sub Combo1_Click()
    Dim objCacheFile            As clsCacheFile
    Static slngLastItem         As Long
    If slngLastItem = Combo1.ItemData(Combo1.ListIndex) Then Exit Sub
    MousePointer = vbHourglass
    Text2.Text = vbNullString
    mobjCacheFiles.Filter , Combo1.ItemData(Combo1.ListIndex)
    List1.Clear
    For Each objCacheFile In mobjCacheFiles.CacheFiles
        With List1
            .AddItem objCacheFile.SourceURL
            .ItemData(.NewIndex) = objCacheFile.Index
        End With
    Next
    Label1.Caption = mobjCacheFiles.Count & " Found"
    slngLastItem = Combo1.ItemData(Combo1.ListIndex)
    MousePointer = vbDefault
End Sub

Private Sub Command1_Click()
    On Error Resume Next
    Command1.Enabled = False
    MousePointer = vbHourglass
    Printer.Print Text1.Text
    MousePointer = vbDefault
    Command1.Enabled = True
End Sub

Private Sub Command2_Click()

    Dim objCacheFile            As clsCacheFile
    Static bytClickID           As Byte
    
    If bytClickID = 0 Then
        bytClickID = 1
        Command2.Caption = "&Clear"
        mobjCacheFiles.Filter , , Text2.Text
    Else
        bytClickID = 0
        Command2.Caption = "&Find"
        mobjCacheFiles.Filter False
    End If
    MousePointer = vbHourglass
    List1.Clear
    
    For Each objCacheFile In mobjCacheFiles.CacheFiles
        With List1
        
            .AddItem objCacheFile.SourceURL
            .ItemData(.NewIndex) = objCacheFile.Index
        End With
    Next
        
End Sub

Public Function RemovePath(ByVal strPath As String) As String
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim intPos As Integer

2:    intPos = InStrRev(strPath, "\")
    
3:    RemovePath = Mid$(strPath, intPos + 1)

'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "strPath:" & strPath & vbNewLine
    strMSLDebugHandler_Variables = "intPos = " & intPos & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Renamer", "modGeneralProcedures", "RemovePath", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Private Sub SaveHypeMPage()

Dim strStartHTML As String, frmPort As frmInet, objTS As TextStream, objFSO As FileSystemObject

20      Set frmPort = New frmInet
    
21      strStartHTML = frmPort.Inet1.OpenURL("http://hypem.com/#/popular", 0)

22      Sleep 250

23      Do Until frmPort.Inet1.StillExecuting = False
    
24          DoEvents
        
25          Sleep 900
26      Loop
    
       Set objFSO = New FileSystemObject
    
    Set objTS = objFSO.CreateTextFile(App.Path & "\HypeM_" & Format$(Date, "dd_mmm_yyyy") & ".html", True)
    
    objTS.Write strStartHTML
    
    objTS.Close
    Set objTS = Nothing

End Sub

Private Sub Form_Load()
    
Dim objCacheFile As clsCacheFile, objCacheFiles As clsCacheFiles, objFSO As FileSystemObject, strFile As String
Dim objFile As File, objFolder As Folder, objFiles As Files, strStoragePath As String
Dim strStoragePathTemp As String, strFirefoxStoragePath As String, objFile2 As File

On Error GoTo errHandler

1       Set objFSO = New FileSystemObject
    
2       If GetComputersName <> "WINDOWS-GOGB36E" Then
    
3           EXE_PATH = "D:\My Stuff\My Music\Project\"
    
4           strStoragePath = "D:\My Stuff\My Music\New Tracks\Tracks\Hype Machine\"
5           strStoragePathTemp = "C:\Temp\Hype Machine Temp\"
        
6           If Not objFSO.FolderExists(strStoragePath) Then
        
7               objFSO.CreateFolder strStoragePath
8           End If
    
9           If Not objFSO.FolderExists(strStoragePathTemp) Then
        
10              objFSO.CreateFolder strStoragePathTemp
11          End If
12      Else
    
13          EXE_PATH = "C:\My Music\Project\"
    
14          strStoragePath = "C:\My Music\Hype Machine\"
15          strStoragePathTemp = "C:\Temp\Hype Machine Temp\"
        
16          If Not objFSO.FolderExists(strStoragePath) Then
        
17              objFSO.CreateFolder strStoragePath
18          End If
        
22          If Not objFSO.FolderExists(strStoragePathTemp) Then
        
23              objFSO.CreateFolder strStoragePathTemp
24          End If
25      End If
            
26      Set objFolder = objFSO.GetFolder(strStoragePathTemp)
                  
27      For Each objFile In objFolder.Files
            
28          If Err.Number = 0 Then
            
29              ExecCmd EXE_PATH & APP_NAME & " " & strStoragePathTemp & objFile.Name & "�""" & RENAME_FROM_TAG
30          End If
            
31          Sleep 200
                        
32          Sleep 200
            
33          DoEvents
34      Next
        
35      Set objFolder = objFSO.GetFolder(strStoragePathTemp)
                    
36      For Each objFile In objFolder.Files
            
37          If objFSO.FileExists(strStoragePath & objFile.Name) Then
                
                ' Do Nothing
38              objFile.Delete
39          Else
                    
40              objFile.Move strStoragePath
41          End If
42      Next
    
43      Set objFolder = objFSO.GetFolder(strStoragePath)
             
44      If objFolder.Files.Count > 0 Then
            
45          Set objFiles = objFolder.Files
                
46          For Each objFile In objFiles
                
47              If IsValidPrefix(objFile.Path) Then Exit For
48          Next
                    
49          ExecCmd EXE_PATH & APP_NAME & " " & objFile.Path & "�""" & FILTER_FOLDER_HYPE_MACHINE
            
50      End If
                
51      Set objFolder = objFSO.GetFolder(strStoragePath)
            
52      If objFolder.Files.Count > 0 Then
            
53          Set objFiles = objFolder.Files
                
54          For Each objFile In objFiles
                
55              If IsValidPrefix(objFile.Path) Then
                    
56                  Exit For
57              End If
58          Next
                            
59          ExecCmd EXE_PATH & APP_NAME & " " & objFile.Path & "�""" & LIGHTWEIGHT_CLEANUP_FILE_NAME_FOLDER
60      End If
            
        
61      Set objFolder = objFSO.GetFolder(strStoragePath)
             
62      If objFolder.Files.Count > 0 Then
            
63          Set objFiles = objFolder.Files
                
64          For Each objFile In objFiles
                
65              If IsValidPrefix(objFile.Path) Then Exit For
66          Next
                    
67          ExecCmd EXE_PATH & APP_NAME & " " & objFile.Path & "�""" & FILTER_FOLDER_HYPE_MACHINE
                
68      End If
    
69      MsgBox "Done!"
    
    End
    
    Exit Sub

errHandler:
    
    If Err.Number = 53 Then
    
        Resume Next
    End If

    MsgBox Err.Number & " - " & Err.Description & " - line - " & Erl
    
End Sub

Private Sub Form_Resize()
    On Error Resume Next
    List1.Width = ScaleWidth - List1.Left
    List1.Height = ScaleHeight - 3375
    Text1.Move Text1.Left, List1.Top + List1.Height + 10, List1.Width
    Command1.Move Text1.Width - Command1.Width, ScaleHeight - (Command1.Height + 50)
End Sub

Private Sub List1_Click()
    Dim objCacheFile        As clsCacheFile
    Label1.Caption = "Item: " & List1.ItemData(List1.ListIndex) & " of " & List1.ListCount
    Set objCacheFile = mobjCacheFiles(List1.ItemData(List1.ListIndex))
    With objCacheFile
        Text1.Text = "Source URL:         " & .SourceURL & vbCrLf & _
                     "File Name:          " & .FileName & vbCrLf & _
                     "Last Modified:      " & .LastModified & vbCrLf & _
                     "Last Accessed:      " & .LastAccessed & vbCrLf & _
                     "Expires:            " & .Expires & vbCrLf & _
                     "Size:               " & .Size & " bytes" & vbCrLf & _
                     "Hit Rate:           " & .HitRate & vbCrLf & _
                     "Use Count:          " & .UseCount & vbCrLf & _
                     "Header:             " & vbCrLf & vbCrLf & _
                     .HeaderInfo
    End With
End Sub

Public Function IsValidPrefix(ByVal strPath As String) As Boolean
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim strPrefix As String

2:    strPrefix = GetPrefix(GetTitle(strPath, True))

3:    Select Case UCase$(strPrefix)
    
        Case ".MP3", ".OGG", ".WMA": IsValidPrefix = True
        
        Case Else: IsValidPrefix = False
        
4:    End Select
    
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "strPath:" & strPath & vbNewLine
    strMSLDebugHandler_Variables = "strPrefix = " & strPrefix & vbNewLine

    objMSLDebugHandler.RaiseError "MP3TurboMate", "modGeneralProcedures", "IsValidPrefix", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function GetTitle(ByVal strTrack As String, ByVal blnIncludePrefix As Boolean) As String
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim lngPos As Long

2:    lngPos = InStrRev(strTrack, "\")
    
3:    If lngPos = 0 Then
        
4:        GetTitle = strTrack
5:        Exit Function
6:    End If
    
7:    If blnIncludePrefix Then
    
8:        GetTitle = Trim$(Mid$(strTrack, lngPos + 1))
9:    Else
    
10:        GetTitle = Replace$(Trim$(Mid$(strTrack, lngPos + 1)), ".mp3", "")
11:    End If
    
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "strTrack:" & strTrack & vbNewLine & "blnIncludePrefix:" & blnIncludePrefix & vbNewLine
    strMSLDebugHandler_Variables = "lngPos = " & lngPos & vbNewLine

    objMSLDebugHandler.RaiseError "MP3TurboMate", "modMusicGeneralProcedures", "GetTitle", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function GetPrefix(ByVal strPath As String) As String
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim lngPos As Long

2:    strPath = RemovePath(strPath)
    
3:    lngPos = InStrRev(strPath, ".")
    
4:    If lngPos > 0 Then GetPrefix = Mid$(strPath, lngPos)

'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "strPath:" & strPath & vbNewLine
    strMSLDebugHandler_Variables = "lngPos = " & lngPos & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modGeneralProcedures", "GetPrefix", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

