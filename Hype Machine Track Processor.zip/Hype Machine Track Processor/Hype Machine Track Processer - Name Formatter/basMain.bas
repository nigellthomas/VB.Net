Attribute VB_Name = "basMain"
Option Explicit

Private Type FILETIME
   dwLowDateTime                        As Long
   dwHighDateTime                       As Long
End Type

Private Type SYSTEMTIME
        wYear As Integer
        wMonth As Integer
        wDayOfWeek As Integer
        wDay As Integer
        wHour As Integer
        wMinute As Integer
        wSecond As Integer
        wMilliseconds As Integer
End Type

Private Type INTERNET_CACHE_ENTRY_INFO
   dwStructSize                         As Long
   lpszSourceUrlName                    As Long
   lpszLocalFileName                    As Long
   CacheEntryType                       As Long
   dwUseCount                           As Long
   dwHitRate                            As Long
   dwSizeLow                            As Long
   dwSizeHigh                           As Long
   LastModifiedTime                     As FILETIME
   ExpireTime                           As FILETIME
   LastAccessTime                       As FILETIME
   LastSyncTime                         As FILETIME
   lpHeaderInfo                         As Long
   dwHeaderInfoSize                     As Long
   lpszFileExtension                    As Long
   dwExemptDelta                        As Long
End Type

Public Enum CacheErrors
    ceCannotFindCache = 0
    ceCacheFound = 1
    ceFileNotFound = 2
    ceAccessDenied = 5
    ceBufferOverRun = 122
End Enum

Public Enum EntryType
    etNormalEntry = &H1
    etEditedEntry = &H8
    etTrackOffLineEntry = &H10
    etTrackOnLineEntry = &H20
    etStickyEntry = &H40
    etSparseEntry = &H10000
    etCookieEntry = &H100000
    etURLHistoryEntry = &H200000
End Enum

Public Const MAX_PATH                   As Long = 260
Public Const MAX_CACHE_ENTRY_INFO_SIZE  As Long = 4096
Public Const LMEM_FIXED                 As Long = &H0
Public Const LMEM_ZEROINIT              As Long = &H40
Public Const LPTR                       As Long = (LMEM_FIXED Or LMEM_ZEROINIT)
Public Const DEFAULT_CACHE_FILTER As Long = etNormalEntry Or _
                                            etEditedEntry Or _
                                            etTrackOffLineEntry Or _
                                            etTrackOnLineEntry Or _
                                            etStickyEntry Or _
                                            etSparseEntry Or _
                                            etCookieEntry Or _
                                            etURLHistoryEntry

Public Declare Function FindFirstUrlCacheEntry Lib "Wininet.dll" Alias "FindFirstUrlCacheEntryA" (ByVal lpszUrlSearchPattern As String, lpFirstCacheEntryInfo As Any, lpdwFirstCacheEntryInfoBufferSize As Long) As Long
Public Declare Function FindNextUrlCacheEntry Lib "Wininet.dll" Alias "FindNextUrlCacheEntryA" (ByVal hEnumHandle As Long, lpNextCacheEntryInfo As Any, lpdwNextCacheEntryInfoBufferSize As Long) As Long
Public Declare Function FindCloseUrlCache Lib "Wininet.dll" (ByVal hEnumHandle As Long) As Long
Public Declare Sub CopyMemory Lib "kernel32" Alias "RtlMoveMemory" (pDest As Any, pSource As Any, ByVal dwLength As Long)
Public Declare Function lstrcpyA Lib "kernel32" (ByVal RetVal As String, ByVal Ptr As Long) As Long
Public Declare Function lstrlenA Lib "kernel32" (ByVal Ptr As Any) As Long
Public Declare Function LocalAlloc Lib "kernel32" (ByVal uFlags As Long, ByVal uBytes As Long) As Long
Public Declare Function LocalFree Lib "kernel32" (ByVal hMem As Long) As Long
Public Declare Function FileTimeToSystemTime Lib "kernel32" (lpFileTime As FILETIME, lpSystemTime As SYSTEMTIME) As Long

Public pobjCacheFiles                   As clsCacheFiles

Public Sub GetCacheURLList()
    On Error GoTo hErr
    
    Dim ICEI                            As INTERNET_CACHE_ENTRY_INFO
    Dim hFile                           As Long
    Dim dwBuffer                        As Long
    Dim pntrICE                         As Long
    Dim strSourceURLName                As String
    Dim strLocalFileName                As String
    Dim strFileExtension                As String
    Dim lngSize                         As Long
    Dim lngEntryType                    As Long
    Dim strHeaderInfo                   As String
    Dim lngHitRate                      As Long
    Dim dtmLastAccessed                 As Date
    Dim dtmLastModified                 As Date
    Dim dtmLastSync                     As Date
    Dim dtmExpires                      As Date
    Dim lngUseCount                     As Long
    Dim typFileTime                     As FILETIME
    Dim typSysTime                      As SYSTEMTIME
    
    Static slngIndex                    As Long
    
    dwBuffer = 0
    slngIndex = 0
    
    hFile = FindFirstUrlCacheEntry(vbNullString, ByVal 0, dwBuffer)
    
    If (hFile = ceCannotFindCache) And (Err.LastDllError = ceBufferOverRun) Then
        pntrICE = LocalAlloc(LMEM_FIXED, dwBuffer)
        If pntrICE Then
            CopyMemory ByVal pntrICE, dwBuffer, 4
            hFile = FindFirstUrlCacheEntry(vbNullString, ByVal pntrICE, dwBuffer)
            If hFile <> ceCannotFindCache Then
                Do
                    CopyMemory ICEI, ByVal pntrICE, Len(ICEI)
                    slngIndex = slngIndex + 1
                    With ICEI
                        strSourceURLName = GetStrFromPtrA(.lpszSourceUrlName)
                        strLocalFileName = GetStrFromPtrA(.lpszLocalFileName)
                        strFileExtension = GetStrFromPtrA(.lpszFileExtension)
                        lngSize = FileSizeInBytes(.dwSizeHigh, .dwSizeLow)
                        lngEntryType = .CacheEntryType
                        strHeaderInfo = GetStrFromPtrA(.lpHeaderInfo)
                        dtmLastAccessed = FileTimeToDate(.LastAccessTime.dwHighDateTime, .LastAccessTime.dwLowDateTime)
                        dtmLastModified = FileTimeToDate(.LastModifiedTime.dwHighDateTime, .LastModifiedTime.dwLowDateTime)
                        dtmLastSync = FileTimeToDate(.LastSyncTime.dwHighDateTime, .LastSyncTime.dwLowDateTime)
                        dtmExpires = FileTimeToDate(.ExpireTime.dwHighDateTime, .ExpireTime.dwLowDateTime)
                        lngHitRate = .dwHitRate
                        lngUseCount = .dwUseCount
                        pobjCacheFiles.Add strSourceURLName, _
                                           strLocalFileName, _
                                           strFileExtension, _
                                           lngSize, _
                                           lngEntryType, _
                                           strHeaderInfo, _
                                           dtmLastAccessed, _
                                           dtmLastModified, _
                                           dtmLastSync, _
                                           dtmExpires, _
                                           lngHitRate, _
                                           lngUseCount, _
                                           slngIndex
                    End With
                    LocalFree pntrICE
                    dwBuffer = 0
                    FindNextUrlCacheEntry hFile, ByVal 0, dwBuffer
                    pntrICE = LocalAlloc(LMEM_FIXED, dwBuffer)
                    CopyMemory ByVal pntrICE, dwBuffer, 4
                Loop While FindNextUrlCacheEntry(hFile, ByVal pntrICE, dwBuffer)
            End If
        End If
    End If
    
    LocalFree (pntrICE)
    FindCloseUrlCache (hFile)
    Exit Sub
hErr:
    Stop
    Resume
End Sub

Private Function GetStrFromPtrA(ByVal lpszA As Long) As String
   GetStrFromPtrA = String$(lstrlenA(ByVal lpszA), 0)
   lstrcpyA ByVal GetStrFromPtrA, ByVal lpszA
End Function

Private Function FileTimeToDate(ByVal dwHighDateTime As Long, ByVal dwLowDateTime As Long) As Date
    On Error Resume Next
    
    Dim typFileTime                     As FILETIME
    Dim typSysTime                      As SYSTEMTIME
    Dim strDateTime                     As String
    With typFileTime
        .dwHighDateTime = dwHighDateTime
        .dwLowDateTime = dwLowDateTime
    End With
    FileTimeToSystemTime typFileTime, typSysTime
    With typSysTime
        strDateTime = CStr(Format(.wMonth, "00"))
        strDateTime = strDateTime & "/" & CStr(Format(.wDay, "00"))
        strDateTime = strDateTime & "/" & CStr(Format(.wYear, "0000"))
        strDateTime = strDateTime & " " & CStr(Format(.wHour, "00"))
        strDateTime = strDateTime & ":" & CStr(Format(.wMinute, "00"))
        strDateTime = strDateTime & ":" & CStr(Format(.wSecond, "00"))
    End With
    FileTimeToDate = Format(strDateTime, "mm/dd/yyyy hh:mm:Ss AM/PM")
End Function

Private Function FileSizeInBytes(ByVal dwFileSizeHigh As Long, dwFileSizeLow As Long) As Long
    FileSizeInBytes = (dwFileSizeHigh * (&HFFFF + 1)) + dwFileSizeLow
End Function

