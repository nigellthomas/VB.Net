VERSION 5.00
Object = "{EAB22AC0-30C1-11CF-A7EB-0000C05BAE0B}#1.1#0"; "shdocvw.dll"
Object = "{48E59290-9880-11CF-9754-00AA00C00908}#1.0#0"; "MSINET.OCX"
Object = "{BE6A92CC-FCEC-11D3-813B-00E098053280}#1.3#0"; "QLControls.ocx"
Begin VB.Form frmInet 
   ClientHeight    =   7215
   ClientLeft      =   165
   ClientTop       =   735
   ClientWidth     =   11325
   Icon            =   "frmInet.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   7215
   ScaleWidth      =   11325
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdClose 
      Cancel          =   -1  'True
      Caption         =   "&Close"
      Height          =   360
      Left            =   9960
      TabIndex        =   8
      Top             =   6795
      Width           =   1275
   End
   Begin VB.Frame fraShare 
      Caption         =   "Share"
      Height          =   6540
      Left            =   135
      TabIndex        =   0
      Top             =   150
      Width           =   11070
      Begin VB.CommandButton cmdBack 
         Caption         =   "<<"
         Height          =   315
         Left            =   7470
         TabIndex        =   6
         Top             =   270
         Width           =   405
      End
      Begin VB.CommandButton cmdForward 
         Caption         =   ">>"
         Height          =   315
         Left            =   7935
         TabIndex        =   7
         Top             =   270
         Width           =   405
      End
      Begin QLControls.QLDropDown cboCycle 
         Height          =   285
         Left            =   5565
         TabIndex        =   5
         Top             =   270
         Width           =   1785
         _ExtentX        =   3149
         _ExtentY        =   503
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         FontName        =   "MS Sans Serif"
         FontSize        =   8.25
         ListIndex       =   -1
      End
      Begin SHDocVwCtl.WebBrowser WebBrowser1 
         Height          =   5745
         Left            =   150
         TabIndex        =   10
         TabStop         =   0   'False
         Top             =   690
         Width           =   10830
         ExtentX         =   19103
         ExtentY         =   10134
         ViewMode        =   0
         Offline         =   0
         Silent          =   0
         RegisterAsBrowser=   0
         RegisterAsDropTarget=   1
         AutoArrange     =   0   'False
         NoClientEdge    =   0   'False
         AlignLeft       =   0   'False
         NoWebView       =   0   'False
         HideFileNames   =   0   'False
         SingleClick     =   0   'False
         SingleSelection =   0   'False
         NoFolders       =   0   'False
         Transparent     =   0   'False
         ViewID          =   "{0057D0E0-3573-11CF-AE69-08002B2E1262}"
         Location        =   ""
      End
      Begin VB.CommandButton cmdEpicCode 
         Caption         =   ">>"
         CausesValidation=   0   'False
         Height          =   285
         Left            =   1500
         TabIndex        =   3
         TabStop         =   0   'False
         Top             =   270
         Width           =   405
      End
      Begin VB.TextBox txtName 
         Appearance      =   0  'Flat
         Height          =   315
         Left            =   1965
         Locked          =   -1  'True
         TabIndex        =   9
         TabStop         =   0   'False
         Top             =   270
         Width           =   2730
      End
      Begin VB.TextBox txtCode 
         Height          =   315
         Left            =   690
         TabIndex        =   2
         Top             =   270
         Width           =   705
      End
      Begin VB.Label Label1 
         Caption         =   "Cycle"
         Height          =   255
         Left            =   5055
         TabIndex        =   4
         Top             =   315
         Width           =   495
      End
      Begin VB.Label lblCode 
         Caption         =   "Code"
         Height          =   255
         Left            =   150
         TabIndex        =   1
         Top             =   315
         Width           =   495
      End
   End
   Begin InetCtlsObjects.Inet Inet1 
      Left            =   315
      Top             =   315
      _ExtentX        =   1005
      _ExtentY        =   1005
      _Version        =   393216
   End
   Begin VB.Menu mnuOptions 
      Caption         =   "Options"
      Begin VB.Menu mnuBritishBulls 
         Caption         =   "British Bulls"
      End
      Begin VB.Menu mnuBarchart 
         Caption         =   "Barchart"
      End
   End
End
Attribute VB_Name = "frmInet"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Public mblnBarChart As Boolean

Public mblnBritishBulls As Boolean

Private mrsCodes As ADODB.Recordset
Private mstrURLLeft As String, mstrURLRight As String

Private Sub cmdClose_Click()

    Me.Hide
    
End Sub

Private Sub cmdBack_Click()

On Error Resume Next

    txtCode.Text = ""

    If Not mrsCodes.BOF Then
    
        mrsCodes.MovePrevious
        
        If mrsCodes.BOF Then mrsCodes.MoveFirst
    End If
    
    txtCode.Text = mrsCodes(0).Value
        
End Sub

Private Sub cmdEpicCode_Click()

Dim strEpicCode As String, strName As String

                        
    If strEpicCode <> vbNullString Then
        
        txtCode = strEpicCode
        txtName.Text = strName

        WebBrowser1.Navigate "http://quote.barchart.com/texpert.asp?sym=" & txtCode.Text & ".LS"

    End If
    
End Sub

Private Sub cmdForward_Click()

On Error Resume Next

    txtCode.Text = ""

    If Not mrsCodes.EOF Then
    
        mrsCodes.MoveNext
        
        If mrsCodes.EOF Then mrsCodes.MoveLast
    End If
    
    txtCode.Text = mrsCodes(0).Value
        
End Sub

Private Sub Form_Load()
       
    Set mrsCodes = New ADODB.Recordset
    
End Sub

Private Sub Form_Resize()

    On Error Resume Next
    
    fraShare.Width = Me.Width - 350
    fraShare.Height = Me.Height - 1400
    
    WebBrowser1.Width = fraShare.Width - 350
    WebBrowser1.Height = fraShare.Height - 800
    
    cmdClose.Top = fraShare.Top + fraShare.Height + 145
    cmdClose.Left = Me.Width - 1500
    
End Sub

Private Sub Form_Unload(Cancel As Integer)

On Error Resume Next

    If mrsCodes.State <> adStateClosed Then mrsCodes.Close
    
    Set mrsCodes = Nothing
    
End Sub

Private Sub mnuBarchart_Click()

    If txtCode.Text = "" Then Exit Sub
    
    'With frmBarchartHistory
    
    '    .txtCode.Text = txtCode.Text
    
     '   .txtCode_LostFocus
    
    '    .cmdRefresh_Click
    
  '      .Show vbModal
    
  '  End With
    
  '  Unload frmBarchartHistory
    
End Sub

Private Sub mnuBritishBulls_Click()

  '  If txtCode.Text = "" Then Exit Sub
    
  '  With frmBritishBullsHistory
    
  '      .txtCode.Text = txtCode.Text
    
  '      .txtCode_LostFocus
    
  '      .cmdRefresh_Click
    
  '      .Show vbModal
    
  '  End With
    
  '  Unload frmBritishBullsHistory
    
End Sub

Private Sub txtCode_Change()

    txtName.Text = ""
    
End Sub


Public Property Get BarChart() As Boolean

    BarChart = mblnBarChart
    
End Property

Public Property Let BarChart(ByVal vNewValue As Boolean)

    mblnBarChart = vNewValue
    
    '"http://quote.barchart.com/texpert.asp?sym=" & txtCode.Text & ".LS"
    mstrURLLeft = "http://quote.barchart.com/texpert.asp?sym=" & txtCode.Text
    mstrURLRight = ".LS"
    
    Me.Caption = "Barchart.com"
    
End Property

Public Property Get BritishBulls() As Boolean

    BritishBulls = mblnBritishBulls

End Property

Public Property Let BritishBulls(ByVal vNewValue As Boolean)

    mblnBritishBulls = vNewValue
    
    mstrURLLeft = "http://www.britishbulls.com/StockPage.asp?CompanyTicker="
    mstrURLRight = ""

    Me.Caption = "British Bulls.com"

End Property


