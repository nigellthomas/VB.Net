Attribute VB_Name = "modConsts"
Option Explicit

Public Const SPLITTER = "�"

Public Const DELETED_FOLDER = "Deleted"
Public Const DUPLICATES_FOLDER = "Duplicates"

Public Const DEFAULT_PLAY_LIST = "Current"

Public Const FILTER_FOLDER = "FILTERMP3SFOLDER"
Public Const FILTER_FOLDER_HYPE_MACHINE = "FILTERMP3SFOLDER_HYPE_MACHINE"
Public Const FILTER_FOLDER_CAPTION = "Filter Folder"
Public Const FILTER_FOLDER_WITH_CRC = "FILTERMP3SFOLDERWITHCRC"
Public Const FILTER_FOLDER_WITH_CRC_CAPTION = "Filter Folder with CRC"

Public Const SHOW_TRACKS = "SHOWTRACKS"
Public Const SHOW_TRACKS_CAPTION = "Show Tracks"

Public Const SEARCH_TRACKS = "SEARCHTRACKS"
Public Const SEARCH_TRACKS_CAPTION = "Search Tracks"

Public Const REMOVE_FROM_DELETED_TRACKS = "REMOVE_FROM_DELETED_TRACKS"
Public Const REMOVE_FROM_DELETED_TRACKS_CAPTION = "Remove from Deleted Tracks"

Public Const SHOW_DELETED_TRACKS = "SHOW_DELETED_TRACKS"
Public Const SHOW_DELETED_TRACKS_CAPTION = "Show Deleted Tracks"

Public Const PROPERISE_CASE = "PROPERISECASE"
Public Const PROPERISE_CASE_CAPTION = "Properise Case"

Public Const CATALOGUE_MP3_CD = "CATALOGUE_MP3_CD"
Public Const CATALOGUE_MP3_CD_CAPTION = "Catalogue MP3 CD"

Public Const DELETE_AND_CATALOGUE = "DELETECATALOGUE"
Public Const CATALOGUE = "CATALOGUE"
Public Const DELETE_AND_CATALOGUE_FOLDER = "DELETECATALOGUEFOLDER"
Public Const CATALOGUE_FOLDER = "CATALOGUEFOLDER"
Public Const CLEANUP_FILE_NAME = "CLEANUPFILENAME"
Public Const LIGHTWEIGHT_CLEANUP_FILE_NAME_FOLDER = "LIGHTWEIGHT_CLEANUPFILENAMEFOLDER"
Public Const CLEANUP_FILE_NAME_FOLDER = "CLEANUPFILENAMEFOLDER"
Public Const CLEANUP_BRACKETS = "CLEANUPBRACKETS"
Public Const CLEANUP_BRACKETS_FOLDER = "CLEANUPBRACKETSFOLDER"
Public Const REMOVE_BRACKETS = "REMOVE_BRACKETS"
Public Const REMOVE_BRACKETS_FOLDER = "REMOVE_BRACKETS_FOLDER"
Public Const RENAME_FROM_SUMMARY_BOX = "RENAME_FROM_SUMMARY_BOX"
Public Const RENAME_FROM_SUMMARY_BOX_FOLDER = "RENAME_FROM_SUMMARY_BOX_FOLDER"
Public Const RENAME_FROM_TAG = "RENAME_FROM_TAG"
Public Const RENAME_FROM_TAG_FOLDER = "RENAME_FROM_TAG_FOLDER"
Public Const UPDATE_TAG = "UPDATE_TAG"
Public Const REVERSE_NAMES = "REVERSE_NAMES"
Public Const MOVE_INTO_FOLDERS = "MOVE_INTO_FOLDERS"
Public Const RENAME_FROM_TAG_AND_DELETE = "RENAME_FROM_TAG_AND_DELETE"
Public Const INDICATE_BIT_RATE = "INDICATE_BIT_RATE"
Public Const REMOVE_BIT_RATE = "REMOVE_BIT_RATE"
Public Const RENAME_TRACKS_FROM_FOLDER_NAME = "RENAME_TRACKS_FROM_FOLDER_NAME"
Public Const RENAME_TRACKS_FROM_FOLDER_NAME_FOLDER = "RENAME_TRACKS_FROM_FOLDER_NAME_FOLDER"
Public Const ADD_TO_ARTISTS_TO_DELETE = "ADD_TO_ARTISTS_TO_DELETE"

Public Const MERGE_TRACKS = "MERGETRACKS"
Public Const MERGE_TRACKS_CAPTION = "Merge Tracks"

Public Const FORMAT_TAG = "Format Tag"
Public Const FORMAT_TAG_FOLDER = "Format Tag Folder"
Public Const CATALOGUE_CAPTION = "Catalogue"
Public Const CATALOGUE_FOLDER_CAPTION = "Catalogue Folder"
Public Const DELETE_AND_CATALOGUE_CAPTION = "Delete and Catalogue"
Public Const DELETE_AND_CATALOGUE_FOLDER_CAPTION = "Delete and Catalogue"
Public Const CLEANUP_FILE_NAME_CAPTION = "Cleanup Filename"
Public Const CLEANUP_FILE_NAME_FOLDER_CAPTION = "Cleanup Filename"
Public Const CLEANUP_BRACKETS_CAPTION = "Cleanup Brackets"
Public Const CLEANUP_BRACKETS_FOLDER_CAPTION = "Cleanup Brackets"
Public Const REMOVE_BRACKETS_CAPTION = "Remove Brackets"
Public Const REMOVE_BRACKETS_FOLDER_CAPTION = "Remove Brackets"
Public Const RENAME_FROM_SUMMARY_BOX_CAPTION = "Rename from Summary Box"
Public Const RENAME_FROM_SUMMARY_BOX_FOLDER_CAPTION = "Rename from Summary Box"
Public Const RENAME_FROM_TAG_CAPTION = "Rename from Tag"
Public Const RENAME_FROM_TAG_FOLDER_CAPTION = "Rename from Tag"
Public Const UPDATE_TAG_CAPTION = "Update Tag"
Public Const REVERSE_NAMES_CAPTION = "Reverse Names"
Public Const MOVE_INTO_FOLDERS_CAPTION = "Move into Folders"
Public Const RENAME_FROM_TAG_AND_DELETE_CAPTION = "Rename from Tag and Delete"
Public Const INDICATE_BIT_RATE_CAPTION = "Indicate Bit Rate"
Public Const REMOVE_BIT_RATE_CAPTION = "Remove Bit Rate"
Public Const RENAME_TRACKS_FROM_FOLDER_NAME_CAPTION = "Rename Tracks from Folder Name"
Public Const ADD_TO_ARTISTS_TO_DELETE_CAPTION = "Add To Artists To Delete"

Public Const RENAME_TRACKS_FROM_USER_NAME = "Rename Tracks from User Name"

Public Const RENAME_TRACKS_FROM_USER_NAME_ONE_ONLY = "One Only"
Public Const RENAME_TRACKS_FROM_USER_NAME_LAST_ONE = "Last One"
Public Const RENAME_TRACKS_FROM_USER_NAME_MIDDLE_ONE = "Middle One"

Public Const RENAME_FOLDER_FROM_ARTIST_NAME = "Rename Folder from Artist Name"

Public Const FILTER_IDENTICAL_TRACKS = "FILTER_IDENTICAL_TRACKS"
Public Const FILTER_IDENTICAL_TRACKS_CAPTION = "Filter Identical Tracks"

Public Const REMOVE_BRACKETS_AND_CATALOGUE = "REMOVE_BRACKETS_AND_CATALOGUE"
Public Const REMOVE_BRACKETS_AND_CATALOGUE_CAPTION = "Remove Brackets and Catalogue"

Public Const WILDCARD_UPDATING = "WILDCARD_UPDATING"
Public Const WILDCARD_UPDATING_CAPTION = "Wildcard Updating"

Public Const UPDATE_TIME = "UPDATE_TIME"
Public Const UPDATE_TIME_CAPTION = "Update Time"

Public Const REMOVE_BRACKETS_AND_CATALOGUE_FOLDER = "REMOVE_BRACKETS_AND_CATALOGUE_FOLDER"
Public Const REMOVE_BRACKETS_AND_CATALOGUE_FOLDER_CAPTION = "Remove Brackets and Catalogue Folder"

Public Const LEFT_SIDE_MARKER = "{~_"
Public Const RIGHT_SIDE_MARKER = "_~}"

Public Const CURRENT_MP3_FOLDER = " {CURRENT MP3}"

Public Const IDEAL_FEATURING_TEXT = " ft. "
Public Const IDEAL_VERSUS_TEXT = " vs "

Public Const CREATE_PLAY_LIST = "Create Play List"
Public Const SHOW_NAMES = "Show Names"

Public Const RENAME_AS_MP3 = "Rename as MP3"

Public Const SCAN_DISK = "Scan Disk"
Public Const SCAN_FOLDER = "Scan Folder"

Public Const REMOVE_MARKS = "Remove Marks"
Public Const REMOVE_MARKS_FOLDER = "Remove Marks"

Public Const REMOVE_NAME = "Remove Name"
Public Const REMOVE_NAME_FOLDER = "Remove Name Folder"

Public Const CREATE_SAMPLES = "Create Samples"

Public Const CreateFile = "CreateFile"
Public Const APPEND = "Append"
Public Const FINISH = "Finish"

Public Const ARTISTTODELETE_MARK = "{ARTISTTODELETE}"
Public Const DELETED_MARK = "{DELETED}"
Public Const CRC_MARK = "{CRC}"
Public Const DISC_LEFT_MARK = "{DISC "
Public Const DISC_RIGHT_MARK = "}"
Public Const IDENTICAL_MARK = "{IDENTICAL}"
Public Const DUPLICATES_MARK = "{DUPLICATE}"

Public Const GET_NAME = "Get Name"
Public Const WIPE_NAME = "Wipe Name"

'*************************
'* Options
'*************************

Public Const OPTIONS_FORM = "Options"

Public Const OPTION_CURRENT_MP3_FOLDER = "Current MP3 Folder"
Public Const OPTION_DEFAULT_SAMPLES_FOLDER = "Samples Folder"

Public Const OPTION_SAMPLES_DEFAULT_PERC = "Samples Default Perc"
Public Const OPTION_NUMBER_OF_TRACKS_TO_DISPLAY = "Number of Tracks to Display"
Public Const OPTION_BIT_RATE_USE_OPTIONAL_MARKING = "Bit Rate - Use Optional Marking"
Public Const OPTION_MAXIMUM_BIT_RATE = "Maximum Bit Rate"
Public Const OPTION_ID3_TAG_SUPPORT = "ID3 Tag Support"
Public Const OPTION_ID3_V2_Version = "ID3 V2 Version"
Public Const OPTION_ASK_FOR_CONFIRMATION = "Ask for Confirmation"


