Public Class clsFolder
    Public Path As String
End Class

