Public Class frmMP3s

    Private Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" (ByVal hWnd As Long, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Long) As Long

    Private mcolFolders As New colFolders, mblnDontIgnoreCloseReason As Boolean

    Private mstrFiles As String

    Private Sub frmFolders_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        If Not mblnDontIgnoreCloseReason Then

            If e.CloseReason = CloseReason.UserClosing Then

                e.Cancel = True

                cmdClose_Click(sender, e)
            End If
        End If

    End Sub

    Private Sub LoadSettings()

        Dim objFile As System.IO.StreamReader

        objFile = My.Computer.FileSystem.OpenTextFileReader(My.Application.Info.DirectoryPath & "\Settings.txt")

        If Not objFile.EndOfStream Then txtWorkSourceLocation.Text = objFile.ReadLine
        If Not objFile.EndOfStream Then txtHomeSourceLocation.Text = objFile.ReadLine
        If Not objFile.EndOfStream Then txtTargetLocation.Text = objFile.ReadLine

        objFile.Close()

        objFile = Nothing

    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        NotifyIcon1.Visible = True

        NotifyIcon1.ContextMenuStrip = mnuFolder

        LoadSettings()

        cmdSave.Enabled = False

    End Sub

    Private Sub NotifyIcon1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles NotifyIcon1.Click

        Dim p As New Point, C As Windows.Forms.Cursor

        C = Cursors.Default

        p = New Point(Cursors.Default.Position.X, Cursors.Default.Position.Y)

        mnuFolder.Show(p)

    End Sub

    Private Sub mnuFolder_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles mnuFolder.ItemClicked

        Select Case e.ClickedItem.Tag

            Case "Close"

                mblnDontIgnoreCloseReason = True

                Me.Close()

            Case "Run"


        End Select

    End Sub

    Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click

        Me.Opacity = 0

    End Sub

    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click

        Dim strFileText As String

        strFileText = txtWorkSourceLocation.Text & vbCrLf & txtHomeSourceLocation.Text & vbCrLf & txtTargetLocation.Text & vbCrLf

        My.Computer.FileSystem.WriteAllText(My.Application.Info.DirectoryPath & "\Settings.txt", strFileText, False)

        cmdSave.Enabled = False

    End Sub

    Private Sub txtLocation_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTargetLocation.GotFocus, txtHomeSourceLocation.GotFocus, txtWorkSourceLocation.GotFocus


    End Sub

    Private Sub txtLocation_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTargetLocation.TextChanged, txtHomeSourceLocation.TextChanged, txtWorkSourceLocation.TextChanged

        cmdSave.Enabled = True

    End Sub

    Public Function GetPath(ByVal strPath As String) As String

        Dim intPos As Integer

        intPos = InStrRev(strPath, "\")

        GetPath = Mid$(strPath, 1, intPos)

    End Function

    Private Sub CloseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseToolStripMenuItem.Click

        Me.Hide()

    End Sub

    Private Sub ToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem1.Click

        Me.Opacity = 100

    End Sub

    Public Function GetAllFilesFromPath(ByVal dir As DirectoryInfo) As String

        Dim d As Object, strFiles As String
        Dim f As FileInfo
        Dim strPath As String

        strFiles = ""

        For Each d In dir.GetFileSystemInfos()

            If (TypeOf (d) Is FileInfo) Then

                f = CType(d, FileInfo)

                strPath = f.FullName

                mstrFiles = mstrFiles & strPath & vbCrLf

                If My.Computer.Name = "SWAPCDV1207NT" Then

                    NotifyIcon1.Text = Mid(strPath.Replace(txtWorkSourceLocation.Text & "\", ""), 1, 63)
                Else

                    NotifyIcon1.Text = Mid(strPath.Replace(txtHomeSourceLocation.Text & "\", ""), 1, 63)
                End If

            Else 'it must be an directory

                NotifyIcon1.Text = Mid("Processing another folder - " & CType(d, DirectoryInfo).FullName, 1, 63)

                GetAllFilesFromPath(CType(d, DirectoryInfo))
            End If
        Next

    End Function

    Private Sub mnuRun_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuRun.Click

        Dim strFiles() As String, objDir As DirectoryInfo, intCount As Integer
        Dim strFile As String, intCount2 As Integer, bytFirstFile As Byte()
        Dim intTotal As Integer, strCacheWarning As String
        Dim bytMP3 As Byte()

        ' MessageBox.Show(HasKnownMagicNumbers("C:\My Music\Hype Machine\Duplicates\Db1cd01.mp3"))
        ' MessageBox.Show(HasTheMP3MagicNumbers("C:\My Music\Hype Machine\Duplicates\Db1cd01.mp3"))

        If My.Computer.Name <> "DESKTOP-MKMB64E" Then

            objDir = New DirectoryInfo(txtWorkSourceLocation.Text)
        Else

            objDir = New DirectoryInfo(txtHomeSourceLocation.Text)
        End If

        'objDir = New DirectoryInfo("C:\My Music\Hype Machine\Duplicates")

        mstrFiles = ""

        GetAllFilesFromPath(objDir)

        strFiles = mstrFiles.Split(vbCrLf)

        intTotal = UBound(strFiles) - 1

        strCacheWarning = ""

        If intTotal > 55000 Then

            strCacheWarning = intTotal & " files need to clear the cache!"
        End If

        For intCount = LBound(strFiles) To intTotal

            NotifyIcon1.Text = "Doing " & intCount & " out of " & intTotal & strCacheWarning

            strFiles(intCount) = strFiles(intCount).Replace(vbCrLf, "").Trim

            bytMP3 = My.Computer.FileSystem.ReadAllBytes(strFiles(intCount))

            If BigEnough(strFiles(intCount), bytMP3) Then

                'If HasTheMP3MagicNumbers(strFiles(intCount), bytMP3) Or Not HasKnownMagicNumbersForMediaFiles(strFiles(intCount), bytMP3) Then

                strFile = txtTargetLocation.Text & "\" & GetFile(strFiles(intCount) & ".mp3")

                    strFile = Replace(strFile, ".mp3.mp3", ".mp3")

                    If Not My.Computer.FileSystem.FileExists(strFile) Then

                        My.Computer.FileSystem.CopyFile(strFiles(intCount), strFile)
                    End If
                'End If
            End If
        Next

        NotifyIcon1.Text = "Doing basic checks" & strCacheWarning

        objDir = New DirectoryInfo(txtTargetLocation.Text)

        mstrFiles = ""
        GetAllFilesFromPath(objDir)

        strFiles = mstrFiles.Split(vbCrLf)

        For intCount = LBound(strFiles) To UBound(strFiles) - 1

            strFiles(intCount) = strFiles(intCount).Trim

            If InStr(strFiles(intCount).ToUpper, "_CACHE_00") > 0 Then

                My.Computer.FileSystem.DeleteFile(strFiles(intCount))
                strFiles(intCount) = ""
            End If

            If InStr(strFiles(intCount).ToUpper, "CACHE.MAP") > 0 Then

                My.Computer.FileSystem.DeleteFile(strFiles(intCount))
                strFiles(intCount) = ""
            End If
        Next

        NotifyIcon1.Text = "Checking for duplicates" & strCacheWarning

        For intCount = LBound(strFiles) To UBound(strFiles) - 1

            If strFiles(intCount) <> "" Then

                strFiles(intCount) = strFiles(intCount).Replace(vbCrLf, "").Trim

                bytFirstFile = My.Computer.FileSystem.ReadAllBytes(strFiles(intCount))

                For intCount2 = intCount + 1 To UBound(strFiles) - 1

                    If strFiles(intCount2) <> "" Then

                        If TheSameFile(bytFirstFile, My.Computer.FileSystem.ReadAllBytes(strFiles(intCount2))) Then

                            My.Computer.FileSystem.DeleteFile(strFiles(intCount2))
                            strFiles(intCount2) = ""
                        End If
                    End If
                Next
            End If
        Next

        'NotifyIcon1.Text = "Called Name Formatter" & strCacheWarning

        'Shell(My.Application.Info.DirectoryPath & "\Hype Machine Track Processer - Name Formatter.exe", AppWinStyle.MinimizedNoFocus, False)

        Timer1.Enabled = True

        MessageBox.Show("Process complete!")

    End Sub

    Public Function TheSameFile(ByVal bytFirstFile As Byte(), ByVal bytSecondFile As Byte()) As Boolean

        Dim blnDifferent As Boolean, intCount As Integer

        Try

            If UBound(bytFirstFile) <> UBound(bytSecondFile) Then

                TheSameFile = False
                Exit Function
            End If

        Catch ex As Exception

        End Try

        For intcount = LBound(bytFirstFile) To UBound(bytFirstFile) - 1

            If bytFirstFile(intCount) <> bytSecondFile(intCount) Then

                blnDifferent = True
                Exit For
            End If
        Next

        TheSameFile = Not blnDifferent

    End Function

    Public Function BigEnough(ByVal strFile As String, Optional ByRef bytMP3 As Byte() = Nothing) As Boolean

        If bytMP3 Is Nothing Then

            bytMP3 = My.Computer.FileSystem.ReadAllBytes(strFile)
        End If

        Try

            If UBound(bytMP3) > 1500000 Then

                BigEnough = True
                Exit Function
            End If

        Catch ex As Exception

        End Try

        BigEnough = False

    End Function

    Public Function GetFile(ByVal strPath As String) As String

        Dim intPos As Integer

        intPos = InStrRev(strPath, "\")

        GetFile = Mid$(strPath, intPos + 1)

    End Function

    Private Sub Timer1_Tick(sender As System.Object, e As System.EventArgs) Handles Timer1.Tick

        NotifyIcon1.Text = "Hype Machine Track Processor"
        Timer1.Enabled = False

    End Sub

    Private Sub NotifyIcon1_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles NotifyIcon1.MouseDoubleClick

    End Sub
End Class
