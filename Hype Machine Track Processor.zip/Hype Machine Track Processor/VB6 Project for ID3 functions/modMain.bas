Attribute VB_Name = "modMain"
Option Explicit

Public Const DELETED_FOLDER = "Deleted"

Public mstrPath As String
Public mobjFSO As FileSystemObject
Public mstrID3TagSupport As String
Public menumIDEV2_Version As ID3v2_Version

Public mblnRecurse As Boolean

' Options
Public mstrCurrentMP3Path As String
Public mstrSamplesFolderOption As String
Public mstrSamplesDefaultPerc As String
Public mlngTrackNumber As Long

Public mlngLevelToBeUsedForOptionalBitRateMarking As Long       ' Only mark mp3s with bit rate less then the level
Public mblnBitRateUseOptionalMarking As Boolean

Public mblnAskForConfirmation As Boolean

' 1 - ID3v1
' 2 - ID3v2
' 3 - Both

Public mblnRememberLastPath As String
Public mstrLastPath As String

Public Const LEFT_SIDE_MARKER = "{~_"
Public Const RIGHT_SIDE_MARKER = "_~}"

Public Function CapitalizeInitialWordsInString(ByVal strString) As String
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim objFolder As Folder, objFile As File, objFiles As Files
2: Dim strNewName As String, lngCount As Long, lngTotal As Long

3:    strNewName = strString
    
4:    strNewName = UCase$(Mid$(strNewName, 1, 1)) & Mid$(strNewName, 2)
    
5:    For lngCount = 2 To Len(strNewName) - 1
    
6:        If (Mid$(strNewName, lngCount, 1) = " " Or Mid$(strNewName, lngCount, 1) = "(") And Trim$(Mid$(strNewName, lngCount + 1, 1)) <> "" Then
        
7:            strNewName = Mid$(strNewName, 1, lngCount) & UCase$(Mid$(strNewName, lngCount + 1, 1)) & Mid$(strNewName, lngCount + 2)
8:        End If
9:    Next
    
10:    CapitalizeInitialWordsInString = strNewName
    
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Variables = "strNewName = " & strNewName & vbNewLine & "lngCount = " & lngCount & vbNewLine & "lngTotal = " & lngTotal & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Renamer", "modGeneralProcedures", "CapitalizeInitialWordsInString", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function


Public Sub Main()


End Sub

Public Function GetPath(ByVal strPath As String) As String
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim intPos As Integer

2:    intPos = InStrRev(strPath, "\")
    
3:    GetPath = Mid$(strPath, 1, intPos)

'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "strPath:" & strPath & vbNewLine
    strMSLDebugHandler_Variables = "intPos = " & intPos & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Renamer", "modGeneralProcedures", "GetPath", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function GetFileCountMP3s(ByVal objFiles As Files) As Long
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim objFile As File, lngCount As Long

2:    For Each objFile In objFiles

3:        If objFile.Type = "Winamp media file" Then

4:            lngCount = lngCount + 1
5:        End If
6:    Next
    
7:    GetFileCountMP3s = lngCount
    
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Variables = "lngCount = " & lngCount & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Renamer", "modGeneralProcedures", "GetFileCountMP3s", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function


Public Function GetArtist(ByVal strTrack As String) As String
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim lngPos As Long

2:    If InStr(1, strTrack, LEFT_SIDE_MARKER) > 0 And InStr(1, strTrack, RIGHT_SIDE_MARKER) > 0 Then
    
3:        lngPos = InStr(1, strTrack, RIGHT_SIDE_MARKER) + Len(RIGHT_SIDE_MARKER)
        
4:        strTrack = Mid$(strTrack, lngPos)
5:    End If

6:    lngPos = InStr(1, strTrack, " - ")
    
7:    If lngPos = 0 Then Exit Function
    
8:    GetArtist = Trim$(Mid$(strTrack, 1, lngPos))
    
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "strTrack:" & strTrack & vbNewLine
    strMSLDebugHandler_Variables = "lngPos = " & lngPos & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Renamer", "modMusicGeneralProcedures", "GetArtist", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function GetTitle(ByVal strTrack As String, ByVal blnIncludePrefix As Boolean) As String
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim lngPos As Long

2:    lngPos = InStrRev(strTrack, "\")
    
3:    If lngPos = 0 Then
        
4:        GetTitle = strTrack
5:        Exit Function
6:    End If
    
7:    If blnIncludePrefix Then
    
8:        GetTitle = Trim$(Mid$(strTrack, lngPos + 1))
9:    Else
    
10:        GetTitle = Replace$(Trim$(Mid$(strTrack, lngPos + 1)), ".mp3", "")
11:    End If
    
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "strTrack:" & strTrack & vbNewLine & "blnIncludePrefix:" & blnIncludePrefix & vbNewLine
    strMSLDebugHandler_Variables = "lngPos = " & lngPos & vbNewLine

    objMSLDebugHandler.RaiseError "MP3TurboMate", "modMusicGeneralProcedures", "GetTitle", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function GetTrackName(ByVal strTrack As String) As String
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim lngPos As Long, strName As String
    
2:    lngPos = InStr(1, strTrack, " - ")
    
3:    strName = Replace$(Trim$(Mid$(strTrack, lngPos + 2)), ".mp3", "")
    
4:    strName = Replace$(strName, ".wma", "")
5:    GetTrackName = Replace$(strName, ".wav", "")
    
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "strTrack:" & strTrack & vbNewLine
    strMSLDebugHandler_Variables = "lngPos = " & lngPos & vbNewLine & "strName = " & strName & vbNewLine

    objMSLDebugHandler.RaiseError "MP3TurboMate", "modMusicGeneralProcedures", "GetTrackName", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Sub GenerateFileListArray_AddSubFolder(objFolder As Scripting.Folder, strType As String, _
                                              ByRef blnRecursive As Boolean, ByRef lngCount As Long, _
                                              ByRef strFiles() As String, ByVal blnIgnoreDeletedFolder As Boolean, _
                                              blnIncludeFullPath As Boolean)

On Error GoTo errHandler

Dim objFile As Scripting.File, objFiles As Scripting.Files

1       Set objFiles = objFolder.Files
    
2       If strType <> "" Then
    
3           If Not objFiles Is Nothing Then
        
4               For Each objFile In objFiles
    
5                   If objFile.Type = strType Then
        
6                       If lngCount = 0 Or lngCount Mod 50 = 0 Then
    
7                           ReDim Preserve strFiles(lngCount + 50)
8                       End If
    
9                       If blnIncludeFullPath Then
                    
10                          strFiles(lngCount) = objFile.Path
11                      Else
                    
12                          strFiles(lngCount) = objFile.Name
13                      End If
    
14                      lngCount = lngCount + 1
15                  End If
16              Next
17          End If
18      Else
    
19          For Each objFile In objFiles
    
20              If lngCount = 0 Or lngCount Mod 50 = 0 Then
    
21                  ReDim Preserve strFiles(lngCount + 50)
22              End If
    
23              If blnIncludeFullPath Then
            
24                  strFiles(lngCount) = objFile.Path
25              Else
            
26                  strFiles(lngCount) = objFile.Name
27              End If
    
28              lngCount = lngCount + 1
29          Next
30      End If
    
31      If blnRecursive Then
    
32          If Not objFolder.SubFolders Is Nothing Then
        
33              For Each objFolder In objFolder.SubFolders
    
34                  If blnIgnoreDeletedFolder Then
                
35                      If objFolder.Name <> DELETED_FOLDER Then GenerateFileListArray_AddSubFolder objFolder, strType, blnRecursive, lngCount, strFiles, blnIgnoreDeletedFolder, blnIncludeFullPath
36                  Else
                
37                      GenerateFileListArray_AddSubFolder objFolder, strType, blnRecursive, lngCount, strFiles, blnIgnoreDeletedFolder, blnIncludeFullPath
38                  End If
39              Next
40          End If
41      End If

Exit Sub
 
errHandler:
 
    '******************************************************
    '* 'Permission Denied' problem under Win 2000
    '******************************************************
    
    If Err.Number = 70 Then
    
        Exit Sub
    End If

    MsgBox "GenerateFileListArray_AddSubFolder - " & Err.Description & " - " & Err.Number & " - line " & Erl
    
End Sub

Public Function GetPrefix(ByVal strPath As String) As String
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim lngPos As Long

2:    strPath = RemovePath(strPath)
    
3:    lngPos = InStrRev(strPath, ".")
    
4:    If lngPos > 0 Then GetPrefix = Mid$(strPath, lngPos)

'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "strPath:" & strPath & vbNewLine
    strMSLDebugHandler_Variables = "lngPos = " & lngPos & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modGeneralProcedures", "GetPrefix", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function RemovePath(ByVal strPath As String) As String
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim intPos As Integer

2:    intPos = InStrRev(strPath, "\")
    
3:    RemovePath = Mid$(strPath, intPos + 1)

'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "strPath:" & strPath & vbNewLine
    strMSLDebugHandler_Variables = "intPos = " & intPos & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Renamer", "modGeneralProcedures", "RemovePath", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function IsValidPrefix(ByVal strPath As String) As Boolean
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim strPrefix As String

2:    strPrefix = GetPrefix(GetTitle(strPath, True))

3:    Select Case UCase$(strPrefix)
    
        Case ".MP3", ".OGG", ".WMA": IsValidPrefix = True
        
        Case Else: IsValidPrefix = False
        
4:    End Select
    
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "strPath:" & strPath & vbNewLine
    strMSLDebugHandler_Variables = "strPrefix = " & strPrefix & vbNewLine

    objMSLDebugHandler.RaiseError "MP3TurboMate", "modGeneralProcedures", "IsValidPrefix", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function


Public Function GenerateFileList_Array(strPath As String, strType As String, _
                                       blnRecursive As Boolean, blnIgnoreDeletedFolder As Boolean, _
                                       blnIncludeFullPath As Boolean) As String()
                        
On Error GoTo MSLDebug_ErrorHandler:

Dim objFSO As New FileSystemObject, objFolder As Scripting.Folder, lngCount As Long
Dim strFiles() As String

    Set objFolder = objFSO.GetFolder(strPath)
    
    GenerateFileListArray_AddSubFolder objFolder, strType, blnRecursive, lngCount, strFiles, blnIgnoreDeletedFolder, blnIncludeFullPath
    
    If lngCount > 0 Then
    
        ReDim Preserve strFiles(lngCount - 1)
    Else
    
        ReDim strFiles(1)
    End If
    
    GenerateFileList_Array = strFiles

'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Variables = "lngCount = " & lngCount & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Renamer", "modGeneralProcedures", "GenerateFileList_Array", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function



