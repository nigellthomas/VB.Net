Attribute VB_Name = "modID3"
' *************************************************************************************************
' This MP3 tagging module reads, writes and deletes ID3 v 1.0, 1.1, 2.2, 2.3 and 2.4 tags,
' with support for extended tag headers, unsynchronized tags, tag footers, appended tags and
' MPEG file information.
'
' This module is a part of Magic MP3 Tagger. Visit www.magic-tagger.com if you're interested in
' this top MP3 tagger!
'
' Copyright by Mathias Kunter.
' You're free to use this module within your programs. These programs may also be commercial.
' The only condition for usage of this module is that you show the following line within the
' credits of your program:
'
' ID3 tagging module by Mathias Kunter (www.magic-tagger.com)
'
' *************************************************************************************************

Option Explicit


'***** The ID3 tag for data input / output with this module *****
Public Type ID3Tag
    Artist As String
    Album As String
    Title As String
    SongYear As String
    Genre As String
    Comment As String
    TrackNr As String

    'The following items are only used with ID3 v2 tags.
    EncodedBy As String
    LinkTo As String
    Copyright As String
    Composer As String
    OrigArtist As String
End Type

Public Type MPEGInfo
    MPEGVersion As String
    HasCRC As Boolean
    Bitrate As Long     'kbit / sec (where k = 1000, not 1024)
    Frequency As Long   'hz
    HasVBR As Boolean
    ChannelMode As String
    IsCopyrighted As Boolean
    IsOriginal As Boolean
    HasEmphasis As Boolean
    Length As Long      'sec
    ID3v1Version As Long    '-1 = no tag
    ID3v2Version As Long    '-1 = no tag
    FileSize As Long    'bytes
End Type

Public Enum ID3v2_Version
    VERSION_2_3
    VERSION_2_4
End Enum

Public Const ID3_GENRE_COUNT As Long = 148



'***** ID3v1 Types *****
Private Type v1Tag
    Identifier(2) As Byte
    Title(29) As Byte
    Artist(29) As Byte
    Album(29) As Byte
    SongYear(3) As Byte
    Comment(29) As Byte
    Genre As Byte
End Type



'***** ID3v2 Types *****

'Tag header for all versions (2.2 - 2.4)
'The v 2.4 footer also uses this structure, since it's a copy of the header.
Private Type v2TagHeader
    Identifier(2) As Byte
    Version(1) As Byte
    Flags As Byte
    Size(3) As Byte
End Type

'Extended tag header for v 2.3
Private Type v2_3ExtHeader
    Size(3) As Byte
    ExtendedFlags(1) As Byte
    PaddingSize(3) As Byte
End Type

'Extended tag header for v 2.4
Private Type v2_4ExtHeader
    Size(3) As Byte
    NumFlags As Byte
    ExtendedFlags As Byte
End Type

'Frame header for v 2.2
Private Type v2_2FrameHeader
    Ident(2) As Byte
    Size(2) As Byte
End Type

'Frame header for v 2.3 and v 2.4
Private Type v2_34FrameHeader
    Ident(3) As Byte
    Size(3) As Byte
    Flags(1) As Byte
End Type

'A v 2.x frame in memory.
Private Type v2MemFrame
    ID As String
    Size As Long
    Data() As Byte
End Type

Private Type v2TagHeaderFlags
    bUnsynch As Boolean
    bExtHeader As Boolean
    bFooter As Boolean
    bUpdateTag As Boolean
End Type

Private Type v2TagSizes
    ReadSize As Long
    ExtHeaderSize As Long
    FooterSize As Long
End Type

Private Enum v2_StrEncoding
    ENC_ISO = 0
    ENC_UNICODE_UTF16_BOM = 1
    ENC_UNICODE_UTF16 = 2
    ENC_UNICODE_UTF8 = 3
End Enum



'The frames stored in memory, used when updating a currently existing v2 tag.
Private mMemFrames() As v2MemFrame, mMemFraCnt As Long

Private Const cGenreString As String = _
"Blues#Classic Rock#Country#Dance#Disco#Funk#Grunge#Hip-Hop#Jazz#Metal#New Age#Oldies#Other#Pop#" & _
"R&B#Rap#Reggae#Rock#Techno#Industrial#Alternative#Ska#Death Metal#Pranks#Soundtrack#Euro-Techno#" & _
"Ambient#Trip-Hop#Vocal#Jazz+Funk#Fusion#Trance#Classical#Instrumental#Acid#House#Game#Sound Clip#" & _
"Gospel#Noise#Alt. Rock#Bass#Soul#Punk#Space#Meditative#Instrumental Pop#Instrumental Rock#Ethnic#" & _
"Gothic#Darkwave#Techno-Industrial#Electronic#Pop-Folk#Eurodance#Dream#Southern Rock#Comedy#Cult#" & _
"Gangsta#Top 40#Christian Rap#Pop/Funk#Jungle#Native American#Cabaret#New Wave#Psychadelic#Rave#" & _
"Showtunes#Trailer#Lo-Fi#Tribal#Acid Punk#Acid Jazz#Polka#Retro#Musical#Rock & Roll#Hard Rock#Folk#" & _
"Folk-Rock#National Folk#Swing#Fast Fusion#Bebob#Latin#Revival#Celtic#Bluegrass#Avantgarde#Gothic Rock#" & _
"Progressive Rock#Psychedelic Rock#Symphonic Rock#Slow Rock#Big Band#Chorus#Easy Listening#Acoustic#" & _
"Humour#Speech#Chanson#Opera#Chamber Music#Sonata#Symphony#Booty Bass#Primus#Porn Groove#Satire#Slow Jam#" & _
"Club#Tango#Samba#Folklore#Ballad#Power Ballad#Rhythmic Soul#Freestyle#Duet#Punk Rock#Drum Solo#A capella#" & _
"Euro-House#Dance Hall#Goa#Drum & Bass#Club-House#Hardcore#Terror#Indie#BritPop#Negerpunk#Polsk Punk#" & _
"Beat#Christian Gangsta#Heavy Metal#Black Metal#Crossover#Contemporary C#Christian Rock#Merengue#Salsa#" & _
"Thrash Metal#Anime#JPop#SynthPop"
Private GenreField() As String, bBuiltGenre As Boolean


'API
Private Const GENERIC_READ = &H80000000
Private Const GENERIC_WRITE = &H40000000
Private Const FILE_SHARE_READ = &H1
Private Const OPEN_EXISTING = &H3

Private Const FILE_BEGIN = 0
Private Const FILE_CURRENT = 1
Private Const FILE_END = 2

Private Const FILE_ATTRIBUTE_READONLY = &H1
Private Const INVALID_HANDLE_VALUE = -1

Private Declare Function CreateFile Lib "kernel32" Alias "CreateFileA" (ByVal lpFileName As String, ByVal dwDesiredAccess As Long, ByVal dwShareMode As Long, lpSecurityAttributes As Any, ByVal dwCreationDisposition As Long, ByVal dwFlagsAndAttributes As Long, ByVal hTemplateFile As Long) As Long
Private Declare Function GetFileSize Lib "kernel32" (ByVal hFile As Long, lpFileSizeHigh As Long) As Long
Private Declare Function SetFilePointer Lib "kernel32" (ByVal hFile As Long, ByVal lDistanceToMove As Long, lpDistanceToMoveHigh As Long, ByVal dwMoveMethod As Long) As Long
Private Declare Function ReadFile Lib "kernel32" (ByVal hFile As Long, lpBuffer As Any, ByVal nNumberOfBytesToRead As Long, lpNumberOfBytesRead As Long, lpOverlapped As Any) As Long
Private Declare Function WriteFile Lib "kernel32" (ByVal hFile As Long, lpBuffer As Any, ByVal nNumberOfBytesToWrite As Long, lpNumberOfBytesWritten As Long, lpOverlapped As Any) As Long
Private Declare Function CloseHandle Lib "kernel32" (ByVal hObject As Long) As Long
Private Declare Function SetEndOfFile Lib "kernel32" (ByVal hFile As Long) As Long
Private Declare Function GetFileAttributes Lib "kernel32" Alias "GetFileAttributesA" (ByVal lpFileName As String) As Long
Private Declare Function SetFileAttributes Lib "kernel32" Alias "SetFileAttributesA" (ByVal lpFileName As String, ByVal dwFileAttributes As Long) As Long

Private Declare Sub CopyMemory Lib "kernel32" Alias "RtlMoveMemory" (Destination As Any, Source As Any, ByVal Length As Long)







'**********************************ID3v 1.0, 1.1****************************************

Public Function ReadID3v1(ByVal FileName As String, ByRef outTag As ID3Tag) As Boolean
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim fh As Long, fsize As Long
2:    Dim RdTag As v1Tag

3:    fh = CreateFile(FileName, GENERIC_READ, FILE_SHARE_READ, ByVal 0, OPEN_EXISTING, 0, 0)
4:    If fh = INVALID_HANDLE_VALUE Then Exit Function
5:    fsize = GetFileSize(fh, 0)
6:    If fsize < 128 Then
7:        CloseHandle fh
8:        Exit Function
9:    End If
    'The ID3v1 tag is located 128 bytes from the end of the file, so look at this position.
10:    SetFilePointer fh, fsize - 128, 0, FILE_BEGIN
11:    ReadFile fh, RdTag, Len(RdTag), 0, ByVal 0
12:    CloseHandle fh

13:    If Data2String(VarPtr(RdTag.Identifier(0)), 3, ENC_ISO) = "TAG" Then
14:        ResetTag outTag

        'An ID3v1 tag is present.
15:        outTag.Artist = Trim$(Data2String(VarPtr(RdTag.Artist(0)), 30, ENC_ISO))
16:        outTag.Album = Trim$(Data2String(VarPtr(RdTag.Album(0)), 30, ENC_ISO))
17:        outTag.Title = Trim$(Data2String(VarPtr(RdTag.Title(0)), 30, ENC_ISO))
18:        If RdTag.Comment(28) = 0 And Not RdTag.Comment(29) = 0 Then
            'ID3v1.1 tag: byte 28 of the comment tag is zeroed, byte 29 is the track number.
19:            outTag.Comment = Trim$(Data2String(VarPtr(RdTag.Comment(0)), 28, ENC_ISO))
20:            outTag.TrackNr = RdTag.Comment(29)
21:        Else
            'ID3v1.0 tag: contains no track number.
22:            outTag.Comment = Trim$(Data2String(VarPtr(RdTag.Comment(0)), 30, ENC_ISO))
23:        End If
24:        outTag.Genre = GetGenreName(RdTag.Genre)
25:        outTag.SongYear = Trim$(Data2String(VarPtr(RdTag.SongYear(0)), 4, ENC_ISO))

26:        ReadID3v1 = True
27:    End If
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "FileName:" & FileName & vbNewLine
    strMSLDebugHandler_Variables = "fh = " & fh & vbNewLine & "fsize = " & fsize & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "ReadID3v1", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function ReadID3v1_ArtistTitle(ByVal FileName As String, ByRef outTag As ID3Tag) As Boolean
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
    
1: Dim fh As Long, fsize As Long
2: Dim RdTag As v1Tag

3:    fh = CreateFile(FileName, GENERIC_READ, FILE_SHARE_READ, ByVal 0, OPEN_EXISTING, 0, 0)
4:    If fh = INVALID_HANDLE_VALUE Then Exit Function
5:    fsize = GetFileSize(fh, 0)
6:    If fsize < 128 Then
7:        CloseHandle fh
8:        Exit Function
9:    End If
    
    'The ID3v1 tag is located 128 bytes from the end of the file, so look at this position.
10:    SetFilePointer fh, fsize - 128, 0, FILE_BEGIN
11:    ReadFile fh, RdTag, Len(RdTag), 0, ByVal 0
12:    CloseHandle fh

13:    If Data2String(VarPtr(RdTag.Identifier(0)), 3, ENC_ISO) = "TAG" Then
14:        ResetTag outTag

        'An ID3v1 tag is present.
15:        outTag.Artist = Trim$(Data2String(VarPtr(RdTag.Artist(0)), 30, ENC_ISO))
16:        outTag.Title = Trim$(Data2String(VarPtr(RdTag.Title(0)), 30, ENC_ISO))

17:        ReadID3v1_ArtistTitle = True
18:    End If
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "FileName:" & FileName & vbNewLine
    strMSLDebugHandler_Variables = "fh = " & fh & vbNewLine & "fsize = " & fsize & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "ReadID3v1_ArtistTitle", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function ReadID3v2_ArtistTitle(ByVal FileName As String, ByRef outTag As ID3Tag) As Boolean
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim fh As Long, fp As Long, TagFooter As v2TagHeader
2:    Dim rdBuf(3) As Byte

3:    fh = CreateFile(FileName, GENERIC_READ, FILE_SHARE_READ, ByVal 0, OPEN_EXISTING, 0, 0)
4:    If fh = INVALID_HANDLE_VALUE Then Exit Function

    'Search for an ID3v2 tag.
5:    Do
6:        SetFilePointer fh, fp, 0, FILE_BEGIN
7:        ReadFile fh, rdBuf(0), 3, 0, ByVal 0
8:        If Data2String(VarPtr(rdBuf(0)), 3, ENC_ISO) = "ID3" Then
            'We've got an ID3 v2 tag.
9:            fp = ReadV2Tag(fh, fp, outTag, False)
10:            ReadID3v2_ArtistTitle = True
11:        Else
12:            fp = -1
13:        End If
14:    Loop While Not fp = -1

15:    If Not ReadID3v2_ArtistTitle Then
        'No tag found at the beginning of the file.
        'Version 2.4 allows the ID3 tag to be appended to the audio data. So, look if we can
        'find such a tag, identified by a footer. According to id3.org, the ID3v2 footer should
        'be added before other tagging systems, therefore prepended to an possibly existing ID3v1 tag.

16:        fp = GetFileSize(fh, 0)
17:        SetFilePointer fh, fp - 128, 0, FILE_BEGIN
18:        ReadFile fh, rdBuf(0), 3, 0, ByVal 0
19:        If Data2String(VarPtr(rdBuf(0)), 3, ENC_ISO) = "TAG" Then
            'Look before the ID3 v1 tag.
20:            fp = fp - 128 - Len(TagFooter)
21:        Else
            'Look at the end of the file.
22:            fp = fp - Len(TagFooter)
23:        End If
24:        If fp < 0 Then fp = 0

25:        SetFilePointer fh, fp, 0, FILE_BEGIN
26:        ReadFile fh, TagFooter, Len(TagFooter), 0, ByVal 0
27:        If Data2String(VarPtr(TagFooter.Identifier(0)), 3, ENC_ISO) = "3DI" Then
            'Got a footer. Calculate the header position from the size.
28:            fp = fp - Data2Long(VarPtr(TagFooter.Size(0)), True) - Len(TagFooter)
29:            If Not fp < 0 Then
30:                ReadV2Tag_ArtistTitle fh, fp, outTag, False
31:                ReadID3v2_ArtistTitle = True
32:            End If
33:        End If
34:    End If
35:    CloseHandle fh
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "FileName:" & FileName & vbNewLine
    strMSLDebugHandler_Variables = "fh = " & fh & vbNewLine & "fp = " & fp & vbNewLine

    objMSLDebugHandler.RaiseError "MP3TurboMate", "modID3", "ReadID3v2_ArtistTitle", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function WriteID3v1(ByVal FileName As String, ByRef inTag As ID3Tag, Optional ByVal bIgnoreReadOnly As Boolean = True) As Boolean
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim fh As Long, fsize As Long
2:    Dim rdBuf(2) As Byte, WrTag As v1Tag

3:    If bIgnoreReadOnly Then IgnoreReadOnly FileName
4:    fh = CreateFile(FileName, GENERIC_READ Or GENERIC_WRITE, FILE_SHARE_READ, ByVal 0, OPEN_EXISTING, 0, 0)
5:    If fh = INVALID_HANDLE_VALUE Then Exit Function
6:    fsize = GetFileSize(fh, 0)

    'Check if there's already an ID3v1 tag present.
    'The ID3v1 tag is located 128 bytes from the end of the file, so look at this position.
7:    If fsize >= 128 Then
8:        SetFilePointer fh, fsize - 128, 0, FILE_BEGIN
9:        ReadFile fh, rdBuf(0), 3, 0, ByVal 0
10:        If Data2String(VarPtr(rdBuf(0)), 3, ENC_ISO) = "TAG" Then
            'An ID3v1 tag is present.
11:            SetFilePointer fh, fsize - 128, 0, FILE_BEGIN
12:        Else
            'An ID3v1 tag isn't present.
13:            SetFilePointer fh, fsize, 0, FILE_BEGIN
14:        End If
15:    Else
        'An ID3v1 tag isn't present.
16:        SetFilePointer fh, fsize, 0, FILE_BEGIN
17:    End If

    'Build up writing tag.
18:    String2Data "TAG", 3, VarPtr(WrTag.Identifier(0)), False
19:    String2Data inTag.Artist, 30, VarPtr(WrTag.Artist(0)), False
20:    String2Data inTag.Album, 30, VarPtr(WrTag.Album(0)), False
21:    String2Data inTag.Title, 30, VarPtr(WrTag.Title(0)), False
22:    String2Data Replace$(inTag.Comment, vbNewLine, " "), 28, VarPtr(WrTag.Comment(0)), False
    'ID3v1.1 tag: comment(28) = 0, comment(29) = track number.
23:    WrTag.Comment(28) = 0
24:    WrTag.Comment(29) = 0
25:    If IsNumeric(inTag.TrackNr) And Len(Trim$(inTag.TrackNr)) <= 3 Then
26:        If CLng(inTag.TrackNr) > 0 And CLng(inTag.TrackNr) <= 255 Then
27:            WrTag.Comment(29) = CByte(inTag.TrackNr)
28:        End If
29:    End If
30:    WrTag.Genre = GetGenreIndex(inTag.Genre)
31:    String2Data inTag.SongYear, 4, VarPtr(WrTag.SongYear(0)), False

    'Write the tag to file.
32:    WriteFile fh, WrTag, Len(WrTag), 0, ByVal 0

33:    CloseHandle fh
34:    WriteID3v1 = True
    
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "FileName:" & FileName & vbNewLine & "bIgnoreReadOnly:" & bIgnoreReadOnly & vbNewLine
    strMSLDebugHandler_Variables = "fh = " & fh & vbNewLine & "fsize = " & fsize & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "WriteID3v1", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function DeleteID3v1(ByVal FileName As String, Optional ByVal bIgnoreReadOnly As Boolean = True) As Boolean
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim fh As Long, fsize As Long
2:    Dim rdBuf(2) As Byte

3:    If bIgnoreReadOnly Then IgnoreReadOnly FileName
4:    fh = CreateFile(FileName, GENERIC_READ Or GENERIC_WRITE, FILE_SHARE_READ, ByVal 0, OPEN_EXISTING, 0, 0)
5:    If fh = INVALID_HANDLE_VALUE Then Exit Function
6:    fsize = GetFileSize(fh, 0)
7:    If fsize < 128 Then
8:        CloseHandle fh
9:        Exit Function
10:    End If

    'Check if there's an ID3v1 tag present.
    'The ID3v1 tag is located 128 bytes from the end of the file, so look at this position.
11:    SetFilePointer fh, fsize - 128, 0, FILE_BEGIN
12:    ReadFile fh, rdBuf(0), 3, 0, ByVal 0
13:    If Data2String(VarPtr(rdBuf(0)), 3, ENC_ISO) = "TAG" Then
        'An ID3v1 tag is present, remove it.
14:        SetFilePointer fh, fsize - 128, 0, FILE_BEGIN
15:        SetEndOfFile fh
16:    End If

17:    CloseHandle fh
18:    DeleteID3v1 = True
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "FileName:" & FileName & vbNewLine & "bIgnoreReadOnly:" & bIgnoreReadOnly & vbNewLine
    strMSLDebugHandler_Variables = "fh = " & fh & vbNewLine & "fsize = " & fsize & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "DeleteID3v1", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function




'**********************************ID3v 2.2, 2.3, 2.4****************************************

Public Function ReadID3v2(ByVal FileName As String, ByRef outTag As ID3Tag) As Boolean
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim fh As Long, fp As Long, TagFooter As v2TagHeader
2:    Dim rdBuf(3) As Byte

3:    fh = CreateFile(FileName, GENERIC_READ, FILE_SHARE_READ, ByVal 0, OPEN_EXISTING, 0, 0)
4:    If fh = INVALID_HANDLE_VALUE Then Exit Function

    'Search for an ID3v2 tag.
5:    Do
6:        SetFilePointer fh, fp, 0, FILE_BEGIN
7:        ReadFile fh, rdBuf(0), 3, 0, ByVal 0
8:        If Data2String(VarPtr(rdBuf(0)), 3, ENC_ISO) = "ID3" Then
            'We've got an ID3 v2 tag.
9:            fp = ReadV2Tag(fh, fp, outTag, False)
10:            ReadID3v2 = True
11:        Else
12:            fp = -1
13:        End If
14:    Loop While Not fp = -1

15:    If Not ReadID3v2 Then
        'No tag found at the beginning of the file.
        'Version 2.4 allows the ID3 tag to be appended to the audio data. So, look if we can
        'find such a tag, identified by a footer. According to id3.org, the ID3v2 footer should
        'be added before other tagging systems, therefore prepended to an possibly existing ID3v1 tag.

16:        fp = GetFileSize(fh, 0)
17:        SetFilePointer fh, fp - 128, 0, FILE_BEGIN
18:        ReadFile fh, rdBuf(0), 3, 0, ByVal 0
19:        If Data2String(VarPtr(rdBuf(0)), 3, ENC_ISO) = "TAG" Then
            'Look before the ID3 v1 tag.
20:            fp = fp - 128 - Len(TagFooter)
21:        Else
            'Look at the end of the file.
22:            fp = fp - Len(TagFooter)
23:        End If
24:        If fp < 0 Then fp = 0

25:        SetFilePointer fh, fp, 0, FILE_BEGIN
26:        ReadFile fh, TagFooter, Len(TagFooter), 0, ByVal 0
27:        If Data2String(VarPtr(TagFooter.Identifier(0)), 3, ENC_ISO) = "3DI" Then
            'Got a footer. Calculate the header position from the size.
28:            fp = fp - Data2Long(VarPtr(TagFooter.Size(0)), True) - Len(TagFooter)
29:            If Not fp < 0 Then
30:                ReadV2Tag fh, fp, outTag, False
31:                ReadID3v2 = True
32:            End If
33:        End If
34:    End If
35:    CloseHandle fh
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "FileName:" & FileName & vbNewLine
    strMSLDebugHandler_Variables = "fh = " & fh & vbNewLine & "fp = " & fp & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "ReadID3v2", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

'Returns the file pointer for the next tag, or -1 if there is no tag appended.
Private Function ReadV2Tag(ByVal fh As Long, ByVal fp As Long, ByRef RdTag As ID3Tag, ByVal bToMem As Boolean) As Long
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim TagSizes As v2TagSizes, arrp As Long
2:    Dim TagHeader As v2TagHeader, TagHeaderFlags As v2TagHeaderFlags
3:    Dim ExtHeader23 As v2_3ExtHeader, ExtHeader24 As v2_4ExtHeader
4:    Dim FraHeader22 As v2_2FrameHeader, FraHeader234 As v2_34FrameHeader
5:    Dim FraDataSize As Long, FraUnsynchDecr As Long, fraID As String, FraText As String
6:    Dim FraOffset As Long, bSkipFra As Boolean
7:    Dim TagData() As Byte, SizeBuf(3) As Byte


8:    ReadV2Tag = -1

    '------------------------------------------------------
    '********************* TAG HEADER *********************
    '------------------------------------------------------

9:    SetFilePointer fh, fp, 0, FILE_BEGIN
10:    ReadFile fh, TagHeader, Len(TagHeader), 0, ByVal 0
11:    If TagHeader.Version(0) < 2 Or TagHeader.Version(0) > 4 Then Exit Function
    'The size stored in the header excludes itself, and excludes the footer (if present).
12:    TagSizes.ReadSize = Data2Long(VarPtr(TagHeader.Size(0)), True)

    'v 2.2 flags: %ab000000 a = unsynch, b = compression (not implemented, ignored)
    'v 2.3 flags: %abc00000 a = unsynch, b = extended header, c = experimental (ignored)
    'v 2.4 flags: %abcd0000 a = unsynch, b = extended header, c = experimental (ignored), d = footer present
13:    If TagHeader.Flags And &H80& Then TagHeaderFlags.bUnsynch = True
14:    If TagHeader.Version(0) >= 3 Then
15:        If TagHeader.Flags And &H40& Then TagHeaderFlags.bExtHeader = True
16:    End If
17:    If TagHeader.Version(0) = 4 Then
18:        If TagHeader.Flags And &H10& Then
19:            TagHeaderFlags.bFooter = True
20:            TagSizes.FooterSize = Len(TagHeader)
            'Add the size of the footer (which is the same size than the header) to the read size.
            'Padding must not exist when a footer is present.
21:            TagSizes.ReadSize = TagSizes.ReadSize + TagSizes.FooterSize
22:        End If
23:    End If

    'Read in the rest of the tag.
24:    ReDim TagData(TagSizes.ReadSize - 1)
25:    ReadFile fh, TagData(0), TagSizes.ReadSize, 0, ByVal 0

    'Perform de-unsynchoronisation of the whole read tag, if nescessary.
    'In version 2.2 and 2.3, the unsynch is done for all data after the header if the flag is set.
    'In version 2.4, the unsynch is applied on a per frame base.
26:    If TagHeader.Version(0) <= 3 And TagHeaderFlags.bUnsynch Then
27:        TagSizes.ReadSize = TagSizes.ReadSize - DeUnsynch(VarPtr(TagData(0)), TagSizes.ReadSize)
28:    End If


    '---------------------------------------------------------------
    '********************* EXTENDED TAG HEADER *********************
    '---------------------------------------------------------------

29:    If TagHeaderFlags.bExtHeader Then
30:        If TagHeader.Version(0) = 3 Then
            'Ignore the v 2.3 extended header.
31:            CopyMemory ExtHeader23, TagData(0), Len(ExtHeader23)
32:            TagSizes.ExtHeaderSize = Data2Long(VarPtr(ExtHeader23.Size(0)), False) + 4
33:        ElseIf TagHeader.Version(0) = 4 Then
            'Read the extended header update flag.
34:            CopyMemory ExtHeader24, TagData(0), Len(ExtHeader24)
35:            TagSizes.ExtHeaderSize = Data2Long(VarPtr(ExtHeader24.Size(0)), True)
36:            If ExtHeader24.ExtendedFlags And &H40& Then TagHeaderFlags.bUpdateTag = True
37:        End If
38:    End If

39:    If Not TagHeaderFlags.bUpdateTag Then
        'Reset output tag.
40:        ResetTag RdTag
41:    End If


    '--------------------------------------------------
    '********************* FRAMES *********************
    '--------------------------------------------------

42:    arrp = TagSizes.ExtHeaderSize
43:    Do
44:        If TagHeader.Version(0) = 2 Then

            'Check if there's enough space to read another tag header. We don't have to take
            'care of a footer here because v 2.2 doesn't support footers.
45:            If arrp < 0 Or arrp > TagSizes.ReadSize - Len(FraHeader22) Then Exit Do

            'Get the frame header.
46:            CopyMemory FraHeader22, TagData(arrp), Len(FraHeader22)
47:            arrp = arrp + Len(FraHeader22)

            'Read out the frame ID.
48:            fraID = Data2String(VarPtr(FraHeader22.Ident(0)), 3, ENC_ISO, False)
49:            If fraID = String$(3, Chr(0)) Then Exit Do

            'Read out the frame data size.
50:            CopyMemory SizeBuf(1), FraHeader22.Size(0), 3
51:            FraDataSize = Data2Long(VarPtr(SizeBuf(0)), False)
52:            If arrp > TagSizes.ReadSize - FraDataSize Then Exit Do

            'Read out the frame itself.
53:            If bToMem Then
                'CRM: Encrypted meta frame. Only supported in v 2.2, not converted.
54:                If Not fraID = "CRM" And FraDataSize > 0 Then
                    'Store this frame in the memory buffer, we only need the data to update
                    'a currently existing tag.
55:                    ReDim Preserve mMemFrames(mMemFraCnt)
56:                    With mMemFrames(mMemFraCnt)
57:                        .ID = fraID
58:                        .Size = FraDataSize
59:                        ReDim .Data(.Size - 1)
60:                        CopyMemory .Data(0), TagData(arrp), .Size
61:                    End With
62:                    mMemFraCnt = mMemFraCnt + 1
63:                    ConvertV23 mMemFraCnt - 1
64:                End If
65:                FraText = ""
66:            Else
67:                FraText = ReadFrame(VarPtr(TagData(arrp)), fraID, FraDataSize)
68:            End If

69:        ElseIf TagHeader.Version(0) >= 3 Then

            'Check if there's enough space to read another tag header.
70:            If arrp < 0 Or arrp > TagSizes.ReadSize - TagSizes.FooterSize - Len(FraHeader234) Then Exit Do

            'Get the frame header.
71:            CopyMemory FraHeader234, TagData(arrp), Len(FraHeader234)
72:            arrp = arrp + Len(FraHeader234)

            'Read out the frame ID.
73:            fraID = Data2String(VarPtr(FraHeader234.Ident(0)), 4, ENC_ISO, False)
74:            If fraID = String$(4, Chr(0)) Then
                'Got the padding. Frame parsing is finished now.
75:                Exit Do
76:            End If

            'Read out the frame data size.
            'v 2.3: No synchsafe integer.
            'v 2.4: Synchsafe integer. However, there are sloppy programs which code version 2.4 with
            'non-synchsafe integers. Do a test therefore, by checking if the next frame is a valid one.
77:            FraDataSize = Data2Long(VarPtr(FraHeader234.Size(0)), IIf(TagHeader.Version(0) = 3, False, True))
78:            If arrp > TagSizes.ReadSize - TagSizes.FooterSize - FraDataSize Then Exit Do
79:            If arrp <= TagSizes.ReadSize - TagSizes.FooterSize - FraDataSize - 4 Then
                'Check if the next frame would be valid.
80:                If Not IsValidFrameName(VarPtr(TagData(arrp + FraDataSize))) Then
                    'Try to decode the number as non-synchsafe.
81:                    FraDataSize = Data2Long(VarPtr(FraHeader234.Size(0)), False)
82:                    If arrp > TagSizes.ReadSize - TagSizes.FooterSize - FraDataSize Then Exit Do
83:                End If
84:            End If

            'Read out the frame flags.
85:            FraOffset = 0
86:            bSkipFra = False
87:            FraUnsynchDecr = 0
88:            If TagHeader.Version(0) = 3 Then
                'v 2.3 frame header flags: %abc00000 %ijk00000
                'abc flags are ignored. i = compression, j = encryption, k = grouping
89:                If FraHeader234.Flags(1) And &HC0& Then
                    'Either compressed or encrypted frame. Skip it.
90:                    bSkipFra = True
91:                End If
92:                If FraHeader234.Flags(1) And &H20& Then
                    'This frame belongs to a group. I don't care about that, but we have to
                    'consider about the 1 byte added to the header which defines the group.
93:                    FraOffset = 1
94:                End If
95:            Else
                'v 2.4 frame header flags: %0abc0000 %0h00kmnp
                'abc flags are ignored. h = grouping, k = compression, m = encryption,
                'n = unsynch, p = data length indicator
96:                If FraHeader234.Flags(1) And &H40& Then
                    'See comment above about grouping.
97:                    FraOffset = 1
98:                End If
99:                If FraHeader234.Flags(1) And &HC& Then
                    'Either compressed or encrypted frame. Skip it.
100:                    bSkipFra = True
101:                End If
102:                If (FraHeader234.Flags(1) And &H2&) Or TagHeaderFlags.bUnsynch Then
103:                    If Not bSkipFra Then
                        'Unsynched frame. DeUnsynch it now.
104:                        FraUnsynchDecr = DeUnsynch(VarPtr(TagData(arrp)), FraDataSize)
105:                    End If
106:                End If
107:                If FraHeader234.Flags(1) And &H1& Then
                    'Data length indicator. Is ignored, but add 4 bytes offset, because it
                    'appends a synchsafe integer to the header.
108:                    FraOffset = FraOffset + 4
109:                End If
110:            End If

            'Read out the frame itself.
111:            If Not bSkipFra Then
                'Skipped frames also are NOT added to the memory, because the new frames
                'are written with a frame header that doesn't include the flags for
                'compression or encryption.
112:                If bToMem And Not fraID = "SEEK" Then
                    'Store this frame in the memory buffer, we only need the data to update
                    'a currently existing tag. The v 2.4 seek frame isn't copied to memory,
                    'because the new written file is going to have different offsets anyway.
                    'However, read out the frame to ensure processing of the appended tag.
113:                    If FraDataSize - FraOffset - FraUnsynchDecr > 0 Then
114:                        ReDim Preserve mMemFrames(mMemFraCnt)
115:                        With mMemFrames(mMemFraCnt)
116:                            .ID = fraID
117:                            .Size = FraDataSize - FraOffset - FraUnsynchDecr
118:                            ReDim .Data(.Size - 1)
119:                            CopyMemory .Data(0), TagData(arrp + FraOffset), .Size
120:                        End With
121:                        mMemFraCnt = mMemFraCnt + 1
122:                        ConvertV23 mMemFraCnt - 1
123:                    End If
124:                    FraText = ""
125:                Else
126:                    FraText = ReadFrame(VarPtr(TagData(arrp + FraOffset)), fraID, FraDataSize - FraOffset - FraUnsynchDecr)
127:                End If
128:            Else
129:                FraText = ""
130:            End If
131:        End If

        'Increase the array pointer.
132:        arrp = arrp + FraDataSize

        'Write the tags into the structure.
133:        If fraID = "TP1" Or fraID = "TPE1" Then
134:            RdTag.Artist = FraText
135:        ElseIf fraID = "TAL" Or fraID = "TALB" Then
136:            RdTag.Album = FraText
137:        ElseIf fraID = "TT2" Or fraID = "TIT2" Then
138:            RdTag.Title = FraText
139:        ElseIf fraID = "TRK" Or fraID = "TRCK" Then
140:            RdTag.TrackNr = FraText
141:        ElseIf fraID = "TDRC" Then
            'The v 2.4 timestamp frame includes the release year.
142:            RdTag.SongYear = Left$(FraText, 4)
143:        ElseIf fraID = "TYE" Or fraID = "TYER" Then
144:            RdTag.SongYear = FraText
145:        ElseIf fraID = "TCO" Or fraID = "TCON" Then
146:            RdTag.Genre = Frame2Genre(FraText)
147:        ElseIf fraID = "COM" Or fraID = "COM " Or fraID = "COMM" Then
148:            RdTag.Comment = FraText
149:        ElseIf fraID = "TEN" Or fraID = "TENC" Then
150:            RdTag.EncodedBy = FraText
151:        ElseIf fraID = "WXX" Or fraID = "WXXX" Then
152:            RdTag.LinkTo = FraText
153:        ElseIf fraID = "TCR" Or fraID = "TCOP" Then
154:            RdTag.Copyright = FraText
155:        ElseIf fraID = "TOA" Or fraID = "TOPE" Then
156:            RdTag.OrigArtist = FraText
157:        ElseIf fraID = "TCM" Or fraID = "TCOM" Then
158:            RdTag.Composer = FraText
159:        ElseIf fraID = "SEEK" Then
160:            If IsNumeric(FraText) Then
                'FraText actually has to be numeric, because its value is generated from Data2Long.
161:                ReadV2Tag = fp + Len(TagHeader) + TagSizes.ReadSize + CLng(FraText)
162:            End If
163:        End If
164:    Loop
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "fh:" & fh & vbNewLine & "fp:" & fp & vbNewLine & "bToMem:" & bToMem & vbNewLine
    strMSLDebugHandler_Variables = "arrp = " & arrp & vbNewLine & "FraDataSize = " & FraDataSize & vbNewLine & "FraUnsynchDecr = " & FraUnsynchDecr & vbNewLine _
                                 & "fraID = " & fraID & vbNewLine & "FraText = " & FraText & vbNewLine & "FraOffset = " & FraOffset & vbNewLine _
                                 & "bSkipFra = " & bSkipFra & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "ReadV2Tag", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Private Function ReadV2Tag_ArtistTitle(ByVal fh As Long, ByVal fp As Long, ByRef RdTag As ID3Tag, ByVal bToMem As Boolean) As Long
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim TagSizes As v2TagSizes, arrp As Long
2:    Dim TagHeader As v2TagHeader, TagHeaderFlags As v2TagHeaderFlags
3:    Dim ExtHeader23 As v2_3ExtHeader, ExtHeader24 As v2_4ExtHeader
4:    Dim FraHeader22 As v2_2FrameHeader, FraHeader234 As v2_34FrameHeader
5:    Dim FraDataSize As Long, FraUnsynchDecr As Long, fraID As String, FraText As String
6:    Dim FraOffset As Long, bSkipFra As Boolean
7:    Dim TagData() As Byte, SizeBuf(3) As Byte


8:    ReadV2Tag_ArtistTitle = -1

    '------------------------------------------------------
    '********************* TAG HEADER *********************
    '------------------------------------------------------

9:    SetFilePointer fh, fp, 0, FILE_BEGIN
10:    ReadFile fh, TagHeader, Len(TagHeader), 0, ByVal 0
11:    If TagHeader.Version(0) < 2 Or TagHeader.Version(0) > 4 Then Exit Function
    'The size stored in the header excludes itself, and excludes the footer (if present).
12:    TagSizes.ReadSize = Data2Long(VarPtr(TagHeader.Size(0)), True)

    'v 2.2 flags: %ab000000 a = unsynch, b = compression (not implemented, ignored)
    'v 2.3 flags: %abc00000 a = unsynch, b = extended header, c = experimental (ignored)
    'v 2.4 flags: %abcd0000 a = unsynch, b = extended header, c = experimental (ignored), d = footer present
13:    If TagHeader.Flags And &H80& Then TagHeaderFlags.bUnsynch = True
14:    If TagHeader.Version(0) >= 3 Then
15:        If TagHeader.Flags And &H40& Then TagHeaderFlags.bExtHeader = True
16:    End If
17:    If TagHeader.Version(0) = 4 Then
18:        If TagHeader.Flags And &H10& Then
19:            TagHeaderFlags.bFooter = True
20:            TagSizes.FooterSize = Len(TagHeader)
            'Add the size of the footer (which is the same size than the header) to the read size.
            'Padding must not exist when a footer is present.
21:            TagSizes.ReadSize = TagSizes.ReadSize + TagSizes.FooterSize
22:        End If
23:    End If

    'Read in the rest of the tag.
24:    ReDim TagData(TagSizes.ReadSize - 1)
25:    ReadFile fh, TagData(0), TagSizes.ReadSize, 0, ByVal 0

    'Perform de-unsynchoronisation of the whole read tag, if nescessary.
    'In version 2.2 and 2.3, the unsynch is done for all data after the header if the flag is set.
    'In version 2.4, the unsynch is applied on a per frame base.
26:    If TagHeader.Version(0) <= 3 And TagHeaderFlags.bUnsynch Then
27:        TagSizes.ReadSize = TagSizes.ReadSize - DeUnsynch(VarPtr(TagData(0)), TagSizes.ReadSize)
28:    End If


    '---------------------------------------------------------------
    '********************* EXTENDED TAG HEADER *********************
    '---------------------------------------------------------------

29:    If TagHeaderFlags.bExtHeader Then
30:        If TagHeader.Version(0) = 3 Then
            'Ignore the v 2.3 extended header.
31:            CopyMemory ExtHeader23, TagData(0), Len(ExtHeader23)
32:            TagSizes.ExtHeaderSize = Data2Long(VarPtr(ExtHeader23.Size(0)), False) + 4
33:        ElseIf TagHeader.Version(0) = 4 Then
            'Read the extended header update flag.
34:            CopyMemory ExtHeader24, TagData(0), Len(ExtHeader24)
35:            TagSizes.ExtHeaderSize = Data2Long(VarPtr(ExtHeader24.Size(0)), True)
36:            If ExtHeader24.ExtendedFlags And &H40& Then TagHeaderFlags.bUpdateTag = True
37:        End If
38:    End If

39:    If Not TagHeaderFlags.bUpdateTag Then
        'Reset output tag.
40:        ResetTag RdTag
41:    End If


    '--------------------------------------------------
    '********************* FRAMES *********************
    '--------------------------------------------------

42:    arrp = TagSizes.ExtHeaderSize
43:    Do
44:        If TagHeader.Version(0) = 2 Then

            'Check if there's enough space to read another tag header. We don't have to take
            'care of a footer here because v 2.2 doesn't support footers.
45:            If arrp < 0 Or arrp > TagSizes.ReadSize - Len(FraHeader22) Then Exit Do

            'Get the frame header.
46:            CopyMemory FraHeader22, TagData(arrp), Len(FraHeader22)
47:            arrp = arrp + Len(FraHeader22)

            'Read out the frame ID.
48:            fraID = Data2String(VarPtr(FraHeader22.Ident(0)), 3, ENC_ISO, False)
49:            If fraID = String$(3, Chr(0)) Then Exit Do

            'Read out the frame data size.
50:            CopyMemory SizeBuf(1), FraHeader22.Size(0), 3
51:            FraDataSize = Data2Long(VarPtr(SizeBuf(0)), False)
52:            If arrp > TagSizes.ReadSize - FraDataSize Then Exit Do

            'Read out the frame itself.
53:            If bToMem Then
                'CRM: Encrypted meta frame. Only supported in v 2.2, not converted.
54:                If Not fraID = "CRM" And FraDataSize > 0 Then
                    'Store this frame in the memory buffer, we only need the data to update
                    'a currently existing tag.
55:                    ReDim Preserve mMemFrames(mMemFraCnt)
56:                    With mMemFrames(mMemFraCnt)
57:                        .ID = fraID
58:                        .Size = FraDataSize
59:                        ReDim .Data(.Size - 1)
60:                        CopyMemory .Data(0), TagData(arrp), .Size
61:                    End With
62:                    mMemFraCnt = mMemFraCnt + 1
63:                    ConvertV23 mMemFraCnt - 1
64:                End If
65:                FraText = ""
66:            Else
67:                FraText = ReadFrame(VarPtr(TagData(arrp)), fraID, FraDataSize)
68:            End If

69:        ElseIf TagHeader.Version(0) >= 3 Then

            'Check if there's enough space to read another tag header.
70:            If arrp < 0 Or arrp > TagSizes.ReadSize - TagSizes.FooterSize - Len(FraHeader234) Then Exit Do

            'Get the frame header.
71:            CopyMemory FraHeader234, TagData(arrp), Len(FraHeader234)
72:            arrp = arrp + Len(FraHeader234)

            'Read out the frame ID.
73:            fraID = Data2String(VarPtr(FraHeader234.Ident(0)), 4, ENC_ISO, False)
74:            If fraID = String$(4, Chr(0)) Then
                'Got the padding. Frame parsing is finished now.
75:                Exit Do
76:            End If

            'Read out the frame data size.
            'v 2.3: No synchsafe integer.
            'v 2.4: Synchsafe integer. However, there are sloppy programs which code version 2.4 with
            'non-synchsafe integers. Do a test therefore, by checking if the next frame is a valid one.
77:            FraDataSize = Data2Long(VarPtr(FraHeader234.Size(0)), IIf(TagHeader.Version(0) = 3, False, True))
78:            If arrp > TagSizes.ReadSize - TagSizes.FooterSize - FraDataSize Then Exit Do
79:            If arrp <= TagSizes.ReadSize - TagSizes.FooterSize - FraDataSize - 4 Then
                'Check if the next frame would be valid.
80:                If Not IsValidFrameName(VarPtr(TagData(arrp + FraDataSize))) Then
                    'Try to decode the number as non-synchsafe.
81:                    FraDataSize = Data2Long(VarPtr(FraHeader234.Size(0)), False)
82:                    If arrp > TagSizes.ReadSize - TagSizes.FooterSize - FraDataSize Then Exit Do
83:                End If
84:            End If

            'Read out the frame flags.
85:            FraOffset = 0
86:            bSkipFra = False
87:            FraUnsynchDecr = 0
88:            If TagHeader.Version(0) = 3 Then
                'v 2.3 frame header flags: %abc00000 %ijk00000
                'abc flags are ignored. i = compression, j = encryption, k = grouping
89:                If FraHeader234.Flags(1) And &HC0& Then
                    'Either compressed or encrypted frame. Skip it.
90:                    bSkipFra = True
91:                End If
92:                If FraHeader234.Flags(1) And &H20& Then
                    'This frame belongs to a group. I don't care about that, but we have to
                    'consider about the 1 byte added to the header which defines the group.
93:                    FraOffset = 1
94:                End If
95:            Else
                'v 2.4 frame header flags: %0abc0000 %0h00kmnp
                'abc flags are ignored. h = grouping, k = compression, m = encryption,
                'n = unsynch, p = data length indicator
96:                If FraHeader234.Flags(1) And &H40& Then
                    'See comment above about grouping.
97:                    FraOffset = 1
98:                End If
99:                If FraHeader234.Flags(1) And &HC& Then
                    'Either compressed or encrypted frame. Skip it.
100:                    bSkipFra = True
101:                End If
102:                If (FraHeader234.Flags(1) And &H2&) Or TagHeaderFlags.bUnsynch Then
103:                    If Not bSkipFra Then
                        'Unsynched frame. DeUnsynch it now.
104:                        FraUnsynchDecr = DeUnsynch(VarPtr(TagData(arrp)), FraDataSize)
105:                    End If
106:                End If
107:                If FraHeader234.Flags(1) And &H1& Then
                    'Data length indicator. Is ignored, but add 4 bytes offset, because it
                    'appends a synchsafe integer to the header.
108:                    FraOffset = FraOffset + 4
109:                End If
110:            End If

            'Read out the frame itself.
111:            If Not bSkipFra Then
                'Skipped frames also are NOT added to the memory, because the new frames
                'are written with a frame header that doesn't include the flags for
                'compression or encryption.
112:                If bToMem And Not fraID = "SEEK" Then
                    'Store this frame in the memory buffer, we only need the data to update
                    'a currently existing tag. The v 2.4 seek frame isn't copied to memory,
                    'because the new written file is going to have different offsets anyway.
                    'However, read out the frame to ensure processing of the appended tag.
113:                    If FraDataSize - FraOffset - FraUnsynchDecr > 0 Then
114:                        ReDim Preserve mMemFrames(mMemFraCnt)
115:                        With mMemFrames(mMemFraCnt)
116:                            .ID = fraID
117:                            .Size = FraDataSize - FraOffset - FraUnsynchDecr
118:                            ReDim .Data(.Size - 1)
119:                            CopyMemory .Data(0), TagData(arrp + FraOffset), .Size
120:                        End With
121:                        mMemFraCnt = mMemFraCnt + 1
122:                        ConvertV23 mMemFraCnt - 1
123:                    End If
124:                    FraText = ""
125:                Else
126:                    FraText = ReadFrame(VarPtr(TagData(arrp + FraOffset)), fraID, FraDataSize - FraOffset - FraUnsynchDecr)
127:                End If
128:            Else
129:                FraText = ""
130:            End If
131:        End If

        'Increase the array pointer.
132:        arrp = arrp + FraDataSize

        'Write the tags into the structure.
133:        If fraID = "TP1" Or fraID = "TPE1" Then
134:            RdTag.Artist = FraText

135:        ElseIf fraID = "TT2" Or fraID = "TIT2" Then
136:            RdTag.Title = FraText
137:        ElseIf fraID = "SEEK" Then
138:            If IsNumeric(FraText) Then
                'FraText actually has to be numeric, because its value is generated from Data2Long.
139:                ReadV2Tag_ArtistTitle = fp + Len(TagHeader) + TagSizes.ReadSize + CLng(FraText)
140:            End If
141:        End If
142:    Loop
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "fh:" & fh & vbNewLine & "fp:" & fp & vbNewLine & "bToMem:" & bToMem & vbNewLine
    strMSLDebugHandler_Variables = "arrp = " & arrp & vbNewLine & "FraDataSize = " & FraDataSize & vbNewLine & "FraUnsynchDecr = " & FraUnsynchDecr & vbNewLine _
                                 & "fraID = " & fraID & vbNewLine & "FraText = " & FraText & vbNewLine & "FraOffset = " & FraOffset & vbNewLine _
                                 & "bSkipFra = " & bSkipFra & vbNewLine

    objMSLDebugHandler.RaiseError "MP3TurboMate", "modID3", "ReadV2Tag_ArtistTitle", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Private Function ReadFrame(ByVal pData As Long, ByVal FrameID As String, ByVal FrameSize As Long) As String
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim EncFormat As Byte, SkipOffset As Long

2:    If FrameSize = 0 Then Exit Function

3:    CopyMemory EncFormat, ByVal pData, 1
4:    If Left$(FrameID, 1) = "T" Then
        'Text frame.
5:        ReadFrame = Data2String(pData + 1, FrameSize - 1, EncFormat)
6:    ElseIf FrameID = "COMM" Or FrameID = "COM " Or FrameID = "COM" Then
        'Comment frame.
        'Skip the 3 bytes language identifier.
7:        SkipOffset = 4
        'Skip the content description.
8:        ReadFrame = Data2String(pData + SkipOffset, FrameSize - SkipOffset, EncFormat)
9:        If EncFormat = ENC_ISO Or EncFormat = ENC_UNICODE_UTF8 Then
10:            SkipOffset = SkipOffset + Len(ReadFrame) + 1
11:        Else
12:            SkipOffset = SkipOffset + Len(ReadFrame) * 2 + 2
13:        End If
        'Read the actual text.
14:        ReadFrame = Data2String(pData + SkipOffset, FrameSize - SkipOffset, EncFormat)
15:    ElseIf FrameID = "WXXX" Or FrameID = "WXX" Then
        'Link frame.
16:        SkipOffset = 1
17:        ReadFrame = Data2String(pData + SkipOffset, FrameSize - SkipOffset, EncFormat)
18:        If EncFormat = ENC_ISO Or EncFormat = ENC_UNICODE_UTF8 Then
19:            SkipOffset = SkipOffset + Len(ReadFrame) + 1
20:        Else
21:            SkipOffset = SkipOffset + Len(ReadFrame) * 2 + 2
22:        End If
23:        ReadFrame = Data2String(pData + SkipOffset, FrameSize - SkipOffset, EncFormat)
24:    ElseIf FrameID = "SEEK" Then
25:        If FrameSize < 4 Then Exit Function
        'Got a seek frame (v 2.4 only). It points to the next tag in the file.
        'According to id3.org, it seems that this value isn't synchsafe... ??
26:        ReadFrame = Data2Long(pData, False)
27:    End If
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "pData:" & pData & vbNewLine & "FrameID:" & FrameID & vbNewLine & "FrameSize:" & FrameSize & vbNewLine
    strMSLDebugHandler_Variables = "SkipOffset = " & SkipOffset & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "ReadFrame", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Private Function IsValidFrameName(ByVal pData As Long) As Boolean
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim i As Long, curData As Byte

2:    For i = 0 To 3
3:        CopyMemory curData, ByVal pData + i, 1
        'Accept $00 $00 $00 $00 as a valid frame name, because this would be the start of the pattern.
4:        If Not curData = 0 And Not (curData >= Asc("A") And curData <= Asc("Z")) And Not (curData >= Asc("0") And curData <= Asc("9")) Then
5:            Exit Function
6:        End If
7:    Next i
8:    IsValidFrameName = True
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "pData:" & pData & vbNewLine
    strMSLDebugHandler_Variables = "i = " & i & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "IsValidFrameName", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

'Unsynch is simply done by replacing &HFF &H00 with &HFF.
'Returns the number of &H00 bytes kicked out.
Private Function DeUnsynch(ByVal pData As Long, ByVal Length As Long) As Long
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim i As Long, subIdx As Long
2:    Dim curData(1) As Byte

3:    Do
        'The following line performs pData(subIdx) = pData(i)
4:        CopyMemory ByVal pData + subIdx, ByVal pData + i, 1
5:        subIdx = subIdx + 1
6:        If i <= Length - 2 Then
7:            CopyMemory curData(0), ByVal pData + i, 2
8:            If curData(0) = &HFF& And curData(1) = &H0& Then
                'Jump over the &H0& byte.
9:                i = i + 2
10:                DeUnsynch = DeUnsynch + 1
11:                If i = Length Then Exit Do
12:            Else
13:                i = i + 1
14:            End If
15:        Else
16:            Exit Do
17:        End If
18:    Loop
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "pData:" & pData & vbNewLine & "Length:" & Length & vbNewLine
    strMSLDebugHandler_Variables = "i = " & i & vbNewLine & "subIdx = " & subIdx & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "DeUnsynch", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

'Converts a frame in memory from v 2.2 to v 2.3 in order to safe it in a new version.
Private Sub ConvertV23(ByVal memIdx As Long)
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim i As Long
2:    Dim sPicType As String, expSize As Long
    
3:    If memIdx < 0 Or memIdx > mMemFraCnt - 1 Then Exit Sub
4:    With mMemFrames(memIdx)
5:        If .ID = "PIC" Then
            'Convert the picture type desc from v 2.2 to 2.3 (and 2.4)
6:            sPicType = UCase$(Data2String(VarPtr(.Data(1)), 3, ENC_ISO))
7:            If sPicType = "PNG" Then
8:                sPicType = "image/png"
9:            ElseIf sPicType = "JPG" Then
10:                sPicType = "image/jpeg"
11:            ElseIf Not sPicType = "-->" Then
12:                sPicType = "image/" & LCase$(sPicType)
13:            End If
            'Expand the data.
14:            expSize = Len(sPicType) - 2
15:            If expSize <= 0 Then Exit Sub
16:            .Size = .Size + expSize
17:            ReDim Preserve .Data(.Size - 1)
            'Copy the data back, because we need more space at the beginning for the string.
18:            For i = .Size - 1 To 4 + expSize Step -1
19:                .Data(i) = .Data(i - expSize)
20:            Next i
            'Write the string into the data field.
21:            String2Data sPicType, 0, VarPtr(.Data(1)), True
22:        ElseIf .ID = "LNK" Then
            'Convert the link frame from v 2.2 to 2.3 (and 2.4)
23:            sPicType = Data2String(VarPtr(.Data(0)), 3, ENC_ISO)
24:            .Size = .Size + 1
25:            ReDim Preserve .Data(.Size - 1)
26:            For i = .Size - 1 To 4 Step -1
27:                .Data(i) = .Data(i - 1)
28:            Next i
29:            String2Data GetNewFrameID(sPicType), 4, VarPtr(.Data(0)), False
30:        ElseIf .ID = "TDOR" Then
            'Convert the TDOR timestamp from 2.4 to 2.3, simply by using only the first
            '4 bytes, identifying the year.
31:            .Size = 4
32:        End If
33:        .ID = GetNewFrameID(.ID)
34:    End With
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Sub
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "memIdx:" & memIdx & vbNewLine
    strMSLDebugHandler_Variables = "i = " & i & vbNewLine & "sPicType = " & sPicType & vbNewLine & "expSize = " & expSize & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "ConvertV23", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Sub

Private Function GetNewFrameID(ByVal sID As String) As String
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    If sID = "UFI" Then
2:        sID = "UFID"
3:    ElseIf sID = "TT1" Then
4:        sID = "TIT1"
5:    ElseIf sID = "TT2" Then
6:        sID = "TIT2"
7:    ElseIf sID = "TT3" Then
8:        sID = "TIT3"
9:    ElseIf sID = "TP1" Then
10:        sID = "TPE1"
11:    ElseIf sID = "TP2" Then
12:        sID = "TPE2"
13:    ElseIf sID = "TP3" Then
14:        sID = "TPE3"
15:    ElseIf sID = "TP4" Then
16:        sID = "TPE4"
17:    ElseIf sID = "TCM" Then
18:        sID = "TCOM"
19:    ElseIf sID = "TXT" Then
20:        sID = "TEXT"
21:    ElseIf sID = "TLA" Then
22:        sID = "TLAN"
23:    ElseIf sID = "TCO" Then
24:        sID = "TCON"
25:    ElseIf sID = "TAL" Then
26:        sID = "TALB"
27:    ElseIf sID = "TPA" Then
28:        sID = "TPOS"
29:    ElseIf sID = "TRK" Then
30:        sID = "TRCK"
31:    ElseIf sID = "TRC" Then
32:        sID = "TSRC"
33:    ElseIf sID = "TYE" Then
34:        sID = "TYER"
35:    ElseIf sID = "TDA" Then
36:        sID = "TDAT"
37:    ElseIf sID = "TIM" Then
38:        sID = "TIME"
39:    ElseIf sID = "TRD" Then
40:        sID = "TRDA"
41:    ElseIf sID = "TMT" Then
42:        sID = "TMED"
43:    ElseIf sID = "TFT" Then
44:        sID = "TFLT"
45:    ElseIf sID = "TBP" Then
46:        sID = "TBPM"
47:    ElseIf sID = "TCR" Then
48:        sID = "TCOP"
49:    ElseIf sID = "TPB" Then
50:        sID = "TPUB"
51:    ElseIf sID = "TEN" Then
52:        sID = "TENC"
53:    ElseIf sID = "TSS" Then
54:        sID = "TSSE"
55:    ElseIf sID = "TOF" Then
56:        sID = "TOFN"
57:    ElseIf sID = "TLE" Then
58:        sID = "TLEN"
59:    ElseIf sID = "TSI" Then
60:        sID = "TSIZ"
61:    ElseIf sID = "TDY" Then
62:        sID = "TDLY"
63:    ElseIf sID = "TKE" Then
64:        sID = "TKEY"
65:    ElseIf sID = "TOT" Then
66:        sID = "TOAL"
67:    ElseIf sID = "TOL" Then
68:        sID = "TOLY"
69:    ElseIf sID = "TOR" Or sID = "TDOR" Then
70:        sID = "TORY"
71:    ElseIf sID = "TXX" Then
72:        sID = "TXXX"
73:    ElseIf sID = "WAF" Then
74:        sID = "WOAF"
75:    ElseIf sID = "WAR" Then
76:        sID = "WOAR"
77:    ElseIf sID = "WAS" Then
78:        sID = "WOAS"
79:    ElseIf sID = "WCM" Then
80:        sID = "WCOM"
81:    ElseIf sID = "WCP" Then
82:        sID = "WCOP"
83:    ElseIf sID = "WPB" Then
84:        sID = "WPUB"
85:    ElseIf sID = "WXX" Then
86:        sID = "WXXX"
87:    ElseIf sID = "IPL" Or sID = "TIPL" Then
88:        sID = "IPLS"
89:    ElseIf sID = "MCI" Then
90:        sID = "MCDI"
91:    ElseIf sID = "ETC" Then
92:        sID = "ETCO"
93:    ElseIf sID = "MLL" Then
94:        sID = "MLLT"
95:    ElseIf sID = "STC" Then
96:        sID = "SYTC"
97:    ElseIf sID = "ULT" Then
98:        sID = "USLT"
99:    ElseIf sID = "SLT" Then
100:        sID = "SYLT"
101:    ElseIf sID = "COM" Then
102:        sID = "COMM"
103:    ElseIf sID = "RVA" Then
104:        sID = "RVAD"
105:    ElseIf sID = "EQU" Then
106:        sID = "EQUA"
107:    ElseIf sID = "REV" Then
108:        sID = "RVRB"
109:    ElseIf sID = "PIC" Then
110:        sID = "APIC"
111:    ElseIf sID = "GEO" Then
112:        sID = "GEOB"
113:    ElseIf sID = "CNT" Then
114:        sID = "PCNT"
115:    ElseIf sID = "POP" Then
116:        sID = "POPM"
117:    ElseIf sID = "BUF" Then
118:        sID = "RBUF"
119:    ElseIf sID = "CRA" Then
120:        sID = "AENC"
121:    ElseIf sID = "LNK" Then
122:        sID = "LINK"
123:    End If
124:    GetNewFrameID = sID
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "sID:" & sID & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "GetNewFrameID", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function


'The version parameter defines in which ID3v2 version the tag is written (2.3 or 2.4).
'You possibly will prefer v 2.3 because it has greater support by other programs and still
'provides all necessary functionality. For example, WinAmp only supports v 2.3.

'The pBuffer parameter can point to a static memory buffer which is used if the file has to
'be rewritten. The buffer should be at least as large as the file size. If no buffer is
'provided or if the buffer is too small, the memory is allocated dynamic, which is slower.
'Especially when tagging more files, it's recommended to allocate a byte array of some MB and
'pass VarPtr(Buffer(0)) for the pBuffer parameter and UBound(Buffer) + 1 for the buffer size.
'This is the fastest file rewriting method possible.

Public Function WriteID3v2(ByVal FileName As String, ByRef inTag As ID3Tag, ByVal Version As ID3v2_Version, ByVal bClearExistingTag As Boolean, Optional ByVal bIgnoreReadOnly As Boolean = True, Optional ByVal pBuffer As Long = 0, Optional ByVal BufferSize As Long = 0) As Boolean
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim i As Long, fh As Long, fp As Long, fsize As Long
2:    Dim TagHeader As v2TagHeader, ExistSize As Long, arrp As Long
3:    Dim WrData() As Byte, WrSize As Long, WrBuf() As Byte, BuildTag As ID3Tag
4:    Dim tmpHeader As v2_34FrameHeader, rdBuf(3) As Byte

5:    If bIgnoreReadOnly Then IgnoreReadOnly FileName
6:    fh = CreateFile(FileName, GENERIC_READ Or GENERIC_WRITE, FILE_SHARE_READ, ByVal 0, OPEN_EXISTING, 0, 0)
7:    If fh = INVALID_HANDLE_VALUE Then Exit Function

    'Never mind on possibly existing appended tags or footer tags. Just leave them in the file.
8:    ExistSize = GetTagSize(fh, 0)
    
    'Read the existing tag into memory if it shouldn't be cleared.
9:    mMemFraCnt = 0
10:    If Not ExistSize = 0 And Not bClearExistingTag Then
11:        Do
12:            SetFilePointer fh, fp, 0, FILE_BEGIN
13:            ReadFile fh, rdBuf(0), 3, 0, ByVal 0
14:            If Data2String(VarPtr(rdBuf(0)), 3, ENC_ISO) = "ID3" Then
                'We've got an ID3 v2 tag. Write it temporary in the BuildTag variable.
15:                fp = ReadV2Tag(fh, fp, BuildTag, True)
16:            Else
17:                fp = -1
18:            End If
19:        Loop While Not fp = -1
20:    End If
    
21:    BuildTag = inTag
22:    BuildTag.Genre = Genre2Frame(BuildTag.Genre)
    
    'Determine required size for the new tag.
23:    WrSize = Len(TagHeader)
24:    With BuildTag
25:        WrSize = WrSize + GetFrameSize("TPE1", .Artist, True)
26:        WrSize = WrSize + GetFrameSize("TALB", .Album, True)
27:        WrSize = WrSize + GetFrameSize("TIT2", .Title, True)
28:        WrSize = WrSize + GetFrameSize(IIf(Version = VERSION_2_3, "TYER", "TDRC"), .SongYear, True)
29:        WrSize = WrSize + GetFrameSize("TCON", .Genre, True)
30:        WrSize = WrSize + GetFrameSize("COMM", .Comment, True)
31:        WrSize = WrSize + GetFrameSize("TRCK", .TrackNr, True)
32:        WrSize = WrSize + GetFrameSize("TENC", .EncodedBy, True)
33:        WrSize = WrSize + GetFrameSize("WXXX", .LinkTo, True)
34:        WrSize = WrSize + GetFrameSize("TCOP", .Copyright, True)
35:        WrSize = WrSize + GetFrameSize("TCOM", .Composer, True)
36:        WrSize = WrSize + GetFrameSize("TOPE", .OrigArtist, True)
37:    End With
    'Add the size of the existing frames which should be preserved.
38:    For i = 0 To mMemFraCnt - 1
39:        If IsToStore(mMemFrames(i).ID) Then
40:            WrSize = WrSize + mMemFrames(i).Size + Len(tmpHeader)
41:        End If
42:    Next i
    
43:    If WrSize <= ExistSize Then
        'Overwrite the existing tag completely.
44:        WrSize = ExistSize
45:    Else
        'We have to rewrite the file anyway.
        'Add padding, and not too less. A few KB don't matter in a 3+ MB file, and the file won't
        'have to be rewritten soon.
46:        If WrSize Mod 2048 < 1024 Then
47:            WrSize = (WrSize \ 2048) * 2048 + 2048
48:        Else
49:            WrSize = (WrSize \ 2048) * 2048 + 4096
50:        End If
51:        WrSize = WrSize + Len(TagHeader)
52:    End If
53:    ReDim WrData(WrSize - 1)


    '***** Build up tag header *****
54:    String2Data "ID3", 3, VarPtr(TagHeader.Identifier(0)), False
55:    TagHeader.Version(0) = IIf(Version = VERSION_2_3, 3, 4)
56:    Long2Data WrSize - Len(TagHeader), True, VarPtr(TagHeader.Size(0))
57:    CopyMemory WrData(0), TagHeader, Len(TagHeader)
58:    arrp = Len(TagHeader)

    '***** No extended header is used, since it even seems that many programs don't support them *****

    '***** Start writing the frame data into the array *****
59:    With BuildTag
        'Note: we don't use VarPtr(WrData(arrp)) here because if arrp == <array size>, the function
        'call would fail, although there is no more data written to the array.
60:        arrp = arrp + WriteFrame(VarPtr(WrData(0)) + arrp, "TPE1", .Artist, Version)
61:        arrp = arrp + WriteFrame(VarPtr(WrData(0)) + arrp, "TALB", .Album, Version)
62:        arrp = arrp + WriteFrame(VarPtr(WrData(0)) + arrp, "TIT2", .Title, Version)
63:        arrp = arrp + WriteFrame(VarPtr(WrData(0)) + arrp, IIf(Version = VERSION_2_3, "TYER", "TDRC"), .SongYear, Version)
64:        arrp = arrp + WriteFrame(VarPtr(WrData(0)) + arrp, "TCON", .Genre, Version)
65:        arrp = arrp + WriteFrame(VarPtr(WrData(0)) + arrp, "COMM", .Comment, Version)
66:        arrp = arrp + WriteFrame(VarPtr(WrData(0)) + arrp, "TRCK", .TrackNr, Version)
67:        arrp = arrp + WriteFrame(VarPtr(WrData(0)) + arrp, "TENC", .EncodedBy, Version)
68:        arrp = arrp + WriteFrame(VarPtr(WrData(0)) + arrp, "WXXX", .LinkTo, Version)
69:        arrp = arrp + WriteFrame(VarPtr(WrData(0)) + arrp, "TCOP", .Copyright, Version)
70:        arrp = arrp + WriteFrame(VarPtr(WrData(0)) + arrp, "TCOM", .Composer, Version)
71:        arrp = arrp + WriteFrame(VarPtr(WrData(0)) + arrp, "TOPE", .OrigArtist, Version)
72:    End With
73:    For i = 0 To mMemFraCnt - 1
74:        If IsToStore(mMemFrames(i).ID) Then
75:            arrp = arrp + WriteMemFrame(VarPtr(WrData(0)) + arrp, i, Version)
76:        End If
77:    Next i

    '***** Padding is added "automatically" because the WrData() array is zeroed from VB *****


    'Write the data out to the file.
78:    If WrSize <= ExistSize Then
        'Here we go, just overwrite the existing tag.
79:        SetFilePointer fh, 0, 0, FILE_BEGIN
80:        WriteFile fh, WrData(0), WrSize, 0, ByVal 0
81:    Else
        'We need to rewrite the entire file...
82:        fsize = GetFileSize(fh, 0)
83:        If pBuffer = 0 Or BufferSize < fsize - ExistSize Then
            'Allocate a dynamic buffer.
84:            ReDim WrBuf(fsize - ExistSize - 1)
85:            pBuffer = VarPtr(WrBuf(0))
86:        End If

        'Use the buffer to store the audio data of the file.
87:        SetFilePointer fh, ExistSize, 0, FILE_BEGIN
88:        ReadFile fh, ByVal pBuffer, fsize - ExistSize, 0, ByVal 0
        'Compute the new file size and expand the existing file.
89:        fsize = WrSize + fsize - ExistSize
90:        SetFilePointer fh, fsize, 0, FILE_BEGIN
91:        SetEndOfFile fh
        'Write the new tag to the file.
92:        SetFilePointer fh, 0, 0, FILE_BEGIN
93:        WriteFile fh, WrData(0), WrSize, 0, ByVal 0
        'Append the audio data again.
94:        WriteFile fh, ByVal pBuffer, fsize - WrSize, 0, ByVal 0
95:    End If

96:    CloseHandle fh
97:    WriteID3v2 = True
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "FileName:" & FileName & vbNewLine & "bClearExistingTag:" & bClearExistingTag & vbNewLine & "bIgnoreReadOnly:" & bIgnoreReadOnly & vbNewLine _
                                  & "pBuffer:" & pBuffer & vbNewLine & "BufferSize:" & BufferSize & vbNewLine
    strMSLDebugHandler_Variables = "i = " & i & vbNewLine & "fh = " & fh & vbNewLine & "fp = " & fp & vbNewLine _
                                 & "fsize = " & fsize & vbNewLine & "ExistSize = " & ExistSize & vbNewLine & "arrp = " & arrp & vbNewLine _
                                 & "WrSize = " & WrSize & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "WriteID3v2", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

'Determines if a frame in memory has to be stored in the new written file.
Private Function IsToStore(ByVal fraID As String) As Boolean
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    IsToStore = True
2:    If fraID = "TPE1" Or fraID = "TALB" Or fraID = "TIT2" Then
3:        IsToStore = False
4:    ElseIf fraID = "TYER" Or fraID = "TDRC" Or fraID = "TCON" Or fraID = "COMM" Then
5:        IsToStore = False
6:    ElseIf fraID = "TRCK" Or fraID = "TENC" Or fraID = "WXXX" Or fraID = "TCOP" Then
7:        IsToStore = False
8:    ElseIf fraID = "TCOM" Or fraID = "TOPE" Then
9:        IsToStore = False
10:    End If
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "fraID:" & fraID & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "IsToStore", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Private Function WriteFrame(ByVal pData As Long, ByVal FrameID As String, ByVal strData As String, ByVal Version As ID3v2_Version) As Long
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim i As Long, fraHeader As v2_34FrameHeader
2:    Dim EncFormat As Byte, WrOffset As Long

3:    If Trim$(strData) = "" Then Exit Function

    'Create the frame header.
4:    String2Data FrameID, 4, VarPtr(fraHeader.Ident(0)), False
5:    WriteFrame = GetFrameSize(FrameID, strData, False)
6:    Long2Data WriteFrame, IIf(Version = VERSION_2_3, False, True), VarPtr(fraHeader.Size(0))
7:    CopyMemory ByVal pData, fraHeader, Len(fraHeader)
8:    WrOffset = Len(fraHeader)

    'Add the size of the header to the return value.
9:    WriteFrame = WriteFrame + Len(fraHeader)

    'Create the frame data.
10:    If Left$(FrameID, 1) = "T" Then
        'Text frame.
        'EncFormat = 0 = ISO encoding
11:        CopyMemory ByVal pData + WrOffset, EncFormat, 1
12:        WrOffset = WrOffset + 1
13:        String2Data strData, 0, pData + WrOffset, True
14:    ElseIf FrameID = "COMM" Then
        'Comment frame.
15:        CopyMemory ByVal pData + WrOffset, EncFormat, 1
16:        WrOffset = WrOffset + 1
        'English language.
17:        String2Data "eng", 0, pData + WrOffset, False
18:        WrOffset = WrOffset + 3
        'Create an empty content description.
19:        CopyMemory ByVal pData + WrOffset, EncFormat, 1
20:        WrOffset = WrOffset + 1
21:        String2Data strData, 0, pData + WrOffset, True
22:    ElseIf FrameID = "WXXX" Then
        'Link frame.
23:        For i = 0 To 1
            'i=0: encoding format, i=1: empty description string
24:            CopyMemory ByVal pData + WrOffset, EncFormat, 1
25:            WrOffset = WrOffset + 1
26:        Next i
27:        String2Data strData, 0, pData + WrOffset, True
28:    Else
29:        Exit Function
30:    End If
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "pData:" & pData & vbNewLine & "FrameID:" & FrameID & vbNewLine & "strData:" & strData & vbNewLine
    strMSLDebugHandler_Variables = "i = " & i & vbNewLine & "WrOffset = " & WrOffset & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "WriteFrame", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Private Function WriteMemFrame(ByVal pData As Long, ByVal fraIdx As Long, ByVal Version As ID3v2_Version) As Long
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim i As Long, fraHeader As v2_34FrameHeader
2:    Dim EncFormat As Byte, WrOffset As Long

3:    If fraIdx < 0 Or fraIdx > mMemFraCnt - 1 Then Exit Function
4:    With mMemFrames(fraIdx)
5:        If Version = VERSION_2_4 Then
6:            If .ID = "TORY" Then
7:                .ID = "TDOR"
8:            ElseIf .ID = "IPLS" Then
9:                .ID = "TIPL"
10:            End If
11:        End If
        'Create the frame header.
12:        String2Data .ID, 4, VarPtr(fraHeader.Ident(0)), False
13:        WriteMemFrame = .Size
14:        Long2Data WriteMemFrame, IIf(Version = VERSION_2_3, False, True), VarPtr(fraHeader.Size(0))
15:        CopyMemory ByVal pData, fraHeader, Len(fraHeader)
16:        WrOffset = Len(fraHeader)
    
        'Add the size of the header to the return value.
17:        WriteMemFrame = WriteMemFrame + Len(fraHeader)
    
        'Create the frame data.
18:        CopyMemory ByVal pData + WrOffset, .Data(0), .Size
19:    End With
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "pData:" & pData & vbNewLine & "fraIdx:" & fraIdx & vbNewLine
    strMSLDebugHandler_Variables = "i = " & i & vbNewLine & "WrOffset = " & WrOffset & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "WriteMemFrame", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Private Function GetFrameSize(ByVal FrameID As String, ByVal strData As String, ByVal bIncludeHeader As Boolean) As Long
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim fraHeader As v2_34FrameHeader

2:    If Trim$(strData) = "" Then Exit Function

3:    If bIncludeHeader Then GetFrameSize = Len(fraHeader)
4:    If Left$(FrameID, 1) = "T" Then
        'Text frame: 1 b encoding, x b string, 1 b null
5:        GetFrameSize = GetFrameSize + Len(strData) + 2
6:    ElseIf FrameID = "COMM" Then
        'Comment frame: 1 b encoding, 3 b language, 1 b empty description, x b string, 1 b null
7:        GetFrameSize = GetFrameSize + Len(strData) + 6
8:    ElseIf FrameID = "WXXX" Then
        'Link frame: 1 b encoding, 1 b empty description, x b string, 1 b null
9:        GetFrameSize = GetFrameSize + Len(strData) + 3
10:    Else
11:        GetFrameSize = 0
12:    End If
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "FrameID:" & FrameID & vbNewLine & "strData:" & strData & vbNewLine & "bIncludeHeader:" & bIncludeHeader & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "GetFrameSize", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function


'See the WriteID3v2 function for a description on the Buffer parameters.
Public Function DeleteID3v2(ByVal FileName As String, Optional ByVal bIgnoreReadOnly As Boolean = True, Optional ByVal pBuffer As Long = 0, Optional ByVal BufferSize As Long = 0) As Boolean
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim fh As Long, fsize As Long
2:    Dim TagHeader As v2TagHeader, ExistSize As Long, WrBuf() As Byte

3:    If bIgnoreReadOnly Then IgnoreReadOnly FileName
4:    fh = CreateFile(FileName, GENERIC_READ Or GENERIC_WRITE, FILE_SHARE_READ, ByVal 0, OPEN_EXISTING, 0, 0)
5:    If fh = INVALID_HANDLE_VALUE Then Exit Function

    'Never mind on possibly existing appended tags or footer tags. Just leave them in the file.
6:    ExistSize = GetTagSize(fh, 0)
7:    If Not ExistSize = 0 Then
8:        fsize = GetFileSize(fh, 0)
9:        If pBuffer = 0 Or BufferSize < fsize - ExistSize Then
            'Allocate a dynamic buffer.
10:            ReDim WrBuf(fsize - ExistSize - 1)
11:            pBuffer = VarPtr(WrBuf(0))
12:        End If

        'Use the buffer to store the audio data of the file.
13:        SetFilePointer fh, ExistSize, 0, FILE_BEGIN
14:        ReadFile fh, ByVal pBuffer, fsize - ExistSize, 0, ByVal 0
        'Compute the new file size and crop the existing file.
15:        fsize = fsize - ExistSize
16:        SetFilePointer fh, fsize, 0, FILE_BEGIN
17:        SetEndOfFile fh
        'Write the audio data to the file again.
18:        SetFilePointer fh, 0, 0, FILE_BEGIN
19:        WriteFile fh, ByVal pBuffer, fsize, 0, ByVal 0
20:    End If

21:    CloseHandle fh
22:    DeleteID3v2 = True
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "FileName:" & FileName & vbNewLine & "bIgnoreReadOnly:" & bIgnoreReadOnly & vbNewLine & "pBuffer:" & pBuffer & vbNewLine _
                                  & "BufferSize:" & BufferSize & vbNewLine
    strMSLDebugHandler_Variables = "fh = " & fh & vbNewLine & "fsize = " & fsize & vbNewLine & "ExistSize = " & ExistSize & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "DeleteID3v2", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function





'**********************************Data converting functions****************************************


'Synchsafe integers are integers that keep its highest bit (bit 7) zeroed, making seven bits
'out of eight available. Thus a 32 bit synchsafe integer can store 28 bits of information.
Private Function Data2Long(ByVal pData As Long, ByVal bSynchSafe As Boolean) As Long
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim i As Integer, Data(3) As Byte

2:    CopyMemory Data(0), ByVal pData, 4

    'Avoid converting wrong synchsafe integers. If bit 7 of any byte is set, it is not synchsafe.
    'However, we can't detect wrong coded values which have bit 7 zeroed.
3:    For i = 0 To 3
4:        If Data(i) And &H80& Then bSynchSafe = False
5:    Next i

    'Perform left-shifts, done by multiplication with the hex values of 2^n. Finally, bit-or the values.
6:    If bSynchSafe Then
7:        Data2Long = (Data(0) * &H200000) Or (Data(1) * &H4000&) Or (Data(2) * &H80&) Or Data(3)
8:    Else
9:        Data2Long = (Data(0) * &H1000000) Or (Data(1) * &H10000) Or (Data(2) * &H100&) Or Data(3)
10:    End If
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "pData:" & pData & vbNewLine & "bSynchSafe:" & bSynchSafe & vbNewLine
    strMSLDebugHandler_Variables = "i = " & i & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "Data2Long", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Private Function Long2Data(ByVal SrcValue As Long, ByVal bSynchSafe As Boolean, ByVal pData As Long)
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim Data(3) As Byte

    'Mask out the corresponding bits and right-shift them afterwards (done by division).
2:    If bSynchSafe Then
3:        Data(0) = (SrcValue And &HFE00000) \ &H200000
4:        Data(1) = (SrcValue And &H1FC000) \ &H4000&
5:        Data(2) = (SrcValue And &H3F80&) \ &H80&
6:        Data(3) = SrcValue And &H7F&
7:    Else
8:        Data(0) = SrcValue \ &H1000000
9:        Data(1) = (SrcValue And &HFF0000) \ &H10000
10:        Data(2) = (SrcValue And &HFF00&) \ &H100&
11:        Data(3) = SrcValue And &HFF&
12:    End If

    'Copy back.
13:    CopyMemory ByVal pData, Data(0), 4
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "SrcValue:" & SrcValue & vbNewLine & "bSynchSafe:" & bSynchSafe & vbNewLine & "pData:" & pData & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "Long2Data", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Private Function Data2String(ByVal pData As Long, ByVal Length As Long, ByVal EncFormat As v2_StrEncoding, Optional ByVal BreakOnNull As Boolean = True) As String
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim i As Long, curData As Byte, curSign As String

2:    For i = 0 To Length - 1
3:        CopyMemory curData, ByVal pData + i, 1
        'New lines are represented by &0A& (which is chr(10)) only in ID3 v2 tags.
        'However, many programs seem to code the newline with chr(13) & chr(10),
        'which is the windows default. Therefore, skip chr(13) and change chr(10) to vbNewLines.
4:        If curData = 13 Then
5:            curSign = ""
6:        ElseIf curData = 10 Then
7:            curSign = vbNewLine
8:        Else
9:            curSign = Chr(curData)
10:        End If
11:        If EncFormat = ENC_ISO Or EncFormat = ENC_UNICODE_UTF8 Then
            'Clear text, null terminated.
12:            If curData = 0 And BreakOnNull Then
13:                Exit Function
14:            Else
15:                Data2String = Data2String & curSign
16:            End If
17:        ElseIf EncFormat = ENC_UNICODE_UTF16_BOM Then
            'UNICODE text with BOM, double-null terminated.
18:            If i >= 2 And i Mod 2 = 0 Then
19:                If curData = 0 And BreakOnNull Then
20:                    Exit Function
21:                Else
22:                    Data2String = Data2String & curSign
23:                End If
24:            End If
25:        ElseIf EncFormat = ENC_UNICODE_UTF16 Then
            'UNICODE text without BOM, double-null terminated.
26:            If i Mod 2 = 0 Then
27:                If curData = 0 And BreakOnNull Then
28:                    Exit Function
29:                Else
30:                    Data2String = Data2String & curSign
31:                End If
32:            End If
33:        End If
34:    Next i
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "pData:" & pData & vbNewLine & "Length:" & Length & vbNewLine & "BreakOnNull:" & BreakOnNull & vbNewLine
    strMSLDebugHandler_Variables = "i = " & i & vbNewLine & "curSign = " & curSign & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "Data2String", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Private Function String2Data(ByVal SrcStr As String, ByVal MaxLength As Long, ByVal pData As Long, ByVal bTerminate As Boolean) As Long
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim i As Long, SrcLen As Long
2:    Dim curAsc As Byte

3:    SrcLen = Len(SrcStr)
4:    If MaxLength <= 0 Then
5:        MaxLength = SrcLen
6:    ElseIf MaxLength > SrcLen Then
7:        MaxLength = SrcLen
8:    End If

9:    For i = 0 To MaxLength - 1
10:        curAsc = Asc(Mid$(SrcStr, i + 1, 1))
11:        CopyMemory ByVal pData + i, curAsc, 1
12:    Next i
13:    If bTerminate Then
        'Add the null terminator.
14:        curAsc = 0
15:        CopyMemory ByVal pData + MaxLength, curAsc, 1
16:        String2Data = MaxLength + 1
17:    Else
18:        String2Data = MaxLength
19:    End If
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "SrcStr:" & SrcStr & vbNewLine & "MaxLength:" & MaxLength & vbNewLine & "pData:" & pData & vbNewLine _
                                  & "bTerminate:" & bTerminate & vbNewLine
    strMSLDebugHandler_Variables = "i = " & i & vbNewLine & "SrcLen = " & SrcLen & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "String2Data", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Private Function Frame2Genre(ByVal strData As String) As String
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim idxFrom As Long, idxTo As Long
2:    Dim strRef As String

3:    Frame2Genre = strData
4:    idxFrom = InStr(1, strData, "(")
5:    idxTo = InStr(1, strData, ")")
6:    If idxFrom = 0 Or idxTo = 0 Then Exit Function

7:    strRef = Mid$(Frame2Genre, idxFrom + 1, idxTo - idxFrom - 1)
8:    If IsNumeric(strRef) Then
9:        Frame2Genre = GetGenreName(CLng(strRef))
10:    ElseIf strRef = "RX" Then
11:        Frame2Genre = "Remix"
12:    ElseIf strRef = "CR" Then
13:        Frame2Genre = "Cover"
14:    End If
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "strData:" & strData & vbNewLine
    strMSLDebugHandler_Variables = "idxFrom = " & idxFrom & vbNewLine & "idxTo = " & idxTo & vbNewLine & "strRef = " & strRef & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "Frame2Genre", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Private Function Genre2Frame(ByVal strGenre As String) As String
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim GenreIdx As Long

2:    GenreIdx = GetGenreIndex(strGenre)
3:    If GenreIdx = 255 Then
4:        Genre2Frame = strGenre
5:    Else
6:        Genre2Frame = "(" & GenreIdx & ")" & GetGenreName(GenreIdx)
7:    End If
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "strGenre:" & strGenre & vbNewLine
    strMSLDebugHandler_Variables = "GenreIdx = " & GenreIdx & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "Genre2Frame", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function GetGenreName(ByVal GenreIndex As Long) As String
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    If GenreIndex < 0 Or GenreIndex > 147 Then Exit Function
    
2:    If Not bBuiltGenre Then
3:        bBuiltGenre = True
4:        GenreField = Split(cGenreString, "#")
5:    End If
6:    GetGenreName = GenreField(GenreIndex)
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "GenreIndex:" & GenreIndex & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "GetGenreName", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function GetGenreIndex(ByVal GenreName As String) As Long
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim i As Long

2:    If Not bBuiltGenre Then
3:        bBuiltGenre = True
4:        GenreField = Split(cGenreString, "#")
5:    End If
6:    GenreName = LCase$(Trim$(GenreName))
7:    For i = 0 To 147
8:        If LCase$(GenreField(i)) = GenreName Then
9:            GetGenreIndex = i
10:            Exit Function
11:        End If
12:    Next i
13:    GetGenreIndex = 255
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "GenreName:" & GenreName & vbNewLine
    strMSLDebugHandler_Variables = "i = " & i & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "GetGenreIndex", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function




'**********************************File information****************************************

Public Function ReadMPEGInfo(ByVal FileName As String, ByRef outInfo As MPEGInfo) As Boolean
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1:    Dim fh As Long, fp As Long, fsize As Long
2:    Dim fraHeader(3) As Byte, mVers As Long, lVers As Long
3:    Dim opByte As Byte, opLong As Long, VBRHeaderPos(1) As Long
4:    Dim VBRHeader(17) As Byte, VBRIdent As String
5:    Dim SamplesPerFrame As Long, VBRNrFrames As Long, VBRBytes As Long
6:    Dim RdTag As v1Tag, TagHeader As v2TagHeader

7:    fh = CreateFile(FileName, GENERIC_READ, FILE_SHARE_READ, ByVal 0, OPEN_EXISTING, 0, 0)
8:    If fh = INVALID_HANDLE_VALUE Then Exit Function
    
9:    fp = GetTagSize(fh, 0)
10:    fsize = GetFileSize(fh, 0)
11:    If fsize < 4 Then
12:        CloseHandle fh
13:        Exit Function
14:    End If
    
    'Search for the MP3 frame header.
15:    Do
16:        SetFilePointer fh, fp, 0, FILE_BEGIN
17:        ReadFile fh, fraHeader(0), 4, 0, ByVal 0
18:        If fraHeader(0) = &HFF& And (fraHeader(1) And &HE0&) = &HE0& Then
            'Got the frame synchronisation (11 bits set).
            'Read the information from the set bits.
            
            'MPEG version
19:            opByte = (fraHeader(1) And &H18&) \ &H8&
20:            If opByte = 0 Then
21:                outInfo.MPEGVersion = "version 2.5"
22:                mVers = 3
23:            ElseIf opByte = 2 Then
24:                outInfo.MPEGVersion = "version 2"
25:                mVers = 2
26:            ElseIf opByte = 3 Then
27:                outInfo.MPEGVersion = "version 1"
28:                mVers = 1
29:            Else
30:                Exit Do
31:            End If
            
            'Layer version
32:            opByte = (fraHeader(1) And &H6&) \ &H2&
33:            If opByte = 1 Then
34:                lVers = 3
35:                SamplesPerFrame = IIf(mVers = 1, 1152, 576)
36:            ElseIf opByte = 2 Then
37:                lVers = 2
38:                SamplesPerFrame = 1152
39:            ElseIf opByte = 3 Then
40:                lVers = 1
41:                SamplesPerFrame = 384
42:            Else
43:                Exit Do
44:            End If
45:            outInfo.MPEGVersion = outInfo.MPEGVersion & " layer " & lVers
            
            'CRC
46:            outInfo.HasCRC = IIf(fraHeader(1) And &H1&, False, True)
            
            'Channel mode.
47:            opByte = (fraHeader(3) And &HC0&) \ &H40&
            
            'The position of an possibly existing VBR header depends on the channel mode.
48:            If Not opByte = 3 Then
49:                VBRHeaderPos(0) = fp + 4 + IIf(mVers = 1, 32, 17)
50:            Else
51:                VBRHeaderPos(0) = fp + 4 + IIf(mVers = 1, 17, 9)
52:            End If
53:            VBRHeaderPos(1) = fp + 4 + 32
            
            'Channel mode.
54:            If opByte = 0 Then
55:                outInfo.ChannelMode = "Stereo"
56:            ElseIf opByte = 1 Then
57:                outInfo.ChannelMode = "Joint stereo"
58:            ElseIf opByte = 2 Then
59:                outInfo.ChannelMode = "Dual channel"
60:            ElseIf opByte = 3 Then
61:                outInfo.ChannelMode = "Mono"
62:            End If
            
            'Frequency
63:            opByte = (fraHeader(2) And &HC&) \ &H4&
64:            If opByte = 0 Then
65:                opLong = 44100
66:            ElseIf opByte = 1 Then
67:                opLong = 48000
68:            ElseIf opByte = 2 Then
69:                opLong = 32000
70:            End If
71:            outInfo.Frequency = opLong / IIf(mVers = 3, 4, mVers)
            
            'Check if there is a VBR header. If present, use it to read out the number of frames.
72:            SetFilePointer fh, VBRHeaderPos(0), 0, FILE_BEGIN
73:            ReadFile fh, VBRHeader(0), 16, 0, ByVal 0
74:            VBRIdent = Data2String(VarPtr(VBRHeader(0)), 4, ENC_ISO)
75:            If VBRIdent = "Xing" Or VBRIdent = "Info" Then
                'A VBR header is present.
76:                If VBRHeader(7) And &H1& Then
                    'The number of frames is stored.
77:                    VBRNrFrames = Data2Long(VarPtr(VBRHeader(8)), False)
78:                    If VBRHeader(7) And &H2& Then
79:                        VBRBytes = Data2Long(VarPtr(VBRHeader(12)), False)
80:                    End If
81:                End If
82:            End If
            'Check if there is a VBRI header.
83:            SetFilePointer fh, VBRHeaderPos(1), 0, FILE_BEGIN
84:            ReadFile fh, VBRHeader(0), 18, 0, ByVal 0
85:            If Data2String(VarPtr(VBRHeader(0)), 4, ENC_ISO) = "VBRI" Then
86:                VBRBytes = Data2Long(VarPtr(VBRHeader(10)), False)
87:                VBRNrFrames = Data2Long(VarPtr(VBRHeader(14)), False)
88:            End If
            
89:            If Not VBRBytes = 0 And Not VBRNrFrames = 0 Then
                'VBR bitrate.
90:                outInfo.HasVBR = True
91:                outInfo.Bitrate = VBRBytes / VBRNrFrames / SamplesPerFrame / 125 * outInfo.Frequency
92:                outInfo.Length = VBRNrFrames / outInfo.Frequency * SamplesPerFrame
93:            Else
                'CBR bitrate
94:                outInfo.HasVBR = False
95:                opByte = (fraHeader(2) And &HF0&) \ &H10&
96:                If Not opByte = 0 And Not opByte = 15 Then
97:                    If mVers = 1 And lVers = 1 Then
98:                        outInfo.Bitrate = opByte * 32
99:                    ElseIf mVers = 1 And lVers = 2 Then
100:                        If opByte = 1 Then
101:                            outInfo.Bitrate = 32
102:                        ElseIf opByte = 2 Then
103:                            outInfo.Bitrate = 48
104:                        ElseIf opByte <= 4 Then
105:                            outInfo.Bitrate = 48 + (opByte - 2) * 8
106:                        ElseIf opByte <= 8 Then
107:                            outInfo.Bitrate = 64 + (opByte - 4) * 16
108:                        ElseIf opByte <= 12 Then
109:                            outInfo.Bitrate = 128 + (opByte - 8) * 32
110:                        Else
111:                            outInfo.Bitrate = 256 + (opByte - 12) * 64
112:                        End If
113:                    ElseIf mVers = 1 And lVers = 3 Then
114:                        If opByte = 1 Then
115:                            outInfo.Bitrate = 32
116:                        ElseIf opByte <= 5 Then
117:                            outInfo.Bitrate = 32 + (opByte - 1) * 8
118:                        ElseIf opByte <= 9 Then
119:                            outInfo.Bitrate = 64 + (opByte - 5) * 16
120:                        ElseIf opByte <= 13 Then
121:                            outInfo.Bitrate = 128 + (opByte - 9) * 32
122:                        Else
123:                            outInfo.Bitrate = 320
124:                        End If
125:                    ElseIf mVers >= 2 And lVers = 1 Then
126:                        If opByte = 1 Then
127:                            outInfo.Bitrate = 32
128:                        ElseIf opByte = 2 Then
129:                            outInfo.Bitrate = 48
130:                        ElseIf opByte <= 4 Then
131:                            outInfo.Bitrate = 48 + (opByte - 2) * 8
132:                        ElseIf opByte <= 12 Then
133:                            outInfo.Bitrate = 64 + (opByte - 4) * 16
134:                        Else
135:                            outInfo.Bitrate = 192 + (opByte - 12) * 32
136:                        End If
137:                    Else
                        'mVers >= 2, lVers >= 2
138:                        If opByte <= 8 Then
139:                            outInfo.Bitrate = opByte * 8
140:                        Else
141:                            outInfo.Bitrate = 64 + (opByte - 8) * 16
142:                        End If
143:                    End If
144:                End If
145:                outInfo.Length = (fsize - fp) / (outInfo.Bitrate * 125)
146:            End If
                        
            'Copyright
147:            outInfo.IsCopyrighted = IIf(fraHeader(3) And &H8&, True, False)
            
            'Original
148:            outInfo.IsOriginal = IIf(fraHeader(3) And &H4&, True, False)
            
            'Emphasis
149:            outInfo.HasEmphasis = IIf(fraHeader(3) And &H3&, True, False)
            
150:            ReadMPEGInfo = True
151:            Exit Do
152:        Else
153:            fp = fp + 1
154:            If fp > fsize - 4 Then Exit Do
155:        End If
156:    Loop
    
    'Read out the tag versions.
    'ID3 v1 tag.
157:    outInfo.ID3v1Version = -1
158:    If fsize >= 128 Then
        'The ID3v1 tag is located 128 bytes from the end of the file, so look at this position.
159:        SetFilePointer fh, fsize - 128, 0, FILE_BEGIN
160:        ReadFile fh, RdTag, Len(RdTag), 0, ByVal 0
161:        If Data2String(VarPtr(RdTag.Identifier(0)), 3, ENC_ISO) = "TAG" Then
162:            If RdTag.Comment(28) = 0 And Not RdTag.Comment(29) = 0 Then
                'ID3v1.1 tag: byte 28 of the comment tag is zeroed, byte 29 is the track number.
163:                outInfo.ID3v1Version = 1
164:            Else
                'ID3v1.0 tag: contains no track number.
165:                outInfo.ID3v1Version = 0
166:            End If
167:        End If
168:    End If
    
    'ID3 v2 tag.
169:    outInfo.ID3v2Version = -1
170:    SetFilePointer fh, 0, 0, FILE_BEGIN
171:    ReadFile fh, TagHeader, Len(TagHeader), 0, ByVal 0
172:    If Data2String(VarPtr(TagHeader.Identifier(0)), 3, ENC_ISO) = "ID3" Then
173:        outInfo.ID3v2Version = TagHeader.Version(0)
174:    End If
    
    'File size.
175:    outInfo.FileSize = fsize
    
176:    CloseHandle fh
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "FileName:" & FileName & vbNewLine
    strMSLDebugHandler_Variables = "fh = " & fh & vbNewLine & "fp = " & fp & vbNewLine & "fsize = " & fsize & vbNewLine _
                                 & "mVers = " & mVers & vbNewLine & "lVers = " & lVers & vbNewLine & "opLong = " & opLong & vbNewLine _
                                 & "VBRIdent = " & VBRIdent & vbNewLine & "SamplesPerFrame = " & SamplesPerFrame & vbNewLine & "VBRNrFrames = " & VBRNrFrames & vbNewLine _
                                 & "VBRBytes = " & VBRBytes & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "ReadMPEGInfo", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function





'**********************************Other "shared use" functions****************************************

Private Function GetTagSize(ByVal fh As Long, ByVal fp As Long) As Long
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim TagHeader As v2TagHeader
    
    'Search for an ID3v2 tag.
2:    SetFilePointer fh, fp, 0, FILE_BEGIN
3:    ReadFile fh, TagHeader, Len(TagHeader), 0, ByVal 0
4:    If Data2String(VarPtr(TagHeader.Identifier(0)), 3, ENC_ISO) = "ID3" Then
        'The size stored in the header excludes itself, and excludes the footer (if present).
5:        GetTagSize = Data2Long(VarPtr(TagHeader.Size(0)), True) + Len(TagHeader)

        'v 2.4 (or later?) flags: %abcd0000 abc = ignored, d = footer present
6:        If TagHeader.Version(0) >= 4 Then
7:            If TagHeader.Flags And &H10& Then
                'Add the size of the footer (which is the same size than the header) to the existing size.
8:                GetTagSize = GetTagSize + Len(TagHeader)
9:            End If
10:        End If
11:    End If
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "fh:" & fh & vbNewLine & "fp:" & fp & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "GetTagSize", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Private Sub IgnoreReadOnly(ByVal FileName As String)
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    Dim rdAttr As Long

2:    rdAttr = GetFileAttributes(FileName)
3:    If rdAttr = -1 Then Exit Sub
4:    If rdAttr And FILE_ATTRIBUTE_READONLY Then
        'Set this bit to 0. Use xor for that.
5:        rdAttr = rdAttr Xor FILE_ATTRIBUTE_READONLY
6:        SetFileAttributes FileName, rdAttr
7:    End If
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Sub
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "FileName:" & FileName & vbNewLine
    strMSLDebugHandler_Variables = "rdAttr = " & rdAttr & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "IgnoreReadOnly", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Sub

Public Sub ResetTag(ByRef Tag As ID3Tag)
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
1:    With Tag
2:        .Album = ""
3:        .Artist = ""
4:        .Comment = ""
5:        .Composer = ""
6:        .Copyright = ""
7:        .EncodedBy = ""
8:        .Genre = ""
9:        .LinkTo = ""
10:        .OrigArtist = ""
11:        .SongYear = ""
12:        .Title = ""
13:        .TrackNr = ""
14:    End With
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Sub
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")
    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "ResetTag", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Sub

Public Function UpdateTagFromFileName(Optional strFile As String = "")
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim objFile As File, objFiles As Files, lngTotal As Long, lngCount As Long

2:    If Trim$(strFile) = "" Then
        
3:        Set objFiles = mobjFSO.GetFolder(mstrPath).Files
    
4:        lngTotal = GetFileCountMP3s(objFiles)
5:    Else
    
6:        Set objFile = mobjFSO.GetFile(strFile)
                
7:        If objFile.Type = "Winamp media file" Then

8:            ProcessTag objFile
9:            Exit Function
10:        End If
            
11:    End If
        
12:    For Each objFile In objFiles
        
13:        If objFile.Type = "Winamp media file" Then

14:            ProcessTag objFile
                        
15:            lngCount = lngCount + 1
        
16:            If lngCount >= lngTotal Then Exit For
17:        End If
18:    Next

'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "strFile:" & strFile & vbNewLine
    strMSLDebugHandler_Variables = "lngTotal = " & lngTotal & vbNewLine & "lngCount = " & lngCount & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "UpdateTagFromFileName", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function ProcessTag(ByRef objFile As File)
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>
        
1: Dim strArtist As String, strTitle As String, myTag As ID3Tag, blnGotTag As Boolean

2:    If objFile.Type = "Winamp media file" Then
    
3:        ResetTag myTag
        
4:        Select Case mstrID3TagSupport
        
            Case "1":
            
5:                ReadID3v1 objFile.Path, myTag
            
            Case "2":
            
6:                ReadID3v2 objFile.Path, myTag
        
            Case "3":
            
7:                blnGotTag = ReadID3v2(objFile.Path, myTag)
8:                If Not blnGotTag Then blnGotTag = ReadID3v1(objFile.Path, myTag)
            
9:        End Select
        
10:        strArtist = GetArtist(objFile.Name)
11:        strTitle = GetTrackName(objFile.Name)
    
12:        If Trim$(strArtist) <> "" And Trim$(strTitle) <> "" Then
        
13:            myTag.Artist = strArtist
14:            myTag.Title = strTitle
            
15:            Select Case mstrID3TagSupport
            
                Case "1":
                    
16:                    WriteID3v1 objFile.Path, myTag, True
                    
                Case "2":
                
17:                    WriteID3v2 objFile.Path, myTag, menumIDEV2_Version, False, True
                    
                Case "3":
                
18:                    WriteID3v1 objFile.Path, myTag, True
19:                    WriteID3v2 objFile.Path, myTag, menumIDEV2_Version, False, True
                    
20:            End Select
21:        End If
22:    End If

'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Variables = "strArtist = " & strArtist & vbNewLine & "strTitle = " & strTitle & vbNewLine & "blnGotTag = " & blnGotTag & vbNewLine

    objMSLDebugHandler.RaiseError "MP3TurboMate", "modID3", "ProcessTag", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function FormatTagFolder(ByVal strPath As String)
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim objFolder As Folder, objFile As File, lngTotal As Long, strTracks() As String, lngTrack As Long
    
2:    If mblnAskForConfirmation Then If MsgBox("Are you sure?", vbYesNo + vbQuestion, "Format Tags") = vbNo Then Exit Function
        
3:    strPath = GetPath(strPath)
    
4:    strTracks = GenerateFileList_Array(strPath, "Winamp media file", False, True, True)
    
5:    lngTotal = UBound(strTracks)
    
6:    For lngTrack = LBound(strTracks) To UBound(strTracks)
    
7:        If IsValidPrefix(strTracks(lngTrack)) Then
            
8:            FormatTag strTracks(lngTrack)
9:        End If
10:    Next
    
'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "strPath:" & strPath & vbNewLine
    strMSLDebugHandler_Variables = "lngTotal = " & lngTotal & vbNewLine & "lngTrack = " & lngTrack & vbNewLine

    objMSLDebugHandler.RaiseError "MP3TurboMate", "modID3", "FormatTagFolder", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function FormatTag(Optional strFile As String = "")
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim objFile As File, objFiles As Files, lngTotal As Long, lngCount As Long, myTag As ID3Tag
2: Dim blnGotTag As Boolean, strTracks() As String, lngTrack As Long
    
3:    If Trim$(strFile) = "" Then
    
4:        strTracks = GenerateFileList_Array(mstrPath, "Winamp media file", mblnRecurse, True, True)
5:    Else
    
6:        ReDim strTracks(0)
            
7:        strTracks(0) = strFile
8:   End If
    
9:   lngTotal = UBound(strTracks)
        
10:    For lngTrack = LBound(strTracks) To UBound(strTracks)
    
11:        Set objFile = mobjFSO.GetFile(strTracks(lngTrack))

12:        If objFile.Type = "Winamp media file" Then

13:            ResetTag myTag
            
14:            Select Case mstrID3TagSupport
            
                Case "1":
            
15:                    blnGotTag = ReadID3v1(objFile.Path, myTag)

                Case "2", "3":
            
16:                    blnGotTag = ReadID3v2(objFile.Path, myTag)
17:                    If Not blnGotTag Then blnGotTag = ReadID3v1(objFile.Path, myTag)
                    
18:            End Select
            
19:            myTag.Artist = Replace$(Replace$(CapitalizeInitialWordsInString(myTag.Artist), "[", "("), "]", ")")
20:            myTag.Title = Replace$(Replace$(CapitalizeInitialWordsInString(myTag.Title), "[", "("), "]", ")")
            
21:            Select Case mstrID3TagSupport
            
                Case "1":
                            
22:                    WriteID3v1 objFile.Path, myTag, True
                
                Case "2":
                
23:                    WriteID3v2 objFile.Path, myTag, menumIDEV2_Version, False, True
                
                Case "3":
                        
24:                    WriteID3v1 objFile.Path, myTag, True
25:                    WriteID3v2 objFile.Path, myTag, menumIDEV2_Version, False, True
                    
26:            End Select
            
27:            lngCount = lngCount + 1
        
28:            If lngCount >= lngTotal Then Exit For
29:        End If
30:    Next

'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "strFile:" & strFile & vbNewLine
    strMSLDebugHandler_Variables = "lngTotal = " & lngTotal & vbNewLine & "lngCount = " & lngCount & vbNewLine & "blnGotTag = " & blnGotTag & vbNewLine _
                                 & "lngTrack = " & lngTrack & vbNewLine

    objMSLDebugHandler.RaiseError "MP3TurboMate", "modID3", "FormatTag", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function IndicateBitRate(Optional ByVal blnPreview As Boolean, Optional ByRef strPreview As Variant)
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim objFile As File, objFiles As Files, lngTotal As Long, lngCount As Long
2: Dim enumMPEGInfo As MPEGInfo, blnMark As Boolean

3:    Set objFiles = mobjFSO.GetFolder(mstrPath).Files
    
4:    lngTotal = GetFileCountMP3s(objFiles)
        
5:    For Each objFile In objFiles

6:        If objFile.Type = "Winamp media file" Then
            
7:            If Mid$(objFile.Name, 1, 3) <> LEFT_SIDE_MARKER Then
            
8:                ReadMPEGInfo mstrPath & objFile.Name, enumMPEGInfo
                
9:                If mblnBitRateUseOptionalMarking Then
                
10:                    If enumMPEGInfo.Bitrate < mlngLevelToBeUsedForOptionalBitRateMarking Then
                    
11:                        blnMark = True
12:                    Else
                    
13:                        blnMark = False
14:                    End If
15:                Else
                
16:                    blnMark = True
17:                End If
                
18:                If blnMark Then
                
19:                    If enumMPEGInfo.HasVBR Then
                    
20:                        objFile.Name = LEFT_SIDE_MARKER & "VBR(" & enumMPEGInfo.Bitrate & ")" & RIGHT_SIDE_MARKER & objFile.Name
21:                    Else
                    
22:                        objFile.Name = LEFT_SIDE_MARKER & enumMPEGInfo.Bitrate & RIGHT_SIDE_MARKER & objFile.Name
23:                    End If
24:                End If
25:            End If
            
26:            lngCount = lngCount + 1
        
27:            If lngCount >= lngTotal Then Exit For
28:        End If
29:    Next

'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "blnPreview:" & blnPreview & vbNewLine
    strMSLDebugHandler_Variables = "lngTotal = " & lngTotal & vbNewLine & "lngCount = " & lngCount & vbNewLine & "blnMark = " & blnMark & vbNewLine

    objMSLDebugHandler.RaiseError "MP3TurboMate", "modID3", "IndicateBitRate", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function RemoveBitRate()
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim objFile As File, objFiles As Files, lngPos As Long, lngTotal As Long, lngCount As Long

2:    Set objFiles = mobjFSO.GetFolder(mstrPath).Files
    
3:    lngTotal = GetFileCountMP3s(objFiles)
        
4:    For Each objFile In objFiles

5:        If objFile.Type = "Winamp media file" Then

6:            If Mid$(objFile.Name, 1, 3) = LEFT_SIDE_MARKER And InStr(1, objFile.Name, RIGHT_SIDE_MARKER) > 0 Then
                
7:                lngPos = InStr(1, objFile.Name, RIGHT_SIDE_MARKER)
                
8:                objFile.Name = Mid$(objFile.Name, lngPos + 3)
                
9:            End If
            
10:            lngCount = lngCount + 1
        
11:            If lngCount >= lngTotal Then Exit For
12:        End If
13:    Next

'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Variables = "lngPos = " & lngPos & vbNewLine & "lngTotal = " & lngTotal & vbNewLine & "lngCount = " & lngCount & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "RemoveBitRate", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function DeleteBelowBitRate(ByVal lngBitRate As Long)
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim objFile As File, objFiles As Files, lngTotal As Long, lngCount As Long
2: Dim enumMPEGInfo As MPEGInfo

3:    Set objFiles = mobjFSO.GetFolder(mstrPath).Files
    
4:    lngTotal = GetFileCountMP3s(objFiles)
        
5:    For Each objFile In objFiles

6:        If objFile.Type = "Winamp media file" Then
                        
7:            ReadMPEGInfo mstrPath & objFile.Name, enumMPEGInfo
            
8:            If enumMPEGInfo.Bitrate <= lngBitRate Then
            
9:                objFile.Delete True
10:            End If
                        
11:            lngCount = lngCount + 1
        
12:            If lngCount >= lngTotal Then Exit For
13:        End If
14:    Next

'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "lngBitRate:" & lngBitRate & vbNewLine
    strMSLDebugHandler_Variables = "lngTotal = " & lngTotal & vbNewLine & "lngCount = " & lngCount & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "DeleteBelowBitRate", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function

Public Function IndicateBelowBitRate(ByVal lngBitRate As Long)
'<<BEGIN_HEADER_ERROR_HANDLER>>
On Error GoTo MSLDebug_ErrorHandler
'<<END_HEADER_ERROR_HANDLER>>

1: Dim objFile As File, objFiles As Files, lngTotal As Long, lngCount As Long
2: Dim enumMPEGInfo As MPEGInfo

3:    Set objFiles = mobjFSO.GetFolder(mstrPath).Files
    
4:    lngTotal = GetFileCountMP3s(objFiles)
        
5:    For Each objFile In objFiles

6:        If objFile.Type = "Winamp media file" Then
            
7:            If Mid$(objFile.Name, 1, 3) <> LEFT_SIDE_MARKER Then
            
8:                ReadMPEGInfo mstrPath & objFile.Name, enumMPEGInfo
                
9:                If enumMPEGInfo.Bitrate < lngBitRate Then
                
10:                    If enumMPEGInfo.HasVBR Then
                    
11:                        objFile.Name = LEFT_SIDE_MARKER & "VBR(" & enumMPEGInfo.Bitrate & ")" & RIGHT_SIDE_MARKER & objFile.Name
12:                    Else
                    
13:                        objFile.Name = LEFT_SIDE_MARKER & enumMPEGInfo.Bitrate & RIGHT_SIDE_MARKER & objFile.Name
14:                    End If
15:                End If
16:            End If
            
17:            lngCount = lngCount + 1
        
18:            If lngCount >= lngTotal Then Exit For
19:        End If
20:    Next


'<<BEGIN_FOOTER_ERROR_HANDLE>>
Exit Function
MSLDebug_ErrorHandler:
    Dim objMSLDebugHandler As Object, strMSLDebugHandler_Parameters As String, strMSLDebugHandler_Variables As String
    Set objMSLDebugHandler = CreateObject("QLxErrorHandler.Error")

    strMSLDebugHandler_Parameters = "lngBitRate:" & lngBitRate & vbNewLine
    strMSLDebugHandler_Variables = "lngTotal = " & lngTotal & vbNewLine & "lngCount = " & lngCount & vbNewLine

    objMSLDebugHandler.RaiseError "MP3Manager", "modID3", "IndicateBelowBitRate", _
           Err, App, Erl, strMSLDebugHandler_Parameters, strMSLDebugHandler_Variables
    Set objMSLDebugHandler = Nothing
'<<END_FOOTER_ERROR_HANDLE>>
End Function


