Public Class colFolders
    Inherits System.Collections.CollectionBase

    Default Public Property Item(ByVal index As Integer) As clsFolder
        Get
            Return CType(List(index), clsFolder)
        End Get
        Set(ByVal value As clsFolder)
            List(index) = value
        End Set
    End Property

    Public Function Add(ByVal value As clsFolder) As Integer

        Return List.Add(value)
    End Function 'Add

End Class
