<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDragDrop
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtDragFrom = New System.Windows.Forms.TextBox
        Me.txtDragTo = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'txtDragFrom
        '
        Me.txtDragFrom.AllowDrop = True
        Me.txtDragFrom.Location = New System.Drawing.Point(129, 41)
        Me.txtDragFrom.Multiline = True
        Me.txtDragFrom.Name = "txtDragFrom"
        Me.txtDragFrom.Size = New System.Drawing.Size(222, 81)
        Me.txtDragFrom.TabIndex = 5
        Me.txtDragFrom.Text = "Drag and drop"
        '
        'txtDragTo
        '
        Me.txtDragTo.AllowDrop = True
        Me.txtDragTo.Location = New System.Drawing.Point(129, 128)
        Me.txtDragTo.Multiline = True
        Me.txtDragTo.Name = "txtDragTo"
        Me.txtDragTo.Size = New System.Drawing.Size(270, 173)
        Me.txtDragTo.TabIndex = 6
        '
        'frmDragDrop
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(564, 468)
        Me.Controls.Add(Me.txtDragTo)
        Me.Controls.Add(Me.txtDragFrom)
        Me.Name = "frmDragDrop"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents songsDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents txtDragFrom As System.Windows.Forms.TextBox
    Friend WithEvents txtDragTo As System.Windows.Forms.TextBox

End Class
