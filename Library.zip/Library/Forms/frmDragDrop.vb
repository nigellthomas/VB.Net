
Public Class frmDragDrop

    Private Sub txtDragTo_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles txtDragTo.DragDrop

        txtDragTo.Text = txtDragTo.Text & CType(e.Data.GetData(GetType(String)), String)

    End Sub

    Private Sub txtDragTo_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles txtDragTo.DragEnter

        ' Could check against DataForms.Text as well
        If e.Data.GetDataPresent(GetType(String)) Then
            e.Effect = DragDropEffects.Move
        Else
            e.Effect = DragDropEffects.None
        End If


    End Sub

    Private Sub txtDragFrom_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles txtDragFrom.DragDrop

        txtDragFrom.Text = CType(e.Data.GetData(GetType(String)), String)

    End Sub

    Private Sub txtDragFrom_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles txtDragFrom.DragEnter
        ' Could check against DataForms.Text as well
        If e.Data.GetDataPresent(GetType(String)) Then
            e.Effect = DragDropEffects.Move
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub

    Private Sub txtDragFrom_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles txtDragFrom.MouseDown

        ' Start a drag-and-drop operation
        If txtDragFrom.SelectedText = "" Then Exit Sub

        DoDragDrop(txtDragFrom.SelectedText, DragDropEffects.Move)

    End Sub

End Class
