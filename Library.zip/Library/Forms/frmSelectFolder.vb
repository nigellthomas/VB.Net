Option Strict Off
Option Explicit On
Friend Class frmSelectFolder
    Inherits System.Windows.Forms.Form

    '* Private Property Variables
    Private mstrFolder As String
    Private mblnRecursive As Boolean
    Private mblnFolderSelectionOnly As Boolean
    Private mstrLocation As String

    '****************************************************************************
    '*  Name         : cmdCancel_Click
    '*  Description  :
    '*  Parameters   : None
    '*  Returns      : Nothing
    '*  Author       : nigel
    '*  Date         : 17 Nov 2000
    '****************************************************************************

    Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click

        On Error Resume Next

        Folder = ""
        Me.Close()

    End Sub

    '****************************************************************************
    '*  Name         : cmdOK_Click
    '*  Description  :
    '*  Parameters   : None
    '*  Returns      : Nothing
    '*  Author       : nigel
    '*  Date         : 17 Nov 2000
    '****************************************************************************

    Private Sub cmdOK_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdOK.Click

        On Error Resume Next

        Folder = Dir1.Path
        Me.Hide()

        Location_Renamed = Folder

    End Sub

    '****************************************************************************
    '*  Name         : Drive1_Change
    '*  Description  :
    '*  Parameters   : None
    '*  Returns      : Nothing
    '*  Author       : nigel
    '*  Date         : 17 Nov 2000
    '****************************************************************************

    Private Sub Drive1_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Drive1.SelectedIndexChanged

        On Error Resume Next

        Dir1.Path = Drive1.Drive

    End Sub


    '****************************************************************************
    '*
    '*  Property Name: Folder
    '*  Description  : Selected folder.
    '*
    '****************************************************************************

    Public Property Folder() As String
        Get

            Folder = mstrFolder

        End Get
        Set(ByVal Value As String)

            mstrFolder = Value

            Dir1.Path = Value

        End Set
    End Property

    '****************************************************************************
    '*
    '*  Property Name: Recursive
    '*  Description  :
    '*
    '****************************************************************************

    Public Property Recursive() As Boolean
        Get

            Recursive = mblnRecursive

        End Get
        Set(ByVal Value As Boolean)

            mblnRecursive = Value

        End Set
    End Property


    '****************************************************************************
    '*
    '*  Property Name: FolderSelectionOnly
    '*  Description  :
    '*
    '****************************************************************************

    Public Property FolderSelectionOnly() As Boolean
        Get

            FolderSelectionOnly = mblnFolderSelectionOnly

        End Get
        Set(ByVal Value As Boolean)

            mblnFolderSelectionOnly = Value

        End Set
    End Property

    '****************************************************************************
    '*
    '*  Property Name: Location
    '*  Description  :
    '*
    '****************************************************************************

    Public Property Location_Renamed() As String
        Get

            Location_Renamed = mstrLocation

        End Get
        Set(ByVal Value As String)

            mstrLocation = Value

        End Set
    End Property

    '****************************************************************************
    '*  Name         : Form_Resize
    '*  Description  :
    '*  Parameters   : None
    '*  Returns      : Nothing
    '*  Author       : nigel
    '*  Date         : 17 Nov 2000
    '****************************************************************************

    Private Sub frmSelectFolder_Resize(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Resize



    End Sub
End Class