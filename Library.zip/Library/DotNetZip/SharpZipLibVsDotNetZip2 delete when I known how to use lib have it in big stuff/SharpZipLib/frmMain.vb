﻿Imports System.IO

Public Class frmMain

    Private zipLib As clsCompareLibs
    Private currentEntries As New List(Of clsCompareLibs.ShortEntry)
    Private startTime As Date
    Private endTime As Date
    Private difference As TimeSpan

    Private callback As clsCompareLibs.ResultCallback = AddressOf zipCallback
    Private Sub zipCallback(ByRef zipData As clsCompareLibs.ZipData)

        Static lastName As String

        If Me.InvokeRequired Then
            Me.Invoke(callback, zipData)
        Else

            With zipData
                If .fileList IsNot Nothing AndAlso .fileList.Count > 0 Then
                    ' We've received a list of files. Add them to the listbox.
                    Dim names As New List(Of String)
                    currentEntries.Clear()

                    For Each entry As clsCompareLibs.ShortEntry In .fileList
                        names.Add(entry.name)
                        currentEntries.Add(entry)
                    Next

                    Me.lbFileList.Items.AddRange(names.ToArray())

                    Me.lblFileName.Text = "Complete."

                    Try
                        zipLib.Close()
                    Catch ex As Exception
                    End Try

                    me.Cursor = System.Windows.Forms.Cursors.Default
                Else
                    ' We're updating the UI with progress data here.

                    ' Have we moved on to a new file?
                    If lastName <> zipData.currentFileName Then
                        ' If so, set the progress bar to 0.
                        pbCurrentFile.Value = 0 
                        lastName = zipData.currentFileName
                    End If

                    lblFileName.Text = .operationTitle
                    If .currentFileName <> "" Then lblFileName.Text += ": ...\" & Path.GetFileName(.currentFileName)
                    If .currentFileBytesCopied > 0 AndAlso .totalBytes > 0 Then
                        pbCurrentFile.Value = CInt((.currentFileBytesCopied / .currentFileLength) * 100)
                        pbTotalBytes.Value = CInt((.totalBytesCopied / .totalBytes) * 100)

                        pbCurrentFile.Refresh()
                        pbTotalBytes.Refresh()
                    End If

                    If .complete Then
                        zipLib.Close()
                        If .cancel Then 
                            lblFileName.Text = "Canceled."
                            pbCurrentFile.Value     = 0
                            pbTotalBytes.Value      = 0
                        Else
                            endTime = Now
                            If endTime.Subtract(startTime).TotalSeconds > 60 then
                                lblFileName.Text = "Complete. This operation took " & _
                                    endTime.Subtract(startTime).Minutes.ToString() & _
                                    " minutes, and " & endTime.Subtract(startTime).Seconds.ToString() & " seconds."
                            Else
                                lblFileName.Text = "Complete. This operation took " & _
                                    endTime.Subtract(startTime).TotalSeconds.ToString("N1") & _
                                    " seconds."
                            End If
                        End If
                        
                        tsbZipFiles.Visible         = True
                        tsbZipFiles.Enabled         = True
                        tsbListZipEntries.Visible   = True
                        tsbCancel.Visible           = False
                        me.Cursor = System.Windows.Forms.Cursors.Default
                    End If

                    If .errorMessage <> "" Then 
                        MsgBox("" & .errorMessage, MsgBoxStyle.Critical, "Zip Example App")
                        me.Cursor = System.Windows.Forms.Cursors.Default
                    End If
                End If
            End With
        End If

    End Sub

    Private Sub ZipSourceFiles()

        Dim zipPath As String = tbZipPath.Text
        If zipPath = "Drag a .zip file here..." Then zipPath = ""

        Try
            startTime = Now
            zipLib = New clsCompareLibs(zipPath, clsCompareLibs.ZipAccessFlags.Create, 1024 * 1024, _
                cbDotNetZip.Checked, CInt(nudCompression.Value), cbZip64.Checked, tbPassword.Text, 100, AddressOf zipCallback)
        Catch ex As Exception
            MsgBox("Could not open zip file: " & tbZipPath.Text & ". The error returned is: " & ex.Message, MsgBoxStyle.Critical, "Zip Example App")
            tsbZipFiles.Visible         = True
            tsbListZipEntries.Visible   = True
            tsbCancel.Visible           = False
            Exit Sub
        End Try

        zipLib.Add(tbSourceFolder.Text)
    End Sub

    Private Sub ListZipEntries()
        Try
            me.Cursor = System.Windows.Forms.Cursors.WaitCursor
            Me.lbFileList.Items.Clear()
            Me.Refresh()
            Me.lblFileName.Text = "Listing zip entries..."
            zipLib = New clsCompareLibs(tbZipPath.Text, clsCompareLibs.ZipAccessFlags.Read, 1024 * 256, cbDotNetZip.Checked, _
                                        CInt(nudCompression.Value), cbZip64.Checked, "", 100, AddressOf zipCallback)
        Catch ex As Exception
            MsgBox("Could not open zip file: " & tbZipPath.Text & ". The error returned is: " & ex.Message, MsgBoxStyle.Critical, "Zip Example App")
            me.Cursor = System.Windows.Forms.Cursors.Default
            Exit Sub
        End Try

        zipLib.GetZipEntries()
    End Sub

    Private Sub frmMain_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        pbCurrentFile.Maximum = 100
        pbCurrentFile.Minimum = 0

        pbTotalBytes.Maximum = 100
        pbTotalBytes.Minimum = 0

        tbPassword.Enabled = False
        Me.tbDestFolder.Text = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) & "\Extracted\"
    End Sub

    Private Sub ListBox1_MouseDoubleClick(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles lbFileList.MouseDoubleClick
        Try
            zipLib = New clsCompareLibs(tbZipPath.Text, clsCompareLibs.ZipAccessFlags.Read, 1024 * 256, cbDotNetZip.Checked, _
                                        CInt(nudCompression.Value), cbZip64.Checked, tbPassword.Text, 100, AddressOf zipCallback)
        Catch ex As Exception
            MsgBox("Could not open zip file: " & tbZipPath.Text & ". The error returned is: " & ex.Message, MsgBoxStyle.Critical, "Zip Example App")
            Exit Sub
        End Try

        zipLib.Extract(Me.lbFileList.Items(Me.lbFileList.SelectedIndex()).ToString(), Me.tbDestFolder.Text)
    End Sub

    Private Sub ExtractSelected()
        If Me.lbFileList.SelectedItems.Count > 0 Then

            tsbZipFiles.Visible         = False
            tsbListZipEntries.Visible   = False
            tsbCancel.Visible           = True

            Me.lblFileName.Text = "Building extraction list..."
            Me.lblFileName.Refresh()
            Application.DoEvents()

            Dim selectedItems As New List(Of clsCompareLibs.ShortEntry)

            If Me.lbFileList.SelectedIndices.Count = currentEntries.Count Then
                ' We're extracting everything...
                selectedItems = currentEntries
            Else
                ' We've selected files to extract. Build a list...
                For count as Int32 = 0 to lbFileList.Items.Count -1
                    If lbFileList.GetSelected(count) Then selectedItems.Add(currentEntries.Item(count))
                Next
            End If

            Me.lblFileName.Text = "Beginning extraction..."
            Me.lblFileName.Refresh()
            Application.DoEvents()

            Try 
            zipLib = New clsCompareLibs(tbZipPath.Text, clsCompareLibs.ZipAccessFlags.Read, 1024 * 256, cbDotNetZip.Checked, _
                                        CInt(nudCompression.Value), cbZip64.Checked, tbPassword.Text, 100, AddressOf zipCallback)
            Catch ex As Exception
                MsgBox("Could not open zip file: " & tbZipPath.Text & ". The error returned is: " & ex.Message, MsgBoxStyle.Critical, "Zip Example App")
                me.Cursor = System.Windows.Forms.Cursors.Default
                tsbZipFiles.Visible         = True
                tsbListZipEntries.Visible   = True
                tsbCancel.Visible           = False
                Exit Sub
            End Try

            startTime = Now
            zipLib.Extract(selectedItems, Me.tbDestFolder.Text )
        End If
    End Sub

    Private Sub ExtractSelectedToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ExtractSelectedToolStripMenuItem.Click
        Me.ExtractSelected()
    End Sub

    Private Sub cbPassword_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles cbPassword.CheckedChanged
        If cbPassword.Checked then
            tbPassword.Enabled  = True
        Else
            tbPassword.Text     = ""
            tbPassword.Enabled  = False
        End If
    End Sub

    Private Sub tsbZipFiles_Click(sender As System.Object, e As System.EventArgs) Handles tsbZipFiles.Click
        tsbZipFiles.Visible         = False
        tsbListZipEntries.Visible   = False
        tsbCancel.Visible           = True
        Me.ZipSourceFiles()
    End Sub

    Private Sub tsbCancel_Click(sender As System.Object, e As System.EventArgs) Handles tsbCancel.Click
        tsbZipFiles.Visible         = True
        tsbCancel.Visible           = False
        tsbListZipEntries.Visible   = True
        tsbZipFiles.Enabled         = False
        zipLib.Cancel()
    End Sub

    Private Sub tsbListZipEntries_Click(sender As System.Object, e As System.EventArgs) Handles tsbListZipEntries.Click
        Me.ListZipEntries()
    End Sub

    Private Sub SelectAllToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SelectAllToolStripMenuItem.Click
        If Me.lbFileList.Items.Count > 0 Then
            me.Cursor = System.Windows.Forms.Cursors.WaitCursor

            Me.lbFileList.BeginUpdate
            For count as Integer = 0 to lbFileList.Items.Count -1
                Me.lbFileList.SetSelected(count, True)
            Next
            Me.lbFileList.EndUpdate

            me.Cursor = System.Windows.Forms.Cursors.Default
        End If
    End Sub

    Private Sub tbSourceFolder_DragDrop(sender As Object, e As System.Windows.Forms.DragEventArgs) Handles tbSourceFolder.DragDrop
        Dim fileList() As String = CType(e.Data.GetData(DataFormats.FileDrop), String())

        If fileList.Length > 0 Then
            Me.tbSourceFolder.Text = fileList(0)
        End If
    End Sub

    Private Sub tbSourceFolder_DragEnter(sender As Object, e As System.Windows.Forms.DragEventArgs) Handles tbSourceFolder.DragEnter
        ' Check the format of the data being dropped.
        If (e.Data.GetDataPresent(DataFormats.FileDrop)) Then
            ' Display the copy cursor.
            e.Effect = DragDropEffects.Link
        Else
            ' Display the no-drop cursor.
            e.Effect = DragDropEffects.None
        End If
    End Sub

    Private Sub tbZipPath_DragDrop(sender As Object, e As System.Windows.Forms.DragEventArgs) Handles tbZipPath.DragDrop
        Dim fileList() As String = CType(e.Data.GetData(DataFormats.FileDrop), String())

        If fileList.Length > 0 Then
            Me.tbZipPath.Text = fileList(0)

            If tbZipPath.Text.Length > 4 AndAlso tbZipPath.Text.Substring(tbZipPath.Text.Trim.Length - 4, 4).ToLower = ".zip" Then
                Me.ListZipEntries()
            End If
        End If
    End Sub

    Private Sub tbZipPath_DragEnter(sender As Object, e As System.Windows.Forms.DragEventArgs) Handles tbZipPath.DragEnter
        ' Check the format of the data being dropped.
        If (e.Data.GetDataPresent(DataFormats.FileDrop)) Then
            ' Display the copy cursor.
            e.Effect = DragDropEffects.Link
        Else
            ' Display the no-drop cursor.
            e.Effect = DragDropEffects.None
        End If
    End Sub

    Private Sub btZipFileDialog_Click(sender As System.Object, e As System.EventArgs) Handles btZipFileDialog.Click
        Dim sfd As New SaveFileDialog()
        sfd.Title = "Create a new zip file."
        sfd.ShowDialog()
        If sfd.FileName <> "" Then Me.tbZipPath.Text = sfd.FileName
    End Sub
End Class
