﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.lbFileList = New System.Windows.Forms.ListBox()
        Me.cmsExtractStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ExtractSelectedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SelectAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tbZipPath = New System.Windows.Forms.TextBox()
        Me.tbDestFolder = New System.Windows.Forms.TextBox()
        Me.lblZipFile = New System.Windows.Forms.Label()
        Me.lblDestFolder = New System.Windows.Forms.Label()
        Me.tbSourceFolder = New System.Windows.Forms.TextBox()
        Me.pbCurrentFile = New System.Windows.Forms.ProgressBar()
        Me.pbTotalBytes = New System.Windows.Forms.ProgressBar()
        Me.lblFileName = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cbDotNetZip = New System.Windows.Forms.CheckBox()
        Me.cbZip64 = New System.Windows.Forms.CheckBox()
        Me.cbPassword = New System.Windows.Forms.CheckBox()
        Me.tbPassword = New System.Windows.Forms.TextBox()
        Me.nudCompression = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.tsBottomButtons = New System.Windows.Forms.ToolStrip()
        Me.tsbZipFiles = New System.Windows.Forms.ToolStripButton()
        Me.tsbListZipEntries = New System.Windows.Forms.ToolStripButton()
        Me.tsbCancel = New System.Windows.Forms.ToolStripButton()
        Me.gbFiles = New System.Windows.Forms.GroupBox()
        Me.btZipFileDialog = New System.Windows.Forms.Button()
        Me.cmsExtractStrip.SuspendLayout
        CType(Me.nudCompression,System.ComponentModel.ISupportInitialize).BeginInit
        Me.GroupBox1.SuspendLayout
        Me.tsBottomButtons.SuspendLayout
        Me.gbFiles.SuspendLayout
        Me.SuspendLayout
        '
        'lbFileList
        '
        Me.lbFileList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom)  _
            Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.lbFileList.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lbFileList.ContextMenuStrip = Me.cmsExtractStrip
        Me.lbFileList.FormattingEnabled = true
        Me.lbFileList.Location = New System.Drawing.Point(15, 19)
        Me.lbFileList.Name = "lbFileList"
        Me.lbFileList.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.lbFileList.Size = New System.Drawing.Size(409, 130)
        Me.lbFileList.TabIndex = 0
        '
        'cmsExtractStrip
        '
        Me.cmsExtractStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExtractSelectedToolStripMenuItem, Me.SelectAllToolStripMenuItem})
        Me.cmsExtractStrip.Name = "cmsExtractStrip"
        Me.cmsExtractStrip.Size = New System.Drawing.Size(157, 48)
        '
        'ExtractSelectedToolStripMenuItem
        '
        Me.ExtractSelectedToolStripMenuItem.Name = "ExtractSelectedToolStripMenuItem"
        Me.ExtractSelectedToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.ExtractSelectedToolStripMenuItem.Text = "Extract Selected"
        '
        'SelectAllToolStripMenuItem
        '
        Me.SelectAllToolStripMenuItem.Name = "SelectAllToolStripMenuItem"
        Me.SelectAllToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.SelectAllToolStripMenuItem.Text = "Select All"
        '
        'tbZipPath
        '
        Me.tbZipPath.AllowDrop = true
        Me.tbZipPath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.tbZipPath.Location = New System.Drawing.Point(89, 184)
        Me.tbZipPath.Name = "tbZipPath"
        Me.tbZipPath.Size = New System.Drawing.Size(330, 20)
        Me.tbZipPath.TabIndex = 1
        Me.tbZipPath.Text = "Drag a .zip file here..."
        '
        'tbDestFolder
        '
        Me.tbDestFolder.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.tbDestFolder.Location = New System.Drawing.Point(88, 210)
        Me.tbDestFolder.Name = "tbDestFolder"
        Me.tbDestFolder.Size = New System.Drawing.Size(365, 20)
        Me.tbDestFolder.TabIndex = 2
        Me.tbDestFolder.Text = "C:\Users\Pete\Desktop\Extracted\"
        '
        'lblZipFile
        '
        Me.lblZipFile.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.lblZipFile.AutoSize = true
        Me.lblZipFile.Location = New System.Drawing.Point(13, 187)
        Me.lblZipFile.Name = "lblZipFile"
        Me.lblZipFile.Size = New System.Drawing.Size(41, 13)
        Me.lblZipFile.TabIndex = 4
        Me.lblZipFile.Text = "Zip File"
        '
        'lblDestFolder
        '
        Me.lblDestFolder.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.lblDestFolder.AutoSize = true
        Me.lblDestFolder.Location = New System.Drawing.Point(13, 213)
        Me.lblDestFolder.Name = "lblDestFolder"
        Me.lblDestFolder.Size = New System.Drawing.Size(58, 13)
        Me.lblDestFolder.TabIndex = 5
        Me.lblDestFolder.Text = "Dest folder"
        '
        'tbSourceFolder
        '
        Me.tbSourceFolder.AllowDrop = true
        Me.tbSourceFolder.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.tbSourceFolder.Location = New System.Drawing.Point(88, 236)
        Me.tbSourceFolder.Name = "tbSourceFolder"
        Me.tbSourceFolder.Size = New System.Drawing.Size(365, 20)
        Me.tbSourceFolder.TabIndex = 6
        Me.tbSourceFolder.Text = "Drag your source files folder here..."
        '
        'pbCurrentFile
        '
        Me.pbCurrentFile.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.pbCurrentFile.Location = New System.Drawing.Point(16, 370)
        Me.pbCurrentFile.MarqueeAnimationSpeed = 1
        Me.pbCurrentFile.Name = "pbCurrentFile"
        Me.pbCurrentFile.Size = New System.Drawing.Size(319, 16)
        Me.pbCurrentFile.TabIndex = 7
        '
        'pbTotalBytes
        '
        Me.pbTotalBytes.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.pbTotalBytes.Location = New System.Drawing.Point(16, 387)
        Me.pbTotalBytes.Name = "pbTotalBytes"
        Me.pbTotalBytes.Size = New System.Drawing.Size(319, 16)
        Me.pbTotalBytes.TabIndex = 8
        '
        'lblFileName
        '
        Me.lblFileName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.lblFileName.AutoEllipsis = true
        Me.lblFileName.Location = New System.Drawing.Point(16, 348)
        Me.lblFileName.Name = "lblFileName"
        Me.lblFileName.Size = New System.Drawing.Size(437, 16)
        Me.lblFileName.TabIndex = 9
        Me.lblFileName.Text = "Idle."
        '
        'Label4
        '
        Me.Label4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = true
        Me.Label4.Location = New System.Drawing.Point(13, 239)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(73, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Source Folder"
        '
        'cbDotNetZip
        '
        Me.cbDotNetZip.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left),System.Windows.Forms.AnchorStyles)
        Me.cbDotNetZip.AutoSize = true
        Me.cbDotNetZip.Location = New System.Drawing.Point(88, 263)
        Me.cbDotNetZip.Name = "cbDotNetZip"
        Me.cbDotNetZip.Size = New System.Drawing.Size(247, 17)
        Me.cbDotNetZip.TabIndex = 12
        Me.cbDotNetZip.Text = "UseDotNetZip ( Leave unchecked for #ZipLib)"
        Me.cbDotNetZip.UseVisualStyleBackColor = true
        '
        'cbZip64
        '
        Me.cbZip64.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left),System.Windows.Forms.AnchorStyles)
        Me.cbZip64.AutoSize = true
        Me.cbZip64.Checked = true
        Me.cbZip64.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbZip64.Location = New System.Drawing.Point(88, 286)
        Me.cbZip64.Name = "cbZip64"
        Me.cbZip64.Size = New System.Drawing.Size(73, 17)
        Me.cbZip64.TabIndex = 13
        Me.cbZip64.Text = "Use zip64"
        Me.cbZip64.UseVisualStyleBackColor = true
        '
        'cbPassword
        '
        Me.cbPassword.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left),System.Windows.Forms.AnchorStyles)
        Me.cbPassword.AutoSize = true
        Me.cbPassword.Location = New System.Drawing.Point(167, 286)
        Me.cbPassword.Name = "cbPassword"
        Me.cbPassword.Size = New System.Drawing.Size(143, 17)
        Me.cbPassword.TabIndex = 14
        Me.cbPassword.Text = "Password protect .zip file"
        Me.cbPassword.UseVisualStyleBackColor = true
        '
        'tbPassword
        '
        Me.tbPassword.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.tbPassword.Location = New System.Drawing.Point(88, 309)
        Me.tbPassword.Name = "tbPassword"
        Me.tbPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.tbPassword.Size = New System.Drawing.Size(365, 20)
        Me.tbPassword.TabIndex = 15
        Me.tbPassword.UseSystemPasswordChar = true
        '
        'nudCompression
        '
        Me.nudCompression.Location = New System.Drawing.Point(6, 16)
        Me.nudCompression.Maximum = New Decimal(New Integer() {9, 0, 0, 0})
        Me.nudCompression.Name = "nudCompression"
        Me.nudCompression.Size = New System.Drawing.Size(106, 20)
        Me.nudCompression.TabIndex = 16
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left),System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.nudCompression)
        Me.GroupBox1.Location = New System.Drawing.Point(334, 262)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(118, 41)
        Me.GroupBox1.TabIndex = 17
        Me.GroupBox1.TabStop = false
        Me.GroupBox1.Text = "Compression Level:"
        '
        'tsBottomButtons
        '
        Me.tsBottomButtons.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.tsBottomButtons.AutoSize = false
        Me.tsBottomButtons.BackColor = System.Drawing.Color.Transparent
        Me.tsBottomButtons.Dock = System.Windows.Forms.DockStyle.None
        Me.tsBottomButtons.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.tsBottomButtons.ImageScalingSize = New System.Drawing.Size(48, 48)
        Me.tsBottomButtons.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsbZipFiles, Me.tsbListZipEntries, Me.tsbCancel})
        Me.tsBottomButtons.Location = New System.Drawing.Point(9, 362)
        Me.tsBottomButtons.Name = "tsBottomButtons"
        Me.tsBottomButtons.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.tsBottomButtons.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.tsBottomButtons.Size = New System.Drawing.Size(447, 52)
        Me.tsBottomButtons.TabIndex = 18
        '
        'tsbZipFiles
        '
        Me.tsbZipFiles.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbZipFiles.Image = CType(resources.GetObject("tsbZipFiles.Image"),System.Drawing.Image)
        Me.tsbZipFiles.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbZipFiles.Name = "tsbZipFiles"
        Me.tsbZipFiles.Size = New System.Drawing.Size(52, 49)
        Me.tsbZipFiles.Text = "Zip source files now."
        '
        'tsbListZipEntries
        '
        Me.tsbListZipEntries.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbListZipEntries.Image = CType(resources.GetObject("tsbListZipEntries.Image"),System.Drawing.Image)
        Me.tsbListZipEntries.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbListZipEntries.Name = "tsbListZipEntries"
        Me.tsbListZipEntries.Size = New System.Drawing.Size(52, 49)
        Me.tsbListZipEntries.Text = "List Zip Entries."
        '
        'tsbCancel
        '
        Me.tsbCancel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbCancel.Image = CType(resources.GetObject("tsbCancel.Image"),System.Drawing.Image)
        Me.tsbCancel.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbCancel.Name = "tsbCancel"
        Me.tsbCancel.Size = New System.Drawing.Size(52, 49)
        Me.tsbCancel.Text = "Cancel"
        Me.tsbCancel.Visible = false
        '
        'gbFiles
        '
        Me.gbFiles.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom)  _
            Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.gbFiles.Controls.Add(Me.lbFileList)
        Me.gbFiles.Location = New System.Drawing.Point(12, 13)
        Me.gbFiles.Name = "gbFiles"
        Me.gbFiles.Size = New System.Drawing.Size(441, 160)
        Me.gbFiles.TabIndex = 19
        Me.gbFiles.TabStop = false
        Me.gbFiles.Text = "Zip file entries. Select some and right click to extract."
        '
        'btZipFileDialog
        '
        Me.btZipFileDialog.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.btZipFileDialog.BackColor = System.Drawing.Color.White
        Me.btZipFileDialog.Image = CType(resources.GetObject("btZipFileDialog.Image"),System.Drawing.Image)
        Me.btZipFileDialog.Location = New System.Drawing.Point(425, 182)
        Me.btZipFileDialog.Name = "btZipFileDialog"
        Me.btZipFileDialog.Size = New System.Drawing.Size(27, 24)
        Me.btZipFileDialog.TabIndex = 20
        Me.btZipFileDialog.UseVisualStyleBackColor = false
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6!, 13!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(465, 423)
        Me.Controls.Add(Me.btZipFileDialog)
        Me.Controls.Add(Me.pbTotalBytes)
        Me.Controls.Add(Me.gbFiles)
        Me.Controls.Add(Me.pbCurrentFile)
        Me.Controls.Add(Me.tsBottomButtons)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.tbPassword)
        Me.Controls.Add(Me.cbPassword)
        Me.Controls.Add(Me.cbZip64)
        Me.Controls.Add(Me.cbDotNetZip)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.tbSourceFolder)
        Me.Controls.Add(Me.lblDestFolder)
        Me.Controls.Add(Me.lblZipFile)
        Me.Controls.Add(Me.tbDestFolder)
        Me.Controls.Add(Me.tbZipPath)
        Me.Controls.Add(Me.lblFileName)
        Me.Icon = CType(resources.GetObject("$this.Icon"),System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(481, 461)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "#ZipLib VS DotNetLib"
        Me.cmsExtractStrip.ResumeLayout(false)
        CType(Me.nudCompression,System.ComponentModel.ISupportInitialize).EndInit
        Me.GroupBox1.ResumeLayout(false)
        Me.tsBottomButtons.ResumeLayout(false)
        Me.tsBottomButtons.PerformLayout
        Me.gbFiles.ResumeLayout(false)
        Me.ResumeLayout(false)
        Me.PerformLayout

End Sub
    Friend WithEvents lbFileList As System.Windows.Forms.ListBox
    Friend WithEvents tbZipPath As System.Windows.Forms.TextBox
    Friend WithEvents tbDestFolder As System.Windows.Forms.TextBox
    Friend WithEvents lblZipFile As System.Windows.Forms.Label
    Friend WithEvents lblDestFolder As System.Windows.Forms.Label
    Friend WithEvents tbSourceFolder As System.Windows.Forms.TextBox
    Friend WithEvents pbCurrentFile As System.Windows.Forms.ProgressBar
    Friend WithEvents pbTotalBytes As System.Windows.Forms.ProgressBar
    Friend WithEvents lblFileName As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmsExtractStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ExtractSelectedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cbDotNetZip As System.Windows.Forms.CheckBox
    Friend WithEvents cbZip64 As System.Windows.Forms.CheckBox
    Friend WithEvents cbPassword As System.Windows.Forms.CheckBox
    Friend WithEvents tbPassword As System.Windows.Forms.TextBox
    Friend WithEvents nudCompression As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents tsBottomButtons As System.Windows.Forms.ToolStrip
    Friend WithEvents tsbZipFiles As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbCancel As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbListZipEntries As System.Windows.Forms.ToolStripButton
    Friend WithEvents gbFiles As System.Windows.Forms.GroupBox
    Friend WithEvents SelectAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btZipFileDialog As System.Windows.Forms.Button

End Class
