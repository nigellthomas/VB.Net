﻿Public Class frmMyMessageBox

    Private mstrValue As String = ""

    Public Function ShowQuestion(text As String, caption As String, buttons As System.Windows.Forms.MessageBoxButtons,
                                 icon As System.Windows.Forms.MessageBoxIcon) As Windows.Forms.DialogResult


        lblBackforButtons.Text = ""
        lblBackforText.Text = ""

        lblText.Text = text

        Me.Text = caption

        If icon = MessageBoxIcon.Question Then

            picIcon.Visible = True
        End If

        Select Case buttons

            Case MessageBoxButtons.OK

                cmdOne.Visible = True
                cmdOne.Text = "OK"
                cmdOne.Left = Me.Width - 110

            Case MessageBoxButtons.OKCancel

                cmdOne.Visible = True
                cmdOne.Text = "OK"
                cmdOne.Left = Me.Width - 210

                cmdTwo.Visible = True
                cmdTwo.Text = "Cancel"
                cmdTwo.Left = Me.Width - 110

            Case MessageBoxButtons.YesNo

                cmdOne.Visible = True
                cmdOne.Text = "Yes"
                cmdOne.Left = Me.Width - 210

                cmdTwo.Visible = True
                cmdTwo.Text = "No"
                cmdTwo.Left = Me.Width - 110

            Case MessageBoxButtons.YesNoCancel

                cmdOne.Visible = True
                cmdOne.Text = "Yes"
                cmdOne.Left = Me.Width - 310

                cmdTwo.Visible = True
                cmdTwo.Text = "No"
                cmdTwo.Left = Me.Width - 210

                cmdThree.Visible = True
                cmdThree.Text = "Cancel"
                cmdThree.Left = Me.Width - 110

        End Select

        Me.ShowDialog()

        Select Case buttons

            Case MessageBoxButtons.OK

                If mstrValue = "OK" Then

                    ShowQuestion = Windows.Forms.DialogResult.OK
                End If

            Case MessageBoxButtons.YesNo

                If mstrValue = "Yes" Then

                    ShowQuestion = Windows.Forms.DialogResult.Yes
                Else

                    ShowQuestion = Windows.Forms.DialogResult.No
                End If

            Case MessageBoxButtons.OKCancel

                If mstrValue = "OK" Then

                    ShowQuestion = Windows.Forms.DialogResult.OK
                Else

                    ShowQuestion = Windows.Forms.DialogResult.Cancel
                End If

            Case MessageBoxButtons.YesNoCancel

                If mstrValue = "Yes" Then

                    ShowQuestion = Windows.Forms.DialogResult.Yes

                ElseIf mstrValue = "No" Then

                    ShowQuestion = Windows.Forms.DialogResult.No

                Else

                    ShowQuestion = Windows.Forms.DialogResult.Cancel
                End If

        End Select

    End Function

    Private Sub cmdButtons_Click(sender As Object, e As EventArgs) Handles cmdOne.Click, cmdTwo.Click, cmdThree.Click

        mstrValue = sender.text

        Me.Hide()

    End Sub

End Class