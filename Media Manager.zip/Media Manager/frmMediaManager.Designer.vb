﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMediaManager
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMediaManager))
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.cmdUpdateTV = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateTV_Backup = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateTV2 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateTV2_Backup = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateTV3 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateTV3_Backup = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateTV4 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateTV4_Backup = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateTV5 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator14 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateTV5_Backup = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator15 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateTV6 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator16 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateTV6_Backup = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator17 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateTV7 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateTV7_Backup = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateTV8 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator18 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateTV8_Backup = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator19 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateTV9 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateTV9_Backup = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator21 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateTV10 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator22 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateTV10_Backup = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator23 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateMovies = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdUpdateMovies_Backup = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator20 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdReloadDrives = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator13 = New System.Windows.Forms.ToolStripSeparator()
        Me.txtSearch = New System.Windows.Forms.ToolStripTextBox()
        Me.cmdFolderSearch = New System.Windows.Forms.ToolStripButton()
        Me.cmdFileSearch = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.lblNumberOfRows = New System.Windows.Forms.ToolStripLabel()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblErrors = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblLastError = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblMessage = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.treDrives = New System.Windows.Forms.TreeView()
        Me.lvwMajorFolders = New System.Windows.Forms.ListView()
        Me.ColumnHeader9 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader10 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader67 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.txtDriveFileSummary_Seriesname = New System.Windows.Forms.TextBox()
        Me.txtomdbAPI_SeriesName = New System.Windows.Forms.TextBox()
        Me.cmdomdbAPI_IMDB = New System.Windows.Forms.Button()
        Me.cmdFinished_Listview = New System.Windows.Forms.Button()
        Me.cmdFinished_RottenTomatoes = New System.Windows.Forms.Button()
        Me.cmdFinished_OmdbAPI = New System.Windows.Forms.Button()
        Me.chkNonStandard_IgnoreTTCFiles = New System.Windows.Forms.CheckBox()
        Me.chkNonStandard_IgnoreSubtitle = New System.Windows.Forms.CheckBox()
        Me.cmdToDo_Edit = New System.Windows.Forms.Button()
        Me.cmdToDo_Add = New System.Windows.Forms.Button()
        Me.chkNonStandard_DoBackup = New System.Windows.Forms.CheckBox()
        Me.cmdToDo_Delete = New System.Windows.Forms.Button()
        Me.cmdFinished_ToDo = New System.Windows.Forms.Button()
        Me.cmdFinished_MumsStuff = New System.Windows.Forms.Button()
        Me.cmdFinished_KnownDuplicates = New System.Windows.Forms.Button()
        Me.cmdFinished_ShowList_Dups = New System.Windows.Forms.Button()
        Me.cmdFinished_AiredShows = New System.Windows.Forms.Button()
        Me.cmdUpdateStatusUpdateDetails = New System.Windows.Forms.Button()
        Me.cmdFinishedPeopleLiked_All = New System.Windows.Forms.Button()
        Me.cmdFinished_UpdateStatus = New System.Windows.Forms.Button()
        Me.cmdFinished_NonStandardFiles = New System.Windows.Forms.Button()
        Me.tabFiles = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.lvwFiles = New System.Windows.Forms.ListView()
        Me.colFileName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.txtPlot = New System.Windows.Forms.TextBox()
        Me.lvwIMDBFiles = New System.Windows.Forms.ListView()
        Me.colName_ = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colAirDate = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.fraOperations = New System.Windows.Forms.GroupBox()
        Me.txtUpdFilenamesHelp = New System.Windows.Forms.TextBox()
        Me.cmdUpdFilesRemoveItemFromGrid = New System.Windows.Forms.Button()
        Me.cmdUpdFilesUpdateFilenamesInListview = New System.Windows.Forms.Button()
        Me.cmdUpdFilesRemoveSelectionsinGrid = New System.Windows.Forms.Button()
        Me.txtCurrentFilename = New System.Windows.Forms.TextBox()
        Me.cmdUpdFilesApplyProposedFilenames = New System.Windows.Forms.Button()
        Me.cmdUpdFilesRevertToOriginalNames = New System.Windows.Forms.Button()
        Me.txtOperationTextbox2 = New System.Windows.Forms.TextBox()
        Me.txtOperationTextbox1 = New System.Windows.Forms.TextBox()
        Me.lblOperationLabel2 = New System.Windows.Forms.Label()
        Me.lblOperationLabel1 = New System.Windows.Forms.Label()
        Me.lstOperations = New System.Windows.Forms.ListBox()
        Me.lvwUpdatefilenames = New System.Windows.Forms.ListView()
        Me.colNameOnDisk = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colTypeOnDisk = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colProposedName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.cmdSeasonsTab_Order = New System.Windows.Forms.Button()
        Me.lvwSeasons = New System.Windows.Forms.ListView()
        Me.colSeason = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colEpisode = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.coltitle = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Airdate = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.txtSeasonsTab_Plot = New System.Windows.Forms.TextBox()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.lvwPeopleLiked = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader13 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader22 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.cmdCompletedSeasons = New System.Windows.Forms.Button()
        Me.cboCompletedSeasons = New System.Windows.Forms.ComboBox()
        Me.lblCompletedSeasons = New System.Windows.Forms.Label()
        Me.lvwCompletedFiles = New System.Windows.Forms.ListView()
        Me.colCompPath = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colCompName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.chkUpdateStatus_IgnoreCompleted_Tab = New System.Windows.Forms.CheckBox()
        Me.lvwUpdateStatus_Tab = New System.Windows.Forms.ListView()
        Me.ColumnHeader20 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader21 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader23 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader24 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader48 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader49 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader50 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader51 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader52 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader53 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader54 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader55 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chkUpdateStatus_Missing_Tab = New System.Windows.Forms.CheckBox()
        Me.cboDrives_Tab = New System.Windows.Forms.ComboBox()
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.cmdWikiLoadEpisodes = New System.Windows.Forms.Button()
        Me.cmdWikiLoad = New System.Windows.Forms.Button()
        Me.webWiki = New System.Windows.Forms.WebBrowser()
        Me.cmdWikiForward = New System.Windows.Forms.Button()
        Me.cmdWikiBack = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtURLWiki = New System.Windows.Forms.TextBox()
        Me.tabDetails = New System.Windows.Forms.TabControl()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.fraDetails = New System.Windows.Forms.GroupBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtAltName = New System.Windows.Forms.TextBox()
        Me.cmdSaveID = New System.Windows.Forms.Button()
        Me.chkSeasonOK = New System.Windows.Forms.CheckBox()
        Me.cmdMissing = New System.Windows.Forms.Button()
        Me.cmdToDo_General = New System.Windows.Forms.Button()
        Me.cmdAddToToDo = New System.Windows.Forms.Button()
        Me.txtAPITitle = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtLastUpdate_API = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtDiscSeasonsEpisodes = New System.Windows.Forms.TextBox()
        Me.chkComplete = New System.Windows.Forms.CheckBox()
        Me.chkFinished = New System.Windows.Forms.CheckBox()
        Me.txtSeriesName = New System.Windows.Forms.TextBox()
        Me.cmdClearID = New System.Windows.Forms.Button()
        Me.txtEnd = New System.Windows.Forms.TextBox()
        Me.cmdIMDB_Name = New System.Windows.Forms.Button()
        Me.cmdUpdate_OMDB_Only = New System.Windows.Forms.Button()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.txtCountry = New System.Windows.Forms.TextBox()
        Me.txtTotalWithAirdate = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cmdIMDB = New System.Windows.Forms.Button()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.txtMyTotal = New System.Windows.Forms.TextBox()
        Me.lblMyTotal = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cboCorrectVersion = New System.Windows.Forms.ComboBox()
        Me.chkDetailsinDoubt = New System.Windows.Forms.CheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmdUpdateNow = New System.Windows.Forms.Button()
        Me.optImdb = New System.Windows.Forms.RadioButton()
        Me.txtLastUpdate_IMDB = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtSeasonCount = New System.Windows.Forms.TextBox()
        Me.txtRating = New System.Windows.Forms.TextBox()
        Me.txtGenre = New System.Windows.Forms.TextBox()
        Me.txtStart = New System.Windows.Forms.TextBox()
        Me.lblImdbRating = New System.Windows.Forms.Label()
        Me.txtIMDBSeasonsEpisodes = New System.Windows.Forms.TextBox()
        Me.lblSeasons = New System.Windows.Forms.Label()
        Me.lblGenre = New System.Windows.Forms.Label()
        Me.lblStart = New System.Windows.Forms.Label()
        Me.lblDescription = New System.Windows.Forms.Label()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.fraMissing = New System.Windows.Forms.GroupBox()
        Me.cmdAddSelMissingSeasonsToToDownload = New System.Windows.Forms.Button()
        Me.cmdAddMissingSeasonsToToDownload = New System.Windows.Forms.Button()
        Me.cmdAddSelMissingToToDownload = New System.Windows.Forms.Button()
        Me.cmdAddMissingToToDownload = New System.Windows.Forms.Button()
        Me.chkX264_Episode = New System.Windows.Forms.CheckBox()
        Me.chkX264_Season = New System.Windows.Forms.CheckBox()
        Me.txtMissingEpisodes = New System.Windows.Forms.TextBox()
        Me.txtMissingSeasons = New System.Windows.Forms.TextBox()
        Me.cmdFinished_MajorFolders = New System.Windows.Forms.Button()
        Me.cmdFinished_DriveStatus = New System.Windows.Forms.Button()
        Me.cmdFinished = New System.Windows.Forms.Button()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.cboDrives = New System.Windows.Forms.ComboBox()
        Me.chkUpdateStatus_IgnoreCompleted = New System.Windows.Forms.CheckBox()
        Me.chkUpdateStatus_Missing = New System.Windows.Forms.CheckBox()
        Me.txtAiredItems_Title = New System.Windows.Forms.TextBox()
        Me.prgProgress = New System.Windows.Forms.ProgressBar()
        Me.lvwAiredShows = New System.Windows.Forms.ListView()
        Me.colAiredDrive = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colShow = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colSeason_ = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colEpisode_ = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colDate = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colAiredLocation = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colAiredimdbID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colAiredTitle = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.cmdomdbAPI_Forward = New System.Windows.Forms.Button()
        Me.lvwPeopleLiked_All = New System.Windows.Forms.ListView()
        Me.ColumnHeader25 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader26 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader27 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader28 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.cboOmdbCountries = New System.Windows.Forms.ComboBox()
        Me.lvwRottenTomatoes = New System.Windows.Forms.ListView()
        Me.ColumnHeader56 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader57 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader58 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader59 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader60 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader64 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.txtAiredItems_FilenameJustSeason = New System.Windows.Forms.TextBox()
        Me.txtDriveFileSummary_FilenameJustSeason = New System.Windows.Forms.TextBox()
        Me.txtDriveFileSummary_FullFilename = New System.Windows.Forms.TextBox()
        Me.txtAiredItems_FullFilename = New System.Windows.Forms.TextBox()
        Me.cboFileCount = New System.Windows.Forms.ComboBox()
        Me.lblUpdateStatus_Report = New System.Windows.Forms.Label()
        Me.txtOmdbAPI_Desc = New System.Windows.Forms.TextBox()
        Me.lvwNonStandardFiles = New System.Windows.Forms.ListView()
        Me.ColumnHeader14 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader15 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader16 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader17 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader18 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader19 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.mnuNonStandardRightClick = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnuNonStandardFilesDelete = New System.Windows.Forms.ToolStripMenuItem()
        Me.lvwMumsStuff = New System.Windows.Forms.ListView()
        Me.ColumnHeader35 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader36 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.lvwToDo = New System.Windows.Forms.ListView()
        Me.ColumnHeader32 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader37 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader65 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.lvwKnownDups = New System.Windows.Forms.ListView()
        Me.ColumnHeader33 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader34 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader38 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.mnuListviewRightClick_Delete = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnuListview_Delete = New System.Windows.Forms.ToolStripMenuItem()
        Me.cmdDriveFileSummary_FullFilename_Copy = New System.Windows.Forms.Button()
        Me.txtAiredItems_FullFilenamewithoutETTV = New System.Windows.Forms.TextBox()
        Me.cmdDriveFileSummary_SeriesName_Copy = New System.Windows.Forms.Button()
        Me.cmdAiredItems_SeriesName_Copy = New System.Windows.Forms.Button()
        Me.cmdAiredItems_Title_Copy = New System.Windows.Forms.Button()
        Me.cmdAiredItems_FullFilename_Copy = New System.Windows.Forms.Button()
        Me.cmdDriveFileSummary_FullFilenamewithoutETTV_Copy = New System.Windows.Forms.Button()
        Me.cmdAiredItems_FullFilenamewithoutETTV_Copy = New System.Windows.Forms.Button()
        Me.cmdDriveFileSummary_FilenameJustSeason_Copy = New System.Windows.Forms.Button()
        Me.cmdAiredItems_FilenameJustSeason_Copy = New System.Windows.Forms.Button()
        Me.cmdShowList_Dups_TrollList = New System.Windows.Forms.Button()
        Me.lvwShowList_Dups = New System.Windows.Forms.ListView()
        Me.ColumnHeader29 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader31 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.mnuListview_AddToDupsOnly = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnuAddToDups = New System.Windows.Forms.ToolStripMenuItem()
        Me.txtAiredItems_Seriesname = New System.Windows.Forms.TextBox()
        Me.lvwUpdateStatus = New System.Windows.Forms.ListView()
        Me.colName1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colMyTotal = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colAirDate1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colWithoutAirdate = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colDiff = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colUpdateLast = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colInDoubt = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colCorrVersion = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colCompleted = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colFinished = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colError = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.lvwSearchResults = New System.Windows.Forms.ListView()
        Me.colDrive = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colFolder = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colType = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colSize = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColMDate = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.calCalendar_AirDates = New System.Windows.Forms.MonthCalendar()
        Me.txtDriveFileSummary_FullFilenamewithoutETTV = New System.Windows.Forms.TextBox()
        Me.lblAiredItems_ExplanationoftxtAiredItems_Title = New System.Windows.Forms.Label()
        Me.lvwListView = New System.Windows.Forms.ListView()
        Me.lvwDriveStatus = New System.Windows.Forms.ListView()
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader7 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader8 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader11 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader12 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader30 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader61 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader66 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader63 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.cmdAiredItems_Process = New System.Windows.Forms.Button()
        Me.cboOmdbTitleLetter = New System.Windows.Forms.ComboBox()
        Me.lblDriveFileSummary_Info = New System.Windows.Forms.Label()
        Me.txtDriveSummary_Desc = New System.Windows.Forms.TextBox()
        Me.cmdomdbAPI_Back = New System.Windows.Forms.Button()
        Me.lvwOmdbAPI = New System.Windows.Forms.ListView()
        Me.ColumnHeader39 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader62 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader40 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader41 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader42 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader43 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader44 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader45 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader46 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader47 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.txtMultiLineTextbox = New System.Windows.Forms.TextBox()
        Me.chkBothTypes = New System.Windows.Forms.CheckBox()
        Me.mnuRightClick = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnuExpandAll = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCollapseAll = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFindCompletedFiles = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFindCompletedFilesSeason = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMakeSeasonStandard = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMoveFilesFromRootToSeason1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMoveTo = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCreateMissingSeasons = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCreateMissingSeasonsUpTo = New System.Windows.Forms.ToolStripMenuItem()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.FileSystemWatcher1 = New System.IO.FileSystemWatcher()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAiredItems = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuRefreshDrives = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDriveStatus = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuLastFilesAdded = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFindNonStandardFiles = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMajorFolders = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMumsStuff = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDriveSummary = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDriveFileSummary = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuomdbAPI = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPeopleAlsoLiked = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuRottenTomatoes = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAutoUpdate = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuUpdateMyTotals = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuUpdateStatus = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuKnownDuplicates = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDuplicates = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuShowList_UsedforDups = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuToDo = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuToDownload = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSimpleConsistencyChecker = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFailedDownloads = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOptions = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOptionsFinished = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOptionsComplete = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.DrivesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMountTV9 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuUseTV9R = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuUseTV9T = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuUseTV9Y = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMountTV10 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMountTV11 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMountTV12 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuListviewRightClick = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnuDeleteFiles = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDup_Email = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDup_Record = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDuplicateBoth = New System.Windows.Forms.ToolStripMenuItem()
        Me.tmrUpdateTimer = New System.Windows.Forms.Timer(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.mnuListview_DriveFileSummary = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnuDriveFileSummary_GeneralTodo = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.tabFiles.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.fraOperations.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        Me.TabPage10.SuspendLayout()
        Me.tabDetails.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.fraDetails.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.fraMissing.SuspendLayout()
        Me.mnuNonStandardRightClick.SuspendLayout()
        Me.mnuListviewRightClick_Delete.SuspendLayout()
        Me.mnuListview_AddToDupsOnly.SuspendLayout()
        Me.mnuRightClick.SuspendLayout()
        CType(Me.FileSystemWatcher1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.mnuListviewRightClick.SuspendLayout()
        Me.mnuListview_DriveFileSummary.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.cmdUpdateTV, Me.ToolStripSeparator2, Me.cmdUpdateTV_Backup, Me.ToolStripSeparator3, Me.cmdUpdateTV2, Me.ToolStripSeparator4, Me.cmdUpdateTV2_Backup, Me.ToolStripSeparator5, Me.cmdUpdateTV3, Me.ToolStripSeparator8, Me.cmdUpdateTV3_Backup, Me.ToolStripSeparator9, Me.cmdUpdateTV4, Me.ToolStripSeparator10, Me.cmdUpdateTV4_Backup, Me.ToolStripSeparator11, Me.cmdUpdateTV5, Me.ToolStripSeparator14, Me.cmdUpdateTV5_Backup, Me.ToolStripSeparator15, Me.cmdUpdateTV6, Me.ToolStripSeparator16, Me.cmdUpdateTV6_Backup, Me.ToolStripSeparator17, Me.cmdUpdateTV7, Me.ToolStripSeparator1, Me.cmdUpdateTV7_Backup, Me.ToolStripSeparator7, Me.cmdUpdateTV8, Me.ToolStripSeparator18, Me.cmdUpdateTV8_Backup, Me.ToolStripSeparator19, Me.cmdUpdateTV9, Me.ToolStripSeparator12, Me.cmdUpdateTV9_Backup, Me.ToolStripSeparator21, Me.cmdUpdateTV10, Me.ToolStripSeparator22, Me.cmdUpdateTV10_Backup, Me.ToolStripSeparator23, Me.cmdUpdateMovies, Me.ToolStripSeparator6, Me.cmdUpdateMovies_Backup, Me.ToolStripSeparator20, Me.cmdReloadDrives, Me.ToolStripSeparator13, Me.txtSearch, Me.cmdFolderSearch, Me.cmdFileSearch, Me.ToolStripLabel1, Me.lblNumberOfRows})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1679, 25)
        Me.ToolStrip1.TabIndex = 1
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'cmdUpdateTV
        '
        Me.cmdUpdateTV.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV.Image = CType(resources.GetObject("cmdUpdateTV.Image"), System.Drawing.Image)
        Me.cmdUpdateTV.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV.Name = "cmdUpdateTV"
        Me.cmdUpdateTV.Size = New System.Drawing.Size(25, 22)
        Me.cmdUpdateTV.Text = "TV"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateTV_Backup
        '
        Me.cmdUpdateTV_Backup.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV_Backup.Image = CType(resources.GetObject("cmdUpdateTV_Backup.Image"), System.Drawing.Image)
        Me.cmdUpdateTV_Backup.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV_Backup.Name = "cmdUpdateTV_Backup"
        Me.cmdUpdateTV_Backup.Size = New System.Drawing.Size(48, 22)
        Me.cmdUpdateTV_Backup.Text = "TV Bkp"
        Me.cmdUpdateTV_Backup.ToolTipText = "TV Backup"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateTV2
        '
        Me.cmdUpdateTV2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV2.Image = CType(resources.GetObject("cmdUpdateTV2.Image"), System.Drawing.Image)
        Me.cmdUpdateTV2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV2.Name = "cmdUpdateTV2"
        Me.cmdUpdateTV2.Size = New System.Drawing.Size(34, 22)
        Me.cmdUpdateTV2.Text = "TV 2"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateTV2_Backup
        '
        Me.cmdUpdateTV2_Backup.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV2_Backup.Image = CType(resources.GetObject("cmdUpdateTV2_Backup.Image"), System.Drawing.Image)
        Me.cmdUpdateTV2_Backup.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV2_Backup.Name = "cmdUpdateTV2_Backup"
        Me.cmdUpdateTV2_Backup.Size = New System.Drawing.Size(57, 22)
        Me.cmdUpdateTV2_Backup.Text = "TV 2 Bkp"
        Me.cmdUpdateTV2_Backup.ToolTipText = "TV 2 Backup"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateTV3
        '
        Me.cmdUpdateTV3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV3.Image = CType(resources.GetObject("cmdUpdateTV3.Image"), System.Drawing.Image)
        Me.cmdUpdateTV3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV3.Name = "cmdUpdateTV3"
        Me.cmdUpdateTV3.Size = New System.Drawing.Size(34, 22)
        Me.cmdUpdateTV3.Text = "TV 3"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateTV3_Backup
        '
        Me.cmdUpdateTV3_Backup.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV3_Backup.Image = CType(resources.GetObject("cmdUpdateTV3_Backup.Image"), System.Drawing.Image)
        Me.cmdUpdateTV3_Backup.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV3_Backup.Name = "cmdUpdateTV3_Backup"
        Me.cmdUpdateTV3_Backup.Size = New System.Drawing.Size(57, 22)
        Me.cmdUpdateTV3_Backup.Text = "TV 3 Bkp"
        Me.cmdUpdateTV3_Backup.ToolTipText = "TV 3 Backup"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateTV4
        '
        Me.cmdUpdateTV4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV4.Image = CType(resources.GetObject("cmdUpdateTV4.Image"), System.Drawing.Image)
        Me.cmdUpdateTV4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV4.Name = "cmdUpdateTV4"
        Me.cmdUpdateTV4.Size = New System.Drawing.Size(34, 22)
        Me.cmdUpdateTV4.Text = "TV 4"
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateTV4_Backup
        '
        Me.cmdUpdateTV4_Backup.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV4_Backup.Image = CType(resources.GetObject("cmdUpdateTV4_Backup.Image"), System.Drawing.Image)
        Me.cmdUpdateTV4_Backup.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV4_Backup.Name = "cmdUpdateTV4_Backup"
        Me.cmdUpdateTV4_Backup.Size = New System.Drawing.Size(57, 22)
        Me.cmdUpdateTV4_Backup.Text = "TV 4 Bkp"
        Me.cmdUpdateTV4_Backup.ToolTipText = "TV 4 Backup"
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateTV5
        '
        Me.cmdUpdateTV5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV5.Image = CType(resources.GetObject("cmdUpdateTV5.Image"), System.Drawing.Image)
        Me.cmdUpdateTV5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV5.Name = "cmdUpdateTV5"
        Me.cmdUpdateTV5.Size = New System.Drawing.Size(34, 22)
        Me.cmdUpdateTV5.Text = "TV 5"
        Me.cmdUpdateTV5.ToolTipText = "TV 5"
        '
        'ToolStripSeparator14
        '
        Me.ToolStripSeparator14.Name = "ToolStripSeparator14"
        Me.ToolStripSeparator14.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateTV5_Backup
        '
        Me.cmdUpdateTV5_Backup.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV5_Backup.Image = CType(resources.GetObject("cmdUpdateTV5_Backup.Image"), System.Drawing.Image)
        Me.cmdUpdateTV5_Backup.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV5_Backup.Name = "cmdUpdateTV5_Backup"
        Me.cmdUpdateTV5_Backup.Size = New System.Drawing.Size(57, 22)
        Me.cmdUpdateTV5_Backup.Text = "TV 5 Bkp"
        Me.cmdUpdateTV5_Backup.ToolTipText = "TV 5 Backup"
        '
        'ToolStripSeparator15
        '
        Me.ToolStripSeparator15.Name = "ToolStripSeparator15"
        Me.ToolStripSeparator15.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateTV6
        '
        Me.cmdUpdateTV6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV6.Image = CType(resources.GetObject("cmdUpdateTV6.Image"), System.Drawing.Image)
        Me.cmdUpdateTV6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV6.Name = "cmdUpdateTV6"
        Me.cmdUpdateTV6.Size = New System.Drawing.Size(34, 22)
        Me.cmdUpdateTV6.Text = "TV 6"
        Me.cmdUpdateTV6.ToolTipText = "TV 6"
        '
        'ToolStripSeparator16
        '
        Me.ToolStripSeparator16.Name = "ToolStripSeparator16"
        Me.ToolStripSeparator16.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateTV6_Backup
        '
        Me.cmdUpdateTV6_Backup.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV6_Backup.Image = CType(resources.GetObject("cmdUpdateTV6_Backup.Image"), System.Drawing.Image)
        Me.cmdUpdateTV6_Backup.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV6_Backup.Name = "cmdUpdateTV6_Backup"
        Me.cmdUpdateTV6_Backup.Size = New System.Drawing.Size(57, 22)
        Me.cmdUpdateTV6_Backup.Text = "TV 6 Bkp"
        Me.cmdUpdateTV6_Backup.ToolTipText = "TV 6 Backup"
        '
        'ToolStripSeparator17
        '
        Me.ToolStripSeparator17.Name = "ToolStripSeparator17"
        Me.ToolStripSeparator17.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateTV7
        '
        Me.cmdUpdateTV7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV7.Image = CType(resources.GetObject("cmdUpdateTV7.Image"), System.Drawing.Image)
        Me.cmdUpdateTV7.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV7.Name = "cmdUpdateTV7"
        Me.cmdUpdateTV7.Size = New System.Drawing.Size(34, 22)
        Me.cmdUpdateTV7.Text = "TV 7"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateTV7_Backup
        '
        Me.cmdUpdateTV7_Backup.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV7_Backup.Image = CType(resources.GetObject("cmdUpdateTV7_Backup.Image"), System.Drawing.Image)
        Me.cmdUpdateTV7_Backup.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV7_Backup.Name = "cmdUpdateTV7_Backup"
        Me.cmdUpdateTV7_Backup.Size = New System.Drawing.Size(57, 22)
        Me.cmdUpdateTV7_Backup.Text = "TV 7 Bkp"
        Me.cmdUpdateTV7_Backup.ToolTipText = "TV 7 Backup"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateTV8
        '
        Me.cmdUpdateTV8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV8.Image = CType(resources.GetObject("cmdUpdateTV8.Image"), System.Drawing.Image)
        Me.cmdUpdateTV8.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV8.Name = "cmdUpdateTV8"
        Me.cmdUpdateTV8.Size = New System.Drawing.Size(34, 22)
        Me.cmdUpdateTV8.Text = "TV 8"
        '
        'ToolStripSeparator18
        '
        Me.ToolStripSeparator18.Name = "ToolStripSeparator18"
        Me.ToolStripSeparator18.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateTV8_Backup
        '
        Me.cmdUpdateTV8_Backup.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV8_Backup.Image = CType(resources.GetObject("cmdUpdateTV8_Backup.Image"), System.Drawing.Image)
        Me.cmdUpdateTV8_Backup.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV8_Backup.Name = "cmdUpdateTV8_Backup"
        Me.cmdUpdateTV8_Backup.Size = New System.Drawing.Size(57, 22)
        Me.cmdUpdateTV8_Backup.Text = "TV 8 Bkp"
        Me.cmdUpdateTV8_Backup.ToolTipText = "TV 8 Backup"
        '
        'ToolStripSeparator19
        '
        Me.ToolStripSeparator19.Name = "ToolStripSeparator19"
        Me.ToolStripSeparator19.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateTV9
        '
        Me.cmdUpdateTV9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV9.Image = CType(resources.GetObject("cmdUpdateTV9.Image"), System.Drawing.Image)
        Me.cmdUpdateTV9.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV9.Name = "cmdUpdateTV9"
        Me.cmdUpdateTV9.Size = New System.Drawing.Size(34, 22)
        Me.cmdUpdateTV9.Text = "TV 9"
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateTV9_Backup
        '
        Me.cmdUpdateTV9_Backup.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV9_Backup.Image = CType(resources.GetObject("cmdUpdateTV9_Backup.Image"), System.Drawing.Image)
        Me.cmdUpdateTV9_Backup.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV9_Backup.Name = "cmdUpdateTV9_Backup"
        Me.cmdUpdateTV9_Backup.Size = New System.Drawing.Size(57, 22)
        Me.cmdUpdateTV9_Backup.Text = "TV 9 Bkp"
        Me.cmdUpdateTV9_Backup.ToolTipText = "TV 9 Backup"
        '
        'ToolStripSeparator21
        '
        Me.ToolStripSeparator21.Name = "ToolStripSeparator21"
        Me.ToolStripSeparator21.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateTV10
        '
        Me.cmdUpdateTV10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV10.Image = CType(resources.GetObject("cmdUpdateTV10.Image"), System.Drawing.Image)
        Me.cmdUpdateTV10.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV10.Name = "cmdUpdateTV10"
        Me.cmdUpdateTV10.Size = New System.Drawing.Size(40, 22)
        Me.cmdUpdateTV10.Text = "TV 10"
        Me.cmdUpdateTV10.ToolTipText = "TV 10"
        '
        'ToolStripSeparator22
        '
        Me.ToolStripSeparator22.Name = "ToolStripSeparator22"
        Me.ToolStripSeparator22.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateTV10_Backup
        '
        Me.cmdUpdateTV10_Backup.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateTV10_Backup.Image = CType(resources.GetObject("cmdUpdateTV10_Backup.Image"), System.Drawing.Image)
        Me.cmdUpdateTV10_Backup.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateTV10_Backup.Name = "cmdUpdateTV10_Backup"
        Me.cmdUpdateTV10_Backup.Size = New System.Drawing.Size(63, 22)
        Me.cmdUpdateTV10_Backup.Text = "TV 10 Bkp"
        Me.cmdUpdateTV10_Backup.ToolTipText = "TV 10 Backup"
        '
        'ToolStripSeparator23
        '
        Me.ToolStripSeparator23.Name = "ToolStripSeparator23"
        Me.ToolStripSeparator23.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateMovies
        '
        Me.cmdUpdateMovies.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateMovies.Image = CType(resources.GetObject("cmdUpdateMovies.Image"), System.Drawing.Image)
        Me.cmdUpdateMovies.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateMovies.Name = "cmdUpdateMovies"
        Me.cmdUpdateMovies.Size = New System.Drawing.Size(49, 22)
        Me.cmdUpdateMovies.Text = "Movies"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(6, 25)
        '
        'cmdUpdateMovies_Backup
        '
        Me.cmdUpdateMovies_Backup.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdUpdateMovies_Backup.Image = CType(resources.GetObject("cmdUpdateMovies_Backup.Image"), System.Drawing.Image)
        Me.cmdUpdateMovies_Backup.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdUpdateMovies_Backup.Name = "cmdUpdateMovies_Backup"
        Me.cmdUpdateMovies_Backup.Size = New System.Drawing.Size(72, 22)
        Me.cmdUpdateMovies_Backup.Text = "Movies Bkp"
        Me.cmdUpdateMovies_Backup.ToolTipText = "Movies Backup"
        '
        'ToolStripSeparator20
        '
        Me.ToolStripSeparator20.Name = "ToolStripSeparator20"
        Me.ToolStripSeparator20.Size = New System.Drawing.Size(6, 25)
        '
        'cmdReloadDrives
        '
        Me.cmdReloadDrives.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdReloadDrives.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdReloadDrives.Name = "cmdReloadDrives"
        Me.cmdReloadDrives.Size = New System.Drawing.Size(82, 22)
        Me.cmdReloadDrives.Text = "Reload Drives"
        '
        'ToolStripSeparator13
        '
        Me.ToolStripSeparator13.Name = "ToolStripSeparator13"
        Me.ToolStripSeparator13.Size = New System.Drawing.Size(6, 25)
        '
        'txtSearch
        '
        Me.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSearch.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(200, 25)
        '
        'cmdFolderSearch
        '
        Me.cmdFolderSearch.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdFolderSearch.Image = CType(resources.GetObject("cmdFolderSearch.Image"), System.Drawing.Image)
        Me.cmdFolderSearch.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdFolderSearch.Name = "cmdFolderSearch"
        Me.cmdFolderSearch.Size = New System.Drawing.Size(46, 22)
        Me.cmdFolderSearch.Text = "Search"
        Me.cmdFolderSearch.ToolTipText = "Do the Search"
        '
        'cmdFileSearch
        '
        Me.cmdFileSearch.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdFileSearch.Image = CType(resources.GetObject("cmdFileSearch.Image"), System.Drawing.Image)
        Me.cmdFileSearch.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdFileSearch.Name = "cmdFileSearch"
        Me.cmdFileSearch.Size = New System.Drawing.Size(95, 22)
        Me.cmdFileSearch.Text = "Just Files Search"
        Me.cmdFileSearch.ToolTipText = "Do the Search"
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(12, 22)
        Me.ToolStripLabel1.Text = "-"
        '
        'lblNumberOfRows
        '
        Me.lblNumberOfRows.Name = "lblNumberOfRows"
        Me.lblNumberOfRows.Size = New System.Drawing.Size(93, 15)
        Me.lblNumberOfRows.Text = "Number of rows"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.lblErrors, Me.lblLastError, Me.lblMessage})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 550)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1679, 22)
        Me.StatusStrip1.TabIndex = 2
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(59, 17)
        Me.ToolStripStatusLabel1.Text = "Last Error:"
        '
        'lblErrors
        '
        Me.lblErrors.Name = "lblErrors"
        Me.lblErrors.Size = New System.Drawing.Size(37, 17)
        Me.lblErrors.Text = "Errors"
        '
        'lblLastError
        '
        Me.lblLastError.Name = "lblLastError"
        Me.lblLastError.Size = New System.Drawing.Size(73, 17)
        Me.lblLastError.Text = "Error History"
        '
        'lblMessage
        '
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(53, 17)
        Me.lblMessage.Text = "Message"
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 49)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.treDrives)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.lvwMajorFolders)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtDriveFileSummary_Seriesname)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtomdbAPI_SeriesName)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdomdbAPI_IMDB)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdFinished_Listview)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdFinished_RottenTomatoes)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdFinished_OmdbAPI)
        Me.SplitContainer1.Panel2.Controls.Add(Me.chkNonStandard_IgnoreTTCFiles)
        Me.SplitContainer1.Panel2.Controls.Add(Me.chkNonStandard_IgnoreSubtitle)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdToDo_Edit)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdToDo_Add)
        Me.SplitContainer1.Panel2.Controls.Add(Me.chkNonStandard_DoBackup)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdToDo_Delete)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdFinished_ToDo)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdFinished_MumsStuff)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdFinished_KnownDuplicates)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdFinished_ShowList_Dups)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdFinished_AiredShows)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdUpdateStatusUpdateDetails)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdFinishedPeopleLiked_All)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdFinished_UpdateStatus)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdFinished_NonStandardFiles)
        Me.SplitContainer1.Panel2.Controls.Add(Me.tabFiles)
        Me.SplitContainer1.Panel2.Controls.Add(Me.tabDetails)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdFinished_MajorFolders)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdFinished_DriveStatus)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdFinished)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdClose)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cboDrives)
        Me.SplitContainer1.Panel2.Controls.Add(Me.chkUpdateStatus_IgnoreCompleted)
        Me.SplitContainer1.Panel2.Controls.Add(Me.chkUpdateStatus_Missing)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtAiredItems_Title)
        Me.SplitContainer1.Panel2.Controls.Add(Me.prgProgress)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lvwAiredShows)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdomdbAPI_Forward)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lvwPeopleLiked_All)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cboOmdbCountries)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lvwRottenTomatoes)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtAiredItems_FilenameJustSeason)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtDriveFileSummary_FilenameJustSeason)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtDriveFileSummary_FullFilename)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtAiredItems_FullFilename)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cboFileCount)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblUpdateStatus_Report)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtOmdbAPI_Desc)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lvwNonStandardFiles)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lvwMumsStuff)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lvwToDo)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lvwKnownDups)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdDriveFileSummary_FullFilename_Copy)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtAiredItems_FullFilenamewithoutETTV)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdDriveFileSummary_SeriesName_Copy)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdAiredItems_SeriesName_Copy)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdAiredItems_Title_Copy)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdAiredItems_FullFilename_Copy)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdDriveFileSummary_FullFilenamewithoutETTV_Copy)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdAiredItems_FullFilenamewithoutETTV_Copy)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdDriveFileSummary_FilenameJustSeason_Copy)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdAiredItems_FilenameJustSeason_Copy)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdShowList_Dups_TrollList)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lvwShowList_Dups)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtAiredItems_Seriesname)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lvwUpdateStatus)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lvwSearchResults)
        Me.SplitContainer1.Panel2.Controls.Add(Me.calCalendar_AirDates)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtDriveFileSummary_FullFilenamewithoutETTV)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblAiredItems_ExplanationoftxtAiredItems_Title)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lvwListView)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lvwDriveStatus)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdAiredItems_Process)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cboOmdbTitleLetter)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblDriveFileSummary_Info)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtDriveSummary_Desc)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdomdbAPI_Back)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lvwOmdbAPI)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtMultiLineTextbox)
        Me.SplitContainer1.Size = New System.Drawing.Size(1679, 501)
        Me.SplitContainer1.SplitterDistance = 556
        Me.SplitContainer1.TabIndex = 3
        '
        'treDrives
        '
        Me.treDrives.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.treDrives.FullRowSelect = True
        Me.treDrives.HideSelection = False
        Me.treDrives.Location = New System.Drawing.Point(3, 1)
        Me.treDrives.Name = "treDrives"
        Me.treDrives.Size = New System.Drawing.Size(556, 497)
        Me.treDrives.TabIndex = 1
        '
        'lvwMajorFolders
        '
        Me.lvwMajorFolders.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader9, Me.ColumnHeader10, Me.ColumnHeader67})
        Me.lvwMajorFolders.FullRowSelect = True
        Me.lvwMajorFolders.GridLines = True
        Me.lvwMajorFolders.HideSelection = False
        Me.lvwMajorFolders.Location = New System.Drawing.Point(957, 71)
        Me.lvwMajorFolders.Name = "lvwMajorFolders"
        Me.lvwMajorFolders.Size = New System.Drawing.Size(513, 159)
        Me.lvwMajorFolders.TabIndex = 8
        Me.lvwMajorFolders.UseCompatibleStateImageBehavior = False
        Me.lvwMajorFolders.View = System.Windows.Forms.View.Details
        Me.lvwMajorFolders.Visible = False
        '
        'ColumnHeader9
        '
        Me.ColumnHeader9.Text = "Drive"
        Me.ColumnHeader9.Width = 70
        '
        'ColumnHeader10
        '
        Me.ColumnHeader10.Text = "Label"
        Me.ColumnHeader10.Width = 120
        '
        'ColumnHeader67
        '
        Me.ColumnHeader67.Text = "Folder"
        Me.ColumnHeader67.Width = 250
        '
        'txtDriveFileSummary_Seriesname
        '
        Me.txtDriveFileSummary_Seriesname.BackColor = System.Drawing.SystemColors.Window
        Me.txtDriveFileSummary_Seriesname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDriveFileSummary_Seriesname.Location = New System.Drawing.Point(918, 29)
        Me.txtDriveFileSummary_Seriesname.Name = "txtDriveFileSummary_Seriesname"
        Me.txtDriveFileSummary_Seriesname.ReadOnly = True
        Me.txtDriveFileSummary_Seriesname.Size = New System.Drawing.Size(500, 20)
        Me.txtDriveFileSummary_Seriesname.TabIndex = 86
        Me.txtDriveFileSummary_Seriesname.TabStop = False
        Me.txtDriveFileSummary_Seriesname.Visible = False
        '
        'txtomdbAPI_SeriesName
        '
        Me.txtomdbAPI_SeriesName.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtomdbAPI_SeriesName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtomdbAPI_SeriesName.Location = New System.Drawing.Point(934, 29)
        Me.txtomdbAPI_SeriesName.Name = "txtomdbAPI_SeriesName"
        Me.txtomdbAPI_SeriesName.ReadOnly = True
        Me.txtomdbAPI_SeriesName.Size = New System.Drawing.Size(250, 20)
        Me.txtomdbAPI_SeriesName.TabIndex = 72
        Me.txtomdbAPI_SeriesName.TabStop = False
        Me.txtomdbAPI_SeriesName.Visible = False
        '
        'cmdomdbAPI_IMDB
        '
        Me.cmdomdbAPI_IMDB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdomdbAPI_IMDB.Image = CType(resources.GetObject("cmdomdbAPI_IMDB.Image"), System.Drawing.Image)
        Me.cmdomdbAPI_IMDB.Location = New System.Drawing.Point(936, 47)
        Me.cmdomdbAPI_IMDB.Name = "cmdomdbAPI_IMDB"
        Me.cmdomdbAPI_IMDB.Size = New System.Drawing.Size(30, 20)
        Me.cmdomdbAPI_IMDB.TabIndex = 70
        Me.cmdomdbAPI_IMDB.UseVisualStyleBackColor = True
        Me.cmdomdbAPI_IMDB.Visible = False
        '
        'cmdFinished_Listview
        '
        Me.cmdFinished_Listview.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdFinished_Listview.Location = New System.Drawing.Point(355, 475)
        Me.cmdFinished_Listview.Name = "cmdFinished_Listview"
        Me.cmdFinished_Listview.Size = New System.Drawing.Size(93, 25)
        Me.cmdFinished_Listview.TabIndex = 61
        Me.cmdFinished_Listview.Text = "Finished"
        Me.cmdFinished_Listview.UseVisualStyleBackColor = True
        Me.cmdFinished_Listview.Visible = False
        '
        'cmdFinished_RottenTomatoes
        '
        Me.cmdFinished_RottenTomatoes.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdFinished_RottenTomatoes.Location = New System.Drawing.Point(417, 478)
        Me.cmdFinished_RottenTomatoes.Name = "cmdFinished_RottenTomatoes"
        Me.cmdFinished_RottenTomatoes.Size = New System.Drawing.Size(93, 25)
        Me.cmdFinished_RottenTomatoes.TabIndex = 58
        Me.cmdFinished_RottenTomatoes.Text = "Finished"
        Me.cmdFinished_RottenTomatoes.UseVisualStyleBackColor = True
        Me.cmdFinished_RottenTomatoes.Visible = False
        '
        'cmdFinished_OmdbAPI
        '
        Me.cmdFinished_OmdbAPI.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdFinished_OmdbAPI.Location = New System.Drawing.Point(355, 475)
        Me.cmdFinished_OmdbAPI.Name = "cmdFinished_OmdbAPI"
        Me.cmdFinished_OmdbAPI.Size = New System.Drawing.Size(93, 25)
        Me.cmdFinished_OmdbAPI.TabIndex = 52
        Me.cmdFinished_OmdbAPI.Text = "Finished"
        Me.cmdFinished_OmdbAPI.UseVisualStyleBackColor = True
        Me.cmdFinished_OmdbAPI.Visible = False
        '
        'chkNonStandard_IgnoreTTCFiles
        '
        Me.chkNonStandard_IgnoreTTCFiles.AutoSize = True
        Me.chkNonStandard_IgnoreTTCFiles.Location = New System.Drawing.Point(1080, 185)
        Me.chkNonStandard_IgnoreTTCFiles.Name = "chkNonStandard_IgnoreTTCFiles"
        Me.chkNonStandard_IgnoreTTCFiles.Size = New System.Drawing.Size(104, 17)
        Me.chkNonStandard_IgnoreTTCFiles.TabIndex = 51
        Me.chkNonStandard_IgnoreTTCFiles.Text = "Ignore TTC Files"
        Me.chkNonStandard_IgnoreTTCFiles.UseVisualStyleBackColor = True
        Me.chkNonStandard_IgnoreTTCFiles.Visible = False
        '
        'chkNonStandard_IgnoreSubtitle
        '
        Me.chkNonStandard_IgnoreSubtitle.AutoSize = True
        Me.chkNonStandard_IgnoreSubtitle.Location = New System.Drawing.Point(1080, 208)
        Me.chkNonStandard_IgnoreSubtitle.Name = "chkNonStandard_IgnoreSubtitle"
        Me.chkNonStandard_IgnoreSubtitle.Size = New System.Drawing.Size(99, 17)
        Me.chkNonStandard_IgnoreSubtitle.TabIndex = 50
        Me.chkNonStandard_IgnoreSubtitle.Text = "Ignore Subtitles"
        Me.chkNonStandard_IgnoreSubtitle.UseVisualStyleBackColor = True
        Me.chkNonStandard_IgnoreSubtitle.Visible = False
        '
        'cmdToDo_Edit
        '
        Me.cmdToDo_Edit.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdToDo_Edit.Location = New System.Drawing.Point(475, 478)
        Me.cmdToDo_Edit.Name = "cmdToDo_Edit"
        Me.cmdToDo_Edit.Size = New System.Drawing.Size(75, 25)
        Me.cmdToDo_Edit.TabIndex = 47
        Me.cmdToDo_Edit.Text = "Edit"
        Me.cmdToDo_Edit.UseVisualStyleBackColor = True
        Me.cmdToDo_Edit.Visible = False
        '
        'cmdToDo_Add
        '
        Me.cmdToDo_Add.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdToDo_Add.Location = New System.Drawing.Point(400, 478)
        Me.cmdToDo_Add.Name = "cmdToDo_Add"
        Me.cmdToDo_Add.Size = New System.Drawing.Size(75, 25)
        Me.cmdToDo_Add.TabIndex = 46
        Me.cmdToDo_Add.Text = "Add"
        Me.cmdToDo_Add.UseVisualStyleBackColor = True
        Me.cmdToDo_Add.Visible = False
        '
        'chkNonStandard_DoBackup
        '
        Me.chkNonStandard_DoBackup.AutoSize = True
        Me.chkNonStandard_DoBackup.Location = New System.Drawing.Point(936, 223)
        Me.chkNonStandard_DoBackup.Name = "chkNonStandard_DoBackup"
        Me.chkNonStandard_DoBackup.Size = New System.Drawing.Size(85, 17)
        Me.chkNonStandard_DoBackup.TabIndex = 49
        Me.chkNonStandard_DoBackup.Text = "Do Backups"
        Me.chkNonStandard_DoBackup.UseVisualStyleBackColor = True
        Me.chkNonStandard_DoBackup.Visible = False
        '
        'cmdToDo_Delete
        '
        Me.cmdToDo_Delete.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdToDo_Delete.Location = New System.Drawing.Point(549, 486)
        Me.cmdToDo_Delete.Name = "cmdToDo_Delete"
        Me.cmdToDo_Delete.Size = New System.Drawing.Size(75, 25)
        Me.cmdToDo_Delete.TabIndex = 48
        Me.cmdToDo_Delete.Text = "Delete"
        Me.cmdToDo_Delete.UseVisualStyleBackColor = True
        Me.cmdToDo_Delete.Visible = False
        '
        'cmdFinished_ToDo
        '
        Me.cmdFinished_ToDo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdFinished_ToDo.Location = New System.Drawing.Point(295, 475)
        Me.cmdFinished_ToDo.Name = "cmdFinished_ToDo"
        Me.cmdFinished_ToDo.Size = New System.Drawing.Size(93, 25)
        Me.cmdFinished_ToDo.TabIndex = 45
        Me.cmdFinished_ToDo.Text = "Finished"
        Me.cmdFinished_ToDo.UseVisualStyleBackColor = True
        Me.cmdFinished_ToDo.Visible = False
        '
        'cmdFinished_MumsStuff
        '
        Me.cmdFinished_MumsStuff.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdFinished_MumsStuff.Location = New System.Drawing.Point(191, 475)
        Me.cmdFinished_MumsStuff.Name = "cmdFinished_MumsStuff"
        Me.cmdFinished_MumsStuff.Size = New System.Drawing.Size(93, 25)
        Me.cmdFinished_MumsStuff.TabIndex = 43
        Me.cmdFinished_MumsStuff.Text = "Finished"
        Me.cmdFinished_MumsStuff.UseVisualStyleBackColor = True
        Me.cmdFinished_MumsStuff.Visible = False
        '
        'cmdFinished_KnownDuplicates
        '
        Me.cmdFinished_KnownDuplicates.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdFinished_KnownDuplicates.Location = New System.Drawing.Point(37, 473)
        Me.cmdFinished_KnownDuplicates.Name = "cmdFinished_KnownDuplicates"
        Me.cmdFinished_KnownDuplicates.Size = New System.Drawing.Size(93, 25)
        Me.cmdFinished_KnownDuplicates.TabIndex = 41
        Me.cmdFinished_KnownDuplicates.Text = "Finished"
        Me.cmdFinished_KnownDuplicates.UseVisualStyleBackColor = True
        Me.cmdFinished_KnownDuplicates.Visible = False
        '
        'cmdFinished_ShowList_Dups
        '
        Me.cmdFinished_ShowList_Dups.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdFinished_ShowList_Dups.Location = New System.Drawing.Point(136, 473)
        Me.cmdFinished_ShowList_Dups.Name = "cmdFinished_ShowList_Dups"
        Me.cmdFinished_ShowList_Dups.Size = New System.Drawing.Size(93, 25)
        Me.cmdFinished_ShowList_Dups.TabIndex = 39
        Me.cmdFinished_ShowList_Dups.Text = "Finished"
        Me.cmdFinished_ShowList_Dups.UseVisualStyleBackColor = True
        Me.cmdFinished_ShowList_Dups.Visible = False
        '
        'cmdFinished_AiredShows
        '
        Me.cmdFinished_AiredShows.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdFinished_AiredShows.Location = New System.Drawing.Point(235, 473)
        Me.cmdFinished_AiredShows.Name = "cmdFinished_AiredShows"
        Me.cmdFinished_AiredShows.Size = New System.Drawing.Size(93, 25)
        Me.cmdFinished_AiredShows.TabIndex = 34
        Me.cmdFinished_AiredShows.Text = "Finished"
        Me.cmdFinished_AiredShows.UseVisualStyleBackColor = True
        Me.cmdFinished_AiredShows.Visible = False
        '
        'cmdUpdateStatusUpdateDetails
        '
        Me.cmdUpdateStatusUpdateDetails.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdUpdateStatusUpdateDetails.Location = New System.Drawing.Point(333, 473)
        Me.cmdUpdateStatusUpdateDetails.Name = "cmdUpdateStatusUpdateDetails"
        Me.cmdUpdateStatusUpdateDetails.Size = New System.Drawing.Size(93, 25)
        Me.cmdUpdateStatusUpdateDetails.TabIndex = 31
        Me.cmdUpdateStatusUpdateDetails.Text = "Update"
        Me.cmdUpdateStatusUpdateDetails.UseVisualStyleBackColor = True
        Me.cmdUpdateStatusUpdateDetails.Visible = False
        '
        'cmdFinishedPeopleLiked_All
        '
        Me.cmdFinishedPeopleLiked_All.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdFinishedPeopleLiked_All.Location = New System.Drawing.Point(432, 473)
        Me.cmdFinishedPeopleLiked_All.Name = "cmdFinishedPeopleLiked_All"
        Me.cmdFinishedPeopleLiked_All.Size = New System.Drawing.Size(93, 25)
        Me.cmdFinishedPeopleLiked_All.TabIndex = 30
        Me.cmdFinishedPeopleLiked_All.Text = "Finished"
        Me.cmdFinishedPeopleLiked_All.UseVisualStyleBackColor = True
        Me.cmdFinishedPeopleLiked_All.Visible = False
        '
        'cmdFinished_UpdateStatus
        '
        Me.cmdFinished_UpdateStatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdFinished_UpdateStatus.Location = New System.Drawing.Point(531, 473)
        Me.cmdFinished_UpdateStatus.Name = "cmdFinished_UpdateStatus"
        Me.cmdFinished_UpdateStatus.Size = New System.Drawing.Size(93, 25)
        Me.cmdFinished_UpdateStatus.TabIndex = 28
        Me.cmdFinished_UpdateStatus.Text = "Finished"
        Me.cmdFinished_UpdateStatus.UseVisualStyleBackColor = True
        Me.cmdFinished_UpdateStatus.Visible = False
        '
        'cmdFinished_NonStandardFiles
        '
        Me.cmdFinished_NonStandardFiles.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdFinished_NonStandardFiles.Location = New System.Drawing.Point(630, 473)
        Me.cmdFinished_NonStandardFiles.Name = "cmdFinished_NonStandardFiles"
        Me.cmdFinished_NonStandardFiles.Size = New System.Drawing.Size(93, 25)
        Me.cmdFinished_NonStandardFiles.TabIndex = 13
        Me.cmdFinished_NonStandardFiles.Text = "Finished"
        Me.cmdFinished_NonStandardFiles.UseVisualStyleBackColor = True
        Me.cmdFinished_NonStandardFiles.Visible = False
        '
        'tabFiles
        '
        Me.tabFiles.Controls.Add(Me.TabPage1)
        Me.tabFiles.Controls.Add(Me.TabPage2)
        Me.tabFiles.Controls.Add(Me.TabPage5)
        Me.tabFiles.Controls.Add(Me.TabPage6)
        Me.tabFiles.Controls.Add(Me.TabPage7)
        Me.tabFiles.Controls.Add(Me.TabPage8)
        Me.tabFiles.Controls.Add(Me.TabPage9)
        Me.tabFiles.Controls.Add(Me.TabPage10)
        Me.tabFiles.Location = New System.Drawing.Point(3, 1)
        Me.tabFiles.Name = "tabFiles"
        Me.tabFiles.SelectedIndex = 0
        Me.tabFiles.Size = New System.Drawing.Size(913, 201)
        Me.tabFiles.TabIndex = 10
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.lvwFiles)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(905, 175)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Files on Disc"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'lvwFiles
        '
        Me.lvwFiles.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colFileName, Me.ColumnHeader2, Me.ColumnHeader4, Me.ColumnHeader3})
        Me.lvwFiles.FullRowSelect = True
        Me.lvwFiles.GridLines = True
        Me.lvwFiles.HideSelection = False
        Me.lvwFiles.Location = New System.Drawing.Point(7, 6)
        Me.lvwFiles.Name = "lvwFiles"
        Me.lvwFiles.Size = New System.Drawing.Size(867, 127)
        Me.lvwFiles.TabIndex = 2
        Me.lvwFiles.UseCompatibleStateImageBehavior = False
        Me.lvwFiles.View = System.Windows.Forms.View.Details
        '
        'colFileName
        '
        Me.colFileName.Text = "Name"
        Me.colFileName.Width = 150
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Type"
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Modified Date"
        Me.ColumnHeader4.Width = 160
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Size"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.txtPlot)
        Me.TabPage2.Controls.Add(Me.lvwIMDBFiles)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(905, 175)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "IMDB"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'txtPlot
        '
        Me.txtPlot.BackColor = System.Drawing.SystemColors.Window
        Me.txtPlot.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPlot.Location = New System.Drawing.Point(6, 96)
        Me.txtPlot.Multiline = True
        Me.txtPlot.Name = "txtPlot"
        Me.txtPlot.ReadOnly = True
        Me.txtPlot.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtPlot.Size = New System.Drawing.Size(867, 60)
        Me.txtPlot.TabIndex = 4
        Me.txtPlot.TabStop = False
        '
        'lvwIMDBFiles
        '
        Me.lvwIMDBFiles.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colName_, Me.colAirDate})
        Me.lvwIMDBFiles.FullRowSelect = True
        Me.lvwIMDBFiles.GridLines = True
        Me.lvwIMDBFiles.HideSelection = False
        Me.lvwIMDBFiles.Location = New System.Drawing.Point(6, 6)
        Me.lvwIMDBFiles.MultiSelect = False
        Me.lvwIMDBFiles.Name = "lvwIMDBFiles"
        Me.lvwIMDBFiles.Size = New System.Drawing.Size(867, 127)
        Me.lvwIMDBFiles.TabIndex = 3
        Me.lvwIMDBFiles.UseCompatibleStateImageBehavior = False
        Me.lvwIMDBFiles.View = System.Windows.Forms.View.Details
        '
        'colName_
        '
        Me.colName_.Text = "Name"
        Me.colName_.Width = 150
        '
        'colAirDate
        '
        Me.colAirDate.Text = "Air Date"
        Me.colAirDate.Width = 120
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.fraOperations)
        Me.TabPage5.Controls.Add(Me.lvwUpdatefilenames)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(905, 175)
        Me.TabPage5.TabIndex = 2
        Me.TabPage5.Text = "Update Filenames"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'fraOperations
        '
        Me.fraOperations.Controls.Add(Me.txtUpdFilenamesHelp)
        Me.fraOperations.Controls.Add(Me.cmdUpdFilesRemoveItemFromGrid)
        Me.fraOperations.Controls.Add(Me.cmdUpdFilesUpdateFilenamesInListview)
        Me.fraOperations.Controls.Add(Me.cmdUpdFilesRemoveSelectionsinGrid)
        Me.fraOperations.Controls.Add(Me.txtCurrentFilename)
        Me.fraOperations.Controls.Add(Me.cmdUpdFilesApplyProposedFilenames)
        Me.fraOperations.Controls.Add(Me.cmdUpdFilesRevertToOriginalNames)
        Me.fraOperations.Controls.Add(Me.txtOperationTextbox2)
        Me.fraOperations.Controls.Add(Me.txtOperationTextbox1)
        Me.fraOperations.Controls.Add(Me.lblOperationLabel2)
        Me.fraOperations.Controls.Add(Me.lblOperationLabel1)
        Me.fraOperations.Controls.Add(Me.lstOperations)
        Me.fraOperations.Location = New System.Drawing.Point(6, 46)
        Me.fraOperations.Name = "fraOperations"
        Me.fraOperations.Size = New System.Drawing.Size(893, 114)
        Me.fraOperations.TabIndex = 4
        Me.fraOperations.TabStop = False
        Me.fraOperations.Text = "Operations"
        '
        'txtUpdFilenamesHelp
        '
        Me.txtUpdFilenamesHelp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtUpdFilenamesHelp.Location = New System.Drawing.Point(730, 27)
        Me.txtUpdFilenamesHelp.Multiline = True
        Me.txtUpdFilenamesHelp.Name = "txtUpdFilenamesHelp"
        Me.txtUpdFilenamesHelp.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtUpdFilenamesHelp.Size = New System.Drawing.Size(340, 100)
        Me.txtUpdFilenamesHelp.TabIndex = 20
        '
        'cmdUpdFilesRemoveItemFromGrid
        '
        Me.cmdUpdFilesRemoveItemFromGrid.Location = New System.Drawing.Point(515, 83)
        Me.cmdUpdFilesRemoveItemFromGrid.Name = "cmdUpdFilesRemoveItemFromGrid"
        Me.cmdUpdFilesRemoveItemFromGrid.Size = New System.Drawing.Size(158, 25)
        Me.cmdUpdFilesRemoveItemFromGrid.TabIndex = 19
        Me.cmdUpdFilesRemoveItemFromGrid.Text = "Remove Item From Grid"
        Me.cmdUpdFilesRemoveItemFromGrid.UseVisualStyleBackColor = True
        '
        'cmdUpdFilesUpdateFilenamesInListview
        '
        Me.cmdUpdFilesUpdateFilenamesInListview.Location = New System.Drawing.Point(6, 83)
        Me.cmdUpdFilesUpdateFilenamesInListview.Name = "cmdUpdFilesUpdateFilenamesInListview"
        Me.cmdUpdFilesUpdateFilenamesInListview.Size = New System.Drawing.Size(162, 25)
        Me.cmdUpdFilesUpdateFilenamesInListview.TabIndex = 8
        Me.cmdUpdFilesUpdateFilenamesInListview.Text = "Update Filenames in Listview"
        Me.cmdUpdFilesUpdateFilenamesInListview.UseVisualStyleBackColor = True
        '
        'cmdUpdFilesRemoveSelectionsinGrid
        '
        Me.cmdUpdFilesRemoveSelectionsinGrid.Location = New System.Drawing.Point(349, 83)
        Me.cmdUpdFilesRemoveSelectionsinGrid.Name = "cmdUpdFilesRemoveSelectionsinGrid"
        Me.cmdUpdFilesRemoveSelectionsinGrid.Size = New System.Drawing.Size(158, 25)
        Me.cmdUpdFilesRemoveSelectionsinGrid.TabIndex = 17
        Me.cmdUpdFilesRemoveSelectionsinGrid.Text = "Remove Selections in Grid"
        Me.cmdUpdFilesRemoveSelectionsinGrid.UseVisualStyleBackColor = True
        '
        'txtCurrentFilename
        '
        Me.txtCurrentFilename.Location = New System.Drawing.Point(244, 26)
        Me.txtCurrentFilename.Name = "txtCurrentFilename"
        Me.txtCurrentFilename.ReadOnly = True
        Me.txtCurrentFilename.Size = New System.Drawing.Size(475, 20)
        Me.txtCurrentFilename.TabIndex = 16
        '
        'cmdUpdFilesApplyProposedFilenames
        '
        Me.cmdUpdFilesApplyProposedFilenames.Location = New System.Drawing.Point(700, 83)
        Me.cmdUpdFilesApplyProposedFilenames.Name = "cmdUpdFilesApplyProposedFilenames"
        Me.cmdUpdFilesApplyProposedFilenames.Size = New System.Drawing.Size(145, 25)
        Me.cmdUpdFilesApplyProposedFilenames.TabIndex = 15
        Me.cmdUpdFilesApplyProposedFilenames.Text = "Update Filenames on Disk"
        Me.cmdUpdFilesApplyProposedFilenames.UseVisualStyleBackColor = True
        '
        'cmdUpdFilesRevertToOriginalNames
        '
        Me.cmdUpdFilesRevertToOriginalNames.Location = New System.Drawing.Point(176, 83)
        Me.cmdUpdFilesRevertToOriginalNames.Name = "cmdUpdFilesRevertToOriginalNames"
        Me.cmdUpdFilesRevertToOriginalNames.Size = New System.Drawing.Size(166, 25)
        Me.cmdUpdFilesRevertToOriginalNames.TabIndex = 14
        Me.cmdUpdFilesRevertToOriginalNames.Text = "Restore Filenames in Listview"
        Me.cmdUpdFilesRevertToOriginalNames.UseVisualStyleBackColor = True
        '
        'txtOperationTextbox2
        '
        Me.txtOperationTextbox2.Location = New System.Drawing.Point(463, 83)
        Me.txtOperationTextbox2.Name = "txtOperationTextbox2"
        Me.txtOperationTextbox2.Size = New System.Drawing.Size(210, 20)
        Me.txtOperationTextbox2.TabIndex = 13
        Me.txtOperationTextbox2.Visible = False
        '
        'txtOperationTextbox1
        '
        Me.txtOperationTextbox1.Location = New System.Drawing.Point(242, 83)
        Me.txtOperationTextbox1.Name = "txtOperationTextbox1"
        Me.txtOperationTextbox1.Size = New System.Drawing.Size(210, 20)
        Me.txtOperationTextbox1.TabIndex = 12
        Me.txtOperationTextbox1.Visible = False
        '
        'lblOperationLabel2
        '
        Me.lblOperationLabel2.AutoSize = True
        Me.lblOperationLabel2.Location = New System.Drawing.Point(460, 61)
        Me.lblOperationLabel2.Name = "lblOperationLabel2"
        Me.lblOperationLabel2.Size = New System.Drawing.Size(39, 13)
        Me.lblOperationLabel2.TabIndex = 11
        Me.lblOperationLabel2.Text = "Label5"
        Me.lblOperationLabel2.Visible = False
        '
        'lblOperationLabel1
        '
        Me.lblOperationLabel1.AutoSize = True
        Me.lblOperationLabel1.Location = New System.Drawing.Point(239, 61)
        Me.lblOperationLabel1.Name = "lblOperationLabel1"
        Me.lblOperationLabel1.Size = New System.Drawing.Size(39, 13)
        Me.lblOperationLabel1.TabIndex = 10
        Me.lblOperationLabel1.Text = "Label4"
        Me.lblOperationLabel1.Visible = False
        '
        'lstOperations
        '
        Me.lstOperations.FormattingEnabled = True
        Me.lstOperations.Location = New System.Drawing.Point(6, 26)
        Me.lstOperations.Name = "lstOperations"
        Me.lstOperations.Size = New System.Drawing.Size(232, 108)
        Me.lstOperations.TabIndex = 18
        '
        'lvwUpdatefilenames
        '
        Me.lvwUpdatefilenames.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colNameOnDisk, Me.colTypeOnDisk, Me.colProposedName})
        Me.lvwUpdatefilenames.FullRowSelect = True
        Me.lvwUpdatefilenames.GridLines = True
        Me.lvwUpdatefilenames.HideSelection = False
        Me.lvwUpdatefilenames.Location = New System.Drawing.Point(6, 6)
        Me.lvwUpdatefilenames.Name = "lvwUpdatefilenames"
        Me.lvwUpdatefilenames.Size = New System.Drawing.Size(867, 60)
        Me.lvwUpdatefilenames.TabIndex = 3
        Me.lvwUpdatefilenames.UseCompatibleStateImageBehavior = False
        Me.lvwUpdatefilenames.View = System.Windows.Forms.View.Details
        '
        'colNameOnDisk
        '
        Me.colNameOnDisk.Text = "Name on Disk"
        Me.colNameOnDisk.Width = 150
        '
        'colTypeOnDisk
        '
        Me.colTypeOnDisk.Text = "Type"
        '
        'colProposedName
        '
        Me.colProposedName.Text = "Proposed Name"
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.cmdSeasonsTab_Order)
        Me.TabPage6.Controls.Add(Me.lvwSeasons)
        Me.TabPage6.Controls.Add(Me.txtSeasonsTab_Plot)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(905, 175)
        Me.TabPage6.TabIndex = 3
        Me.TabPage6.Text = "Seasons"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'cmdSeasonsTab_Order
        '
        Me.cmdSeasonsTab_Order.Location = New System.Drawing.Point(822, 136)
        Me.cmdSeasonsTab_Order.Name = "cmdSeasonsTab_Order"
        Me.cmdSeasonsTab_Order.Size = New System.Drawing.Size(83, 25)
        Me.cmdSeasonsTab_Order.TabIndex = 53
        Me.cmdSeasonsTab_Order.Text = "Reorder"
        Me.ToolTip1.SetToolTip(Me.cmdSeasonsTab_Order, "Reorder the seasons")
        Me.cmdSeasonsTab_Order.UseVisualStyleBackColor = True
        '
        'lvwSeasons
        '
        Me.lvwSeasons.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colSeason, Me.colEpisode, Me.coltitle, Me.Airdate})
        Me.lvwSeasons.FullRowSelect = True
        Me.lvwSeasons.GridLines = True
        Me.lvwSeasons.HideSelection = False
        Me.lvwSeasons.Location = New System.Drawing.Point(6, 6)
        Me.lvwSeasons.MultiSelect = False
        Me.lvwSeasons.Name = "lvwSeasons"
        Me.lvwSeasons.Size = New System.Drawing.Size(867, 127)
        Me.lvwSeasons.TabIndex = 6
        Me.lvwSeasons.UseCompatibleStateImageBehavior = False
        Me.lvwSeasons.View = System.Windows.Forms.View.Details
        '
        'colSeason
        '
        Me.colSeason.Text = "Season"
        Me.colSeason.Width = 80
        '
        'colEpisode
        '
        Me.colEpisode.Text = "Episode"
        Me.colEpisode.Width = 80
        '
        'coltitle
        '
        Me.coltitle.Text = "Title"
        Me.coltitle.Width = 300
        '
        'Airdate
        '
        Me.Airdate.Text = "Airdate"
        Me.Airdate.Width = 120
        '
        'txtSeasonsTab_Plot
        '
        Me.txtSeasonsTab_Plot.BackColor = System.Drawing.SystemColors.Window
        Me.txtSeasonsTab_Plot.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSeasonsTab_Plot.Location = New System.Drawing.Point(6, 101)
        Me.txtSeasonsTab_Plot.Multiline = True
        Me.txtSeasonsTab_Plot.Name = "txtSeasonsTab_Plot"
        Me.txtSeasonsTab_Plot.ReadOnly = True
        Me.txtSeasonsTab_Plot.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtSeasonsTab_Plot.Size = New System.Drawing.Size(806, 60)
        Me.txtSeasonsTab_Plot.TabIndex = 5
        Me.txtSeasonsTab_Plot.TabStop = False
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.lvwPeopleLiked)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(905, 175)
        Me.TabPage7.TabIndex = 4
        Me.TabPage7.Text = "People Also Liked"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'lvwPeopleLiked
        '
        Me.lvwPeopleLiked.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader13, Me.ColumnHeader22})
        Me.lvwPeopleLiked.FullRowSelect = True
        Me.lvwPeopleLiked.GridLines = True
        Me.lvwPeopleLiked.HideSelection = False
        Me.lvwPeopleLiked.Location = New System.Drawing.Point(6, 6)
        Me.lvwPeopleLiked.MultiSelect = False
        Me.lvwPeopleLiked.Name = "lvwPeopleLiked"
        Me.lvwPeopleLiked.Size = New System.Drawing.Size(867, 127)
        Me.lvwPeopleLiked.TabIndex = 4
        Me.lvwPeopleLiked.UseCompatibleStateImageBehavior = False
        Me.lvwPeopleLiked.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Name"
        Me.ColumnHeader1.Width = 150
        '
        'ColumnHeader13
        '
        Me.ColumnHeader13.Text = "Rating"
        '
        'ColumnHeader22
        '
        Me.ColumnHeader22.Text = "Desc"
        Me.ColumnHeader22.Width = 1000
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.cmdCompletedSeasons)
        Me.TabPage8.Controls.Add(Me.cboCompletedSeasons)
        Me.TabPage8.Controls.Add(Me.lblCompletedSeasons)
        Me.TabPage8.Controls.Add(Me.lvwCompletedFiles)
        Me.TabPage8.Location = New System.Drawing.Point(4, 22)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(905, 175)
        Me.TabPage8.TabIndex = 5
        Me.TabPage8.Text = "Completed"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'cmdCompletedSeasons
        '
        Me.cmdCompletedSeasons.Location = New System.Drawing.Point(225, 150)
        Me.cmdCompletedSeasons.Name = "cmdCompletedSeasons"
        Me.cmdCompletedSeasons.Size = New System.Drawing.Size(85, 21)
        Me.cmdCompletedSeasons.TabIndex = 32
        Me.cmdCompletedSeasons.Text = "Reload"
        Me.cmdCompletedSeasons.UseVisualStyleBackColor = True
        '
        'cboCompletedSeasons
        '
        Me.cboCompletedSeasons.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCompletedSeasons.FormattingEnabled = True
        Me.cboCompletedSeasons.Items.AddRange(New Object() {"", "IMDB", "TV.com"})
        Me.cboCompletedSeasons.Location = New System.Drawing.Point(57, 151)
        Me.cboCompletedSeasons.Name = "cboCompletedSeasons"
        Me.cboCompletedSeasons.Size = New System.Drawing.Size(160, 21)
        Me.cboCompletedSeasons.TabIndex = 31
        '
        'lblCompletedSeasons
        '
        Me.lblCompletedSeasons.AutoSize = True
        Me.lblCompletedSeasons.Location = New System.Drawing.Point(4, 154)
        Me.lblCompletedSeasons.Name = "lblCompletedSeasons"
        Me.lblCompletedSeasons.Size = New System.Drawing.Size(51, 13)
        Me.lblCompletedSeasons.TabIndex = 30
        Me.lblCompletedSeasons.Text = "Seasons:"
        '
        'lvwCompletedFiles
        '
        Me.lvwCompletedFiles.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colCompPath, Me.colCompName})
        Me.lvwCompletedFiles.FullRowSelect = True
        Me.lvwCompletedFiles.GridLines = True
        Me.lvwCompletedFiles.HideSelection = False
        Me.lvwCompletedFiles.Location = New System.Drawing.Point(7, 11)
        Me.lvwCompletedFiles.MultiSelect = False
        Me.lvwCompletedFiles.Name = "lvwCompletedFiles"
        Me.lvwCompletedFiles.Size = New System.Drawing.Size(891, 137)
        Me.lvwCompletedFiles.TabIndex = 5
        Me.lvwCompletedFiles.UseCompatibleStateImageBehavior = False
        Me.lvwCompletedFiles.View = System.Windows.Forms.View.Details
        '
        'colCompPath
        '
        Me.colCompPath.Text = "Path"
        Me.colCompPath.Width = 450
        '
        'colCompName
        '
        Me.colCompName.Text = "Name"
        Me.colCompName.Width = 275
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.chkUpdateStatus_IgnoreCompleted_Tab)
        Me.TabPage9.Controls.Add(Me.lvwUpdateStatus_Tab)
        Me.TabPage9.Controls.Add(Me.chkUpdateStatus_Missing_Tab)
        Me.TabPage9.Controls.Add(Me.cboDrives_Tab)
        Me.TabPage9.Location = New System.Drawing.Point(4, 22)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(905, 175)
        Me.TabPage9.TabIndex = 6
        Me.TabPage9.Text = "Missing Items"
        Me.TabPage9.ToolTipText = "Update Status / Missing Items"
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'chkUpdateStatus_IgnoreCompleted_Tab
        '
        Me.chkUpdateStatus_IgnoreCompleted_Tab.AutoSize = True
        Me.chkUpdateStatus_IgnoreCompleted_Tab.Checked = True
        Me.chkUpdateStatus_IgnoreCompleted_Tab.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkUpdateStatus_IgnoreCompleted_Tab.Location = New System.Drawing.Point(172, 8)
        Me.chkUpdateStatus_IgnoreCompleted_Tab.Name = "chkUpdateStatus_IgnoreCompleted_Tab"
        Me.chkUpdateStatus_IgnoreCompleted_Tab.Size = New System.Drawing.Size(109, 17)
        Me.chkUpdateStatus_IgnoreCompleted_Tab.TabIndex = 59
        Me.chkUpdateStatus_IgnoreCompleted_Tab.Text = "Ignore Completed"
        Me.chkUpdateStatus_IgnoreCompleted_Tab.UseVisualStyleBackColor = True
        '
        'lvwUpdateStatus_Tab
        '
        Me.lvwUpdateStatus_Tab.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lvwUpdateStatus_Tab.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader20, Me.ColumnHeader21, Me.ColumnHeader23, Me.ColumnHeader24, Me.ColumnHeader48, Me.ColumnHeader49, Me.ColumnHeader50, Me.ColumnHeader51, Me.ColumnHeader52, Me.ColumnHeader53, Me.ColumnHeader54, Me.ColumnHeader55})
        Me.lvwUpdateStatus_Tab.FullRowSelect = True
        Me.lvwUpdateStatus_Tab.GridLines = True
        Me.lvwUpdateStatus_Tab.HideSelection = False
        Me.lvwUpdateStatus_Tab.Location = New System.Drawing.Point(7, 31)
        Me.lvwUpdateStatus_Tab.Name = "lvwUpdateStatus_Tab"
        Me.lvwUpdateStatus_Tab.Size = New System.Drawing.Size(880, 132)
        Me.lvwUpdateStatus_Tab.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.lvwUpdateStatus_Tab.TabIndex = 58
        Me.lvwUpdateStatus_Tab.UseCompatibleStateImageBehavior = False
        Me.lvwUpdateStatus_Tab.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader20
        '
        Me.ColumnHeader20.Text = "Name"
        Me.ColumnHeader20.Width = 275
        '
        'ColumnHeader21
        '
        Me.ColumnHeader21.Text = "ID"
        '
        'ColumnHeader23
        '
        Me.ColumnHeader23.Text = "My Total"
        Me.ColumnHeader23.Width = 75
        '
        'ColumnHeader24
        '
        Me.ColumnHeader24.Text = "imDB - Airdate"
        Me.ColumnHeader24.Width = 100
        '
        'ColumnHeader48
        '
        Me.ColumnHeader48.Text = "imDB - without airdate"
        Me.ColumnHeader48.Width = 120
        '
        'ColumnHeader49
        '
        Me.ColumnHeader49.Text = "Diff."
        Me.ColumnHeader49.Width = 78
        '
        'ColumnHeader50
        '
        Me.ColumnHeader50.Text = "Last Update imDB"
        Me.ColumnHeader50.Width = 100
        '
        'ColumnHeader51
        '
        Me.ColumnHeader51.Text = "In Doubt"
        Me.ColumnHeader51.Width = 54
        '
        'ColumnHeader52
        '
        Me.ColumnHeader52.Text = "Corr. Version"
        Me.ColumnHeader52.Width = 82
        '
        'ColumnHeader53
        '
        Me.ColumnHeader53.Text = "Compl."
        Me.ColumnHeader53.Width = 50
        '
        'ColumnHeader54
        '
        Me.ColumnHeader54.Text = "Finished"
        Me.ColumnHeader54.Width = 50
        '
        'ColumnHeader55
        '
        Me.ColumnHeader55.Text = "imdb Update Error"
        Me.ColumnHeader55.Width = 175
        '
        'chkUpdateStatus_Missing_Tab
        '
        Me.chkUpdateStatus_Missing_Tab.AutoSize = True
        Me.chkUpdateStatus_Missing_Tab.Checked = True
        Me.chkUpdateStatus_Missing_Tab.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkUpdateStatus_Missing_Tab.Location = New System.Drawing.Point(83, 8)
        Me.chkUpdateStatus_Missing_Tab.Name = "chkUpdateStatus_Missing_Tab"
        Me.chkUpdateStatus_Missing_Tab.Size = New System.Drawing.Size(83, 17)
        Me.chkUpdateStatus_Missing_Tab.TabIndex = 57
        Me.chkUpdateStatus_Missing_Tab.Text = "Just Missing"
        Me.chkUpdateStatus_Missing_Tab.UseVisualStyleBackColor = True
        '
        'cboDrives_Tab
        '
        Me.cboDrives_Tab.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDrives_Tab.FormattingEnabled = True
        Me.cboDrives_Tab.Location = New System.Drawing.Point(7, 6)
        Me.cboDrives_Tab.Name = "cboDrives_Tab"
        Me.cboDrives_Tab.Size = New System.Drawing.Size(70, 21)
        Me.cboDrives_Tab.TabIndex = 28
        '
        'TabPage10
        '
        Me.TabPage10.Controls.Add(Me.cmdWikiLoadEpisodes)
        Me.TabPage10.Controls.Add(Me.cmdWikiLoad)
        Me.TabPage10.Controls.Add(Me.webWiki)
        Me.TabPage10.Controls.Add(Me.cmdWikiForward)
        Me.TabPage10.Controls.Add(Me.cmdWikiBack)
        Me.TabPage10.Controls.Add(Me.Label9)
        Me.TabPage10.Controls.Add(Me.txtURLWiki)
        Me.TabPage10.Location = New System.Drawing.Point(4, 22)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage10.Size = New System.Drawing.Size(905, 175)
        Me.TabPage10.TabIndex = 7
        Me.TabPage10.Text = "Wiki & TV.com Info"
        Me.TabPage10.UseVisualStyleBackColor = True
        '
        'cmdWikiLoadEpisodes
        '
        Me.cmdWikiLoadEpisodes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdWikiLoadEpisodes.Image = CType(resources.GetObject("cmdWikiLoadEpisodes.Image"), System.Drawing.Image)
        Me.cmdWikiLoadEpisodes.Location = New System.Drawing.Point(513, 5)
        Me.cmdWikiLoadEpisodes.Name = "cmdWikiLoadEpisodes"
        Me.cmdWikiLoadEpisodes.Size = New System.Drawing.Size(30, 20)
        Me.cmdWikiLoadEpisodes.TabIndex = 62
        Me.ToolTip1.SetToolTip(Me.cmdWikiLoadEpisodes, "Shows Episodes")
        Me.cmdWikiLoadEpisodes.UseVisualStyleBackColor = True
        '
        'cmdWikiLoad
        '
        Me.cmdWikiLoad.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdWikiLoad.Image = CType(resources.GetObject("cmdWikiLoad.Image"), System.Drawing.Image)
        Me.cmdWikiLoad.Location = New System.Drawing.Point(482, 5)
        Me.cmdWikiLoad.Name = "cmdWikiLoad"
        Me.cmdWikiLoad.Size = New System.Drawing.Size(30, 20)
        Me.cmdWikiLoad.TabIndex = 61
        Me.ToolTip1.SetToolTip(Me.cmdWikiLoad, "Show")
        Me.cmdWikiLoad.UseVisualStyleBackColor = True
        '
        'webWiki
        '
        Me.webWiki.Location = New System.Drawing.Point(9, 32)
        Me.webWiki.MinimumSize = New System.Drawing.Size(20, 20)
        Me.webWiki.Name = "webWiki"
        Me.webWiki.Size = New System.Drawing.Size(890, 90)
        Me.webWiki.TabIndex = 54
        '
        'cmdWikiForward
        '
        Me.cmdWikiForward.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdWikiForward.Location = New System.Drawing.Point(446, 5)
        Me.cmdWikiForward.Name = "cmdWikiForward"
        Me.cmdWikiForward.Size = New System.Drawing.Size(30, 20)
        Me.cmdWikiForward.TabIndex = 53
        Me.cmdWikiForward.Text = ">>"
        Me.cmdWikiForward.UseVisualStyleBackColor = True
        '
        'cmdWikiBack
        '
        Me.cmdWikiBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdWikiBack.Location = New System.Drawing.Point(416, 5)
        Me.cmdWikiBack.Name = "cmdWikiBack"
        Me.cmdWikiBack.Size = New System.Drawing.Size(30, 20)
        Me.cmdWikiBack.TabIndex = 52
        Me.cmdWikiBack.Text = "<<"
        Me.cmdWikiBack.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 8)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(56, 13)
        Me.Label9.TabIndex = 51
        Me.Label9.Text = "Wiki URL:"
        '
        'txtURLWiki
        '
        Me.txtURLWiki.BackColor = System.Drawing.SystemColors.Window
        Me.txtURLWiki.Location = New System.Drawing.Point(68, 5)
        Me.txtURLWiki.Name = "txtURLWiki"
        Me.txtURLWiki.Size = New System.Drawing.Size(330, 20)
        Me.txtURLWiki.TabIndex = 12
        Me.txtURLWiki.TabStop = False
        '
        'tabDetails
        '
        Me.tabDetails.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.tabDetails.Controls.Add(Me.TabPage3)
        Me.tabDetails.Controls.Add(Me.TabPage4)
        Me.tabDetails.Location = New System.Drawing.Point(3, 225)
        Me.tabDetails.Name = "tabDetails"
        Me.tabDetails.SelectedIndex = 0
        Me.tabDetails.Size = New System.Drawing.Size(1098, 250)
        Me.tabDetails.TabIndex = 11
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.fraDetails)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Margin = New System.Windows.Forms.Padding(1)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1090, 224)
        Me.TabPage3.TabIndex = 0
        Me.TabPage3.Text = "Details"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'fraDetails
        '
        Me.fraDetails.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.fraDetails.Controls.Add(Me.Label10)
        Me.fraDetails.Controls.Add(Me.txtAltName)
        Me.fraDetails.Controls.Add(Me.cmdSaveID)
        Me.fraDetails.Controls.Add(Me.chkSeasonOK)
        Me.fraDetails.Controls.Add(Me.cmdMissing)
        Me.fraDetails.Controls.Add(Me.cmdToDo_General)
        Me.fraDetails.Controls.Add(Me.cmdAddToToDo)
        Me.fraDetails.Controls.Add(Me.txtAPITitle)
        Me.fraDetails.Controls.Add(Me.Label8)
        Me.fraDetails.Controls.Add(Me.txtLastUpdate_API)
        Me.fraDetails.Controls.Add(Me.Label7)
        Me.fraDetails.Controls.Add(Me.Label6)
        Me.fraDetails.Controls.Add(Me.Label5)
        Me.fraDetails.Controls.Add(Me.txtDiscSeasonsEpisodes)
        Me.fraDetails.Controls.Add(Me.chkComplete)
        Me.fraDetails.Controls.Add(Me.chkFinished)
        Me.fraDetails.Controls.Add(Me.txtSeriesName)
        Me.fraDetails.Controls.Add(Me.cmdClearID)
        Me.fraDetails.Controls.Add(Me.txtEnd)
        Me.fraDetails.Controls.Add(Me.cmdIMDB_Name)
        Me.fraDetails.Controls.Add(Me.cmdUpdate_OMDB_Only)
        Me.fraDetails.Controls.Add(Me.txtDescription)
        Me.fraDetails.Controls.Add(Me.txtCountry)
        Me.fraDetails.Controls.Add(Me.txtTotalWithAirdate)
        Me.fraDetails.Controls.Add(Me.Label4)
        Me.fraDetails.Controls.Add(Me.cmdIMDB)
        Me.fraDetails.Controls.Add(Me.txtTotal)
        Me.fraDetails.Controls.Add(Me.lblTotal)
        Me.fraDetails.Controls.Add(Me.txtMyTotal)
        Me.fraDetails.Controls.Add(Me.lblMyTotal)
        Me.fraDetails.Controls.Add(Me.Label3)
        Me.fraDetails.Controls.Add(Me.cboCorrectVersion)
        Me.fraDetails.Controls.Add(Me.chkDetailsinDoubt)
        Me.fraDetails.Controls.Add(Me.Label2)
        Me.fraDetails.Controls.Add(Me.cmdUpdateNow)
        Me.fraDetails.Controls.Add(Me.optImdb)
        Me.fraDetails.Controls.Add(Me.txtLastUpdate_IMDB)
        Me.fraDetails.Controls.Add(Me.Label1)
        Me.fraDetails.Controls.Add(Me.txtSeasonCount)
        Me.fraDetails.Controls.Add(Me.txtRating)
        Me.fraDetails.Controls.Add(Me.txtGenre)
        Me.fraDetails.Controls.Add(Me.txtStart)
        Me.fraDetails.Controls.Add(Me.lblImdbRating)
        Me.fraDetails.Controls.Add(Me.txtIMDBSeasonsEpisodes)
        Me.fraDetails.Controls.Add(Me.lblSeasons)
        Me.fraDetails.Controls.Add(Me.lblGenre)
        Me.fraDetails.Controls.Add(Me.lblStart)
        Me.fraDetails.Controls.Add(Me.lblDescription)
        Me.fraDetails.Controls.Add(Me.txtID)
        Me.fraDetails.Location = New System.Drawing.Point(3, 2)
        Me.fraDetails.Name = "fraDetails"
        Me.fraDetails.Size = New System.Drawing.Size(1090, 218)
        Me.fraDetails.TabIndex = 10
        Me.fraDetails.TabStop = False
        Me.fraDetails.Text = "Details"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(3, 149)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(22, 13)
        Me.Label10.TabIndex = 57
        Me.Label10.Text = "Alt:"
        '
        'txtAltName
        '
        Me.txtAltName.BackColor = System.Drawing.SystemColors.Window
        Me.txtAltName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAltName.Location = New System.Drawing.Point(47, 144)
        Me.txtAltName.Name = "txtAltName"
        Me.txtAltName.ReadOnly = True
        Me.txtAltName.Size = New System.Drawing.Size(211, 20)
        Me.txtAltName.TabIndex = 56
        Me.txtAltName.TabStop = False
        '
        'cmdSaveID
        '
        Me.cmdSaveID.Location = New System.Drawing.Point(321, 97)
        Me.cmdSaveID.Name = "cmdSaveID"
        Me.cmdSaveID.Size = New System.Drawing.Size(57, 20)
        Me.cmdSaveID.TabIndex = 55
        Me.cmdSaveID.Text = "Save  ID"
        Me.cmdSaveID.UseVisualStyleBackColor = True
        '
        'chkSeasonOK
        '
        Me.chkSeasonOK.AutoSize = True
        Me.chkSeasonOK.CheckAlign = System.Drawing.ContentAlignment.BottomRight
        Me.chkSeasonOK.Enabled = False
        Me.chkSeasonOK.Location = New System.Drawing.Point(465, 149)
        Me.chkSeasonOK.Name = "chkSeasonOK"
        Me.chkSeasonOK.Size = New System.Drawing.Size(86, 17)
        Me.chkSeasonOK.TabIndex = 54
        Me.chkSeasonOK.Text = "Season OK?"
        Me.ToolTip1.SetToolTip(Me.chkSeasonOK, "Consider this season complete")
        Me.chkSeasonOK.UseVisualStyleBackColor = True
        '
        'cmdMissing
        '
        Me.cmdMissing.Location = New System.Drawing.Point(796, 185)
        Me.cmdMissing.Name = "cmdMissing"
        Me.cmdMissing.Size = New System.Drawing.Size(82, 25)
        Me.cmdMissing.TabIndex = 53
        Me.cmdMissing.Text = "Missing"
        Me.ToolTip1.SetToolTip(Me.cmdMissing, "Update Status / Missing Items")
        Me.cmdMissing.UseVisualStyleBackColor = True
        '
        'cmdToDo_General
        '
        Me.cmdToDo_General.Location = New System.Drawing.Point(710, 185)
        Me.cmdToDo_General.Name = "cmdToDo_General"
        Me.cmdToDo_General.Size = New System.Drawing.Size(83, 25)
        Me.cmdToDo_General.TabIndex = 52
        Me.cmdToDo_General.Text = "General Todo"
        Me.ToolTip1.SetToolTip(Me.cmdToDo_General, "Add a 'general' todo")
        Me.cmdToDo_General.UseVisualStyleBackColor = True
        '
        'cmdAddToToDo
        '
        Me.cmdAddToToDo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdAddToToDo.Location = New System.Drawing.Point(336, 120)
        Me.cmdAddToToDo.Name = "cmdAddToToDo"
        Me.cmdAddToToDo.Size = New System.Drawing.Size(40, 20)
        Me.cmdAddToToDo.TabIndex = 51
        Me.cmdAddToToDo.Text = "Todo"
        Me.ToolTip1.SetToolTip(Me.cmdAddToToDo, "Add to download list")
        Me.cmdAddToToDo.UseVisualStyleBackColor = True
        '
        'txtAPITitle
        '
        Me.txtAPITitle.BackColor = System.Drawing.SystemColors.Window
        Me.txtAPITitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAPITitle.Location = New System.Drawing.Point(47, 97)
        Me.txtAPITitle.Name = "txtAPITitle"
        Me.txtAPITitle.ReadOnly = True
        Me.txtAPITitle.Size = New System.Drawing.Size(211, 20)
        Me.txtAPITitle.TabIndex = 49
        Me.txtAPITitle.TabStop = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(3, 99)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(50, 13)
        Me.Label8.TabIndex = 50
        Me.Label8.Text = "API Title:"
        '
        'txtLastUpdate_API
        '
        Me.txtLastUpdate_API.BackColor = System.Drawing.SystemColors.Window
        Me.txtLastUpdate_API.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtLastUpdate_API.Location = New System.Drawing.Point(321, 9)
        Me.txtLastUpdate_API.Name = "txtLastUpdate_API"
        Me.txtLastUpdate_API.ReadOnly = True
        Me.txtLastUpdate_API.Size = New System.Drawing.Size(67, 20)
        Me.txtLastUpdate_API.TabIndex = 48
        Me.txtLastUpdate_API.TabStop = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(247, 11)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(73, 13)
        Me.Label7.TabIndex = 47
        Me.Label7.Text = "Last Upd API:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(557, 96)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(34, 13)
        Me.Label6.TabIndex = 46
        Me.Label6.Text = "IMDB"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(557, 47)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 13)
        Me.Label5.TabIndex = 45
        Me.Label5.Text = "Disc"
        '
        'txtDiscSeasonsEpisodes
        '
        Me.txtDiscSeasonsEpisodes.BackColor = System.Drawing.SystemColors.Window
        Me.txtDiscSeasonsEpisodes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDiscSeasonsEpisodes.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDiscSeasonsEpisodes.Location = New System.Drawing.Point(591, 40)
        Me.txtDiscSeasonsEpisodes.Multiline = True
        Me.txtDiscSeasonsEpisodes.Name = "txtDiscSeasonsEpisodes"
        Me.txtDiscSeasonsEpisodes.ReadOnly = True
        Me.txtDiscSeasonsEpisodes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDiscSeasonsEpisodes.Size = New System.Drawing.Size(480, 53)
        Me.txtDiscSeasonsEpisodes.TabIndex = 44
        Me.txtDiscSeasonsEpisodes.TabStop = False
        '
        'chkComplete
        '
        Me.chkComplete.AutoSize = True
        Me.chkComplete.CheckAlign = System.Drawing.ContentAlignment.BottomRight
        Me.chkComplete.Location = New System.Drawing.Point(475, 172)
        Me.chkComplete.Name = "chkComplete"
        Me.chkComplete.Size = New System.Drawing.Size(76, 17)
        Me.chkComplete.TabIndex = 43
        Me.chkComplete.Text = "Complete?"
        Me.ToolTip1.SetToolTip(Me.chkComplete, "Show is finished, I have every episode and I've checked everything")
        Me.chkComplete.UseVisualStyleBackColor = True
        '
        'chkFinished
        '
        Me.chkFinished.AutoSize = True
        Me.chkFinished.CheckAlign = System.Drawing.ContentAlignment.BottomRight
        Me.chkFinished.Location = New System.Drawing.Point(398, 172)
        Me.chkFinished.Name = "chkFinished"
        Me.chkFinished.Size = New System.Drawing.Size(71, 17)
        Me.chkFinished.TabIndex = 42
        Me.chkFinished.Text = "Finished?"
        Me.ToolTip1.SetToolTip(Me.chkFinished, "Show has 'finished' but no end year on IMDB")
        Me.chkFinished.UseVisualStyleBackColor = True
        '
        'txtSeriesName
        '
        Me.txtSeriesName.BackColor = System.Drawing.SystemColors.Window
        Me.txtSeriesName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSeriesName.Location = New System.Drawing.Point(47, 120)
        Me.txtSeriesName.Name = "txtSeriesName"
        Me.txtSeriesName.ReadOnly = True
        Me.txtSeriesName.Size = New System.Drawing.Size(211, 20)
        Me.txtSeriesName.TabIndex = 23
        Me.txtSeriesName.TabStop = False
        '
        'cmdClearID
        '
        Me.cmdClearID.Location = New System.Drawing.Point(261, 97)
        Me.cmdClearID.Name = "cmdClearID"
        Me.cmdClearID.Size = New System.Drawing.Size(54, 20)
        Me.cmdClearID.TabIndex = 40
        Me.cmdClearID.Text = "Clear ID"
        Me.cmdClearID.UseVisualStyleBackColor = True
        '
        'txtEnd
        '
        Me.txtEnd.BackColor = System.Drawing.SystemColors.Window
        Me.txtEnd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtEnd.Location = New System.Drawing.Point(426, 144)
        Me.txtEnd.Name = "txtEnd"
        Me.txtEnd.ReadOnly = True
        Me.txtEnd.Size = New System.Drawing.Size(33, 20)
        Me.txtEnd.TabIndex = 12
        Me.txtEnd.TabStop = False
        '
        'cmdIMDB_Name
        '
        Me.cmdIMDB_Name.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdIMDB_Name.Image = CType(resources.GetObject("cmdIMDB_Name.Image"), System.Drawing.Image)
        Me.cmdIMDB_Name.Location = New System.Drawing.Point(420, 99)
        Me.cmdIMDB_Name.Name = "cmdIMDB_Name"
        Me.cmdIMDB_Name.Size = New System.Drawing.Size(30, 20)
        Me.cmdIMDB_Name.TabIndex = 38
        Me.cmdIMDB_Name.UseVisualStyleBackColor = True
        '
        'cmdUpdate_OMDB_Only
        '
        Me.cmdUpdate_OMDB_Only.Location = New System.Drawing.Point(882, 185)
        Me.cmdUpdate_OMDB_Only.Name = "cmdUpdate_OMDB_Only"
        Me.cmdUpdate_OMDB_Only.Size = New System.Drawing.Size(106, 25)
        Me.cmdUpdate_OMDB_Only.TabIndex = 37
        Me.cmdUpdate_OMDB_Only.Text = "Upd. - OMDBAPI"
        Me.cmdUpdate_OMDB_Only.UseVisualStyleBackColor = True
        '
        'txtDescription
        '
        Me.txtDescription.BackColor = System.Drawing.SystemColors.Window
        Me.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDescription.Location = New System.Drawing.Point(47, 30)
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.ReadOnly = True
        Me.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDescription.Size = New System.Drawing.Size(500, 66)
        Me.txtDescription.TabIndex = 1
        Me.txtDescription.TabStop = False
        '
        'txtCountry
        '
        Me.txtCountry.BackColor = System.Drawing.SystemColors.Window
        Me.txtCountry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCountry.Location = New System.Drawing.Point(261, 144)
        Me.txtCountry.Name = "txtCountry"
        Me.txtCountry.ReadOnly = True
        Me.txtCountry.Size = New System.Drawing.Size(68, 20)
        Me.txtCountry.TabIndex = 35
        Me.txtCountry.TabStop = False
        '
        'txtTotalWithAirdate
        '
        Me.txtTotalWithAirdate.BackColor = System.Drawing.SystemColors.Window
        Me.txtTotalWithAirdate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTotalWithAirdate.Location = New System.Drawing.Point(859, 14)
        Me.txtTotalWithAirdate.Name = "txtTotalWithAirdate"
        Me.txtTotalWithAirdate.ReadOnly = True
        Me.txtTotalWithAirdate.Size = New System.Drawing.Size(32, 20)
        Me.txtTotalWithAirdate.TabIndex = 34
        Me.txtTotalWithAirdate.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(782, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(71, 13)
        Me.Label4.TabIndex = 33
        Me.Label4.Text = "Tot. (Airdate):"
        '
        'cmdIMDB
        '
        Me.cmdIMDB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdIMDB.Image = CType(resources.GetObject("cmdIMDB.Image"), System.Drawing.Image)
        Me.cmdIMDB.Location = New System.Drawing.Point(384, 99)
        Me.cmdIMDB.Name = "cmdIMDB"
        Me.cmdIMDB.Size = New System.Drawing.Size(30, 20)
        Me.cmdIMDB.TabIndex = 32
        Me.cmdIMDB.UseVisualStyleBackColor = True
        '
        'txtTotal
        '
        Me.txtTotal.BackColor = System.Drawing.SystemColors.Window
        Me.txtTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTotal.Location = New System.Drawing.Point(937, 14)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.ReadOnly = True
        Me.txtTotal.Size = New System.Drawing.Size(32, 20)
        Me.txtTotal.TabIndex = 31
        Me.txtTotal.TabStop = False
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.Location = New System.Drawing.Point(897, 16)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(34, 13)
        Me.lblTotal.TabIndex = 30
        Me.lblTotal.Text = "Total:"
        '
        'txtMyTotal
        '
        Me.txtMyTotal.BackColor = System.Drawing.SystemColors.Window
        Me.txtMyTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMyTotal.Location = New System.Drawing.Point(744, 14)
        Me.txtMyTotal.Name = "txtMyTotal"
        Me.txtMyTotal.ReadOnly = True
        Me.txtMyTotal.Size = New System.Drawing.Size(32, 20)
        Me.txtMyTotal.TabIndex = 29
        Me.txtMyTotal.TabStop = False
        '
        'lblMyTotal
        '
        Me.lblMyTotal.AutoSize = True
        Me.lblMyTotal.Location = New System.Drawing.Point(687, 16)
        Me.lblMyTotal.Name = "lblMyTotal"
        Me.lblMyTotal.Size = New System.Drawing.Size(51, 13)
        Me.lblMyTotal.TabIndex = 28
        Me.lblMyTotal.Text = "My Total:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(216, 173)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 13)
        Me.Label3.TabIndex = 27
        Me.Label3.Text = "Correct"
        '
        'cboCorrectVersion
        '
        Me.cboCorrectVersion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCorrectVersion.FormattingEnabled = True
        Me.cboCorrectVersion.Items.AddRange(New Object() {"", "IMDB", "TV.com"})
        Me.cboCorrectVersion.Location = New System.Drawing.Point(257, 169)
        Me.cboCorrectVersion.Name = "cboCorrectVersion"
        Me.cboCorrectVersion.Size = New System.Drawing.Size(61, 21)
        Me.cboCorrectVersion.TabIndex = 26
        '
        'chkDetailsinDoubt
        '
        Me.chkDetailsinDoubt.AutoSize = True
        Me.chkDetailsinDoubt.CheckAlign = System.Drawing.ContentAlignment.BottomRight
        Me.chkDetailsinDoubt.Location = New System.Drawing.Point(319, 172)
        Me.chkDetailsinDoubt.Name = "chkDetailsinDoubt"
        Me.chkDetailsinDoubt.Size = New System.Drawing.Size(73, 17)
        Me.chkDetailsinDoubt.TabIndex = 25
        Me.chkDetailsinDoubt.Text = "In Doubt?"
        Me.chkDetailsinDoubt.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 122)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "Name:"
        '
        'cmdUpdateNow
        '
        Me.cmdUpdateNow.Location = New System.Drawing.Point(994, 185)
        Me.cmdUpdateNow.Name = "cmdUpdateNow"
        Me.cmdUpdateNow.Size = New System.Drawing.Size(81, 25)
        Me.cmdUpdateNow.TabIndex = 21
        Me.cmdUpdateNow.Text = "Update"
        Me.cmdUpdateNow.UseVisualStyleBackColor = True
        '
        'optImdb
        '
        Me.optImdb.AutoSize = True
        Me.optImdb.Checked = True
        Me.optImdb.Location = New System.Drawing.Point(47, 12)
        Me.optImdb.Name = "optImdb"
        Me.optImdb.Size = New System.Drawing.Size(52, 17)
        Me.optImdb.TabIndex = 19
        Me.optImdb.TabStop = True
        Me.optImdb.Text = "IMDB"
        Me.optImdb.UseVisualStyleBackColor = True
        '
        'txtLastUpdate_IMDB
        '
        Me.txtLastUpdate_IMDB.BackColor = System.Drawing.SystemColors.Window
        Me.txtLastUpdate_IMDB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtLastUpdate_IMDB.Location = New System.Drawing.Point(480, 9)
        Me.txtLastUpdate_IMDB.Name = "txtLastUpdate_IMDB"
        Me.txtLastUpdate_IMDB.ReadOnly = True
        Me.txtLastUpdate_IMDB.Size = New System.Drawing.Size(67, 20)
        Me.txtLastUpdate_IMDB.TabIndex = 18
        Me.txtLastUpdate_IMDB.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(394, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(83, 13)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Last Upd IMDB:"
        '
        'txtSeasonCount
        '
        Me.txtSeasonCount.BackColor = System.Drawing.SystemColors.Window
        Me.txtSeasonCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSeasonCount.Location = New System.Drawing.Point(644, 14)
        Me.txtSeasonCount.Name = "txtSeasonCount"
        Me.txtSeasonCount.ReadOnly = True
        Me.txtSeasonCount.Size = New System.Drawing.Size(32, 20)
        Me.txtSeasonCount.TabIndex = 15
        Me.txtSeasonCount.TabStop = False
        '
        'txtRating
        '
        Me.txtRating.BackColor = System.Drawing.SystemColors.Window
        Me.txtRating.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtRating.Location = New System.Drawing.Point(513, 122)
        Me.txtRating.Name = "txtRating"
        Me.txtRating.ReadOnly = True
        Me.txtRating.Size = New System.Drawing.Size(70, 20)
        Me.txtRating.TabIndex = 13
        Me.txtRating.TabStop = False
        '
        'txtGenre
        '
        Me.txtGenre.BackColor = System.Drawing.SystemColors.Window
        Me.txtGenre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtGenre.Location = New System.Drawing.Point(47, 169)
        Me.txtGenre.Name = "txtGenre"
        Me.txtGenre.ReadOnly = True
        Me.txtGenre.Size = New System.Drawing.Size(168, 20)
        Me.txtGenre.TabIndex = 11
        Me.txtGenre.TabStop = False
        '
        'txtStart
        '
        Me.txtStart.BackColor = System.Drawing.SystemColors.Window
        Me.txtStart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStart.Location = New System.Drawing.Point(390, 144)
        Me.txtStart.Name = "txtStart"
        Me.txtStart.ReadOnly = True
        Me.txtStart.Size = New System.Drawing.Size(33, 20)
        Me.txtStart.TabIndex = 10
        Me.txtStart.TabStop = False
        '
        'lblImdbRating
        '
        Me.lblImdbRating.AutoSize = True
        Me.lblImdbRating.Location = New System.Drawing.Point(442, 124)
        Me.lblImdbRating.Name = "lblImdbRating"
        Me.lblImdbRating.Size = New System.Drawing.Size(65, 13)
        Me.lblImdbRating.TabIndex = 7
        Me.lblImdbRating.Text = "Rate/Votes:"
        '
        'txtIMDBSeasonsEpisodes
        '
        Me.txtIMDBSeasonsEpisodes.BackColor = System.Drawing.SystemColors.Window
        Me.txtIMDBSeasonsEpisodes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtIMDBSeasonsEpisodes.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtIMDBSeasonsEpisodes.Location = New System.Drawing.Point(591, 94)
        Me.txtIMDBSeasonsEpisodes.Multiline = True
        Me.txtIMDBSeasonsEpisodes.Name = "txtIMDBSeasonsEpisodes"
        Me.txtIMDBSeasonsEpisodes.ReadOnly = True
        Me.txtIMDBSeasonsEpisodes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtIMDBSeasonsEpisodes.Size = New System.Drawing.Size(480, 53)
        Me.txtIMDBSeasonsEpisodes.TabIndex = 6
        Me.txtIMDBSeasonsEpisodes.TabStop = False
        '
        'lblSeasons
        '
        Me.lblSeasons.AutoSize = True
        Me.lblSeasons.Location = New System.Drawing.Point(592, 16)
        Me.lblSeasons.Name = "lblSeasons"
        Me.lblSeasons.Size = New System.Drawing.Size(51, 13)
        Me.lblSeasons.TabIndex = 5
        Me.lblSeasons.Text = "Seasons:"
        '
        'lblGenre
        '
        Me.lblGenre.AutoSize = True
        Me.lblGenre.Location = New System.Drawing.Point(3, 172)
        Me.lblGenre.Name = "lblGenre"
        Me.lblGenre.Size = New System.Drawing.Size(39, 13)
        Me.lblGenre.TabIndex = 4
        Me.lblGenre.Text = "Genre:"
        '
        'lblStart
        '
        Me.lblStart.AutoSize = True
        Me.lblStart.Location = New System.Drawing.Point(336, 148)
        Me.lblStart.Name = "lblStart"
        Me.lblStart.Size = New System.Drawing.Size(53, 13)
        Me.lblStart.TabIndex = 2
        Me.lblStart.Text = "Start/End"
        '
        'lblDescription
        '
        Me.lblDescription.AutoSize = True
        Me.lblDescription.Location = New System.Drawing.Point(3, 47)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(35, 13)
        Me.lblDescription.TabIndex = 0
        Me.lblDescription.Text = "Desc:"
        '
        'txtID
        '
        Me.txtID.BackColor = System.Drawing.SystemColors.Window
        Me.txtID.Location = New System.Drawing.Point(261, 120)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(68, 20)
        Me.txtID.TabIndex = 22
        Me.txtID.TabStop = False
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.fraMissing)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(1090, 224)
        Me.TabPage4.TabIndex = 1
        Me.TabPage4.Text = "Missing"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'fraMissing
        '
        Me.fraMissing.Controls.Add(Me.cmdAddSelMissingSeasonsToToDownload)
        Me.fraMissing.Controls.Add(Me.cmdAddMissingSeasonsToToDownload)
        Me.fraMissing.Controls.Add(Me.cmdAddSelMissingToToDownload)
        Me.fraMissing.Controls.Add(Me.cmdAddMissingToToDownload)
        Me.fraMissing.Controls.Add(Me.chkX264_Episode)
        Me.fraMissing.Controls.Add(Me.chkX264_Season)
        Me.fraMissing.Controls.Add(Me.txtMissingEpisodes)
        Me.fraMissing.Controls.Add(Me.txtMissingSeasons)
        Me.fraMissing.Location = New System.Drawing.Point(3, 2)
        Me.fraMissing.Name = "fraMissing"
        Me.fraMissing.Size = New System.Drawing.Size(1078, 218)
        Me.fraMissing.TabIndex = 52
        Me.fraMissing.TabStop = False
        Me.fraMissing.Text = "Missing"
        '
        'cmdAddSelMissingSeasonsToToDownload
        '
        Me.cmdAddSelMissingSeasonsToToDownload.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdAddSelMissingSeasonsToToDownload.Location = New System.Drawing.Point(177, 185)
        Me.cmdAddSelMissingSeasonsToToDownload.Name = "cmdAddSelMissingSeasonsToToDownload"
        Me.cmdAddSelMissingSeasonsToToDownload.Size = New System.Drawing.Size(136, 25)
        Me.cmdAddSelMissingSeasonsToToDownload.TabIndex = 52
        Me.cmdAddSelMissingSeasonsToToDownload.Text = "Add Sel. Missing to Dlds"
        Me.ToolTip1.SetToolTip(Me.cmdAddSelMissingSeasonsToToDownload, "Add Selected Missing To To Download")
        Me.cmdAddSelMissingSeasonsToToDownload.UseVisualStyleBackColor = True
        '
        'cmdAddMissingSeasonsToToDownload
        '
        Me.cmdAddMissingSeasonsToToDownload.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdAddMissingSeasonsToToDownload.Location = New System.Drawing.Point(63, 185)
        Me.cmdAddMissingSeasonsToToDownload.Name = "cmdAddMissingSeasonsToToDownload"
        Me.cmdAddMissingSeasonsToToDownload.Size = New System.Drawing.Size(111, 25)
        Me.cmdAddMissingSeasonsToToDownload.TabIndex = 51
        Me.cmdAddMissingSeasonsToToDownload.Text = "Add Missing to Dlds"
        Me.ToolTip1.SetToolTip(Me.cmdAddMissingSeasonsToToDownload, "Add Missing To To Download")
        Me.cmdAddMissingSeasonsToToDownload.UseVisualStyleBackColor = True
        '
        'cmdAddSelMissingToToDownload
        '
        Me.cmdAddSelMissingToToDownload.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdAddSelMissingToToDownload.Location = New System.Drawing.Point(707, 185)
        Me.cmdAddSelMissingToToDownload.Name = "cmdAddSelMissingToToDownload"
        Me.cmdAddSelMissingToToDownload.Size = New System.Drawing.Size(136, 25)
        Me.cmdAddSelMissingToToDownload.TabIndex = 50
        Me.cmdAddSelMissingToToDownload.Text = "Add Sel. Missing to Dlds"
        Me.ToolTip1.SetToolTip(Me.cmdAddSelMissingToToDownload, "Add Selected Missing To To Download")
        Me.cmdAddSelMissingToToDownload.UseVisualStyleBackColor = True
        '
        'cmdAddMissingToToDownload
        '
        Me.cmdAddMissingToToDownload.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdAddMissingToToDownload.Location = New System.Drawing.Point(593, 185)
        Me.cmdAddMissingToToDownload.Name = "cmdAddMissingToToDownload"
        Me.cmdAddMissingToToDownload.Size = New System.Drawing.Size(111, 25)
        Me.cmdAddMissingToToDownload.TabIndex = 49
        Me.cmdAddMissingToToDownload.Text = "Add Missing to Dlds"
        Me.ToolTip1.SetToolTip(Me.cmdAddMissingToToDownload, "Add Missing To To Download")
        Me.cmdAddMissingToToDownload.UseVisualStyleBackColor = True
        '
        'chkX264_Episode
        '
        Me.chkX264_Episode.AutoSize = True
        Me.chkX264_Episode.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkX264_Episode.Location = New System.Drawing.Point(536, 190)
        Me.chkX264_Episode.Name = "chkX264_Episode"
        Me.chkX264_Episode.Size = New System.Drawing.Size(51, 17)
        Me.chkX264_Episode.TabIndex = 48
        Me.chkX264_Episode.Text = "X264"
        Me.chkX264_Episode.UseVisualStyleBackColor = True
        '
        'chkX264_Season
        '
        Me.chkX264_Season.AutoSize = True
        Me.chkX264_Season.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkX264_Season.Location = New System.Drawing.Point(6, 190)
        Me.chkX264_Season.Name = "chkX264_Season"
        Me.chkX264_Season.Size = New System.Drawing.Size(51, 17)
        Me.chkX264_Season.TabIndex = 47
        Me.chkX264_Season.Text = "X264"
        Me.chkX264_Season.UseVisualStyleBackColor = True
        '
        'txtMissingEpisodes
        '
        Me.txtMissingEpisodes.BackColor = System.Drawing.SystemColors.Window
        Me.txtMissingEpisodes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMissingEpisodes.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMissingEpisodes.Location = New System.Drawing.Point(536, 19)
        Me.txtMissingEpisodes.Multiline = True
        Me.txtMissingEpisodes.Name = "txtMissingEpisodes"
        Me.txtMissingEpisodes.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtMissingEpisodes.Size = New System.Drawing.Size(513, 160)
        Me.txtMissingEpisodes.TabIndex = 46
        Me.txtMissingEpisodes.TabStop = False
        '
        'txtMissingSeasons
        '
        Me.txtMissingSeasons.BackColor = System.Drawing.SystemColors.Window
        Me.txtMissingSeasons.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMissingSeasons.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMissingSeasons.Location = New System.Drawing.Point(6, 19)
        Me.txtMissingSeasons.Multiline = True
        Me.txtMissingSeasons.Name = "txtMissingSeasons"
        Me.txtMissingSeasons.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtMissingSeasons.Size = New System.Drawing.Size(513, 160)
        Me.txtMissingSeasons.TabIndex = 45
        Me.txtMissingSeasons.TabStop = False
        '
        'cmdFinished_MajorFolders
        '
        Me.cmdFinished_MajorFolders.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdFinished_MajorFolders.Location = New System.Drawing.Point(726, 473)
        Me.cmdFinished_MajorFolders.Name = "cmdFinished_MajorFolders"
        Me.cmdFinished_MajorFolders.Size = New System.Drawing.Size(93, 25)
        Me.cmdFinished_MajorFolders.TabIndex = 7
        Me.cmdFinished_MajorFolders.Text = "Finished"
        Me.cmdFinished_MajorFolders.UseVisualStyleBackColor = True
        Me.cmdFinished_MajorFolders.Visible = False
        '
        'cmdFinished_DriveStatus
        '
        Me.cmdFinished_DriveStatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdFinished_DriveStatus.Location = New System.Drawing.Point(825, 473)
        Me.cmdFinished_DriveStatus.Name = "cmdFinished_DriveStatus"
        Me.cmdFinished_DriveStatus.Size = New System.Drawing.Size(93, 25)
        Me.cmdFinished_DriveStatus.TabIndex = 6
        Me.cmdFinished_DriveStatus.Text = "Finished"
        Me.cmdFinished_DriveStatus.UseVisualStyleBackColor = True
        Me.cmdFinished_DriveStatus.Visible = False
        '
        'cmdFinished
        '
        Me.cmdFinished.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdFinished.Location = New System.Drawing.Point(924, 473)
        Me.cmdFinished.Name = "cmdFinished"
        Me.cmdFinished.Size = New System.Drawing.Size(93, 25)
        Me.cmdFinished.TabIndex = 4
        Me.cmdFinished.Text = "Finished"
        Me.cmdFinished.UseVisualStyleBackColor = True
        Me.cmdFinished.Visible = False
        '
        'cmdClose
        '
        Me.cmdClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdClose.Location = New System.Drawing.Point(1023, 473)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Size = New System.Drawing.Size(93, 25)
        Me.cmdClose.TabIndex = 2
        Me.cmdClose.Text = "Close"
        Me.cmdClose.UseVisualStyleBackColor = True
        '
        'cboDrives
        '
        Me.cboDrives.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDrives.FormattingEnabled = True
        Me.cboDrives.Location = New System.Drawing.Point(928, 129)
        Me.cboDrives.Name = "cboDrives"
        Me.cboDrives.Size = New System.Drawing.Size(70, 21)
        Me.cboDrives.TabIndex = 27
        Me.cboDrives.Visible = False
        '
        'chkUpdateStatus_IgnoreCompleted
        '
        Me.chkUpdateStatus_IgnoreCompleted.AutoSize = True
        Me.chkUpdateStatus_IgnoreCompleted.Checked = True
        Me.chkUpdateStatus_IgnoreCompleted.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkUpdateStatus_IgnoreCompleted.Location = New System.Drawing.Point(1039, 61)
        Me.chkUpdateStatus_IgnoreCompleted.Name = "chkUpdateStatus_IgnoreCompleted"
        Me.chkUpdateStatus_IgnoreCompleted.Size = New System.Drawing.Size(109, 17)
        Me.chkUpdateStatus_IgnoreCompleted.TabIndex = 57
        Me.chkUpdateStatus_IgnoreCompleted.Text = "Ignore Completed"
        Me.chkUpdateStatus_IgnoreCompleted.UseVisualStyleBackColor = True
        Me.chkUpdateStatus_IgnoreCompleted.Visible = False
        '
        'chkUpdateStatus_Missing
        '
        Me.chkUpdateStatus_Missing.AutoSize = True
        Me.chkUpdateStatus_Missing.Checked = True
        Me.chkUpdateStatus_Missing.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkUpdateStatus_Missing.Location = New System.Drawing.Point(934, 50)
        Me.chkUpdateStatus_Missing.Name = "chkUpdateStatus_Missing"
        Me.chkUpdateStatus_Missing.Size = New System.Drawing.Size(83, 17)
        Me.chkUpdateStatus_Missing.TabIndex = 56
        Me.chkUpdateStatus_Missing.Text = "Just Missing"
        Me.chkUpdateStatus_Missing.UseVisualStyleBackColor = True
        Me.chkUpdateStatus_Missing.Visible = False
        '
        'txtAiredItems_Title
        '
        Me.txtAiredItems_Title.BackColor = System.Drawing.SystemColors.Window
        Me.txtAiredItems_Title.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAiredItems_Title.Location = New System.Drawing.Point(1027, 179)
        Me.txtAiredItems_Title.Name = "txtAiredItems_Title"
        Me.txtAiredItems_Title.ReadOnly = True
        Me.txtAiredItems_Title.Size = New System.Drawing.Size(500, 20)
        Me.txtAiredItems_Title.TabIndex = 63
        Me.txtAiredItems_Title.TabStop = False
        Me.txtAiredItems_Title.Visible = False
        '
        'prgProgress
        '
        Me.prgProgress.Location = New System.Drawing.Point(1034, 172)
        Me.prgProgress.Name = "prgProgress"
        Me.prgProgress.Size = New System.Drawing.Size(233, 23)
        Me.prgProgress.TabIndex = 66
        Me.prgProgress.Visible = False
        '
        'lvwAiredShows
        '
        Me.lvwAiredShows.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colAiredDrive, Me.colShow, Me.colSeason_, Me.colEpisode_, Me.colDate, Me.colAiredLocation, Me.colAiredimdbID, Me.colAiredTitle})
        Me.lvwAiredShows.FullRowSelect = True
        Me.lvwAiredShows.GridLines = True
        Me.lvwAiredShows.HideSelection = False
        Me.lvwAiredShows.Location = New System.Drawing.Point(1064, 144)
        Me.lvwAiredShows.MultiSelect = False
        Me.lvwAiredShows.Name = "lvwAiredShows"
        Me.lvwAiredShows.Size = New System.Drawing.Size(867, 127)
        Me.lvwAiredShows.TabIndex = 33
        Me.lvwAiredShows.UseCompatibleStateImageBehavior = False
        Me.lvwAiredShows.View = System.Windows.Forms.View.Details
        Me.lvwAiredShows.Visible = False
        '
        'colAiredDrive
        '
        Me.colAiredDrive.Text = "Drive"
        Me.colAiredDrive.Width = 76
        '
        'colShow
        '
        Me.colShow.Text = "Show"
        Me.colShow.Width = 225
        '
        'colSeason_
        '
        Me.colSeason_.Text = "Season"
        Me.colSeason_.Width = 70
        '
        'colEpisode_
        '
        Me.colEpisode_.Text = "Episode"
        Me.colEpisode_.Width = 70
        '
        'colDate
        '
        Me.colDate.Text = "Air Date"
        Me.colDate.Width = 84
        '
        'colAiredLocation
        '
        Me.colAiredLocation.Text = "Location"
        Me.colAiredLocation.Width = 500
        '
        'colAiredimdbID
        '
        Me.colAiredimdbID.Text = "ID"
        Me.colAiredimdbID.Width = 150
        '
        'colAiredTitle
        '
        Me.colAiredTitle.Text = "Title"
        Me.colAiredTitle.Width = 0
        '
        'cmdomdbAPI_Forward
        '
        Me.cmdomdbAPI_Forward.Location = New System.Drawing.Point(1034, 179)
        Me.cmdomdbAPI_Forward.Name = "cmdomdbAPI_Forward"
        Me.cmdomdbAPI_Forward.Size = New System.Drawing.Size(40, 23)
        Me.cmdomdbAPI_Forward.TabIndex = 68
        Me.cmdomdbAPI_Forward.Text = ">>"
        Me.cmdomdbAPI_Forward.UseVisualStyleBackColor = True
        Me.cmdomdbAPI_Forward.Visible = False
        '
        'lvwPeopleLiked_All
        '
        Me.lvwPeopleLiked_All.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader25, Me.ColumnHeader26, Me.ColumnHeader27, Me.ColumnHeader28})
        Me.lvwPeopleLiked_All.FullRowSelect = True
        Me.lvwPeopleLiked_All.GridLines = True
        Me.lvwPeopleLiked_All.HideSelection = False
        Me.lvwPeopleLiked_All.Location = New System.Drawing.Point(1064, 140)
        Me.lvwPeopleLiked_All.MultiSelect = False
        Me.lvwPeopleLiked_All.Name = "lvwPeopleLiked_All"
        Me.lvwPeopleLiked_All.Size = New System.Drawing.Size(867, 127)
        Me.lvwPeopleLiked_All.TabIndex = 29
        Me.lvwPeopleLiked_All.UseCompatibleStateImageBehavior = False
        Me.lvwPeopleLiked_All.View = System.Windows.Forms.View.Details
        Me.lvwPeopleLiked_All.Visible = False
        '
        'ColumnHeader25
        '
        Me.ColumnHeader25.Text = "Name"
        Me.ColumnHeader25.Width = 250
        '
        'ColumnHeader26
        '
        Me.ColumnHeader26.Text = "Rating"
        '
        'ColumnHeader27
        '
        Me.ColumnHeader27.Text = "Desc"
        Me.ColumnHeader27.Width = 1000
        '
        'ColumnHeader28
        '
        Me.ColumnHeader28.Text = "ID"
        Me.ColumnHeader28.Width = 0
        '
        'cboOmdbCountries
        '
        Me.cboOmdbCountries.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboOmdbCountries.FormattingEnabled = True
        Me.cboOmdbCountries.Location = New System.Drawing.Point(924, 153)
        Me.cboOmdbCountries.Name = "cboOmdbCountries"
        Me.cboOmdbCountries.Size = New System.Drawing.Size(190, 21)
        Me.cboOmdbCountries.TabIndex = 3
        Me.cboOmdbCountries.Visible = False
        '
        'lvwRottenTomatoes
        '
        Me.lvwRottenTomatoes.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader56, Me.ColumnHeader57, Me.ColumnHeader58, Me.ColumnHeader59, Me.ColumnHeader60, Me.ColumnHeader64})
        Me.lvwRottenTomatoes.FullRowSelect = True
        Me.lvwRottenTomatoes.GridLines = True
        Me.lvwRottenTomatoes.HideSelection = False
        Me.lvwRottenTomatoes.Location = New System.Drawing.Point(1064, 129)
        Me.lvwRottenTomatoes.MultiSelect = False
        Me.lvwRottenTomatoes.Name = "lvwRottenTomatoes"
        Me.lvwRottenTomatoes.Size = New System.Drawing.Size(867, 127)
        Me.lvwRottenTomatoes.TabIndex = 59
        Me.lvwRottenTomatoes.UseCompatibleStateImageBehavior = False
        Me.lvwRottenTomatoes.View = System.Windows.Forms.View.Details
        Me.lvwRottenTomatoes.Visible = False
        '
        'ColumnHeader56
        '
        Me.ColumnHeader56.Text = "Title"
        Me.ColumnHeader56.Width = 250
        '
        'ColumnHeader57
        '
        Me.ColumnHeader57.Text = "Rating"
        '
        'ColumnHeader58
        '
        Me.ColumnHeader58.Text = "Votes"
        Me.ColumnHeader58.Width = 75
        '
        'ColumnHeader59
        '
        Me.ColumnHeader59.Text = "Country"
        Me.ColumnHeader59.Width = 80
        '
        'ColumnHeader60
        '
        Me.ColumnHeader60.Text = "Genre"
        Me.ColumnHeader60.Width = 150
        '
        'ColumnHeader64
        '
        Me.ColumnHeader64.Text = "Desc"
        Me.ColumnHeader64.Width = 2500
        '
        'txtAiredItems_FilenameJustSeason
        '
        Me.txtAiredItems_FilenameJustSeason.BackColor = System.Drawing.SystemColors.Window
        Me.txtAiredItems_FilenameJustSeason.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAiredItems_FilenameJustSeason.Location = New System.Drawing.Point(922, 161)
        Me.txtAiredItems_FilenameJustSeason.Name = "txtAiredItems_FilenameJustSeason"
        Me.txtAiredItems_FilenameJustSeason.ReadOnly = True
        Me.txtAiredItems_FilenameJustSeason.Size = New System.Drawing.Size(500, 20)
        Me.txtAiredItems_FilenameJustSeason.TabIndex = 74
        Me.txtAiredItems_FilenameJustSeason.TabStop = False
        Me.txtAiredItems_FilenameJustSeason.Visible = False
        '
        'txtDriveFileSummary_FilenameJustSeason
        '
        Me.txtDriveFileSummary_FilenameJustSeason.BackColor = System.Drawing.SystemColors.Window
        Me.txtDriveFileSummary_FilenameJustSeason.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDriveFileSummary_FilenameJustSeason.Location = New System.Drawing.Point(1019, 148)
        Me.txtDriveFileSummary_FilenameJustSeason.Name = "txtDriveFileSummary_FilenameJustSeason"
        Me.txtDriveFileSummary_FilenameJustSeason.ReadOnly = True
        Me.txtDriveFileSummary_FilenameJustSeason.Size = New System.Drawing.Size(500, 20)
        Me.txtDriveFileSummary_FilenameJustSeason.TabIndex = 87
        Me.txtDriveFileSummary_FilenameJustSeason.TabStop = False
        Me.txtDriveFileSummary_FilenameJustSeason.Visible = False
        '
        'txtDriveFileSummary_FullFilename
        '
        Me.txtDriveFileSummary_FullFilename.BackColor = System.Drawing.SystemColors.Window
        Me.txtDriveFileSummary_FullFilename.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDriveFileSummary_FullFilename.Location = New System.Drawing.Point(957, 153)
        Me.txtDriveFileSummary_FullFilename.Name = "txtDriveFileSummary_FullFilename"
        Me.txtDriveFileSummary_FullFilename.ReadOnly = True
        Me.txtDriveFileSummary_FullFilename.Size = New System.Drawing.Size(500, 20)
        Me.txtDriveFileSummary_FullFilename.TabIndex = 88
        Me.txtDriveFileSummary_FullFilename.TabStop = False
        Me.txtDriveFileSummary_FullFilename.Visible = False
        '
        'txtAiredItems_FullFilename
        '
        Me.txtAiredItems_FullFilename.BackColor = System.Drawing.SystemColors.Window
        Me.txtAiredItems_FullFilename.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAiredItems_FullFilename.Location = New System.Drawing.Point(928, 136)
        Me.txtAiredItems_FullFilename.Name = "txtAiredItems_FullFilename"
        Me.txtAiredItems_FullFilename.ReadOnly = True
        Me.txtAiredItems_FullFilename.Size = New System.Drawing.Size(500, 20)
        Me.txtAiredItems_FullFilename.TabIndex = 62
        Me.txtAiredItems_FullFilename.TabStop = False
        Me.txtAiredItems_FullFilename.Visible = False
        '
        'cboFileCount
        '
        Me.cboFileCount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFileCount.FormattingEnabled = True
        Me.cboFileCount.Location = New System.Drawing.Point(928, 134)
        Me.cboFileCount.Name = "cboFileCount"
        Me.cboFileCount.Size = New System.Drawing.Size(105, 21)
        Me.cboFileCount.TabIndex = 69
        Me.cboFileCount.Visible = False
        '
        'lblUpdateStatus_Report
        '
        Me.lblUpdateStatus_Report.AutoSize = True
        Me.lblUpdateStatus_Report.Location = New System.Drawing.Point(947, 144)
        Me.lblUpdateStatus_Report.Name = "lblUpdateStatus_Report"
        Me.lblUpdateStatus_Report.Size = New System.Drawing.Size(116, 13)
        Me.lblUpdateStatus_Report.TabIndex = 84
        Me.lblUpdateStatus_Report.Text = "Update Status - Report"
        Me.lblUpdateStatus_Report.Visible = False
        '
        'txtOmdbAPI_Desc
        '
        Me.txtOmdbAPI_Desc.BackColor = System.Drawing.SystemColors.Window
        Me.txtOmdbAPI_Desc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtOmdbAPI_Desc.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOmdbAPI_Desc.Location = New System.Drawing.Point(969, 144)
        Me.txtOmdbAPI_Desc.Multiline = True
        Me.txtOmdbAPI_Desc.Name = "txtOmdbAPI_Desc"
        Me.txtOmdbAPI_Desc.ReadOnly = True
        Me.txtOmdbAPI_Desc.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtOmdbAPI_Desc.Size = New System.Drawing.Size(550, 75)
        Me.txtOmdbAPI_Desc.TabIndex = 54
        Me.txtOmdbAPI_Desc.TabStop = False
        Me.txtOmdbAPI_Desc.Visible = False
        '
        'lvwNonStandardFiles
        '
        Me.lvwNonStandardFiles.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lvwNonStandardFiles.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader14, Me.ColumnHeader15, Me.ColumnHeader16, Me.ColumnHeader17, Me.ColumnHeader18, Me.ColumnHeader19})
        Me.lvwNonStandardFiles.ContextMenuStrip = Me.mnuNonStandardRightClick
        Me.lvwNonStandardFiles.FullRowSelect = True
        Me.lvwNonStandardFiles.GridLines = True
        Me.lvwNonStandardFiles.HideSelection = False
        Me.lvwNonStandardFiles.Location = New System.Drawing.Point(934, 144)
        Me.lvwNonStandardFiles.Name = "lvwNonStandardFiles"
        Me.lvwNonStandardFiles.Size = New System.Drawing.Size(371, 101)
        Me.lvwNonStandardFiles.TabIndex = 12
        Me.lvwNonStandardFiles.UseCompatibleStateImageBehavior = False
        Me.lvwNonStandardFiles.View = System.Windows.Forms.View.Details
        Me.lvwNonStandardFiles.Visible = False
        '
        'ColumnHeader14
        '
        Me.ColumnHeader14.Text = "Drive"
        Me.ColumnHeader14.Width = 120
        '
        'ColumnHeader15
        '
        Me.ColumnHeader15.Text = "Folder"
        Me.ColumnHeader15.Width = 275
        '
        'ColumnHeader16
        '
        Me.ColumnHeader16.Text = "Name"
        Me.ColumnHeader16.Width = 275
        '
        'ColumnHeader17
        '
        Me.ColumnHeader17.Text = "Type"
        '
        'ColumnHeader18
        '
        Me.ColumnHeader18.Text = "Size"
        Me.ColumnHeader18.Width = 90
        '
        'ColumnHeader19
        '
        Me.ColumnHeader19.Text = "Modified Date"
        Me.ColumnHeader19.Width = 150
        '
        'mnuNonStandardRightClick
        '
        Me.mnuNonStandardRightClick.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuNonStandardFilesDelete})
        Me.mnuNonStandardRightClick.Name = "mnuNonStandardRightClick"
        Me.mnuNonStandardRightClick.Size = New System.Drawing.Size(108, 26)
        '
        'mnuNonStandardFilesDelete
        '
        Me.mnuNonStandardFilesDelete.Name = "mnuNonStandardFilesDelete"
        Me.mnuNonStandardFilesDelete.Size = New System.Drawing.Size(107, 22)
        Me.mnuNonStandardFilesDelete.Text = "Delete"
        '
        'lvwMumsStuff
        '
        Me.lvwMumsStuff.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lvwMumsStuff.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader35, Me.ColumnHeader36})
        Me.lvwMumsStuff.FullRowSelect = True
        Me.lvwMumsStuff.GridLines = True
        Me.lvwMumsStuff.HideSelection = False
        Me.lvwMumsStuff.Location = New System.Drawing.Point(1027, 129)
        Me.lvwMumsStuff.Name = "lvwMumsStuff"
        Me.lvwMumsStuff.Size = New System.Drawing.Size(393, 164)
        Me.lvwMumsStuff.TabIndex = 42
        Me.lvwMumsStuff.UseCompatibleStateImageBehavior = False
        Me.lvwMumsStuff.View = System.Windows.Forms.View.Details
        Me.lvwMumsStuff.Visible = False
        '
        'ColumnHeader35
        '
        Me.ColumnHeader35.Text = "Name"
        Me.ColumnHeader35.Width = 500
        '
        'ColumnHeader36
        '
        Me.ColumnHeader36.Text = "Drive"
        Me.ColumnHeader36.Width = 150
        '
        'lvwToDo
        '
        Me.lvwToDo.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader32, Me.ColumnHeader37, Me.ColumnHeader65})
        Me.lvwToDo.FullRowSelect = True
        Me.lvwToDo.GridLines = True
        Me.lvwToDo.HideSelection = False
        Me.lvwToDo.Location = New System.Drawing.Point(1019, 123)
        Me.lvwToDo.MultiSelect = False
        Me.lvwToDo.Name = "lvwToDo"
        Me.lvwToDo.Size = New System.Drawing.Size(867, 127)
        Me.lvwToDo.TabIndex = 44
        Me.lvwToDo.UseCompatibleStateImageBehavior = False
        Me.lvwToDo.View = System.Windows.Forms.View.Details
        Me.lvwToDo.Visible = False
        '
        'ColumnHeader32
        '
        Me.ColumnHeader32.Text = "Title"
        Me.ColumnHeader32.Width = 350
        '
        'ColumnHeader37
        '
        Me.ColumnHeader37.Text = "Description"
        Me.ColumnHeader37.Width = 735
        '
        'ColumnHeader65
        '
        Me.ColumnHeader65.Text = "SeqNo"
        Me.ColumnHeader65.Width = 0
        '
        'lvwKnownDups
        '
        Me.lvwKnownDups.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader33, Me.ColumnHeader34, Me.ColumnHeader38})
        Me.lvwKnownDups.ContextMenuStrip = Me.mnuListviewRightClick_Delete
        Me.lvwKnownDups.FullRowSelect = True
        Me.lvwKnownDups.GridLines = True
        Me.lvwKnownDups.HideSelection = False
        Me.lvwKnownDups.Location = New System.Drawing.Point(1019, 124)
        Me.lvwKnownDups.MultiSelect = False
        Me.lvwKnownDups.Name = "lvwKnownDups"
        Me.lvwKnownDups.Size = New System.Drawing.Size(867, 127)
        Me.lvwKnownDups.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.lvwKnownDups.TabIndex = 40
        Me.lvwKnownDups.UseCompatibleStateImageBehavior = False
        Me.lvwKnownDups.View = System.Windows.Forms.View.Details
        Me.lvwKnownDups.Visible = False
        '
        'ColumnHeader33
        '
        Me.ColumnHeader33.Text = "ID"
        Me.ColumnHeader33.Width = 50
        '
        'ColumnHeader34
        '
        Me.ColumnHeader34.Text = "Path"
        Me.ColumnHeader34.Width = 500
        '
        'ColumnHeader38
        '
        Me.ColumnHeader38.Text = "Notes"
        Me.ColumnHeader38.Width = 350
        '
        'mnuListviewRightClick_Delete
        '
        Me.mnuListviewRightClick_Delete.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuListview_Delete})
        Me.mnuListviewRightClick_Delete.Name = "mnuListviewRightClick_Delete"
        Me.mnuListviewRightClick_Delete.Size = New System.Drawing.Size(108, 26)
        '
        'mnuListview_Delete
        '
        Me.mnuListview_Delete.Name = "mnuListview_Delete"
        Me.mnuListview_Delete.Size = New System.Drawing.Size(107, 22)
        Me.mnuListview_Delete.Text = "Delete"
        '
        'cmdDriveFileSummary_FullFilename_Copy
        '
        Me.cmdDriveFileSummary_FullFilename_Copy.Location = New System.Drawing.Point(938, 144)
        Me.cmdDriveFileSummary_FullFilename_Copy.Name = "cmdDriveFileSummary_FullFilename_Copy"
        Me.cmdDriveFileSummary_FullFilename_Copy.Size = New System.Drawing.Size(75, 23)
        Me.cmdDriveFileSummary_FullFilename_Copy.TabIndex = 90
        Me.cmdDriveFileSummary_FullFilename_Copy.Text = "Copy"
        Me.cmdDriveFileSummary_FullFilename_Copy.UseVisualStyleBackColor = True
        Me.cmdDriveFileSummary_FullFilename_Copy.Visible = False
        '
        'txtAiredItems_FullFilenamewithoutETTV
        '
        Me.txtAiredItems_FullFilenamewithoutETTV.BackColor = System.Drawing.SystemColors.Window
        Me.txtAiredItems_FullFilenamewithoutETTV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAiredItems_FullFilenamewithoutETTV.Location = New System.Drawing.Point(924, 126)
        Me.txtAiredItems_FullFilenamewithoutETTV.Name = "txtAiredItems_FullFilenamewithoutETTV"
        Me.txtAiredItems_FullFilenamewithoutETTV.ReadOnly = True
        Me.txtAiredItems_FullFilenamewithoutETTV.Size = New System.Drawing.Size(500, 20)
        Me.txtAiredItems_FullFilenamewithoutETTV.TabIndex = 73
        Me.txtAiredItems_FullFilenamewithoutETTV.TabStop = False
        Me.txtAiredItems_FullFilenamewithoutETTV.Visible = False
        '
        'cmdDriveFileSummary_SeriesName_Copy
        '
        Me.cmdDriveFileSummary_SeriesName_Copy.Location = New System.Drawing.Point(983, 144)
        Me.cmdDriveFileSummary_SeriesName_Copy.Name = "cmdDriveFileSummary_SeriesName_Copy"
        Me.cmdDriveFileSummary_SeriesName_Copy.Size = New System.Drawing.Size(75, 23)
        Me.cmdDriveFileSummary_SeriesName_Copy.TabIndex = 91
        Me.cmdDriveFileSummary_SeriesName_Copy.Text = "Copy"
        Me.cmdDriveFileSummary_SeriesName_Copy.UseVisualStyleBackColor = True
        Me.cmdDriveFileSummary_SeriesName_Copy.Visible = False
        '
        'cmdAiredItems_SeriesName_Copy
        '
        Me.cmdAiredItems_SeriesName_Copy.Location = New System.Drawing.Point(1000, 105)
        Me.cmdAiredItems_SeriesName_Copy.Name = "cmdAiredItems_SeriesName_Copy"
        Me.cmdAiredItems_SeriesName_Copy.Size = New System.Drawing.Size(75, 23)
        Me.cmdAiredItems_SeriesName_Copy.TabIndex = 80
        Me.cmdAiredItems_SeriesName_Copy.Text = "Copy"
        Me.cmdAiredItems_SeriesName_Copy.UseVisualStyleBackColor = True
        Me.cmdAiredItems_SeriesName_Copy.Visible = False
        '
        'cmdAiredItems_Title_Copy
        '
        Me.cmdAiredItems_Title_Copy.Location = New System.Drawing.Point(983, 119)
        Me.cmdAiredItems_Title_Copy.Name = "cmdAiredItems_Title_Copy"
        Me.cmdAiredItems_Title_Copy.Size = New System.Drawing.Size(75, 23)
        Me.cmdAiredItems_Title_Copy.TabIndex = 78
        Me.cmdAiredItems_Title_Copy.Text = "Copy"
        Me.cmdAiredItems_Title_Copy.UseVisualStyleBackColor = True
        Me.cmdAiredItems_Title_Copy.Visible = False
        '
        'cmdAiredItems_FullFilename_Copy
        '
        Me.cmdAiredItems_FullFilename_Copy.Location = New System.Drawing.Point(934, 73)
        Me.cmdAiredItems_FullFilename_Copy.Name = "cmdAiredItems_FullFilename_Copy"
        Me.cmdAiredItems_FullFilename_Copy.Size = New System.Drawing.Size(75, 23)
        Me.cmdAiredItems_FullFilename_Copy.TabIndex = 65
        Me.cmdAiredItems_FullFilename_Copy.Text = "Copy"
        Me.cmdAiredItems_FullFilename_Copy.UseVisualStyleBackColor = True
        Me.cmdAiredItems_FullFilename_Copy.Visible = False
        '
        'cmdDriveFileSummary_FullFilenamewithoutETTV_Copy
        '
        Me.cmdDriveFileSummary_FullFilenamewithoutETTV_Copy.Location = New System.Drawing.Point(983, 119)
        Me.cmdDriveFileSummary_FullFilenamewithoutETTV_Copy.Name = "cmdDriveFileSummary_FullFilenamewithoutETTV_Copy"
        Me.cmdDriveFileSummary_FullFilenamewithoutETTV_Copy.Size = New System.Drawing.Size(75, 23)
        Me.cmdDriveFileSummary_FullFilenamewithoutETTV_Copy.TabIndex = 92
        Me.cmdDriveFileSummary_FullFilenamewithoutETTV_Copy.Text = "Copy"
        Me.cmdDriveFileSummary_FullFilenamewithoutETTV_Copy.UseVisualStyleBackColor = True
        Me.cmdDriveFileSummary_FullFilenamewithoutETTV_Copy.Visible = False
        '
        'cmdAiredItems_FullFilenamewithoutETTV_Copy
        '
        Me.cmdAiredItems_FullFilenamewithoutETTV_Copy.Location = New System.Drawing.Point(988, 113)
        Me.cmdAiredItems_FullFilenamewithoutETTV_Copy.Name = "cmdAiredItems_FullFilenamewithoutETTV_Copy"
        Me.cmdAiredItems_FullFilenamewithoutETTV_Copy.Size = New System.Drawing.Size(75, 23)
        Me.cmdAiredItems_FullFilenamewithoutETTV_Copy.TabIndex = 76
        Me.cmdAiredItems_FullFilenamewithoutETTV_Copy.Text = "Copy"
        Me.cmdAiredItems_FullFilenamewithoutETTV_Copy.UseVisualStyleBackColor = True
        Me.cmdAiredItems_FullFilenamewithoutETTV_Copy.Visible = False
        '
        'cmdDriveFileSummary_FilenameJustSeason_Copy
        '
        Me.cmdDriveFileSummary_FilenameJustSeason_Copy.Location = New System.Drawing.Point(988, 127)
        Me.cmdDriveFileSummary_FilenameJustSeason_Copy.Name = "cmdDriveFileSummary_FilenameJustSeason_Copy"
        Me.cmdDriveFileSummary_FilenameJustSeason_Copy.Size = New System.Drawing.Size(75, 23)
        Me.cmdDriveFileSummary_FilenameJustSeason_Copy.TabIndex = 93
        Me.cmdDriveFileSummary_FilenameJustSeason_Copy.Text = "Copy"
        Me.cmdDriveFileSummary_FilenameJustSeason_Copy.UseVisualStyleBackColor = True
        Me.cmdDriveFileSummary_FilenameJustSeason_Copy.Visible = False
        '
        'cmdAiredItems_FilenameJustSeason_Copy
        '
        Me.cmdAiredItems_FilenameJustSeason_Copy.Location = New System.Drawing.Point(983, 115)
        Me.cmdAiredItems_FilenameJustSeason_Copy.Name = "cmdAiredItems_FilenameJustSeason_Copy"
        Me.cmdAiredItems_FilenameJustSeason_Copy.Size = New System.Drawing.Size(75, 23)
        Me.cmdAiredItems_FilenameJustSeason_Copy.TabIndex = 77
        Me.cmdAiredItems_FilenameJustSeason_Copy.Text = "Copy"
        Me.cmdAiredItems_FilenameJustSeason_Copy.UseVisualStyleBackColor = True
        Me.cmdAiredItems_FilenameJustSeason_Copy.Visible = False
        '
        'cmdShowList_Dups_TrollList
        '
        Me.cmdShowList_Dups_TrollList.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdShowList_Dups_TrollList.Location = New System.Drawing.Point(1007, 156)
        Me.cmdShowList_Dups_TrollList.Name = "cmdShowList_Dups_TrollList"
        Me.cmdShowList_Dups_TrollList.Size = New System.Drawing.Size(93, 25)
        Me.cmdShowList_Dups_TrollList.TabIndex = 81
        Me.cmdShowList_Dups_TrollList.Text = "Troll List"
        Me.ToolTip1.SetToolTip(Me.cmdShowList_Dups_TrollList, "Goes thu. list looking for dup shows that are alphabetically next to each other")
        Me.cmdShowList_Dups_TrollList.UseVisualStyleBackColor = True
        Me.cmdShowList_Dups_TrollList.Visible = False
        '
        'lvwShowList_Dups
        '
        Me.lvwShowList_Dups.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader29, Me.ColumnHeader31})
        Me.lvwShowList_Dups.ContextMenuStrip = Me.mnuListview_AddToDupsOnly
        Me.lvwShowList_Dups.FullRowSelect = True
        Me.lvwShowList_Dups.GridLines = True
        Me.lvwShowList_Dups.HideSelection = False
        Me.lvwShowList_Dups.Location = New System.Drawing.Point(928, 129)
        Me.lvwShowList_Dups.Name = "lvwShowList_Dups"
        Me.lvwShowList_Dups.Size = New System.Drawing.Size(867, 127)
        Me.lvwShowList_Dups.TabIndex = 38
        Me.lvwShowList_Dups.UseCompatibleStateImageBehavior = False
        Me.lvwShowList_Dups.View = System.Windows.Forms.View.Details
        Me.lvwShowList_Dups.Visible = False
        '
        'ColumnHeader29
        '
        Me.ColumnHeader29.Text = "Title"
        Me.ColumnHeader29.Width = 250
        '
        'ColumnHeader31
        '
        Me.ColumnHeader31.Text = "Drive"
        Me.ColumnHeader31.Width = 100
        '
        'mnuListview_AddToDupsOnly
        '
        Me.mnuListview_AddToDupsOnly.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAddToDups})
        Me.mnuListview_AddToDupsOnly.Name = "mnuRightClick"
        Me.mnuListview_AddToDupsOnly.Size = New System.Drawing.Size(169, 26)
        '
        'mnuAddToDups
        '
        Me.mnuAddToDups.Name = "mnuAddToDups"
        Me.mnuAddToDups.Size = New System.Drawing.Size(168, 22)
        Me.mnuAddToDups.Text = "Add to Duplicates"
        '
        'txtAiredItems_Seriesname
        '
        Me.txtAiredItems_Seriesname.BackColor = System.Drawing.SystemColors.Window
        Me.txtAiredItems_Seriesname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAiredItems_Seriesname.Location = New System.Drawing.Point(920, 137)
        Me.txtAiredItems_Seriesname.Name = "txtAiredItems_Seriesname"
        Me.txtAiredItems_Seriesname.ReadOnly = True
        Me.txtAiredItems_Seriesname.Size = New System.Drawing.Size(500, 20)
        Me.txtAiredItems_Seriesname.TabIndex = 79
        Me.txtAiredItems_Seriesname.TabStop = False
        Me.txtAiredItems_Seriesname.Visible = False
        '
        'lvwUpdateStatus
        '
        Me.lvwUpdateStatus.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lvwUpdateStatus.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colName1, Me.colID, Me.colMyTotal, Me.colAirDate1, Me.colWithoutAirdate, Me.colDiff, Me.colUpdateLast, Me.colInDoubt, Me.colCorrVersion, Me.colCompleted, Me.colFinished, Me.colError})
        Me.lvwUpdateStatus.FullRowSelect = True
        Me.lvwUpdateStatus.GridLines = True
        Me.lvwUpdateStatus.HideSelection = False
        Me.lvwUpdateStatus.Location = New System.Drawing.Point(950, 105)
        Me.lvwUpdateStatus.Name = "lvwUpdateStatus"
        Me.lvwUpdateStatus.Size = New System.Drawing.Size(967, 106)
        Me.lvwUpdateStatus.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.lvwUpdateStatus.TabIndex = 14
        Me.lvwUpdateStatus.UseCompatibleStateImageBehavior = False
        Me.lvwUpdateStatus.View = System.Windows.Forms.View.Details
        Me.lvwUpdateStatus.Visible = False
        '
        'colName1
        '
        Me.colName1.Text = "Name"
        Me.colName1.Width = 275
        '
        'colID
        '
        Me.colID.Text = "ID"
        '
        'colMyTotal
        '
        Me.colMyTotal.Text = "My Total"
        Me.colMyTotal.Width = 75
        '
        'colAirDate1
        '
        Me.colAirDate1.Text = "imDB - Airdate"
        Me.colAirDate1.Width = 100
        '
        'colWithoutAirdate
        '
        Me.colWithoutAirdate.Text = "imDB - without airdate"
        Me.colWithoutAirdate.Width = 120
        '
        'colDiff
        '
        Me.colDiff.Text = "Diff."
        Me.colDiff.Width = 78
        '
        'colUpdateLast
        '
        Me.colUpdateLast.Text = "Last Update imDB"
        Me.colUpdateLast.Width = 100
        '
        'colInDoubt
        '
        Me.colInDoubt.Text = "In Doubt"
        Me.colInDoubt.Width = 54
        '
        'colCorrVersion
        '
        Me.colCorrVersion.Text = "Corr. Version"
        Me.colCorrVersion.Width = 82
        '
        'colCompleted
        '
        Me.colCompleted.Text = "Compl."
        Me.colCompleted.Width = 50
        '
        'colFinished
        '
        Me.colFinished.Text = "Finished"
        Me.colFinished.Width = 50
        '
        'colError
        '
        Me.colError.Text = "imdb Update Error"
        Me.colError.Width = 175
        '
        'lvwSearchResults
        '
        Me.lvwSearchResults.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lvwSearchResults.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colDrive, Me.colFolder, Me.colName, Me.colType, Me.colSize, Me.ColMDate})
        Me.lvwSearchResults.FullRowSelect = True
        Me.lvwSearchResults.GridLines = True
        Me.lvwSearchResults.HideSelection = False
        Me.lvwSearchResults.Location = New System.Drawing.Point(1019, 126)
        Me.lvwSearchResults.Name = "lvwSearchResults"
        Me.lvwSearchResults.Size = New System.Drawing.Size(393, 164)
        Me.lvwSearchResults.TabIndex = 3
        Me.lvwSearchResults.UseCompatibleStateImageBehavior = False
        Me.lvwSearchResults.View = System.Windows.Forms.View.Details
        Me.lvwSearchResults.Visible = False
        '
        'colDrive
        '
        Me.colDrive.Text = "Drive"
        Me.colDrive.Width = 40
        '
        'colFolder
        '
        Me.colFolder.Text = "Folder"
        Me.colFolder.Width = 150
        '
        'colName
        '
        Me.colName.Text = "Name"
        Me.colName.Width = 150
        '
        'colType
        '
        Me.colType.Text = "Type"
        Me.colType.Width = 50
        '
        'colSize
        '
        Me.colSize.Text = "Size"
        Me.colSize.Width = 59
        '
        'ColMDate
        '
        Me.ColMDate.Text = "Modified Date"
        Me.ColMDate.Width = 20
        '
        'calCalendar_AirDates
        '
        Me.calCalendar_AirDates.Location = New System.Drawing.Point(1019, 108)
        Me.calCalendar_AirDates.MaxSelectionCount = 31
        Me.calCalendar_AirDates.Name = "calCalendar_AirDates"
        Me.calCalendar_AirDates.TabIndex = 32
        Me.calCalendar_AirDates.Visible = False
        '
        'txtDriveFileSummary_FullFilenamewithoutETTV
        '
        Me.txtDriveFileSummary_FullFilenamewithoutETTV.BackColor = System.Drawing.SystemColors.Window
        Me.txtDriveFileSummary_FullFilenamewithoutETTV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDriveFileSummary_FullFilenamewithoutETTV.Location = New System.Drawing.Point(947, 142)
        Me.txtDriveFileSummary_FullFilenamewithoutETTV.Name = "txtDriveFileSummary_FullFilenamewithoutETTV"
        Me.txtDriveFileSummary_FullFilenamewithoutETTV.ReadOnly = True
        Me.txtDriveFileSummary_FullFilenamewithoutETTV.Size = New System.Drawing.Size(500, 20)
        Me.txtDriveFileSummary_FullFilenamewithoutETTV.TabIndex = 89
        Me.txtDriveFileSummary_FullFilenamewithoutETTV.TabStop = False
        Me.txtDriveFileSummary_FullFilenamewithoutETTV.Visible = False
        '
        'lblAiredItems_ExplanationoftxtAiredItems_Title
        '
        Me.lblAiredItems_ExplanationoftxtAiredItems_Title.AutoSize = True
        Me.lblAiredItems_ExplanationoftxtAiredItems_Title.Location = New System.Drawing.Point(985, 137)
        Me.lblAiredItems_ExplanationoftxtAiredItems_Title.Name = "lblAiredItems_ExplanationoftxtAiredItems_Title"
        Me.lblAiredItems_ExplanationoftxtAiredItems_Title.Size = New System.Drawing.Size(163, 13)
        Me.lblAiredItems_ExplanationoftxtAiredItems_Title.TabIndex = 75
        Me.lblAiredItems_ExplanationoftxtAiredItems_Title.Text = "Useful when no Season\Episode"
        Me.lblAiredItems_ExplanationoftxtAiredItems_Title.Visible = False
        '
        'lvwListView
        '
        Me.lvwListView.FullRowSelect = True
        Me.lvwListView.GridLines = True
        Me.lvwListView.HideSelection = False
        Me.lvwListView.Location = New System.Drawing.Point(1034, 123)
        Me.lvwListView.MultiSelect = False
        Me.lvwListView.Name = "lvwListView"
        Me.lvwListView.Size = New System.Drawing.Size(867, 127)
        Me.lvwListView.TabIndex = 60
        Me.lvwListView.UseCompatibleStateImageBehavior = False
        Me.lvwListView.View = System.Windows.Forms.View.Details
        Me.lvwListView.Visible = False
        '
        'lvwDriveStatus
        '
        Me.lvwDriveStatus.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lvwDriveStatus.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader5, Me.ColumnHeader7, Me.ColumnHeader8, Me.ColumnHeader11, Me.ColumnHeader12, Me.ColumnHeader30, Me.ColumnHeader61, Me.ColumnHeader66, Me.ColumnHeader63, Me.ColumnHeader6})
        Me.lvwDriveStatus.FullRowSelect = True
        Me.lvwDriveStatus.GridLines = True
        Me.lvwDriveStatus.HideSelection = False
        Me.lvwDriveStatus.Location = New System.Drawing.Point(924, 108)
        Me.lvwDriveStatus.Name = "lvwDriveStatus"
        Me.lvwDriveStatus.Size = New System.Drawing.Size(1198, 120)
        Me.lvwDriveStatus.TabIndex = 5
        Me.lvwDriveStatus.UseCompatibleStateImageBehavior = False
        Me.lvwDriveStatus.View = System.Windows.Forms.View.Details
        Me.lvwDriveStatus.Visible = False
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "Drive Name"
        Me.ColumnHeader5.Width = 140
        '
        'ColumnHeader7
        '
        Me.ColumnHeader7.Text = "Last Backedup"
        Me.ColumnHeader7.Width = 125
        '
        'ColumnHeader8
        '
        Me.ColumnHeader8.Text = "Free Space"
        Me.ColumnHeader8.Width = 110
        '
        'ColumnHeader11
        '
        Me.ColumnHeader11.Text = "Space for Bkp"
        Me.ColumnHeader11.Width = 100
        '
        'ColumnHeader12
        '
        Me.ColumnHeader12.Text = "Capacity"
        Me.ColumnHeader12.Width = 70
        '
        'ColumnHeader30
        '
        Me.ColumnHeader30.Text = "Refresh Date"
        Me.ColumnHeader30.Width = 100
        '
        'ColumnHeader61
        '
        Me.ColumnHeader61.Text = "Earliest imdb Upd"
        Me.ColumnHeader61.Width = 100
        '
        'ColumnHeader66
        '
        Me.ColumnHeader66.DisplayIndex = 8
        Me.ColumnHeader66.Text = "Show"
        Me.ColumnHeader66.Width = 175
        '
        'ColumnHeader63
        '
        Me.ColumnHeader63.DisplayIndex = 9
        Me.ColumnHeader63.Text = "DriveID"
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.DisplayIndex = 7
        Me.ColumnHeader6.Text = "Last Auto Upd"
        Me.ColumnHeader6.Width = 100
        '
        'cmdAiredItems_Process
        '
        Me.cmdAiredItems_Process.Location = New System.Drawing.Point(957, 123)
        Me.cmdAiredItems_Process.Name = "cmdAiredItems_Process"
        Me.cmdAiredItems_Process.Size = New System.Drawing.Size(101, 23)
        Me.cmdAiredItems_Process.TabIndex = 94
        Me.cmdAiredItems_Process.Text = "Process"
        Me.ToolTip1.SetToolTip(Me.cmdAiredItems_Process, "Process for the selected month")
        Me.cmdAiredItems_Process.UseVisualStyleBackColor = True
        Me.cmdAiredItems_Process.Visible = False
        '
        'cboOmdbTitleLetter
        '
        Me.cboOmdbTitleLetter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboOmdbTitleLetter.FormattingEnabled = True
        Me.cboOmdbTitleLetter.Location = New System.Drawing.Point(945, 153)
        Me.cboOmdbTitleLetter.Name = "cboOmdbTitleLetter"
        Me.cboOmdbTitleLetter.Size = New System.Drawing.Size(190, 21)
        Me.cboOmdbTitleLetter.TabIndex = 55
        Me.cboOmdbTitleLetter.Visible = False
        '
        'lblDriveFileSummary_Info
        '
        Me.lblDriveFileSummary_Info.AutoSize = True
        Me.lblDriveFileSummary_Info.Location = New System.Drawing.Point(925, 137)
        Me.lblDriveFileSummary_Info.Name = "lblDriveFileSummary_Info"
        Me.lblDriveFileSummary_Info.Size = New System.Drawing.Size(239, 13)
        Me.lblDriveFileSummary_Info.TabIndex = 83
        Me.lblDriveFileSummary_Info.Text = "Only the 50 Largest && 50 Smallest files are loaded"
        Me.lblDriveFileSummary_Info.Visible = False
        '
        'txtDriveSummary_Desc
        '
        Me.txtDriveSummary_Desc.BackColor = System.Drawing.SystemColors.Window
        Me.txtDriveSummary_Desc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDriveSummary_Desc.Location = New System.Drawing.Point(957, 130)
        Me.txtDriveSummary_Desc.Multiline = True
        Me.txtDriveSummary_Desc.Name = "txtDriveSummary_Desc"
        Me.txtDriveSummary_Desc.ReadOnly = True
        Me.txtDriveSummary_Desc.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDriveSummary_Desc.Size = New System.Drawing.Size(500, 66)
        Me.txtDriveSummary_Desc.TabIndex = 82
        Me.txtDriveSummary_Desc.TabStop = False
        Me.txtDriveSummary_Desc.Visible = False
        '
        'cmdomdbAPI_Back
        '
        Me.cmdomdbAPI_Back.Location = New System.Drawing.Point(1047, 172)
        Me.cmdomdbAPI_Back.Name = "cmdomdbAPI_Back"
        Me.cmdomdbAPI_Back.Size = New System.Drawing.Size(40, 23)
        Me.cmdomdbAPI_Back.TabIndex = 67
        Me.cmdomdbAPI_Back.Text = "<<"
        Me.cmdomdbAPI_Back.UseVisualStyleBackColor = True
        Me.cmdomdbAPI_Back.Visible = False
        '
        'lvwOmdbAPI
        '
        Me.lvwOmdbAPI.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader39, Me.ColumnHeader62, Me.ColumnHeader40, Me.ColumnHeader41, Me.ColumnHeader42, Me.ColumnHeader43, Me.ColumnHeader44, Me.ColumnHeader45, Me.ColumnHeader46, Me.ColumnHeader47})
        Me.lvwOmdbAPI.FullRowSelect = True
        Me.lvwOmdbAPI.GridLines = True
        Me.lvwOmdbAPI.HideSelection = False
        Me.lvwOmdbAPI.Location = New System.Drawing.Point(934, 71)
        Me.lvwOmdbAPI.MultiSelect = False
        Me.lvwOmdbAPI.Name = "lvwOmdbAPI"
        Me.lvwOmdbAPI.Size = New System.Drawing.Size(867, 127)
        Me.lvwOmdbAPI.TabIndex = 53
        Me.lvwOmdbAPI.UseCompatibleStateImageBehavior = False
        Me.lvwOmdbAPI.View = System.Windows.Forms.View.Details
        Me.lvwOmdbAPI.Visible = False
        '
        'ColumnHeader39
        '
        Me.ColumnHeader39.Text = "Title"
        Me.ColumnHeader39.Width = 250
        '
        'ColumnHeader62
        '
        Me.ColumnHeader62.Text = "Drive"
        '
        'ColumnHeader40
        '
        Me.ColumnHeader40.Text = "Rating"
        '
        'ColumnHeader41
        '
        Me.ColumnHeader41.Text = "Votes"
        Me.ColumnHeader41.Width = 75
        '
        'ColumnHeader42
        '
        Me.ColumnHeader42.Text = "Country"
        Me.ColumnHeader42.Width = 80
        '
        'ColumnHeader43
        '
        Me.ColumnHeader43.Text = "Genre"
        Me.ColumnHeader43.Width = 150
        '
        'ColumnHeader44
        '
        Me.ColumnHeader44.Text = "Start"
        Me.ColumnHeader44.Width = 55
        '
        'ColumnHeader45
        '
        Me.ColumnHeader45.Text = "End"
        Me.ColumnHeader45.Width = 55
        '
        'ColumnHeader46
        '
        Me.ColumnHeader46.Text = "Seasons"
        Me.ColumnHeader46.Width = 70
        '
        'ColumnHeader47
        '
        Me.ColumnHeader47.Text = "Desc"
        Me.ColumnHeader47.Width = 2500
        '
        'txtMultiLineTextbox
        '
        Me.txtMultiLineTextbox.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.txtMultiLineTextbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMultiLineTextbox.Location = New System.Drawing.Point(1019, 116)
        Me.txtMultiLineTextbox.Multiline = True
        Me.txtMultiLineTextbox.Name = "txtMultiLineTextbox"
        Me.txtMultiLineTextbox.ReadOnly = True
        Me.txtMultiLineTextbox.Size = New System.Drawing.Size(192, 86)
        Me.txtMultiLineTextbox.TabIndex = 3
        Me.txtMultiLineTextbox.Visible = False
        '
        'chkBothTypes
        '
        Me.chkBothTypes.AutoSize = True
        Me.chkBothTypes.Location = New System.Drawing.Point(1166, 4)
        Me.chkBothTypes.Name = "chkBothTypes"
        Me.chkBothTypes.Size = New System.Drawing.Size(151, 17)
        Me.chkBothTypes.TabIndex = 8
        Me.chkBothTypes.Text = "Include backups in search"
        Me.chkBothTypes.UseVisualStyleBackColor = True
        '
        'mnuRightClick
        '
        Me.mnuRightClick.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuExpandAll, Me.mnuCollapseAll, Me.mnuFindCompletedFiles, Me.mnuFindCompletedFilesSeason, Me.mnuMakeSeasonStandard, Me.mnuMoveFilesFromRootToSeason1, Me.mnuMoveTo, Me.mnuCreateMissingSeasons, Me.mnuCreateMissingSeasonsUpTo})
        Me.mnuRightClick.Name = "mnuRightClick"
        Me.mnuRightClick.Size = New System.Drawing.Size(266, 202)
        '
        'mnuExpandAll
        '
        Me.mnuExpandAll.Name = "mnuExpandAll"
        Me.mnuExpandAll.Size = New System.Drawing.Size(265, 22)
        Me.mnuExpandAll.Text = "Expand"
        '
        'mnuCollapseAll
        '
        Me.mnuCollapseAll.Name = "mnuCollapseAll"
        Me.mnuCollapseAll.Size = New System.Drawing.Size(265, 22)
        Me.mnuCollapseAll.Text = "Collapse"
        '
        'mnuFindCompletedFiles
        '
        Me.mnuFindCompletedFiles.Name = "mnuFindCompletedFiles"
        Me.mnuFindCompletedFiles.Size = New System.Drawing.Size(265, 22)
        Me.mnuFindCompletedFiles.Text = "Find Completed Files"
        '
        'mnuFindCompletedFilesSeason
        '
        Me.mnuFindCompletedFilesSeason.Name = "mnuFindCompletedFilesSeason"
        Me.mnuFindCompletedFilesSeason.Size = New System.Drawing.Size(265, 22)
        Me.mnuFindCompletedFilesSeason.Text = "Find Completed Files for this Season"
        '
        'mnuMakeSeasonStandard
        '
        Me.mnuMakeSeasonStandard.Name = "mnuMakeSeasonStandard"
        Me.mnuMakeSeasonStandard.Size = New System.Drawing.Size(265, 22)
        Me.mnuMakeSeasonStandard.Text = "Make Season Name Standard"
        '
        'mnuMoveFilesFromRootToSeason1
        '
        Me.mnuMoveFilesFromRootToSeason1.Name = "mnuMoveFilesFromRootToSeason1"
        Me.mnuMoveFilesFromRootToSeason1.Size = New System.Drawing.Size(265, 22)
        Me.mnuMoveFilesFromRootToSeason1.Text = "Move Files from Root to Season 1"
        '
        'mnuMoveTo
        '
        Me.mnuMoveTo.Name = "mnuMoveTo"
        Me.mnuMoveTo.Size = New System.Drawing.Size(265, 22)
        Me.mnuMoveTo.Text = "Move to..."
        '
        'mnuCreateMissingSeasons
        '
        Me.mnuCreateMissingSeasons.Name = "mnuCreateMissingSeasons"
        Me.mnuCreateMissingSeasons.Size = New System.Drawing.Size(265, 22)
        Me.mnuCreateMissingSeasons.Text = "Create Missing Folders"
        '
        'mnuCreateMissingSeasonsUpTo
        '
        Me.mnuCreateMissingSeasonsUpTo.Name = "mnuCreateMissingSeasonsUpTo"
        Me.mnuCreateMissingSeasonsUpTo.Size = New System.Drawing.Size(265, 22)
        Me.mnuCreateMissingSeasonsUpTo.Text = "Create Missing Folder - Upto"
        '
        'Timer1
        '
        Me.Timer1.Interval = 5000
        '
        'FileSystemWatcher1
        '
        Me.FileSystemWatcher1.EnableRaisingEvents = True
        Me.FileSystemWatcher1.SynchronizingObject = Me
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.DrivesToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1679, 24)
        Me.MenuStrip1.TabIndex = 4
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAiredItems, Me.mnuRefreshDrives, Me.mnuDriveStatus, Me.mnuLastFilesAdded, Me.mnuFindNonStandardFiles, Me.mnuMajorFolders, Me.mnuMumsStuff, Me.mnuDriveSummary, Me.mnuDriveFileSummary, Me.mnuomdbAPI, Me.mnuPeopleAlsoLiked, Me.mnuRottenTomatoes, Me.mnuAutoUpdate, Me.mnuUpdateMyTotals, Me.mnuUpdateStatus, Me.mnuKnownDuplicates, Me.mnuDuplicates, Me.mnuShowList_UsedforDups, Me.mnuToDo, Me.mnuToDownload, Me.mnuSimpleConsistencyChecker, Me.mnuFailedDownloads, Me.mnuOptions, Me.ToolStripMenuItem1, Me.mnuExit})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'mnuAiredItems
        '
        Me.mnuAiredItems.Name = "mnuAiredItems"
        Me.mnuAiredItems.Size = New System.Drawing.Size(314, 22)
        Me.mnuAiredItems.Text = "Aired Items"
        '
        'mnuRefreshDrives
        '
        Me.mnuRefreshDrives.Name = "mnuRefreshDrives"
        Me.mnuRefreshDrives.Size = New System.Drawing.Size(314, 22)
        Me.mnuRefreshDrives.Text = "Refresh Drives"
        '
        'mnuDriveStatus
        '
        Me.mnuDriveStatus.Name = "mnuDriveStatus"
        Me.mnuDriveStatus.Size = New System.Drawing.Size(314, 22)
        Me.mnuDriveStatus.Text = "Drive Status"
        '
        'mnuLastFilesAdded
        '
        Me.mnuLastFilesAdded.Name = "mnuLastFilesAdded"
        Me.mnuLastFilesAdded.Size = New System.Drawing.Size(314, 22)
        Me.mnuLastFilesAdded.Text = "Last Files Added"
        '
        'mnuFindNonStandardFiles
        '
        Me.mnuFindNonStandardFiles.Name = "mnuFindNonStandardFiles"
        Me.mnuFindNonStandardFiles.Size = New System.Drawing.Size(314, 22)
        Me.mnuFindNonStandardFiles.Text = "Find Non Standard Files"
        '
        'mnuMajorFolders
        '
        Me.mnuMajorFolders.Name = "mnuMajorFolders"
        Me.mnuMajorFolders.Size = New System.Drawing.Size(314, 22)
        Me.mnuMajorFolders.Text = "Major Folders"
        '
        'mnuMumsStuff
        '
        Me.mnuMumsStuff.Name = "mnuMumsStuff"
        Me.mnuMumsStuff.Size = New System.Drawing.Size(314, 22)
        Me.mnuMumsStuff.Text = "Mums Stuff"
        '
        'mnuDriveSummary
        '
        Me.mnuDriveSummary.Name = "mnuDriveSummary"
        Me.mnuDriveSummary.Size = New System.Drawing.Size(314, 22)
        Me.mnuDriveSummary.Text = "Drive Summary"
        '
        'mnuDriveFileSummary
        '
        Me.mnuDriveFileSummary.Name = "mnuDriveFileSummary"
        Me.mnuDriveFileSummary.Size = New System.Drawing.Size(314, 22)
        Me.mnuDriveFileSummary.Text = "Drive File Summary"
        '
        'mnuomdbAPI
        '
        Me.mnuomdbAPI.Name = "mnuomdbAPI"
        Me.mnuomdbAPI.Size = New System.Drawing.Size(314, 22)
        Me.mnuomdbAPI.Text = "omdb API"
        '
        'mnuPeopleAlsoLiked
        '
        Me.mnuPeopleAlsoLiked.Name = "mnuPeopleAlsoLiked"
        Me.mnuPeopleAlsoLiked.Size = New System.Drawing.Size(314, 22)
        Me.mnuPeopleAlsoLiked.Text = "People Also Liked - All"
        '
        'mnuRottenTomatoes
        '
        Me.mnuRottenTomatoes.Name = "mnuRottenTomatoes"
        Me.mnuRottenTomatoes.Size = New System.Drawing.Size(314, 22)
        Me.mnuRottenTomatoes.Text = "Rotten Tomatoes"
        '
        'mnuAutoUpdate
        '
        Me.mnuAutoUpdate.Name = "mnuAutoUpdate"
        Me.mnuAutoUpdate.Size = New System.Drawing.Size(314, 22)
        Me.mnuAutoUpdate.Text = "Auto Update"
        '
        'mnuUpdateMyTotals
        '
        Me.mnuUpdateMyTotals.Name = "mnuUpdateMyTotals"
        Me.mnuUpdateMyTotals.Size = New System.Drawing.Size(314, 22)
        Me.mnuUpdateMyTotals.Text = "Update My Totals (Run after adding new files)"
        '
        'mnuUpdateStatus
        '
        Me.mnuUpdateStatus.Name = "mnuUpdateStatus"
        Me.mnuUpdateStatus.Size = New System.Drawing.Size(314, 22)
        Me.mnuUpdateStatus.Text = "Update Status / Missing Items"
        '
        'mnuKnownDuplicates
        '
        Me.mnuKnownDuplicates.Name = "mnuKnownDuplicates"
        Me.mnuKnownDuplicates.Size = New System.Drawing.Size(314, 22)
        Me.mnuKnownDuplicates.Text = "Known Duplicates - X"
        '
        'mnuDuplicates
        '
        Me.mnuDuplicates.Name = "mnuDuplicates"
        Me.mnuDuplicates.Size = New System.Drawing.Size(314, 22)
        Me.mnuDuplicates.Text = "Search for Duplicates"
        '
        'mnuShowList_UsedforDups
        '
        Me.mnuShowList_UsedforDups.Name = "mnuShowList_UsedforDups"
        Me.mnuShowList_UsedforDups.Size = New System.Drawing.Size(314, 22)
        Me.mnuShowList_UsedforDups.Text = "Show List (Used to find dup shows)"
        '
        'mnuToDo
        '
        Me.mnuToDo.Name = "mnuToDo"
        Me.mnuToDo.Size = New System.Drawing.Size(314, 22)
        Me.mnuToDo.Text = "To Do"
        '
        'mnuToDownload
        '
        Me.mnuToDownload.Name = "mnuToDownload"
        Me.mnuToDownload.Size = New System.Drawing.Size(314, 22)
        Me.mnuToDownload.Text = "To Download"
        '
        'mnuSimpleConsistencyChecker
        '
        Me.mnuSimpleConsistencyChecker.Name = "mnuSimpleConsistencyChecker"
        Me.mnuSimpleConsistencyChecker.Size = New System.Drawing.Size(314, 22)
        Me.mnuSimpleConsistencyChecker.Text = "Simple Consistency Checker"
        '
        'mnuFailedDownloads
        '
        Me.mnuFailedDownloads.Name = "mnuFailedDownloads"
        Me.mnuFailedDownloads.Size = New System.Drawing.Size(314, 22)
        Me.mnuFailedDownloads.Text = "Failed Downloads"
        Me.mnuFailedDownloads.Visible = False
        '
        'mnuOptions
        '
        Me.mnuOptions.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuOptionsFinished, Me.mnuOptionsComplete})
        Me.mnuOptions.Name = "mnuOptions"
        Me.mnuOptions.Size = New System.Drawing.Size(314, 22)
        Me.mnuOptions.Text = "Options"
        '
        'mnuOptionsFinished
        '
        Me.mnuOptionsFinished.Checked = True
        Me.mnuOptionsFinished.CheckState = System.Windows.Forms.CheckState.Checked
        Me.mnuOptionsFinished.Name = "mnuOptionsFinished"
        Me.mnuOptionsFinished.Size = New System.Drawing.Size(158, 22)
        Me.mnuOptionsFinished.Text = "Show Finished"
        '
        'mnuOptionsComplete
        '
        Me.mnuOptionsComplete.Checked = True
        Me.mnuOptionsComplete.CheckState = System.Windows.Forms.CheckState.Checked
        Me.mnuOptionsComplete.Name = "mnuOptionsComplete"
        Me.mnuOptionsComplete.Size = New System.Drawing.Size(158, 22)
        Me.mnuOptionsComplete.Text = "Show Complete"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(311, 6)
        '
        'mnuExit
        '
        Me.mnuExit.Name = "mnuExit"
        Me.mnuExit.Size = New System.Drawing.Size(314, 22)
        Me.mnuExit.Text = "E&xit"
        '
        'DrivesToolStripMenuItem
        '
        Me.DrivesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuMountTV9, Me.mnuMountTV10, Me.mnuMountTV11, Me.mnuMountTV12})
        Me.DrivesToolStripMenuItem.Name = "DrivesToolStripMenuItem"
        Me.DrivesToolStripMenuItem.Size = New System.Drawing.Size(51, 20)
        Me.DrivesToolStripMenuItem.Text = "Drives"
        '
        'mnuMountTV9
        '
        Me.mnuMountTV9.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuUseTV9R, Me.mnuUseTV9T, Me.mnuUseTV9Y})
        Me.mnuMountTV9.Name = "mnuMountTV9"
        Me.mnuMountTV9.Size = New System.Drawing.Size(142, 22)
        Me.mnuMountTV9.Text = "Mount TV 9"
        '
        'mnuUseTV9R
        '
        Me.mnuUseTV9R.Name = "mnuUseTV9R"
        Me.mnuUseTV9R.Size = New System.Drawing.Size(103, 22)
        Me.mnuUseTV9R.Text = "Use R"
        '
        'mnuUseTV9T
        '
        Me.mnuUseTV9T.Name = "mnuUseTV9T"
        Me.mnuUseTV9T.Size = New System.Drawing.Size(103, 22)
        Me.mnuUseTV9T.Text = "Use T"
        '
        'mnuUseTV9Y
        '
        Me.mnuUseTV9Y.Name = "mnuUseTV9Y"
        Me.mnuUseTV9Y.Size = New System.Drawing.Size(103, 22)
        Me.mnuUseTV9Y.Text = "Use Y"
        '
        'mnuMountTV10
        '
        Me.mnuMountTV10.Name = "mnuMountTV10"
        Me.mnuMountTV10.Size = New System.Drawing.Size(142, 22)
        Me.mnuMountTV10.Text = "Mount TV 10"
        '
        'mnuMountTV11
        '
        Me.mnuMountTV11.Name = "mnuMountTV11"
        Me.mnuMountTV11.Size = New System.Drawing.Size(142, 22)
        Me.mnuMountTV11.Text = "Mount TV 11"
        '
        'mnuMountTV12
        '
        Me.mnuMountTV12.Name = "mnuMountTV12"
        Me.mnuMountTV12.Size = New System.Drawing.Size(142, 22)
        Me.mnuMountTV12.Text = "Mount TV 12"
        '
        'mnuListviewRightClick
        '
        Me.mnuListviewRightClick.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuDeleteFiles, Me.mnuDup_Email, Me.mnuDup_Record, Me.mnuDuplicateBoth})
        Me.mnuListviewRightClick.Name = "mnuRightClick"
        Me.mnuListviewRightClick.Size = New System.Drawing.Size(169, 92)
        '
        'mnuDeleteFiles
        '
        Me.mnuDeleteFiles.Name = "mnuDeleteFiles"
        Me.mnuDeleteFiles.Size = New System.Drawing.Size(168, 22)
        Me.mnuDeleteFiles.Text = "Delete File(s)"
        '
        'mnuDup_Email
        '
        Me.mnuDup_Email.Name = "mnuDup_Email"
        Me.mnuDup_Email.Size = New System.Drawing.Size(168, 22)
        Me.mnuDup_Email.Text = "Duplicate - Email"
        Me.mnuDup_Email.Visible = False
        '
        'mnuDup_Record
        '
        Me.mnuDup_Record.Name = "mnuDup_Record"
        Me.mnuDup_Record.Size = New System.Drawing.Size(168, 22)
        Me.mnuDup_Record.Text = "Add to Duplicates"
        '
        'mnuDuplicateBoth
        '
        Me.mnuDuplicateBoth.Name = "mnuDuplicateBoth"
        Me.mnuDuplicateBoth.Size = New System.Drawing.Size(168, 22)
        Me.mnuDuplicateBoth.Text = "Duplicate - Both"
        Me.mnuDuplicateBoth.Visible = False
        '
        'tmrUpdateTimer
        '
        Me.tmrUpdateTimer.Interval = 4000
        '
        'mnuListview_DriveFileSummary
        '
        Me.mnuListview_DriveFileSummary.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuDriveFileSummary_GeneralTodo})
        Me.mnuListview_DriveFileSummary.Name = "mnuRightClick"
        Me.mnuListview_DriveFileSummary.Size = New System.Drawing.Size(145, 26)
        '
        'mnuDriveFileSummary_GeneralTodo
        '
        Me.mnuDriveFileSummary_GeneralTodo.Name = "mnuDriveFileSummary_GeneralTodo"
        Me.mnuDriveFileSummary_GeneralTodo.Size = New System.Drawing.Size(144, 22)
        Me.mnuDriveFileSummary_GeneralTodo.Text = "General Todo"
        '
        'frmMediaManager
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1679, 572)
        Me.Controls.Add(Me.chkBothTypes)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMediaManager"
        Me.Text = "Media Manager"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.Panel2.PerformLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.tabFiles.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.fraOperations.ResumeLayout(False)
        Me.fraOperations.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage8.PerformLayout()
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        Me.TabPage10.ResumeLayout(False)
        Me.TabPage10.PerformLayout()
        Me.tabDetails.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.fraDetails.ResumeLayout(False)
        Me.fraDetails.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.fraMissing.ResumeLayout(False)
        Me.fraMissing.PerformLayout()
        Me.mnuNonStandardRightClick.ResumeLayout(False)
        Me.mnuListviewRightClick_Delete.ResumeLayout(False)
        Me.mnuListview_AddToDupsOnly.ResumeLayout(False)
        Me.mnuRightClick.ResumeLayout(False)
        CType(Me.FileSystemWatcher1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.mnuListviewRightClick.ResumeLayout(False)
        Me.mnuListview_DriveFileSummary.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents cmdUpdateTV As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmdUpdateTV_Backup As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmdUpdateTV2 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmdUpdateTV2_Backup As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmdUpdateMovies As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmdUpdateMovies_Backup As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents txtSearch As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents cmdFileSearch As System.Windows.Forms.ToolStripButton
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents treDrives As System.Windows.Forms.TreeView
    Friend WithEvents lblErrors As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents mnuRightClick As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mnuFindCompletedFiles As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFindCompletedFilesSeason As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmdUpdateTV3 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmdUpdateTV3_Backup As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents lblMessage As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents cmdUpdateTV4 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmdUpdateTV4_Backup As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator11 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmdFinished As System.Windows.Forms.Button
    Friend WithEvents lvwSearchResults As System.Windows.Forms.ListView
    Friend WithEvents colDrive As System.Windows.Forms.ColumnHeader
    Friend WithEvents colFolder As System.Windows.Forms.ColumnHeader
    Friend WithEvents colName As System.Windows.Forms.ColumnHeader
    Friend WithEvents colType As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColMDate As System.Windows.Forms.ColumnHeader
    Friend WithEvents colSize As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdFinished_DriveStatus As System.Windows.Forms.Button
    Friend WithEvents lvwDriveStatus As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader8 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lblLastError As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents FileSystemWatcher1 As System.IO.FileSystemWatcher
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuDriveStatus As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMajorFolders As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmdFinished_MajorFolders As System.Windows.Forms.Button
    Friend WithEvents lvwMajorFolders As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader9 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader10 As System.Windows.Forms.ColumnHeader
    Friend WithEvents mnuDuplicates As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuLastFilesAdded As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmdFolderSearch As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator13 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmdUpdateTV7 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmdUpdateTV7_Backup As System.Windows.Forms.ToolStripButton
    Friend WithEvents chkBothTypes As System.Windows.Forms.CheckBox
    Friend WithEvents lblNumberOfRows As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ColumnHeader11 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdUpdateTV5 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator14 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmdUpdateTV5_Backup As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator15 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ColumnHeader12 As System.Windows.Forms.ColumnHeader
    Friend WithEvents tabFiles As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents lvwFiles As System.Windows.Forms.ListView
    Friend WithEvents colFileName As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents tabDetails As System.Windows.Forms.TabControl
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents fraDetails As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cboCorrectVersion As System.Windows.Forms.ComboBox
    Friend WithEvents chkDetailsinDoubt As System.Windows.Forms.CheckBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmdUpdateNow As System.Windows.Forms.Button
    Friend WithEvents optImdb As System.Windows.Forms.RadioButton
    Friend WithEvents txtLastUpdate_IMDB As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtSeasonCount As System.Windows.Forms.TextBox
    Friend WithEvents txtRating As System.Windows.Forms.TextBox
    Friend WithEvents txtEnd As System.Windows.Forms.TextBox
    Friend WithEvents txtGenre As System.Windows.Forms.TextBox
    Friend WithEvents txtStart As System.Windows.Forms.TextBox
    Friend WithEvents lblImdbRating As System.Windows.Forms.Label
    Friend WithEvents txtIMDBSeasonsEpisodes As System.Windows.Forms.TextBox
    Friend WithEvents lblSeasons As System.Windows.Forms.Label
    Friend WithEvents lblGenre As System.Windows.Forms.Label
    Friend WithEvents lblStart As System.Windows.Forms.Label
    Friend WithEvents lblDescription As System.Windows.Forms.Label
    Friend WithEvents txtID As System.Windows.Forms.TextBox
    Friend WithEvents txtSeriesName As System.Windows.Forms.TextBox
    Friend WithEvents txtDescription As System.Windows.Forms.TextBox
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents lvwIMDBFiles As System.Windows.Forms.ListView
    Friend WithEvents colName_ As System.Windows.Forms.ColumnHeader
    Friend WithEvents txtTotal As System.Windows.Forms.TextBox
    Friend WithEvents lblTotal As System.Windows.Forms.Label
    Friend WithEvents txtMyTotal As System.Windows.Forms.TextBox
    Friend WithEvents lblMyTotal As System.Windows.Forms.Label
    Friend WithEvents mnuMakeSeasonStandard As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents lvwUpdatefilenames As System.Windows.Forms.ListView
    Friend WithEvents colNameOnDisk As System.Windows.Forms.ColumnHeader
    Friend WithEvents colTypeOnDisk As System.Windows.Forms.ColumnHeader
    Friend WithEvents colProposedName As System.Windows.Forms.ColumnHeader
    Friend WithEvents fraOperations As System.Windows.Forms.GroupBox
    Friend WithEvents cmdUpdFilesUpdateFilenamesInListview As System.Windows.Forms.Button
    Friend WithEvents txtOperationTextbox2 As System.Windows.Forms.TextBox
    Friend WithEvents txtOperationTextbox1 As System.Windows.Forms.TextBox
    Friend WithEvents lblOperationLabel2 As System.Windows.Forms.Label
    Friend WithEvents lblOperationLabel1 As System.Windows.Forms.Label
    Friend WithEvents cmdUpdFilesApplyProposedFilenames As System.Windows.Forms.Button
    Friend WithEvents cmdUpdFilesRevertToOriginalNames As System.Windows.Forms.Button
    Friend WithEvents txtCurrentFilename As System.Windows.Forms.TextBox
    Friend WithEvents cmdUpdFilesRemoveSelectionsinGrid As System.Windows.Forms.Button
    Friend WithEvents lstOperations As System.Windows.Forms.ListBox
    Friend WithEvents cmdUpdFilesRemoveItemFromGrid As System.Windows.Forms.Button
    Friend WithEvents cmdIMDB As System.Windows.Forms.Button
    Friend WithEvents mnuFindNonStandardFiles As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lvwNonStandardFiles As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader14 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader15 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader16 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader17 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader18 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader19 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdFinished_NonStandardFiles As System.Windows.Forms.Button
    Friend WithEvents mnuListviewRightClick As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mnuDeleteFiles As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents colAirDate As System.Windows.Forms.ColumnHeader
    Friend WithEvents txtPlot As System.Windows.Forms.TextBox
    Friend WithEvents txtTotalWithAirdate As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtCountry As System.Windows.Forms.TextBox
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents lvwSeasons As System.Windows.Forms.ListView
    Friend WithEvents colSeason As System.Windows.Forms.ColumnHeader
    Friend WithEvents colEpisode As System.Windows.Forms.ColumnHeader
    Friend WithEvents coltitle As System.Windows.Forms.ColumnHeader
    Friend WithEvents Airdate As System.Windows.Forms.ColumnHeader
    Friend WithEvents txtSeasonsTab_Plot As System.Windows.Forms.TextBox
    Friend WithEvents mnuAutoUpdate As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tmrUpdateTimer As System.Windows.Forms.Timer
    Friend WithEvents mnuExpandAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuCollapseAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuUpdateStatus As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAiredItems As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cboDrives As System.Windows.Forms.ComboBox
    Friend WithEvents lvwUpdateStatus As System.Windows.Forms.ListView
    Friend WithEvents colName1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents colInDoubt As System.Windows.Forms.ColumnHeader
    Friend WithEvents colCorrVersion As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdFinished_UpdateStatus As System.Windows.Forms.Button
    Friend WithEvents colMyTotal As System.Windows.Forms.ColumnHeader
    Friend WithEvents colAirDate1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents colWithoutAirdate As System.Windows.Forms.ColumnHeader
    Friend WithEvents colUpdateLast As System.Windows.Forms.ColumnHeader
    Friend WithEvents colError As System.Windows.Forms.ColumnHeader
    Friend WithEvents colDiff As System.Windows.Forms.ColumnHeader
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents lvwPeopleLiked As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader13 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader22 As System.Windows.Forms.ColumnHeader
    Friend WithEvents mnuPeopleAlsoLiked As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lvwPeopleLiked_All As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader25 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader26 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader27 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdFinishedPeopleLiked_All As System.Windows.Forms.Button
    Friend WithEvents cmdUpdate_OMDB_Only As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents cmdIMDB_Name As System.Windows.Forms.Button
    Friend WithEvents colID As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdUpdateStatusUpdateDetails As System.Windows.Forms.Button
    Friend WithEvents calCalendar_AirDates As System.Windows.Forms.MonthCalendar
    Friend WithEvents lvwAiredShows As System.Windows.Forms.ListView
    Friend WithEvents colShow As System.Windows.Forms.ColumnHeader
    Friend WithEvents colEpisode_ As System.Windows.Forms.ColumnHeader
    Friend WithEvents colDate As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdFinished_AiredShows As System.Windows.Forms.Button
    Friend WithEvents colSeason_ As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader28 As System.Windows.Forms.ColumnHeader
    Friend WithEvents mnuShowList_UsedforDups As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lvwShowList_Dups As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader29 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader31 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdFinished_ShowList_Dups As System.Windows.Forms.Button
    Friend WithEvents cmdUpdateTV6 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator16 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmdUpdateTV6_Backup As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator17 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmdClearID As System.Windows.Forms.Button
    Friend WithEvents cmdUpdateTV8 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator18 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmdUpdateTV8_Backup As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator19 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuRefreshDrives As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ColumnHeader30 As System.Windows.Forms.ColumnHeader
    Friend WithEvents mnuDup_Email As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuDup_Record As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuKnownDuplicates As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lvwKnownDups As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader33 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader34 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdFinished_KnownDuplicates As System.Windows.Forms.Button
    Friend WithEvents mnuMumsStuff As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lvwMumsStuff As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader35 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader36 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdFinished_MumsStuff As System.Windows.Forms.Button
    Friend WithEvents mnuDuplicateBoth As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents chkComplete As System.Windows.Forms.CheckBox
    Friend WithEvents chkFinished As System.Windows.Forms.CheckBox
    Friend WithEvents txtDiscSeasonsEpisodes As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents mnuOptions As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuOptionsFinished As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuOptionsComplete As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents txtLastUpdate_API As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtAPITitle As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents mnuMoveFilesFromRootToSeason1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents fraMissing As System.Windows.Forms.GroupBox
    Friend WithEvents txtMissingEpisodes As System.Windows.Forms.TextBox
    Friend WithEvents txtMissingSeasons As System.Windows.Forms.TextBox
    Friend WithEvents mnuMoveTo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents chkX264_Season As System.Windows.Forms.CheckBox
    Friend WithEvents chkX264_Episode As System.Windows.Forms.CheckBox
    Friend WithEvents mnuToDo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmdFinished_ToDo As System.Windows.Forms.Button
    Friend WithEvents lvwToDo As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader32 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader37 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdToDo_Delete As System.Windows.Forms.Button
    Friend WithEvents cmdToDo_Edit As System.Windows.Forms.Button
    Friend WithEvents cmdToDo_Add As System.Windows.Forms.Button
    Friend WithEvents mnuCreateMissingSeasons As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuNonStandardRightClick As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mnuNonStandardFilesDelete As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents chkNonStandard_DoBackup As System.Windows.Forms.CheckBox
    Friend WithEvents mnuCreateMissingSeasonsUpTo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuListviewRightClick_Delete As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mnuListview_Delete As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ColumnHeader38 As System.Windows.Forms.ColumnHeader
    Friend WithEvents txtUpdFilenamesHelp As System.Windows.Forms.TextBox
    Friend WithEvents chkNonStandard_IgnoreSubtitle As System.Windows.Forms.CheckBox
    Friend WithEvents cmdAddToToDo As System.Windows.Forms.Button
    Friend WithEvents chkNonStandard_IgnoreTTCFiles As System.Windows.Forms.CheckBox
    Friend WithEvents cmdToDo_General As System.Windows.Forms.Button
    Friend WithEvents mnuomdbAPI As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmdFinished_OmdbAPI As System.Windows.Forms.Button
    Friend WithEvents lvwOmdbAPI As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader39 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader40 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader41 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader42 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader43 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader44 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader45 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader46 As System.Windows.Forms.ColumnHeader
    Friend WithEvents txtOmdbAPI_Desc As System.Windows.Forms.TextBox
    Friend WithEvents ColumnHeader47 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cboOmdbCountries As System.Windows.Forms.ComboBox
    Friend WithEvents cboOmdbTitleLetter As System.Windows.Forms.ComboBox
    Friend WithEvents mnuToDownload As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmdAddMissingToToDownload As System.Windows.Forms.Button
    Friend WithEvents cmdAddSelMissingToToDownload As System.Windows.Forms.Button
    Friend WithEvents chkUpdateStatus_Missing As System.Windows.Forms.CheckBox
    Friend WithEvents colCompleted As System.Windows.Forms.ColumnHeader
    Friend WithEvents colFinished As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdAddSelMissingSeasonsToToDownload As System.Windows.Forms.Button
    Friend WithEvents cmdAddMissingSeasonsToToDownload As System.Windows.Forms.Button
    Friend WithEvents chkUpdateStatus_IgnoreCompleted As System.Windows.Forms.CheckBox
    Friend WithEvents mnuFailedDownloads As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmdMissing As System.Windows.Forms.Button
    Friend WithEvents mnuUpdateMyTotals As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents lvwCompletedFiles As System.Windows.Forms.ListView
    Friend WithEvents colCompPath As System.Windows.Forms.ColumnHeader
    Friend WithEvents colCompName As System.Windows.Forms.ColumnHeader
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents lvwUpdateStatus_Tab As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader20 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader21 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader23 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader24 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader48 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader49 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader50 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader51 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader52 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader53 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader54 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader55 As System.Windows.Forms.ColumnHeader
    Friend WithEvents chkUpdateStatus_Missing_Tab As System.Windows.Forms.CheckBox
    Friend WithEvents cboDrives_Tab As System.Windows.Forms.ComboBox
    Friend WithEvents chkUpdateStatus_IgnoreCompleted_Tab As System.Windows.Forms.CheckBox
    Friend WithEvents mnuRottenTomatoes As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmdFinished_RottenTomatoes As System.Windows.Forms.Button
    Friend WithEvents lvwRottenTomatoes As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader56 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader57 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader58 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader59 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader60 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader64 As System.Windows.Forms.ColumnHeader
    Friend WithEvents mnuDriveSummary As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lvwListView As System.Windows.Forms.ListView
    Friend WithEvents cmdFinished_Listview As System.Windows.Forms.Button
    Friend WithEvents chkSeasonOK As System.Windows.Forms.CheckBox
    Friend WithEvents colAiredLocation As System.Windows.Forms.ColumnHeader
    Friend WithEvents colAiredimdbID As System.Windows.Forms.ColumnHeader
    Friend WithEvents txtAiredItems_FullFilename As System.Windows.Forms.TextBox
    Friend WithEvents colAiredDrive As System.Windows.Forms.ColumnHeader
    Friend WithEvents txtAiredItems_Title As System.Windows.Forms.TextBox
    Friend WithEvents colAiredTitle As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdAiredItems_FullFilename_Copy As System.Windows.Forms.Button
    Friend WithEvents prgProgress As System.Windows.Forms.ProgressBar
    Friend WithEvents mnuListview_AddToDupsOnly As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mnuAddToDups As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmdomdbAPI_Back As System.Windows.Forms.Button
    Friend WithEvents cmdomdbAPI_Forward As System.Windows.Forms.Button
    Friend WithEvents ColumnHeader61 As System.Windows.Forms.ColumnHeader
    Friend WithEvents txtMultiLineTextbox As System.Windows.Forms.TextBox
    Friend WithEvents ToolStripSeparator20 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmdReloadDrives As System.Windows.Forms.ToolStripButton
    Friend WithEvents cboFileCount As System.Windows.Forms.ComboBox
    Friend WithEvents TabPage10 As System.Windows.Forms.TabPage
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtURLWiki As System.Windows.Forms.TextBox
    Friend WithEvents cmdWikiForward As System.Windows.Forms.Button
    Friend WithEvents cmdWikiBack As System.Windows.Forms.Button
    Friend WithEvents webWiki As System.Windows.Forms.WebBrowser
    Friend WithEvents cmdWikiLoad As System.Windows.Forms.Button
    Friend WithEvents cmdWikiLoadEpisodes As System.Windows.Forms.Button
    Friend WithEvents cmdomdbAPI_IMDB As System.Windows.Forms.Button
    Friend WithEvents txtomdbAPI_SeriesName As System.Windows.Forms.TextBox
    Friend WithEvents ColumnHeader62 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader63 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cboCompletedSeasons As System.Windows.Forms.ComboBox
    Friend WithEvents lblCompletedSeasons As System.Windows.Forms.Label
    Friend WithEvents cmdCompletedSeasons As System.Windows.Forms.Button
    Friend WithEvents ColumnHeader65 As System.Windows.Forms.ColumnHeader
    Friend WithEvents mnuSimpleConsistencyChecker As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmdSeasonsTab_Order As System.Windows.Forms.Button
    Friend WithEvents txtAiredItems_FullFilenamewithoutETTV As System.Windows.Forms.TextBox
    Friend WithEvents txtAiredItems_FilenameJustSeason As System.Windows.Forms.TextBox
    Friend WithEvents lblAiredItems_ExplanationoftxtAiredItems_Title As System.Windows.Forms.Label
    Friend WithEvents cmdAiredItems_Title_Copy As System.Windows.Forms.Button
    Friend WithEvents cmdAiredItems_FilenameJustSeason_Copy As System.Windows.Forms.Button
    Friend WithEvents cmdAiredItems_FullFilenamewithoutETTV_Copy As System.Windows.Forms.Button
    Friend WithEvents txtAiredItems_Seriesname As System.Windows.Forms.TextBox
    Friend WithEvents cmdAiredItems_SeriesName_Copy As System.Windows.Forms.Button
    Friend WithEvents cmdShowList_Dups_TrollList As System.Windows.Forms.Button
    Friend WithEvents txtDriveSummary_Desc As System.Windows.Forms.TextBox
    Friend WithEvents mnuDriveFileSummary As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblDriveFileSummary_Info As System.Windows.Forms.Label
    Friend WithEvents mnuListview_DriveFileSummary As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mnuDriveFileSummary_GeneralTodo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblUpdateStatus_Report As System.Windows.Forms.Label
    Friend WithEvents ColumnHeader66 As System.Windows.Forms.ColumnHeader
    Friend WithEvents txtDriveFileSummary_Seriesname As System.Windows.Forms.TextBox
    Friend WithEvents txtDriveFileSummary_FilenameJustSeason As System.Windows.Forms.TextBox
    Friend WithEvents txtDriveFileSummary_FullFilenamewithoutETTV As System.Windows.Forms.TextBox
    Friend WithEvents txtDriveFileSummary_FullFilename As System.Windows.Forms.TextBox
    Friend WithEvents cmdDriveFileSummary_FullFilename_Copy As System.Windows.Forms.Button
    Friend WithEvents cmdDriveFileSummary_SeriesName_Copy As System.Windows.Forms.Button
    Friend WithEvents cmdDriveFileSummary_FullFilenamewithoutETTV_Copy As System.Windows.Forms.Button
    Friend WithEvents cmdDriveFileSummary_FilenameJustSeason_Copy As System.Windows.Forms.Button
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdAiredItems_Process As System.Windows.Forms.Button
    Friend WithEvents DrivesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMountTV9 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMountTV10 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMountTV11 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMountTV12 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuUseTV9R As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuUseTV9T As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuUseTV9Y As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmdUpdateTV9 As ToolStripButton
    Friend WithEvents ToolStripSeparator12 As ToolStripSeparator
    Friend WithEvents cmdUpdateTV9_Backup As ToolStripButton
    Friend WithEvents ToolStripSeparator21 As ToolStripSeparator
    Friend WithEvents cmdUpdateTV10 As ToolStripButton
    Friend WithEvents ToolStripSeparator22 As ToolStripSeparator
    Friend WithEvents cmdUpdateTV10_Backup As ToolStripButton
    Friend WithEvents ToolStripSeparator23 As ToolStripSeparator
    Friend WithEvents cmdSaveID As Button
    Friend WithEvents Label10 As Label
    Friend WithEvents txtAltName As TextBox
    Friend WithEvents ColumnHeader67 As ColumnHeader
End Class
