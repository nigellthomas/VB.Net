﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMyMessageBox
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMyMessageBox))
        Me.lblText = New System.Windows.Forms.Label()
        Me.cmdOne = New System.Windows.Forms.Button()
        Me.cmdTwo = New System.Windows.Forms.Button()
        Me.cmdThree = New System.Windows.Forms.Button()
        Me.lblBackforButtons = New System.Windows.Forms.Label()
        Me.lblBackforText = New System.Windows.Forms.Label()
        Me.picIcon = New System.Windows.Forms.PictureBox()
        CType(Me.picIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblText
        '
        Me.lblText.BackColor = System.Drawing.Color.White
        Me.lblText.Location = New System.Drawing.Point(85, 9)
        Me.lblText.Name = "lblText"
        Me.lblText.Size = New System.Drawing.Size(423, 155)
        Me.lblText.TabIndex = 0
        Me.lblText.Text = "message text"
        '
        'cmdOne
        '
        Me.cmdOne.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdOne.Location = New System.Drawing.Point(290, 194)
        Me.cmdOne.Name = "cmdOne"
        Me.cmdOne.Size = New System.Drawing.Size(93, 25)
        Me.cmdOne.TabIndex = 8
        Me.cmdOne.UseVisualStyleBackColor = True
        Me.cmdOne.Visible = False
        '
        'cmdTwo
        '
        Me.cmdTwo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdTwo.Location = New System.Drawing.Point(389, 194)
        Me.cmdTwo.Name = "cmdTwo"
        Me.cmdTwo.Size = New System.Drawing.Size(93, 25)
        Me.cmdTwo.TabIndex = 9
        Me.cmdTwo.UseVisualStyleBackColor = True
        Me.cmdTwo.Visible = False
        '
        'cmdThree
        '
        Me.cmdThree.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdThree.Location = New System.Drawing.Point(488, 194)
        Me.cmdThree.Name = "cmdThree"
        Me.cmdThree.Size = New System.Drawing.Size(93, 25)
        Me.cmdThree.TabIndex = 10
        Me.cmdThree.UseVisualStyleBackColor = True
        Me.cmdThree.Visible = False
        '
        'lblBackforButtons
        '
        Me.lblBackforButtons.Location = New System.Drawing.Point(-4, 164)
        Me.lblBackforButtons.Name = "lblBackforButtons"
        Me.lblBackforButtons.Size = New System.Drawing.Size(607, 71)
        Me.lblBackforButtons.TabIndex = 11
        Me.lblBackforButtons.Text = "Back for buttons"
        '
        'lblBackforText
        '
        Me.lblBackforText.BackColor = System.Drawing.Color.White
        Me.lblBackforText.Location = New System.Drawing.Point(-4, 0)
        Me.lblBackforText.Name = "lblBackforText"
        Me.lblBackforText.Size = New System.Drawing.Size(607, 164)
        Me.lblBackforText.TabIndex = 12
        Me.lblBackforText.Text = "back for text"
        '
        'picIcon
        '
        Me.picIcon.Image = CType(resources.GetObject("picIcon.Image"), System.Drawing.Image)
        Me.picIcon.Location = New System.Drawing.Point(12, 26)
        Me.picIcon.Name = "picIcon"
        Me.picIcon.Size = New System.Drawing.Size(45, 43)
        Me.picIcon.TabIndex = 13
        Me.picIcon.TabStop = False
        '
        'frmMyMessageBox
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(593, 231)
        Me.Controls.Add(Me.picIcon)
        Me.Controls.Add(Me.lblText)
        Me.Controls.Add(Me.lblBackforText)
        Me.Controls.Add(Me.cmdThree)
        Me.Controls.Add(Me.cmdTwo)
        Me.Controls.Add(Me.cmdOne)
        Me.Controls.Add(Me.lblBackforButtons)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmMyMessageBox"
        CType(Me.picIcon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblText As System.Windows.Forms.Label
    Friend WithEvents cmdOne As System.Windows.Forms.Button
    Friend WithEvents cmdTwo As System.Windows.Forms.Button
    Friend WithEvents cmdThree As System.Windows.Forms.Button
    Friend WithEvents lblBackforButtons As System.Windows.Forms.Label
    Friend WithEvents lblBackforText As System.Windows.Forms.Label
    Friend WithEvents picIcon As System.Windows.Forms.PictureBox
End Class
