﻿Public Class frmDrive

    Public SelectedDrive As String

    Public Sub LoadDrives(ByVal blnConnectedOnly As Boolean, ByVal blnNonBackupDrivesOnly As Boolean)

        Dim strDrive As String, intCount As Integer

        cboDrives.Items.Clear()

        For intCount = 1 To 18

            Select Case intCount

                Case 1 : strDrive = TV
                Case 2 : strDrive = TV_Backup
                Case 3 : strDrive = TV2
                Case 4 : strDrive = TV2_Backup
                Case 5 : strDrive = TV3
                Case 6 : strDrive = TV3_Backup
                Case 7 : strDrive = TV4
                Case 8 : strDrive = TV4_Backup
                Case 9 : strDrive = TV5
                Case 10 : strDrive = TV5_Backup
                Case 11 : strDrive = TV6
                Case 12 : strDrive = TV6_Backup
                Case 13 : strDrive = TV7
                Case 14 : strDrive = TV7_Backup
                Case 15 : strDrive = TV8
                Case 16 : strDrive = TV8_Backup

                Case 17 : strDrive = TV9
                Case 18 : strDrive = TV9_Backup

                Case 19 : strDrive = TV10
                Case 20 : strDrive = TV10_Backup

                Case 21 : strDrive = Movies
                Case 22 : strDrive = Movies_Backup

            End Select

            If blnConnectedOnly Then

                If IsDriveConnected(strDrive) Then

                    If blnNonBackupDrivesOnly = False Then

                        cboDrives.Items.Add(strDrive)
                    Else

                        If InStr(strDrive, " Backup") = 0 Then

                            cboDrives.Items.Add(strDrive)
                        End If
                    End If

                End If

            Else

                If blnNonBackupDrivesOnly = False Then

                    cboDrives.Items.Add(strDrive)
                Else

                    If InStr(strDrive, " Backup") = 0 Then

                        cboDrives.Items.Add(strDrive)
                    End If
                End If

            End If
        Next

        If cboDrives.Items.Count > 0 Then

            cboDrives.SelectedIndex = 0
        Else

            cmdOK.Enabled = False
        End If

    End Sub

    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click

        SelectedDrive = ""

    End Sub

    Private Sub cmdOK_Click(sender As Object, e As EventArgs) Handles cmdOK.Click

        SelectedDrive = cboDrives.Text

    End Sub
End Class