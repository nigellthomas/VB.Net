﻿Module modConsts

    Public Const TABS_FOR_FILE = vbTab
    Public Const FIND_COMPLETED_FILES_LOCATION = "C:\Documents and Settings\Owner\My Documents\Downloads\_Completed\_To Be Moved\"

    Public Const MAX_DUPLICATE_COUNT = 4

    Public Const APP_NAME = "Media Manager"

    Public Const AUTO_UPDATE_MENU = "Auto Update"
    Public Const AUTO_UPDATE_STOP_MENU = "Stop Auto Updater"

    Public Const TAB_IMDB As Integer = 1

    Public Const SIZE_ADJUSTMENT_FOR_DETAIL_PANEL As Integer = 305
    Public Const DEFAULT_TOP As Integer = 1
    Public Const DEFAULT_HEIGHT_REDUCATION As Integer = 52

    Public Const COL_UPDATESTATUS_NAME As Integer = 0
    Public Const COL_UPDATESTATUS_ID As Integer = 1

    Public Const COL_DRIVESTATUS_DRIVEID As Integer = 8
    Public Const COL_DRIVEFILESUMMARY_SIZEINMB As Integer = 3

    Public Const PEOPLE_COL_IMDBID As Integer = 3

    Public Const OMDBAPI_TitleColumn As Integer = 0
    Public Const OMDBAPI_RatingColumn As Integer = 2
    Public Const OMDBAPI_DescColumn As Integer = 9

    Public Const OMDBAPI_NumberToShow As Integer = 250

    Public Const DRIVE_SUMMARY = "Drive Summary"
    Public Const DRIVE_FILE_SUMMARY = "Drive File Summary"
    Public Const Update_Status = "Update Status"

    Public Const COMPLETED_TAB = "TabPage8"

    Public Const TV = "F:\TV"
    Public mstrTV_FreeSpace As String
    Public Const TV_Backup = "V:\TV Backup"
    Public mstrTV_Backup_FreeSpace As String

    Public Const TV2 = "T:\TV 2"
    Public mstrTV2_FreeSpace As String
    Public Const TV2_Backup = "W:\TV 2 Backup"
    Public mstrTV2_Backup_FreeSpace As String

    Public Const TV3 = "R:\TV 3"
    Public mstrTV3_FreeSpace As String
    Public Const TV3_Backup = "S:\TV 3 Backup"
    Public mstrTV3_Backup_FreeSpace As String

    Public Const TV4 = "P:\TV 4"
    Public mstrTV4_FreeSpace As String
    Public Const TV4_Backup = "U:\TV 4 Backup"
    Public mstrTV4_Backup_FreeSpace As String

    Public Const TV5 = "L:\TV 5"
    Public mstrTV5_FreeSpace As String
    Public Const TV5_Backup = "X:\TV 5 Backup"
    Public mstrTV5_Backup_FreeSpace As String

    Public Const TV6 = "Y:\TV 6"
    Public mstrTV6_FreeSpace As String
    Public Const TV6_Backup = "Z:\TV 6 Backup"
    Public mstrTV6_Backup_FreeSpace As String

    Public Const TV7 = "A:\TV 7"
    Public mstrTV7_FreeSpace As String
    Public Const TV7_Backup = "K:\TV 7 Backup"
    Public mstrTV7_Backup_FreeSpace As String

    Public Const TV8 = "Q:\TV 8"
    Public mstrTV8_FreeSpace As String
    Public Const TV8_Backup = "Y:\TV 8 Backup"
    Public mstrTV8_Backup_FreeSpace As String

    ' Use the DOS command mountvol to find the volume id of a drive
    ' https://superuser.com/questions/465730/access-to-a-disk-drive-using-volume-id-instead-of-a-drive-letter-in-windows

    Public OLDDRIVE As String = "OLDDRIVE"
    Public NEWDRIVE As String = "NEWDRIVE"

    Public TV9 = "Q:\TV 9"
    Public mstrTV9_FreeSpace As String
    Public TV9_Backup = "Y:\TV 9 Backup"
    Public mstrTV9_Backup_FreeSpace As String

    Public Const TV10 = "Q:\TV 10"
    Public mstrTV10_FreeSpace As String
    Public Const TV10_Backup = "Y:\TV 10 Backup"
    Public mstrTV10_Backup_FreeSpace As String

    Public Const TV11 = "TV 11"
    Public mstrTV11_FreeSpace As String
    Public Const TV11_Backup = "TV 11 Backup"
    Public mstrTV11_Backup_FreeSpace As String

    Public Const TV12 = "TV 12"
    Public mstrTV12_FreeSpace As String
    Public Const TV12_Backup = "TV 12 Backup"
    Public mstrTV12_Backup_FreeSpace As String

    Public Const Movies = "N:\Movies"
    Public mstrMovies_FreeSpace As String
    Public Const Movies_Backup = "O:\Movies Backup"
    Public mstrMovies_Backup_FreeSpace As String

    Public FILES_BACKUP_LOCATION As String

    Public Const ToDownload As String = "ToDownload"
    Public Const FailedDownloads As String = "FailedDownloads"

    Public Const FOLDER_BOOKS As String = "_Books"
    Public Const FOLDER_MAGS As String = "_Magazines"
    Public Const FOLDER_TV As String = "_TV"
    Public Const FOLDER_MOVIES As String = "_Movies"
    Public Const FOLDER_PROCESSED As String = "_Processed"
    Public Const FOLDER_MUSIC As String = "_Music"
    Public Const FOLDER_DELETED As String = "_Deleted"

End Module
