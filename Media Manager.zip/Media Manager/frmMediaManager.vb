﻿Imports System
Imports System.Diagnostics.Eventing.Reader
Imports System.IO

Public Class frmMediaManager

    Private mobjColumn_ToDo As ColumnHeader
    Private mobjColumn_NonStandard As ColumnHeader
    Private mobjColumn_Files As ColumnHeader
    Private mobjColumn_MumsStuff As ColumnHeader
    Private mobjColumn_KnownDups As ColumnHeader
    Private mobjColumn_Last100FilesAdded As ColumnHeader
    Private mobjColumn_DriveStatus As ColumnHeader
    Private mobjColumn_UpdateStatus As ColumnHeader
    Private mobjColumn_omdbAPI As ColumnHeader
    Private mobjColumn_showList_Dups As ColumnHeader
    Private mobjColumn_RottenTomatoes As ColumnHeader
    Private mobjColumn_Listview As ColumnHeader

    Private mstrPath As String

    Private mstrErrors As String, mSearchColour As Color

    Private mblnAutoUpdating As Boolean
    Private mblnFinishedLoading As Boolean

    Private Const DRIVE_NOT_FOUND As String = "unknown"

    Private KAT_URL As String = "http://freeproxy.io/o.php?u=http%3A%2F%2Fkat.cr%2Fusearch%2F%3Fq%3D"

    Private mstrRefreshPath As String
    Private mstrRefreshPathCurrentFile As String

    Private mstrDuplicatesText As String, mstrAutoUpdater_Drive As String
    Private mblnDupFile As Boolean
    Private mblnLoadingCompletedFiles As Boolean

    Private mblnIgnoreCheckedEvent As Boolean
    Private mintRowUpperLimit As Integer
    Private mstrTypeUsingDriveControl As String

    Private marrTVFolderFiles() As String

    Private mblnSeasonsOrderAsc As Boolean

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

    End Sub

    Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click

        CloseOLEConnection(mobjOLEConn)

        Me.Close()

        End

    End Sub

    Private Sub frmMediaUpdater_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load

        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized

        lblNumberOfRows.Text = ""
        lblMessage.Text = ""
        lblErrors.Text = ""
        mblnSeasonsOrderAsc = False

        GetDBConnection(My.Application.Info.DirectoryPath & "\MediaManager.mdb")

        GetOptions()

        mSearchColour = Color.LightSalmon

        Me.Show()

        LoadDrives()

        UpdateLabels()

        LoadOperations(lstOperations)
        LoadCountries()
        LoadTitleLetter()

        UpdateKnownDups()

        mblnFinishedLoading = True

        fraDetails.Left = 3

    End Sub

    Private Sub frmMediaUpdater_Resize(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Resize

        Dim intWidth As Integer

        If Me.Width < 1450 Then Me.Width = 1450
        If Me.Height < 1000 Then Me.Height = 1000

        tabFiles.Height = SplitContainer1.Panel2.Height - SIZE_ADJUSTMENT_FOR_DETAIL_PANEL
        tabFiles.Width = SplitContainer1.Panel2.Width - 10

        tabDetails.Top = tabFiles.Top + tabFiles.Height + 6
        tabDetails.Width = tabFiles.Width
        tabDetails.Left = tabFiles.Left

        lvwFiles.Height = tabFiles.Height - 32
        lvwFiles.Width = tabFiles.Width - 12

        lvwUpdatefilenames.Width = tabFiles.Width - 18

        fraOperations.Left = lvwUpdatefilenames.Left
        fraOperations.Width = lvwUpdatefilenames.Width - 10
        fraOperations.Height = 170
        fraOperations.Top = tabFiles.Height - fraOperations.Height - 30

        lvwUpdatefilenames.Height = (tabFiles.Height - 38) - fraOperations.Height

        lvwFiles.Columns(0).Width = lvwFiles.Width * 0.6
        lvwFiles.Columns(1).Width = lvwFiles.Width * 0.1
        lvwFiles.Columns(2).Width = lvwFiles.Width * 0.145
        lvwFiles.Columns(3).Width = lvwFiles.Width * 0.1

        lvwIMDBFiles.Height = tabFiles.Height - 110

        lvwIMDBFiles.Width = tabFiles.Width - 5
        txtPlot.Width = lvwIMDBFiles.Width - 10
        txtPlot.Top = lvwIMDBFiles.Top + lvwIMDBFiles.Height + 10

        lvwIMDBFiles.Columns(0).Width = lvwIMDBFiles.Width - 130

        lvwUpdatefilenames.Columns(COL_UPDATEFILE_DISKFILENAME).Width = ((lvwUpdatefilenames.Width - lvwUpdatefilenames.Columns(COL_UPDATEFILE_DISKFILENAME).Width) + 400) / 2
        lvwUpdatefilenames.Columns(COL_UPDATEFILE_PROPOSEDNAME).Width = lvwUpdatefilenames.Columns(COL_UPDATEFILE_DISKFILENAME).Width

        cmdUpdFilesApplyProposedFilenames.Left = fraOperations.Left + fraOperations.Width - 165

        lvwSeasons.Height = tabFiles.Height - 110
        lvwSeasons.Width = tabFiles.Width - 13

        txtSeasonsTab_Plot.Width = lvwSeasons.Width - 100
        txtSeasonsTab_Plot.Top = lvwSeasons.Top + lvwSeasons.Height + 10

        cmdSeasonsTab_Order.Left = txtSeasonsTab_Plot.Left + txtSeasonsTab_Plot.Width + 5
        cmdSeasonsTab_Order.Top = txtSeasonsTab_Plot.Top

        lvwPeopleLiked.Height = lvwFiles.Height - 10
        lvwPeopleLiked.Width = lvwFiles.Width - 10

        lvwCompletedFiles.Width = lvwFiles.Width - 10
        lvwCompletedFiles.Height = lvwFiles.Height - 30

        intWidth = lvwCompletedFiles.Width * 0.81

        lvwCompletedFiles.Columns(0).Width = intWidth * 0.62
        lvwCompletedFiles.Columns(1).Width = intWidth * 0.38

        cboCompletedSeasons.Top = lvwCompletedFiles.Top + lvwCompletedFiles.Height + 4
        cmdCompletedSeasons.Top = cboCompletedSeasons.Top - 1
        cmdCompletedSeasons.Left = cboCompletedSeasons.Left + cboCompletedSeasons.Width + 7
        cmdCompletedSeasons.BringToFront()
        lblCompletedSeasons.Top = cboCompletedSeasons.Top + 4

        cmdUpdFilesUpdateFilenamesInListview.Top = fraOperations.Height - 30
        cmdUpdFilesRevertToOriginalNames.Top = cmdUpdFilesUpdateFilenamesInListview.Top
        cmdUpdFilesApplyProposedFilenames.Top = cmdUpdFilesUpdateFilenamesInListview.Top
        cmdUpdFilesRemoveSelectionsinGrid.Top = cmdUpdFilesUpdateFilenamesInListview.Top
        cmdUpdFilesRemoveItemFromGrid.Top = cmdUpdFilesUpdateFilenamesInListview.Top

        lvwSearchResults.Columns(0).Width = 85
        lvwSearchResults.Columns(1).Width = lvwFiles.Width * 0.25
        lvwSearchResults.Columns(2).Width = lvwFiles.Width * 0.41
        lvwSearchResults.Columns(3).Width = lvwFiles.Width * 0.05
        lvwSearchResults.Columns(4).Width = lvwFiles.Width * 0.0725
        lvwSearchResults.Columns(5).Width = lvwFiles.Width * 0.12

        chkBothTypes.Left = cmdFolderSearch.Bounds.Left

        cmdClose.Top = tabDetails.Top + tabDetails.Height + 5

        fraMissing.Width = tabDetails.Width - 20

        txtMissingEpisodes.Width = fraMissing.Width - 550

        webWiki.Width = tabFiles.Width - 25
        webWiki.Height = tabFiles.Height - 70

    End Sub

    Private Sub SaveOptions(ByVal strField As String, ByVal strState As String)

        Dim strSQL As String
        Dim comTypes As OleDbCommand

        strSQL = "Update tblOptions set " & strField & " = '" & strState & "'"

        comTypes = New OleDbCommand(strSQL, mobjOLEConn)

        comTypes.ExecuteReader()

        CloseOLECommand(comTypes)

    End Sub

    Private Sub GetOptions()

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand

        strSQL = "Select * from tblOptions"

        comTypes = New OleDbCommand(strSQL, mobjOLEConn)

        drTypes = comTypes.ExecuteReader()

        If drTypes.HasRows Then

            drTypes.Read()

            If Trim(drTypes("ShowFinished") & "") = "Y" Then

                mnuOptionsFinished.Checked = True
            Else

                mnuOptionsFinished.Checked = False
            End If

            If Trim(drTypes("ShowCompleted") & "") = "Y" Then

                mnuOptionsComplete.Checked = True
            Else

                mnuOptionsComplete.Checked = False
            End If


        End If

        CloseOLECommand(comTypes)
        CloseDataReader(drTypes)

    End Sub

    Private Sub LoadDrives()

        Dim objFirstNode As TreeNode

        objFirstNode = AddDrive(TV, mstrTV_FreeSpace)
        AddDrive(TV_Backup, mstrTV_Backup_FreeSpace)

        AddDrive(TV2, mstrTV2_FreeSpace)
        AddDrive(TV2_Backup, mstrTV2_Backup_FreeSpace)

        AddDrive(TV3, mstrTV3_FreeSpace)
        AddDrive(TV3_Backup, mstrTV3_Backup_FreeSpace)

        AddDrive(TV4, mstrTV4_FreeSpace)
        AddDrive(TV4_Backup, mstrTV4_Backup_FreeSpace)

        AddDrive(TV5, mstrTV5_FreeSpace)
        AddDrive(TV5_Backup, mstrTV5_Backup_FreeSpace)

        AddDrive(TV6, mstrTV6_FreeSpace)
        AddDrive(TV6_Backup, mstrTV6_Backup_FreeSpace)

        AddDrive(TV7, mstrTV7_FreeSpace)
        AddDrive(TV7_Backup, mstrTV7_Backup_FreeSpace)

        AddDrive(TV8, mstrTV8_FreeSpace)
        AddDrive(TV8_Backup, mstrTV8_Backup_FreeSpace)

        AddDrive(TV9, mstrTV9_FreeSpace)
        AddDrive(TV9_Backup, mstrTV9_Backup_FreeSpace)

        cboDrives.Items.Clear()

        cboDrives.Items.Add(TV)
        cboDrives.Items.Add(TV2)
        cboDrives.Items.Add(TV3)
        cboDrives.Items.Add(TV4)
        cboDrives.Items.Add(TV5)
        cboDrives.Items.Add(TV6)
        cboDrives.Items.Add(TV7)
        cboDrives.Items.Add(TV8)
        cboDrives.Items.Add(TV9)
        cboDrives.Text = cboDrives.Items(0)

        cboDrives_Tab.Items.Clear()

        cboDrives_Tab.Items.Add(TV)
        cboDrives_Tab.Items.Add(TV2)
        cboDrives_Tab.Items.Add(TV3)
        cboDrives_Tab.Items.Add(TV4)
        cboDrives_Tab.Items.Add(TV5)
        cboDrives_Tab.Items.Add(TV6)
        cboDrives_Tab.Items.Add(TV7)
        cboDrives_Tab.Items.Add(TV8)
        cboDrives_Tab.Items.Add(TV9)
        cboDrives_Tab.Text = cboDrives_Tab.Items(0)

        AddDrive(Movies, mstrMovies_FreeSpace)
        AddDrive(Movies_Backup, mstrMovies_Backup_FreeSpace)

        objFirstNode.EnsureVisible()
        'objFirstNode.Expand()
        treDrives.SelectedNode = objFirstNode

    End Sub

    Private Sub LoadUpdateFilenamesFiles(ByVal strPath As String, ByVal blnConnected As Boolean)

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand, strDrivename As String

        Dim objItem As ListViewItem, objDir As New DirectoryInfo(strPath)

        lvwUpdatefilenames.Items.Clear()

        If blnConnected Then

            If My.Computer.Name <> HOME_PC Then

                blnConnected = False
            End If

            cmdUpdFilesApplyProposedFilenames.Enabled = True
            cmdUpdFilesUpdateFilenamesInListview.Enabled = True
            cmdUpdFilesRevertToOriginalNames.Enabled = True
            cmdUpdFilesRemoveSelectionsinGrid.Enabled = True
            cmdUpdFilesRemoveItemFromGrid.Enabled = True
        Else

            'cmdUpdFilesApplyProposedFilenames.Enabled = False
            'cmdUpdFilesUpdateFilenamesInListview.Enabled = False
            'cmdUpdFilesRevertToOriginalNames.Enabled = False
            'cmdUpdFilesRemoveSelectionsinGrid.Enabled = False
            'cmdUpdFilesRemoveItemFromGrid.Enabled = False
        End If

        If blnConnected Then

            Try

                For Each objfile As FileInfo In objDir.GetFiles()

                    objItem = lvwUpdatefilenames.Items.Add(objfile.Name)
                    objItem.SubItems.Add(objfile.Extension)
                    objItem.SubItems.Add(objfile.Name)
                Next

                lvwUpdatefilenames.Sorting = SortOrder.Ascending
                lvwUpdatefilenames.Sort()

            Catch ex As DirectoryNotFoundException

                AddError(System.Reflection.MethodBase.GetCurrentMethod().Name & " - " & "Error : " & strPath & " not found!")

            Catch ex1 As UnauthorizedAccessException

                AddError(System.Reflection.MethodBase.GetCurrentMethod().Name & " - " & "Error : No permissions to access the folder!")

            End Try
        Else

            strDrivename = GetDriveAndMainFolder(strPath, True)

            If Count_Occurrances(strPath.Replace("'", "''"), "\") = 2 Then

                strSQL = "Select * from tblDriveContents where drivename = '" & strDrivename & "' and foldername like '%" & ParseTextForSQL(strPath.Replace("'", "''")) & "%'"
            Else

                strSQL = "Select * from tblDriveContents where drivename = '" & strDrivename & "' and foldername = '" & ParseTextForSQL(strPath.Replace("'", "''")) & "'"
            End If

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    If Trim(drTypes("Filename") & "") <> "" Then

                        objItem = lvwUpdatefilenames.Items.Add(Trim(drTypes("Filename") & ""))
                        objItem.SubItems.Add(Trim(drTypes("FileType") & ""))
                        objItem.SubItems.Add(Trim(drTypes("Filename") & ""))
                    End If

                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

            lvwUpdatefilenames.Sorting = SortOrder.Ascending
            lvwUpdatefilenames.Sort()
        End If

        If optImdb.Checked = True Then

            LoadIMDBFiles(strPath)
        Else

        End If

        UpdateUpdateFilenamesSelectionCount()

    End Sub

    Private Sub LoadFiles(ByVal strPath As String, ByVal blnConnected As Boolean)

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand, strDrivename As String, strSeasonImOn As String

        Dim objItem As ListViewItem, objDir As New DirectoryInfo(strPath)

        lvwFiles.Items.Clear()

        lvwSeasons.Items.Clear()
        lvwPeopleLiked.Items.Clear()
        lvwCompletedFiles.Items.Clear()

        txtPlot.Text = ""
        txtSeasonsTab_Plot.Text = ""
        txtMissingEpisodes.Text = ""
        txtMissingSeasons.Text = ""
        mblnIgnoreCheckedEvent = True
        chkSeasonOK.Checked = False
        mblnIgnoreCheckedEvent = False

        If blnConnected Then

            If My.Computer.Name <> HOME_PC Then

                blnConnected = False
            End If
        Else


        End If

        If blnConnected Then

            Try

                For Each objfile As FileInfo In objDir.GetFiles()

                    objItem = lvwFiles.Items.Add(objfile.Name)

                    objItem.SubItems.Add(objfile.Extension)
                    objItem.SubItems.Add(Format(objfile.LastWriteTime, "dd MMM yyyy HH:mm:ss"))
                    objItem.SubItems.Add(SetBytes(objfile.Length))
                Next

                lvwFiles.Sorting = SortOrder.Ascending
                lvwFiles.Sort()

            Catch ex As DirectoryNotFoundException

                AddError(System.Reflection.MethodBase.GetCurrentMethod().Name & " - " & "Error : " & strPath & " not found!")

            Catch ex1 As UnauthorizedAccessException

                AddError(System.Reflection.MethodBase.GetCurrentMethod().Name & " - " & "Error : No permissions to access the folder!")

            End Try
        Else

            strDrivename = GetDriveAndMainFolder(strPath, True)

            If Count_Occurrances(strPath.Replace("'", "''"), "\") = 2 Then

                strSQL = "Select * from tblDriveContents where drivename = '" & strDrivename & "' and foldername like '%" & strPath.Replace("'", "''") & "%' Order by Filename"
            Else

                strSQL = "Select * from tblDriveContents where drivename = '" & strDrivename & "' and foldername = '" & strPath.Replace("'", "''") & "' Order by Filename"
            End If

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    If Trim(drTypes("Filename") & "") <> "" Then

                        objItem = lvwFiles.Items.Add(Trim(drTypes("Filename") & ""))

                        objItem.SubItems.Add(Trim(drTypes("FileType") & ""))
                        objItem.SubItems.Add(Trim(drTypes("ModifiedDate") & ""))
                        objItem.SubItems.Add(SetBytes(Trim(drTypes("FileSize") & "")))
                    End If

                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

            lvwFiles.Sorting = SortOrder.Ascending
            lvwFiles.Sort()
        End If

        If OnSeasonInTreeview(strPath, strSeasonImOn) Then

            chkSeasonOK.Text = strSeasonImOn & " OK?"
            chkSeasonOK.Enabled = True

            mblnIgnoreCheckedEvent = True
            chkSeasonOK.Checked = IsSeasonOK(txtSeriesName.Text, strSeasonImOn)
            mblnIgnoreCheckedEvent = False
        Else

            chkSeasonOK.Checked = False
            chkSeasonOK.Enabled = False
        End If

        UpdateListviewFiles(lvwFiles)

        If optImdb.Checked = True Then

            LoadIMDBFiles(strPath)
        Else


        End If

        LoadUpdateFilenamesFiles(strPath, blnConnected)

    End Sub

    Private Sub LoadMissingElements(ByVal strPath As String)

        Dim intCount As Integer, objItem As ListViewItem, strName As String
        Dim strTitle As String, strSeason As String, intTotalEpisodes As Integer, strFilename As String
        Dim blnFound As Boolean, intAdded As Integer, strX264 As String
        Dim strName2 As String, strName3 As String, strDLPath As String, strDLFilename1 As String, strDLFilename2 As String, strDLFilename3 As String, strDLFilename4 As String

        txtMissingSeasons.Text = ""
        txtMissingEpisodes.Text = ""

        If Count_Occurrances(strPath, "\") = 2 Or Count_Occurrances(strPath, "\") = 3 Then

            If Count_Occurrances(strPath, "\") = 2 Then

                strTitle = GetLastLevel(strPath)
            End If

            If Count_Occurrances(strPath, "\") = 3 Then

                strTitle = GetLastLevel(RemoveOneLevelAndSlash(strPath))
            End If

            ' Seasons
            If txtSeasonCount.Text <> "" Then

                If chkX264_Season.Checked Then

                    strX264 = " X264"
                End If

                If txtSeasonCount.Text > 0 Then

                    For intCount = 1 To txtSeasonCount.Text Step 2

                        txtMissingSeasons.Text = txtMissingSeasons.Text & strTitle & " S" & Format(intCount, "00") & strX264

                        If intCount + 1 <= txtSeasonCount.Text Then

                            txtMissingSeasons.Text = txtMissingSeasons.Text & vbTab & vbTab & strTitle & " S" & Format(intCount + 1, "00") & strX264 & vbCrLf
                        End If

                    Next
                End If
            End If

        End If

        If Count_Occurrances(strPath, "\") = 3 Then

            ' Episodes

            If chkX264_Episode.Checked Then

                strX264 = " X264"
            Else

                strX264 = ""
            End If

            If Count_Occurrances(strPath, "\") = 3 Then

                strSeason = GetLastLevel(strPath).ToLower.Replace("season", "").Trim
                strTitle = GetLastLevel(RemoveOneLevelAndSlash(strPath))
            End If

            If IsNumeric(strSeason) And strTitle <> "" Then

                intTotalEpisodes = GetEpisodeCountForShowsSeasonTakingIntoAccountAirDate(txtID.Text, strSeason)
            End If

            For intCount = 1 To intTotalEpisodes

                strName = "S" & Format(CInt(strSeason), "00") & "E" & Format(intCount, "00")
                strName2 = "S" & Format(CInt(strSeason), "00") & " E" & Format(intCount, "00")
                'strName3 = "S" & CInt(strSeason) & "E" & intCount

                blnFound = False

                ' Check for different formats in listview
                For Each objItem In lvwFiles.Items

                    strFilename = objItem.Text.Replace(".", " ")

                    If (InStr(strFilename.ToLower, strName.ToLower) > 0) Or (InStr(strFilename.ToLower, strName2.ToLower) > 0) Then
                        '(InStr(strFilename.ToLower, strName3.ToLower) > 0) Then

                        blnFound = True
                        Exit For
                    End If
                Next

                ' Check for already downloaded
                If Not blnFound Then

                    strDLPath = ROOT_DRIVE & "\_Torrent\Completed\_TV\" & RemoveDriveAndFolder(strPath) & "\"

                    strDLFilename1 = strTitle & " - " & "S" & Format(CInt(strSeason), "00") & "E" & Format(intCount, "00")
                    strDLFilename2 = strTitle & " S" & Format(CInt(strSeason), "00") & "E" & Format(intCount, "00")
                    strDLFilename3 = strTitle & " - " & "S" & Format(CInt(strSeason), "00") & "E" & Format(intCount, "00")
                    strDLFilename4 = strTitle & " S" & Format(CInt(strSeason), "00") & "E" & Format(intCount, "00")

                    strDLFilename1 = strDLFilename1.Replace(".", " ")
                    strDLFilename2 = strDLFilename2.Replace(".", " ")
                    strDLFilename3 = strDLFilename3.Replace(" ", ".")
                    strDLFilename4 = strDLFilename4.Replace(" ", ".")

                    If (My.Computer.FileSystem.FileExists(strDLPath & strDLFilename1 & ".mkv") Or
                       My.Computer.FileSystem.FileExists(strDLPath & strDLFilename1 & ".avi") Or
                       My.Computer.FileSystem.FileExists(strDLPath & strDLFilename1 & ".mp4")) Or
                       (My.Computer.FileSystem.FileExists(strDLPath & strDLFilename2 & ".mkv") Or
                       My.Computer.FileSystem.FileExists(strDLPath & strDLFilename2 & ".avi") Or
                       My.Computer.FileSystem.FileExists(strDLPath & strDLFilename2 & ".mp4")) Or
                       (My.Computer.FileSystem.FileExists(strDLPath & strDLFilename3 & ".mkv") Or
                       My.Computer.FileSystem.FileExists(strDLPath & strDLFilename3 & ".avi") Or
                       My.Computer.FileSystem.FileExists(strDLPath & strDLFilename3 & ".mp4")) Or
                       (My.Computer.FileSystem.FileExists(strDLPath & strDLFilename4 & ".mkv") Or
                       My.Computer.FileSystem.FileExists(strDLPath & strDLFilename4 & ".avi") Or
                       My.Computer.FileSystem.FileExists(strDLPath & strDLFilename4 & ".mp4")) Then

                        blnFound = True

                        If intAdded = 0 Then

                            txtMissingEpisodes.Text = txtMissingEpisodes.Text & strTitle & " " & strName & strX264 & " in \_TV" & vbTab & vbTab
                            intAdded = 1
                        Else

                            txtMissingEpisodes.Text = txtMissingEpisodes.Text & strTitle & " " & strName & strX264 & " in \_TV" & vbCrLf
                            intAdded = 0
                        End If
                    End If
                End If

                ' _Copy From
                If Not blnFound Then

                    strDLPath = ROOT_DRIVE & "\_Torrent\Completed\_TV\_Copy From\" & RemoveDrive(GetDriveAndMainFolder(strPath)) & RemoveDriveAndFolder(strPath) & "\"

                    strDLFilename1 = strTitle & " - " & "S" & Format(CInt(strSeason), "00") & "E" & Format(intCount, "00")
                    strDLFilename2 = strTitle & " S" & Format(CInt(strSeason), "00") & "E" & Format(intCount, "00")
                    strDLFilename3 = strTitle & " - " & "S" & Format(CInt(strSeason), "00") & "E" & Format(intCount, "00")
                    strDLFilename4 = strTitle & " S" & Format(CInt(strSeason), "00") & "E" & Format(intCount, "00")

                    strDLFilename1 = strDLFilename1.Replace(".", " ")
                    strDLFilename2 = strDLFilename2.Replace(".", " ")
                    strDLFilename3 = strDLFilename3.Replace(" ", ".")
                    strDLFilename4 = strDLFilename4.Replace(" ", ".")

                    If (My.Computer.FileSystem.FileExists(strDLPath & strDLFilename1 & ".mkv") Or
                       My.Computer.FileSystem.FileExists(strDLPath & strDLFilename1 & ".avi") Or
                       My.Computer.FileSystem.FileExists(strDLPath & strDLFilename1 & ".mp4")) Or
                       (My.Computer.FileSystem.FileExists(strDLPath & strDLFilename2 & ".mkv") Or
                       My.Computer.FileSystem.FileExists(strDLPath & strDLFilename2 & ".avi") Or
                       My.Computer.FileSystem.FileExists(strDLPath & strDLFilename2 & ".mp4")) Or
                       (My.Computer.FileSystem.FileExists(strDLPath & strDLFilename3 & ".mkv") Or
                       My.Computer.FileSystem.FileExists(strDLPath & strDLFilename3 & ".avi") Or
                       My.Computer.FileSystem.FileExists(strDLPath & strDLFilename3 & ".mp4")) Or
                       (My.Computer.FileSystem.FileExists(strDLPath & strDLFilename4 & ".mkv") Or
                       My.Computer.FileSystem.FileExists(strDLPath & strDLFilename4 & ".avi") Or
                       My.Computer.FileSystem.FileExists(strDLPath & strDLFilename4 & ".mp4")) Then

                        blnFound = True

                        If intAdded = 0 Then

                            txtMissingEpisodes.Text = txtMissingEpisodes.Text & strTitle & " " & strName & strX264 & " in \_Copy From" & vbTab & vbTab
                            intAdded = 1
                        Else

                            txtMissingEpisodes.Text = txtMissingEpisodes.Text & strTitle & " " & strName & strX264 & " in \_Copy From" & vbCrLf
                            intAdded = 0
                        End If
                    End If
                End If

                If Not blnFound Then

                    If intAdded = 0 Then

                        txtMissingEpisodes.Text = txtMissingEpisodes.Text & strTitle & " " & strName & strX264 & vbTab & vbTab
                        intAdded = 1
                    Else

                        txtMissingEpisodes.Text = txtMissingEpisodes.Text & strTitle & " " & strName & strX264 & vbCrLf
                        intAdded = 0
                    End If
                End If
            Next

        End If

    End Sub

    Private Function GetEpisodeCountForShowsSeason(ByVal strID As String, ByVal strSeason As String) As String

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand

        strSQL = "Select max(Episode) as NumEpisodes from tblSeasons_Imdb where imdbID = '" & strID & "' and Season = " & strSeason

        comTypes = New OleDbCommand(strSQL, mobjOLEConn)

        drTypes = comTypes.ExecuteReader()

        If drTypes.HasRows Then

            drTypes.Read()

            GetEpisodeCountForShowsSeason = Trim(drTypes("NumEpisodes") & "")
        End If

        If GetEpisodeCountForShowsSeason = "" Then GetEpisodeCountForShowsSeason = "0"

        CloseOLECommand(comTypes)
        CloseDataReader(drTypes)

    End Function

    Private Function GetEpisodeCountForShowsSeasonTakingIntoAccountAirDate(ByVal strID As String, ByVal strSeason As String) As String

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand, strDate As String

        strDate = Mid(Now.ToShortDateString, 4, 2) & "/" & Mid(Now.ToShortDateString, 1, 2) & "/" & Mid(Now.ToShortDateString, 7, 4)

        strSQL = "Select Max(Episode) as NumEpisodes from tblSeasons_Imdb where imdbID = '" & strID & "' and Season = " & strSeason _
               & " and AirDate <= #" & strDate & "#"

        comTypes = New OleDbCommand(strSQL, mobjOLEConn)

        drTypes = comTypes.ExecuteReader()

        If drTypes.HasRows Then

            drTypes.Read()

            GetEpisodeCountForShowsSeasonTakingIntoAccountAirDate = Trim(drTypes("NumEpisodes") & "")
        End If

        If GetEpisodeCountForShowsSeasonTakingIntoAccountAirDate = "" Then GetEpisodeCountForShowsSeasonTakingIntoAccountAirDate = "0"

        CloseOLECommand(comTypes)
        CloseDataReader(drTypes)

    End Function

    Private Sub UpdateListviewFiles(ByRef objListview As ListView)

        Dim intCurrentRow As Integer, strCurrentRow As String
        Dim item As ListViewItem

        Try

            Dim Selection As ListView.SelectedListViewItemCollection = objListview.SelectedItems

            For Each item In Selection

                intCurrentRow = item.Index + 1
            Next

        Catch ex As Exception

        End Try

        If intCurrentRow <> 0 Then strCurrentRow = " on row " & intCurrentRow

        If objListview.Items.Count = 0 Then

            objListview.Columns(0).Text = "Name"

        ElseIf objListview.Items.Count = 1 Then

            objListview.Columns(0).Text = "Name - " & objListview.Items.Count & " file"

        ElseIf objListview.Items.Count > 1 Then

            objListview.Columns(0).Text = "Name - " & GetNumberOfMovieFiles() & " files" & strCurrentRow
        End If

    End Sub

    Private Function GetNumberOfMovieFiles() As Integer

        Dim objItem As ListViewItem, intCount As Integer = 0
        Dim strType As String

        GetNumberOfMovieFiles = 0

        For Each objItem In lvwFiles.Items

            strType = objItem.SubItems(1).Text

            Select Case strType
                Case ".srt", ".ass", ".idx", ".mht", ".mp3", ".pdf", ".sub", ".png", ".txt"
                Case Else : intCount = intCount + 1
            End Select
        Next

        GetNumberOfMovieFiles = intCount

    End Function

    Private Sub LoadIMDBFiles(Optional strPath As String = "")

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand
        Dim objItem As ListViewItem, intCount As Integer
        Dim strSeriesName As String, strID As String, strSeason As String

        intCount = 1

        If strPath = "" Then

            strSeriesName = ReturnLevel3(treDrives.SelectedNode.FullPath)
            strSeason = ReturnLevel4(treDrives.SelectedNode.FullPath)
        Else

            strSeriesName = ReturnLevel3(strPath)
            strSeason = ReturnLevel4(strPath)
        End If

        If Mid(strSeason, 2, 1) = ":" Then strSeason = "1"

        strSeason = strSeason.ToLower

        strSeason = strSeason.Replace("season", "").Trim

        strSeason = strSeason.Replace("series", "").Trim

        lvwIMDBFiles.Items.Clear()
        txtPlot.Text = ""

        strSQL = "Select imdbID from tblShows where Title = '" & ParseTextForSQL(strSeriesName) & "'"

        comTypes = New OleDbCommand(strSQL, mobjOLEConn)

        drTypes = comTypes.ExecuteReader()

        If drTypes.HasRows Then

            drTypes.Read()

            strID = Trim(drTypes("imdbID") & "")
        End If

        CloseOLECommand(comTypes)
        CloseDataReader(drTypes)

        If strID <> "" Then

            strSQL = "SELECT * FROM tblSeasons_Imdb where imdbID = '" & strID & "' and Season = " & strSeason & " Order by Episode"

            Try

                comTypes = New OleDbCommand(strSQL, mobjOLEConn)

                drTypes = comTypes.ExecuteReader()

                If drTypes.HasRows Then

                    While drTypes.Read()

                        If Trim(drTypes("Title") & "") <> "" Then

                            objItem = lvwIMDBFiles.Items.Add(Trim(drTypes("Episode") & "") & " - " & Trim(drTypes("Title") & ""))

                            objItem.SubItems.Add(Trim(drTypes("AirDate") & ""))

                            If intCount = 1 Then

                                txtPlot.Text = Trim(drTypes("Description") & "")

                                intCount = 2

                                lvwIMDBFiles.Items(0).Selected = True
                            End If
                        End If

                    End While
                End If

                CloseOLECommand(comTypes)
                CloseDataReader(drTypes)

            Catch ex As Exception

                If ex.Message = "" Then


                End If


            End Try

        Else


        End If

    End Sub

    Function SetBytes(ByVal strBytes As String) As String

        Dim Bytes As Long

        On Error GoTo hell

        If strBytes.Trim = "" Then

            SetBytes = ""
            Exit Function
        End If

        Bytes = strBytes

        If Bytes >= 1073741824 Then
            SetBytes = Format(Bytes / 1024 / 1024 / 1024, "#0.00") _
                 & " GB"
        ElseIf Bytes >= 1048576 Then
            SetBytes = Format(Bytes / 1024 / 1024, "#0.00") & " MB"
        ElseIf Bytes >= 1024 Then
            SetBytes = Format(Bytes / 1024, "#0.00") & " KB"
        ElseIf Bytes < 1024 Then
            SetBytes = Fix(Bytes) & " Bytes"
        End If

        Exit Function
hell:
        SetBytes = "0 Bytes"
    End Function

    Private Sub AddError(ByVal strError As String)

        lblErrors.Text = Now.ToLongTimeString & " - " & strError

        mstrErrors = mstrErrors & strError & vbCrLf

    End Sub

    Private Function GetDrive(ByVal strDrive As String) As String

        Dim intPos As Integer

        intPos = InStr(1, strDrive, "\")

        If intPos > 0 Then

            GetDrive = Mid(strDrive, 1, intPos)
        Else

            GetDrive = strDrive & "\"
        End If

    End Function

    Private Function GetDriveAndMainFolder(ByVal strDrive As String, Optional blnRemoveLastSlash As Boolean = False) As String

        Dim intPos As Integer, strTemp As String

        intPos = InStr(1, strDrive, "\")
        intPos = InStr(intPos + 1, strDrive, "\")

        If intPos > 0 Then

            strTemp = Mid(strDrive, 1, intPos)
        Else

            strTemp = strDrive
        End If

        If blnRemoveLastSlash Then

            If Mid(strTemp, Len(strTemp), 1) = "\" Then

                strTemp = Mid(strTemp, 1, Len(strTemp) - 1)
            End If
        End If

        GetDriveAndMainFolder = strTemp

    End Function

    Private Function AddDrive(ByVal strLabel As String, ByRef strFree As String) As TreeNode

        Dim treNode As TreeNode, objDrive As DriveInfo

        Try

            objDrive = New DriveInfo(GetDrive(strLabel))

            If My.Computer.FileSystem.DirectoryExists(strLabel) Then

                strFree = SetBytes(objDrive.AvailableFreeSpace)
            Else

                strFree = DRIVE_NOT_FOUND
            End If

        Catch ex As DriveNotFoundException

            strFree = DRIVE_NOT_FOUND

        Catch ex2 As IOException

            strFree = DRIVE_NOT_FOUND

        End Try

        If My.Computer.Name <> HOME_PC Then

            strFree = DRIVE_NOT_FOUND
        End If

        objDrive = Nothing

        treNode = treDrives.Nodes.Add(strLabel)
        treNode.Tag = strFree

        If strFree = DRIVE_NOT_FOUND Then

            treNode.ForeColor = Color.Gray
        Else

            treNode.ForeColor = Color.Black
            treNode.BackColor = Color.DarkKhaki
        End If

        If My.Computer.Name <> HOME_PC Then

            LoadFoldersDriveDisconnected(treNode, treNode.Text)
        Else
            If treNode.Tag <> DRIVE_NOT_FOUND Then

                LoadFoldersDriveConnected(treNode, treNode.Text)
            Else

                LoadFoldersDriveDisconnected(treNode, treNode.Text)
            End If
        End If

        AddDrive = treNode

    End Function

    Private Sub UpdateTooltip(ByRef cmdButton As ToolStripButton, ByVal strDrive As String)

        cmdButton.ToolTipText = GetLastUpdatedDate(strDrive)

    End Sub

    Private Sub UpdateLabel(ByRef cmdButton As ToolStripButton, ByVal strDrive As String)

        If strDrive = "D:\TV" Then

            cmdButton.Text = "Upd " & strDrive

        Else
            cmdButton.Text = strDrive.Replace("Backup", "Bkp")
        End If

        UpdateTooltip(cmdButton, strDrive)

    End Sub

    Private Sub LoadCountries()

        Dim strSQL As String, drTypes As OleDbDataReader, comTypes As OleDbCommand

        strSQL = "Select Distinct(Country) as Country from tblShows Order by Country Desc"

        comTypes = New OleDbCommand(strSQL, mobjOLEConn)

        drTypes = comTypes.ExecuteReader()

        If drTypes.HasRows Then

            cboOmdbCountries.Items.Add("")

            While drTypes.Read()

                cboOmdbCountries.Items.Add(drTypes("Country").ToString.Trim)

            End While
        End If

        CloseOLECommand(comTypes)
        CloseDataReader(drTypes)

        If cboOmdbCountries.Items.Count > 0 Then cboOmdbCountries.Text = cboOmdbCountries.Items(2).ToString

    End Sub

    Private Sub LoadTitleLetter()

        Dim intLetter As Integer

        cboOmdbTitleLetter.Items.Add(" ")

        For intLetter = 65 To 90

            cboOmdbTitleLetter.Items.Add(Chr(intLetter))
        Next

        If cboOmdbTitleLetter.Items.Count > 0 Then cboOmdbTitleLetter.Text = cboOmdbTitleLetter.Items(1).ToString

    End Sub

    Private Sub UpdateLabels()

        UpdateLabel(cmdUpdateTV, TV)
        UpdateLabel(cmdUpdateTV_Backup, TV_Backup)

        UpdateLabel(cmdUpdateTV2, TV2)
        UpdateLabel(cmdUpdateTV2_Backup, TV2_Backup)

        UpdateLabel(cmdUpdateTV3, TV3)
        UpdateLabel(cmdUpdateTV3_Backup, TV3_Backup)

        UpdateLabel(cmdUpdateTV4, TV4)
        UpdateLabel(cmdUpdateTV4_Backup, TV4_Backup)

        UpdateLabel(cmdUpdateTV5, TV5)
        UpdateLabel(cmdUpdateTV5_Backup, TV5_Backup)

        UpdateLabel(cmdUpdateTV6, TV6)
        UpdateLabel(cmdUpdateTV6_Backup, TV6_Backup)

        UpdateLabel(cmdUpdateTV7, TV7)
        UpdateLabel(cmdUpdateTV7_Backup, TV7_Backup)

        UpdateLabel(cmdUpdateTV8, TV8)
        UpdateLabel(cmdUpdateTV8_Backup, TV8_Backup)

        UpdateLabel(cmdUpdateTV9, TV9)
        UpdateLabel(cmdUpdateTV9_Backup, TV9_Backup)

        UpdateLabel(cmdUpdateTV10, TV10)
        UpdateLabel(cmdUpdateTV10_Backup, TV10_Backup)

        UpdateLabel(cmdUpdateMovies, Movies)
        UpdateLabel(cmdUpdateMovies_Backup, Movies_Backup)

    End Sub

    Function Getlastfolder(ByVal strpath As String) As String

        Dim intPos As Integer

        intPos = InStrRev(strpath, "\")

        Getlastfolder = Mid(strpath, intPos + 1)

    End Function

    Private Sub treDrives_KeyUp(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles treDrives.KeyUp

        Dim objNewNode As New System.Windows.Forms.TreeNodeMouseClickEventArgs(treDrives.SelectedNode, MouseButtons.Left, 1, 1, 1)

        If Not mblnAutoUpdating Then

            treDrives_NodeMouseClick(Nothing, objNewNode)
        End If

    End Sub

    Private Sub treDrives_NodeMouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeNodeMouseClickEventArgs) Handles treDrives.NodeMouseClick

        Dim strPath As String, objNode As TreeNode, strSeriesName As String = ""
        Dim blnUpdate As Boolean

        If e.Node Is Nothing Then Exit Sub

        If cmdFinished.Visible Then

            cmdFinished_Click(sender, e)
        End If

        strPath = ""
        objNode = e.Node

        While Not objNode.Parent Is Nothing

            strPath = "\" & objNode.Text & strPath
            objNode = objNode.Parent
        End While

        If InStr(1, strPath, "\") = 1 Then

            If InStr(2, strPath, "\") = 0 Then

                strSeriesName = Mid(strPath, 2)
            Else

                strSeriesName = Mid(strPath, 2, InStr(2, strPath, "\") - 2)
            End If

        End If

        If strPath = "" Then

            strPath = e.Node.Text
        Else

            strPath = objNode.Text & strPath
        End If

        LoadFiles(strPath, objNode.Tag <> DRIVE_NOT_FOUND)

        UpdateAppCaption(Me, treDrives, strPath)

        mstrPath = strPath

        If strSeriesName <> "" Then

            LoadSeriesDetails(strSeriesName, optImdb.Checked = True, strPath)
        Else

            ClearSeriesDetails()
            txtSeriesName.Text = ""
        End If

        If mblnAutoUpdating Then

            If SlashCount(strPath) = 2 Then

                If txtID.Text = "" Then

                    blnUpdate = False

                ElseIf txtLastUpdate_IMDB.Text = "" Then

                    blnUpdate = True

                ElseIf DateDiff(DateInterval.Day, CDate(txtLastUpdate_IMDB.Text), CDate(Now.ToShortDateString)) > 7 Then

                    blnUpdate = True
                Else

                    blnUpdate = False
                End If

                If blnUpdate Then

                    cmdUpdateNow_Click(Nothing, Nothing)
                End If

            End If

            If mnuAutoUpdate.Text = AUTO_UPDATE_STOP_MENU Then

                tmrUpdateTimer.Enabled = True
            Else

                ' Stop the processs
                tmrUpdateTimer.Enabled = False
            End If
        End If

    End Sub

    Private Sub UpdateKnownDups()

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand, intCount As Integer

        mnuKnownDuplicates.Text = "Known Duplicates - X"

        intCount = 0

        Try

            strSQL = "SELECT dupid FROM tblDups GROUP BY DupID"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    intCount = intCount + 1
                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

            mnuKnownDuplicates.Text = mnuKnownDuplicates.Text.Replace("X", intCount)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Function GetDiscSeasonEpisodeDetails(ByVal strID As String, ByVal blnIMDB As Boolean, ByVal strPath As String, ByRef strResults As String) As Boolean

        Dim strSQL As String, drTypes As OleDbDataReader, comTypes As OleDbCommand
        Dim strSQL_Airdate As String, drTypes_Airdate As OleDbDataReader, comTypes_Airdate As OleDbCommand, intTotal_Airdate As Integer

        Dim strTemp As String, strLines() As String, blnFinished As Boolean
        Dim intCount As Integer, intTotal As Integer, intLoop As Integer, intRowCount As Integer
        Dim intNumber As Integer, intMaxNumber As Integer, intChar As Integer, strSpacer As String
        Dim strSeasons(100) As String, strSeason As String, strChar As String
        Dim strLevel3 As String

        Try

            GetDiscSeasonEpisodeDetails = False

            For intLoop = 1 To 100

                strSeasons(intLoop) = 0
            Next

            strLevel3 = ReturnDownToLevel3(strPath)

            strSQL = "select foldername, Filename from tblDriveContents where drivename = '" & GetDriveAndMainFolder(ParseTextForSQL(strPath), True) &
                     "' and foldername like '%" & ParseTextForSQL(strLevel3) &
                     "%' and (filetype <> '.srt' and filetype <> '.ass' and filetype <> '.idx' and filetype <> '.mht' and filetype <> '.mp3' and filetype <> '.pdf' and filetype <> '.sub' and filetype <> '.png'  and filetype <> '.txt')"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    strSeason = Trim(drTypes("Foldername")).ToLower

                    strSeason = strSeason.Replace(strLevel3.ToLower, "")

                    strSeason = strSeason.Replace(" one", " 1")
                    strSeason = strSeason.Replace(" two", " 2")
                    strSeason = strSeason.Replace(" three", " 3")
                    strSeason = strSeason.Replace(" four", " 4")
                    strSeason = strSeason.Replace(" five", " 5")
                    strSeason = strSeason.Replace(" six", " 6")
                    strSeason = strSeason.Replace(" seven", " 7")
                    strSeason = strSeason.Replace(" eight", " 8")
                    strSeason = strSeason.Replace(" nine", " 9")
                    strSeason = strSeason.Replace(" ten", " 10")
                    strSeason = strSeason.Replace(" eleven", " 11")
                    strSeason = strSeason.Replace(" twelve", " 12")
                    strSeason = strSeason.Replace(" thirteen", " 13")
                    strSeason = strSeason.Replace(" fourteen", " 14")
                    strSeason = strSeason.Replace(" fifteen", " 15")
                    strSeason = strSeason.Replace(" sixteen", " 16")

                    strSeason = strSeason.Replace("season ", "")
                    strSeason = strSeason.Replace("series ", "").Trim

                    For intChar = 1 To strSeason.Length

                        strChar = Mid(strSeason, intChar, 1)

                        If IsNumeric(strChar) Then

                            ' Keep
                        Else

                            If intChar = 0 Then

                                strSeason = "X" & Mid(strSeason, 2)

                            ElseIf intChar = strSeason.Length Then

                                strSeason = Mid(strSeason, 1, intChar - 1) & "X"

                            Else

                                strSeason = Mid(strSeason, 1, intChar - 1) & "X" & Mid(strSeason, intChar + 1)
                            End If

                        End If
                    Next

                    strSeason = strSeason.Replace("X", "")
                    strSeason = strSeason.Replace(" ", "")

                    If IsNumeric(strSeason) Then

                        strSeasons(CInt(strSeason)) = strSeasons(CInt(strSeason)) + 1

                        If FileIsTwoEpisodes(Trim(drTypes("Filename")).ToLower) Then

                            strSeasons(CInt(strSeason)) = strSeasons(CInt(strSeason)) + 1
                        End If
                    End If

                End While
            End If

            strResults = ""

            For intLoop = 1 To 100

                If strSeasons(intLoop) <> 0 Then

                    If IsSeasonOK(txtSeriesName.Text, "Season " & intLoop) Then

                        If intLoop Mod 6 > 0 Then

                            strResults = strResults & intLoop & " (" & CountFromSeasonInfo(txtID.Text, intLoop) & ")   "
                        Else

                            strResults = strResults & intLoop & " (" & CountFromSeasonInfo(txtID.Text, intLoop) & ")" & vbCrLf
                        End If
                    Else

                        If intLoop Mod 6 > 0 Then

                            strResults = strResults & intLoop & " (" & strSeasons(intLoop) & ")   "
                        Else

                            strResults = strResults & intLoop & " (" & strSeasons(intLoop) & ")" & vbCrLf
                        End If
                    End If
                End If
            Next

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

            GetDiscSeasonEpisodeDetails = True

        Catch ex As Exception

            AddError(System.Reflection.MethodBase.GetCurrentMethod().Name & " - " & ex.Message)

            strResults = "Error Occurred."
            GetDiscSeasonEpisodeDetails = True

        End Try

    End Function

    Private Function GetSeasonEpisodeDetails(ByVal strID As String, ByVal blnIMDB As Boolean) As String

        Dim strSQL As String, drTypes As OleDbDataReader, comTypes As OleDbCommand
        Dim strSQL_Airdate As String, drTypes_Airdate As OleDbDataReader, comTypes_Airdate As OleDbCommand, intTotal_Airdate As Integer
        Dim strSQL_Pilot As String
        Dim strTemp As String, strLines() As String, blnFinished As Boolean
        Dim intCount As Integer, intTotal As Integer, intLoop As Integer, intRowCount As Integer
        Dim intNumber As Integer, intMaxNumber As Integer, intChar As Integer, strSpacer As String
        Dim blnPilotFound As Boolean

        intTotal = 0
        strTemp = ""
        blnPilotFound = False

        If blnIMDB Then

            strSQL_Pilot = "SELECT Title FROM tblSeasons_Imdb where imdbID = '" & strID & "' and Season = 1 and Episode = 1 and Title like '%Pilot%' and airdate is NULL"
            strSQL = "SELECT Season, Max(Episode) as EpisodeCount FROM tblSeasons_Imdb where imdbID = '" & strID & "' Group By Season Order by Season"
            strSQL_Airdate = "SELECT Season, Count(Episode) as EpisodeCount FROM tblSeasons_Imdb where imdbID = '" & strID & "' and AirDate < #" _
                            & Mid(Now.ToShortDateString, 4, 2) & "/" & Mid(Now.ToShortDateString, 1, 2) & "/" & Mid(Now.ToShortDateString, 7, 4) & "# and episode <> 0 Group By Season Order by Season"
        Else


        End If

        ' Pilot?
        comTypes = New OleDbCommand(strSQL_Pilot, mobjOLEConn)

        drTypes = comTypes.ExecuteReader()

        If drTypes.HasRows Then

            blnPilotFound = True
        End If

        CloseOLECommand(comTypes)
        CloseDataReader(drTypes)

        ' Without airdate
        comTypes = New OleDbCommand(strSQL, mobjOLEConn)

        drTypes = comTypes.ExecuteReader()

        If drTypes.HasRows Then

            While drTypes.Read()

                intRowCount = intRowCount + 1
            End While
        End If

        CloseOLECommand(comTypes)
        CloseDataReader(drTypes)

        comTypes = New OleDbCommand(strSQL, mobjOLEConn)

        drTypes = comTypes.ExecuteReader()

        If drTypes.HasRows Then

            While drTypes.Read()

                intCount = intCount + 1

                If intCount Mod 6 > 0 Then

                    If Trim(drTypes("Season")) = 1 Then

                        If blnPilotFound Then

                            strTemp = strTemp & strSpacer & Trim(drTypes("Season") & " (" & drTypes("EpisodeCount") - 1) & ")   "

                            intTotal = intTotal + CInt(drTypes("EpisodeCount") - 1)
                        Else

                            strTemp = strTemp & strSpacer & Trim(drTypes("Season") & " (" & drTypes("EpisodeCount")) & ")   "

                            intTotal = intTotal + CInt(drTypes("EpisodeCount"))
                        End If

                    Else

                        strTemp = strTemp & strSpacer & Trim(drTypes("Season") & " (" & drTypes("EpisodeCount")) & ")   "

                        intTotal = intTotal + CInt(drTypes("EpisodeCount"))
                    End If

                Else

                    strTemp = strTemp & Trim(drTypes("Season") & " (" & drTypes("EpisodeCount") & ")") & vbCrLf

                    intTotal = intTotal + CInt(drTypes("EpisodeCount"))
                End If

            End While
        End If

        If strTemp <> "" Then
            strLines = strTemp.Split(vbCrLf)

            If strLines.GetUpperBound(0) = 1 Then

                ' No need to process
            Else

                For intLoop = 0 To strLines.GetUpperBound(0)

                    strLines(intLoop) = strLines(intLoop).Trim
                Next

                strTemp = ""
                For intLoop = 0 To strLines.GetUpperBound(0)

                    strTemp = strTemp & strLines(intLoop).Trim & vbCrLf
                Next
            End If
        End If

        CloseOLECommand(comTypes)
        CloseDataReader(drTypes)

        ' With airdate taken into account
        comTypes_Airdate = New OleDbCommand(strSQL_Airdate, mobjOLEConn)

        drTypes_Airdate = comTypes_Airdate.ExecuteReader()

        If drTypes_Airdate.HasRows Then

            While drTypes_Airdate.Read()

                If CInt(drTypes_Airdate("Season")) = 1 Then

                    If blnPilotFound Then

                        intTotal_Airdate = intTotal_Airdate + CInt(drTypes_Airdate("EpisodeCount") - 1)
                    Else

                        intTotal_Airdate = intTotal_Airdate + CInt(drTypes_Airdate("EpisodeCount"))
                    End If
                Else

                    intTotal_Airdate = intTotal_Airdate + CInt(drTypes_Airdate("EpisodeCount"))
                End If


            End While
        End If

        CloseOLECommand(comTypes_Airdate)
        CloseDataReader(drTypes_Airdate)

        txtTotalWithAirdate.Text = intTotal_Airdate

        GetSeasonEpisodeDetails = strTemp

        txtTotal.Text = intTotal
        txtMyTotal.Text = GetMyTotalOfFilesForSeries(mstrPath)

        If (txtTotalWithAirdate.Text <> txtMyTotal.Text) And (txtTotalWithAirdate.Text <> "" And txtMyTotal.Text <> "") Then

            txtMyTotal.BackColor = Color.Red
            txtTotalWithAirdate.BackColor = Color.Red
        Else

            txtMyTotal.BackColor = Color.White
            txtTotalWithAirdate.BackColor = Color.White
        End If

        If blnIMDB Then

            strSQL = "Update tblShows set MyTotal = " & txtMyTotal.Text & ", imDB_AirDateTotal = " & txtTotalWithAirdate.Text & ", imDB_TotalWithoutAirDate = " & txtTotal.Text _
                   & " Where imdbID = '" & txtID.Text & "'"
        Else


        End If

        Try

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Function

    Private Function GetMyTotalOfFilesForSeries(ByVal strPath As String) As Integer

        Dim strSQL As String, drTypes As OleDbDataReader, strFilename As String
        Dim comTypes As OleDbCommand, strDrivename As String, intFileCount As Integer
        Dim strSeason As String, blnIgnoredSeasons(100) As Boolean, intCount As Integer

        If SlashCount(strPath) = 3 Then

            strPath = RemoveOneLevelAndSlash(strPath)
        End If

        If strPath = "" Then

            GetMyTotalOfFilesForSeries = 0
            Exit Function
        End If

        intFileCount = 0

        strDrivename = GetDriveAndMainFolder(strPath, True)

        strSQL = "Select Filename, Foldername from tblDriveContents where drivename = '" _
               & strDrivename & "' and foldername like '" & strPath.Replace("'", "''") & "\%' and filetype in ('.avi', '.divx', '.mp4', '.flv', '.m4v', '.mkv', '.mov', '.mpg', '.rmvb') Order By Foldername"

        comTypes = New OleDbCommand(strSQL, mobjOLEConn)

        drTypes = comTypes.ExecuteReader()

        If drTypes.HasRows Then

            While drTypes.Read()

                strFilename = Trim(drTypes("Filename") & "")

                strSeason = GetLastLevel(Trim(drTypes("Foldername") & ""))

                If IsSeasonOK(txtSeriesName.Text, strSeason) Then

                    blnIgnoredSeasons(GetJustNumerics(strSeason)) = True
                    ' Ignore for now
                Else

                    If FileIsTwoEpisodes(strFilename) = True Then

                        intFileCount = intFileCount + 2
                    Else

                        intFileCount = intFileCount + 1
                    End If
                End If
            End While
        End If

        For intCount = 1 To blnIgnoredSeasons.GetUpperBound(0)

            If blnIgnoredSeasons(intCount) Then

                intFileCount = intFileCount + CInt(GetEpisodeCountForShowsSeason(txtID.Text, intCount))
            End If
        Next

        GetMyTotalOfFilesForSeries = intFileCount

        CloseOLECommand(comTypes)
        CloseDataReader(drTypes)

    End Function

    Private Sub LoadSeriesDetails(ByVal strSeriesName As String, ByVal blnIMDB As Boolean, ByVal strPath As String, Optional ByVal blnClearAPITitle As Boolean = True)

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand, strDiscSeasonsEpisodes As String
        Dim objItem As ListViewItem, strDrivename As String
        Dim strLevels() As String, intCount As Integer
        Dim strDrive As String, objNode As TreeNode, objLevel1 As TreeNode, objTest As TreeNode
        Dim intPartCount As Integer, strNextPart As String, objPrevLevel As TreeNode
        Dim intSlashCount As Integer, strFoldername As String, objTryToFindNode As TreeNode

        Try

            If blnClearAPITitle Then
                txtAPITitle.Text = ""
                txtLastUpdate_API.Text = ""
                txtLastUpdate_IMDB.Text = ""
            End If

            If strSeriesName = "" Then

                ClearSeriesDetails()
                Exit Sub
            End If

            txtSeriesName.Text = strSeriesName

            strSQL = "Select * from tblShows where Title = '" & ParseTextForSQL(strSeriesName) & "'"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                drTypes.Read()

                If blnIMDB Then

                    If Trim(drTypes("imdbID") & "") <> "" Then

                        txtID.Text = Trim(drTypes("imdbID") & "")

                        txtAPITitle.Text = Trim(drTypes("API_Title") & "")

                        txtDescription.Text = Trim(drTypes("imdbDescription") & "").Replace("&quot;", " & ").Replace("  ", " ")

                        txtGenre.Text = Trim(drTypes("Genre") & "")
                        txtaltname.Text = Trim(drTypes("AltName") & "")
                        txtStart.Text = Trim(drTypes("imdbStartYear") & "")
                        txtEnd.Text = Trim(drTypes("imdbEndYear") & "")

                        txtSeasonCount.Text = Trim(drTypes("imdbSeasonCount") & "")
                        txtIMDBSeasonsEpisodes.Text = GetSeasonEpisodeDetails(Trim(drTypes("imdbID") & ""), True)
                        If GetDiscSeasonEpisodeDetails(Trim(drTypes("imdbID") & ""), True, strPath, strDiscSeasonsEpisodes) Then

                            txtDiscSeasonsEpisodes.Text = strDiscSeasonsEpisodes
                        Else

                            txtDiscSeasonsEpisodes.Text = ""
                        End If

                        txtRating.Text = Trim(drTypes("imdbRating") & "/") & Trim(drTypes("imdbVotes") & "")

                        txtCountry.Text = Trim(drTypes("Country") & "")

                        txtLastUpdate_API.Text = Trim(drTypes("imdbDateOfLastUpdate_API") & "")
                        txtLastUpdate_IMDB.Text = Trim(drTypes("imdbDateOfLastUpdate") & "")

                        If Trim(drTypes("DetailsInDoubt") & "") = "Y" Then

                            chkDetailsinDoubt.Checked = True
                        Else

                            chkDetailsinDoubt.Checked = False
                        End If

                        If Trim(drTypes("Complete") & "") = "Y" Then

                            chkComplete.Checked = True
                        Else

                            chkComplete.Checked = False
                        End If

                        If Trim(drTypes("Finished") & "") = "Y" Then

                            chkFinished.Checked = True
                        Else

                            chkFinished.Checked = False
                        End If

                        cboCorrectVersion.Text = Trim(drTypes("CorrectVersion") & "")

                        LoadSeasons()
                        LoadPeopleLiked(False)
                        LoadMissingElements(strPath)
                    Else

                        ClearSeriesDetails()
                    End If

                Else

                    txtID.Text = strSeriesName

                    txtDescription.Text = Trim(drTypes("TV_Com_Description") & "")

                    txtGenre.Text = Trim(drTypes("Genre") & "")
                    txtaltname.Text = Trim(drTypes("AltName") & "")
                    txtStart.Text = Trim(drTypes("TV_Com_StartYear") & "")
                    txtEnd.Text = Trim(drTypes("TV_Com_EndYear") & "")

                    txtSeasonCount.Text = Trim(drTypes("TV_Com_SeasonCount") & "")
                    txtIMDBSeasonsEpisodes.Text = GetSeasonEpisodeDetails(strSeriesName, False)
                    If GetDiscSeasonEpisodeDetails(Trim(drTypes("imdbID") & ""), True, strPath, strDiscSeasonsEpisodes) Then

                        txtDiscSeasonsEpisodes.Text = strDiscSeasonsEpisodes
                    End If

                    txtRating.Text = Trim(drTypes("TV_Com_Rating") & "\") & Trim(drTypes("TV_Com_Votes") & "")

                    txtCountry.Text = Trim(drTypes("Country") & "")

                    txtLastUpdate_IMDB.Text = Trim(drTypes("TV_Com_DateOfLastUpdate") & "")

                    If Trim(drTypes("DetailsInDoubt") & "") = "Y" Then

                        chkDetailsinDoubt.Checked = True
                    Else

                        chkDetailsinDoubt.Checked = False
                    End If

                    cboCorrectVersion.Text = Trim(drTypes("CorrectVersion") & "")
                End If
            Else

                ClearSeriesDetails()
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch Ex As Exception

            DisplayException_Messagebox(Ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
        End Try

    End Sub

    Private Sub LoadPeopleLiked(ByVal blnAllType As Boolean)

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand
        Dim objItem As ListViewItem, lvwListView As ListView
        Dim strTitle As String

        If blnAllType Then

            lvwListView = lvwPeopleLiked_All
            strTitle = "Name "
        Else

            lvwListView = lvwPeopleLiked
            strTitle = "Name "
        End If

        lvwListView.Items.Clear()

        If txtID.Text = "" And Not blnAllType Then Exit Sub

        If optImdb.Checked Then

            Try

                If blnAllType Then

                    strSQL = "Select * from tblImdb_Shows_People_Liked Order by PickRating Desc"
                Else

                    strSQL = "Select * from tblImdb_Shows_People_Liked where imdbID = '" & txtID.Text & "' Order by PickRating Desc"
                End If

                comTypes = New OleDbCommand(strSQL, mobjOLEConn)

                drTypes = comTypes.ExecuteReader()

                If drTypes.HasRows Then

                    While drTypes.Read()

                        If Trim(drTypes("PickTitle") & "") <> "" Then

                            objItem = lvwListView.Items.Add(Trim(drTypes("PickTitle") & ""))

                            If lvwListView.Items.Count = 1 Then

                                objItem.Selected = True
                            End If

                            objItem.SubItems.Add(Trim(drTypes("PickRating") & ""))

                            objItem.SubItems.Add(Trim(drTypes("PickDesc") & ""))

                            objItem.SubItems.Add(Trim(drTypes("PickimdbID") & ""))
                        End If
                    End While
                End If

                CloseOLECommand(comTypes)
                CloseDataReader(drTypes)

            Catch Ex As Exception

                AddError(System.Reflection.MethodBase.GetCurrentMethod().Name & " - " & Ex.Message)
            End Try

        End If

        lvwListView.Columns(0).Text = strTitle & " - " & lvwListView.Items.Count & " shows"

    End Sub

    Private Sub LoadSeasons()

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand
        Dim objItem As ListViewItem, intCount As Integer, intSeason As Integer
        Dim strOrderBy As String

        intCount = 1
        intSeason = 0

        lvwSeasons.Items.Clear()

        If txtID.Text = "" Then Exit Sub

        If optImdb.Checked Then

            Try

                If mblnSeasonsOrderAsc Then

                    strOrderBy = " Order by Season Asc, Episode "
                Else

                    strOrderBy = " Order by Season Desc, Episode "
                End If

                strSQL = "Select Season,Episode,Title,Description, Airdate from tblSeasons_Imdb where imdbID = '" & txtID.Text & "'" & strOrderBy

                comTypes = New OleDbCommand(strSQL, mobjOLEConn)

                drTypes = comTypes.ExecuteReader()

                If drTypes.HasRows Then

                    While drTypes.Read()

                        If Trim(drTypes("Season") & "") <> "" Then

                            If intSeason > 0 And (Trim(drTypes("Season") & "") <> intSeason) Then

                                objItem = lvwSeasons.Items.Add("")
                            End If

                            objItem = lvwSeasons.Items.Add(Trim(drTypes("Season") & ""))

                            intSeason = Trim(drTypes("Season") & "")

                            objItem.SubItems.Add(Trim(drTypes("Episode") & ""))

                            objItem.SubItems.Add(Trim(drTypes("Title") & ""))
                            objItem.SubItems.Add(Trim(drTypes("Airdate") & ""))

                            If intCount = 1 Then

                                txtSeasonsTab_Plot.Text = Trim(drTypes("Description") & "")

                                intCount = 2

                                lvwSeasons.Items(0).Selected = True
                            End If
                        End If
                    End While
                End If

                CloseOLECommand(comTypes)
                CloseDataReader(drTypes)

            Catch Ex As Exception

                AddError(System.Reflection.MethodBase.GetCurrentMethod().Name & " - " & Ex.Message)
            End Try

        End If

    End Sub

    Private Sub ClearSeriesDetails()

        txtID.Text = ""
        txtAPITitle.Text = ""
        txtDescription.Text = ""

        txtGenre.Text = ""
        txtAltName.Text = ""
        txtStart.Text = ""
        txtEnd.Text = ""

        txtSeasonCount.Text = ""
        txtIMDBSeasonsEpisodes.Text = ""
        txtDiscSeasonsEpisodes.Text = ""

        txtRating.Text = ""

        txtCountry.Text = ""

        txtLastUpdate_IMDB.Text = ""

        txtMyTotal.Text = ""
        txtMyTotal.BackColor = Color.White
        txtTotal.Text = ""
        txtTotal.BackColor = Color.White
        txtTotalWithAirdate.Text = ""
        txtTotalWithAirdate.BackColor = Color.White

        chkDetailsinDoubt.Checked = False
        chkFinished.Checked = False
        chkComplete.Checked = False
        cboCorrectVersion.Text = ""

        txtMissingEpisodes.Text = ""
        txtMissingSeasons.Text = ""

    End Sub

    Private Sub OutputFolderToFile(ByVal strPath As String, ByVal strDir As String, ByRef objStreamWriter As TextWriter, ByVal strLeftHandSide As String)

        For Each strSubDir As String In Directory.GetDirectories(strDir)

            objStreamWriter.WriteLine(strLeftHandSide & strSubDir)

            OutputFilesToFile(strPath, strSubDir, objStreamWriter, TABS_FOR_FILE & strLeftHandSide)
            OutputFolderToFile(strPath, strSubDir, objStreamWriter, TABS_FOR_FILE & strLeftHandSide)
        Next

    End Sub

    Private Sub OutputFilesToFile(ByVal strPath As String, ByVal strDir As String, ByRef objStreamWriter As TextWriter, ByVal strLeftHandSide As String)

        Dim objDir As New DirectoryInfo(strDir), objFile As FileInfo

        For Each objFile In objDir.GetFiles()

            Try

                File.SetAttributes(objFile.FullName, FileAttributes.Normal)

            Catch ex As Exception

                DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

            End Try

            If objFile.Name <> "Thumbs.db" Then

                objStreamWriter.WriteLine(strLeftHandSide & objFile.Name)

                InsertDBEntry(strPath, objFile.Directory.FullName, objFile.Name, objFile.Length, objFile.LastWriteTime, objFile.Extension)
            End If
        Next

        objStreamWriter.WriteLine()

    End Sub

    Private Sub DeleteExistingDBEntries(ByVal strPath As String)

        Dim strSQL As String, comTypes As OleDbCommand

        Try

            strSQL = "delete from tblDriveContents where Drivename = '" & strPath & "'"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            comTypes.ExecuteNonQuery()

            CloseOLECommand(comTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub DeleteMajorFolders(ByVal strDriveName As String)

        Dim strSQL As String, comTypes As OleDbCommand

        Try

            strSQL = "delete from tblMajorFolders where Drivename = '" & strDriveName & "'"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            comTypes.ExecuteNonQuery()

            CloseOLECommand(comTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Function RemoveUpToFirstChar(ByVal strText As String, ByVal strCharacter As String) As String

        Dim intPos As Integer

        intPos = InStr(1, strText, strCharacter)

        If intPos > 0 Then

            RemoveUpToFirstChar = Mid(strText, intPos + 1)
        Else

            RemoveUpToFirstChar = strText
        End If

    End Function

    Private Function RemoveAllButTopLevel(ByVal strFoldername As String) As String

        Dim intPos As Integer

        intPos = InStr(1, strFoldername, "\")

        If intPos > 0 Then

            RemoveAllButTopLevel = Mid(strFoldername, 1, intPos - 1)
        Else

            RemoveAllButTopLevel = strFoldername
        End If

    End Function

    Private Function RemoveDriveAndAllBut1Folder(ByVal strFoldername As String) As String

        Dim intPos As Integer

        intPos = InStrRev(strFoldername, "\")

        If intPos > 0 Then

            RemoveDriveAndAllBut1Folder = Mid(strFoldername, intPos + 1)
        Else

            RemoveDriveAndAllBut1Folder = strFoldername
        End If

    End Function

    Private Function RemoveDriveAndFolder(ByVal strFoldername As String) As String

        Dim intPos As Integer

        intPos = InStr(1, strFoldername, "\")

        intPos = InStr(intPos + 1, strFoldername, "\")

        If intPos > 0 Then

            RemoveDriveAndFolder = Mid(strFoldername, intPos + 1)
        Else

            RemoveDriveAndFolder = strFoldername
        End If

    End Function

    Private Function RemoveDrive(ByVal strFoldername As String) As String

        Dim intPos As Integer

        intPos = InStr(1, strFoldername, "\")

        If intPos > 0 Then

            RemoveDrive = Mid(strFoldername, intPos + 1)
        Else

            RemoveDrive = strFoldername
        End If

    End Function

    Private Sub InsertMajorFolderDBEntry(ByVal strDriveName As String, ByVal strDriveLabel As String, ByVal strFoldername As String)

        Dim strSQL As String, comTypes As OleDbCommand
        Dim strFolderNameOverflow As String

        If RemoveUpToFirstChar(strFoldername, "\").ToUpper = "$RECYCLE.BIN" Then Exit Sub
        If RemoveUpToFirstChar(strFoldername, "\").ToUpper = "RECYCLER" Then Exit Sub
        If RemoveUpToFirstChar(strFoldername, "\").ToUpper = "SYSTEM VOLUME INFORMATION" Then Exit Sub

        Try

            strFolderNameOverflow = "-"
            strDriveLabel = RemoveDrive(strDriveLabel)

            strSQL = "Insert into tblMajorFolders (DriveName, DriveLabel, Foldername) values ('" _
                      & strDriveName & "','" & strDriveLabel & "','" & ParseTextForSQL(RemoveDrive(strFoldername)) & "')"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            comTypes.ExecuteReader()

            CloseOLECommand(comTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub InsertDBEntry(ByVal strDriveName As String, ByVal strFoldername As String, ByVal strFilename As String, _
                              ByVal strSize As String, ByVal strModifiedDate As String, ByVal strFileType As String)

        Dim strSQL As String, comTypes As OleDbCommand
        Dim strFolderNameOverflow As String
        Dim strModifiedDate_JustDate As String

        Try

            strFolderNameOverflow = "-"

            If InStr(1, strModifiedDate, " ") > 0 Then

                strModifiedDate_JustDate = Mid(strModifiedDate, 1, InStr(1, strModifiedDate, " ") - 1)
            Else

                strModifiedDate_JustDate = strModifiedDate
            End If

            strSQL = "Insert into tblDriveContents (DriveName, Foldername, FoldernameWithoutPath, FolderNameOverflow, Filename, FileSize, ModifiedDate, FileType, ModifiedDate_JustDate) values ('" _
                      & strDriveName & "','" & ParseTextForSQL(strFoldername) & "','" & ParseTextForSQL(RemoveAllButTopLevel(RemoveDriveAndFolder(strFoldername))) & "','" & ParseTextForSQL(strFolderNameOverflow) & "','" & ParseTextForSQL(strFilename) & "','" & strSize & "','" _
                      & strModifiedDate & "','" & strFileType & "','" & strModifiedDate_JustDate & "')"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            comTypes.ExecuteReader()

            CloseOLECommand(comTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Public Function ParseTextForSQL(ByVal strSQL As String) As String

        ParseTextForSQL = Replace(strSQL, "'", "''")

        If ParseTextForSQL = Nothing Then ParseTextForSQL = ""

    End Function

    Private Function UpdateFiles(ByVal strPath As String, ByRef objSender As System.Object) As Boolean

        Dim strName As String, objStreamWriter As TextWriter

        Me.Cursor = Cursors.WaitCursor

        Try

            DeleteMajorFolders(RemoveOneLevel(strPath))

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name & " - DeleteMajorFolders")

        End Try

        Try

            For Each strDir As String In Directory.GetDirectories(RemoveOneLevel(strPath))

                InsertMajorFolderDBEntry(RemoveOneLevel(strPath), strPath, strDir)
            Next

        Catch directorynotfoundexException As DirectoryNotFoundException

            Me.Cursor = Cursors.Default
            Exit Function

        Catch Exception As Exception

            DisplayException_Messagebox(Exception, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

        Try

            strName = FILES_BACKUP_LOCATION & Getlastfolder(strPath) & ".txt"

            DeleteExistingDBEntries(strPath)

            objStreamWriter = New StreamWriter(strName, False)

            For Each strDir As String In Directory.GetDirectories(strPath)

                objStreamWriter.WriteLine(strDir)

                OutputFilesToFile(strPath, strDir, objStreamWriter, TABS_FOR_FILE)
                OutputFolderToFile(strPath, strDir, objStreamWriter, TABS_FOR_FILE)
            Next

            objStreamWriter.Close()

            UpdateLastBackedUpDate(strPath)
            objSender.tooltiptext = GetLastUpdatedDate(strPath)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name & " - File")
        End Try

        Me.Cursor = Cursors.Default

        UpdateFiles = True

    End Function

    Private Sub LoadFoldersDriveDisconnected(ByRef treDriveNode As TreeNode, ByVal strPath As String)

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand
        Dim objItem As ListViewItem, strDrivename As String
        Dim strLevels() As String, intCount As Integer
        Dim strDrive As String, objNode As TreeNode, objLevel1 As TreeNode, objTest As TreeNode
        Dim intPartCount As Integer, strNextPart As String, objPrevLevel As TreeNode
        Dim intSlashCount As Integer, strFoldername As String, objTryToFindNode As TreeNode
        Dim strSeriesName As String, blnShowCompleted As Boolean, blnShowFinished As Boolean
        Dim blnAddSeries As Boolean, drSeries As OleDbDataReader, comSeries As OleDbCommand
        Dim blnThisSeriesCompleted As Boolean, blnThisSeriesFinished As Boolean

        Try

            blnShowCompleted = mnuOptionsComplete.Checked
            blnShowFinished = mnuOptionsFinished.Checked
            blnAddSeries = True

            treDriveNode.Nodes.Clear()

            strDrive = treDriveNode.Text

            strDrivename = GetDriveAndMainFolder(strPath)

            strSQL = "Select foldername from tblDriveContents where drivename = '" & strDrivename & "' and foldername like '" & strDrivename & "\%' Group by foldername"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    If Trim(drTypes("Foldername") & "") <> "" Then

                        strFoldername = RemoveDrive(treDriveNode.Text, Trim(drTypes("Foldername") & ""))

                        blnThisSeriesFinished = False
                        blnThisSeriesCompleted = False
                        blnAddSeries = True

                        ' Dont add completed/finisdhed shows
                        If blnShowCompleted = False Or blnShowFinished = False Then

                            strSeriesName = GetNextElement(strFoldername, 0)

                            strSQL = "Select Finished, Complete from tblShows where Title = '" & ParseTextForSQL(strSeriesName) & "' "

                            comSeries = New OleDbCommand(strSQL, mobjOLEConn)

                            drSeries = comSeries.ExecuteReader()

                            If drSeries.HasRows Then

                                drSeries.Read()

                                If Trim(drSeries("Finished") & "") = "Y" Then blnThisSeriesFinished = True
                                If Trim(drSeries("Complete") & "") = "Y" Then blnThisSeriesCompleted = True

                                If blnShowCompleted = False And blnThisSeriesCompleted = True Then blnAddSeries = False
                                If blnShowFinished = False And blnThisSeriesFinished = True Then blnAddSeries = False

                            End If

                            CloseOLECommand(comSeries)
                            CloseDataReader(drSeries)
                        End If

                        If blnAddSeries Then

                            intSlashCount = SlashCount(strFoldername)

                            objNode = treDriveNode

                            For intCount = 0 To intSlashCount

                                strNextPart = GetNextElement(strFoldername, intCount)

                                objTryToFindNode = objNode.Nodes(strNextPart)

                                If objTryToFindNode Is Nothing Then

                                    objNode = objNode.Nodes.Add(strNextPart, strNextPart)
                                Else

                                    objNode = objTryToFindNode
                                End If

                            Next
                        End If
                    End If
                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch Ex As Exception

            MessageBox.Show("LoadFoldersDriveDisconnected - general - " & Ex.Message)
        End Try

    End Sub

    Private Function GetNextElement(ByVal strPath As String, ByVal intCount As Integer) As String

        Dim intPos As Integer, strParts() As String

        strParts = Split(strPath, "\")

        Return strParts(intCount)

    End Function

    Private Function GetNextPart(ByVal strPath As String, ByVal intCount As Integer) As String

        Dim intPos As Integer, intCountSoFar As Integer

        strPath = strPath & "\"

        For intPos = 1 To Len(strPath)

            If Mid(strPath, intPos, 1) = "\" Then

                intCountSoFar = intCountSoFar + 1

                If intCount = intCountSoFar Then

                    Return Trim(Mid(strPath, 1, intPos - 1))
                End If
            End If
        Next

        Return ""

    End Function

    Private Function RemoveDrive(ByVal strDrive As String, ByVal strFoldername As String) As String

        strFoldername = strFoldername.Replace(strDrive, "")

        If strFoldername <> "" Then

            strFoldername = Mid(strFoldername, 2)
        End If

        RemoveDrive = strFoldername

    End Function

    Private Function GetLevels(ByVal strDrive As String, ByVal strFoldername As String) As String()

        Dim strLevels() As String

        strFoldername = strFoldername.Replace(strDrive, "")

        If strFoldername <> "" Then

            strFoldername = Mid(strFoldername, 2)
        End If

        strLevels = Split(strFoldername, "/")

        GetLevels = strLevels

    End Function

    Private Sub LoadFoldersDriveConnected(ByRef treNode As TreeNode, ByVal strPath As String)

        Dim treFolder As TreeNode, strSQL As String, intPos As Integer
        Dim strSeriesName As String, blnShowCompleted As Boolean, blnShowFinished As Boolean
        Dim blnAddSeries As Boolean, drSeries As OleDbDataReader, comSeries As OleDbCommand
        Dim blnThisSeriesCompleted As Boolean, blnThisSeriesFinished As Boolean

        blnShowCompleted = mnuOptionsComplete.Checked
        blnShowFinished = mnuOptionsFinished.Checked
        blnAddSeries = True

        treNode.Nodes.Clear()

        Try

            For Each strDir As String In Directory.GetDirectories(strPath)

                blnThisSeriesFinished = False
                blnThisSeriesCompleted = False
                blnAddSeries = True

                ' Dont add completed/finisdhed shows
                If blnShowCompleted = False Or blnShowFinished = False Then

                    intPos = InStrRev(strDir, "\")

                    If intPos > 0 Then

                        strSeriesName = Mid(strDir, intPos + 1)
                    Else

                        strSeriesName = strDir
                    End If

                    strSQL = "Select Finished, Complete from tblShows where Title = '" & ParseTextForSQL(strSeriesName) & "' "

                    comSeries = New OleDbCommand(strSQL, mobjOLEConn)

                    drSeries = comSeries.ExecuteReader()

                    If drSeries.HasRows Then

                        drSeries.Read()

                        If Trim(drSeries("Finished") & "") = "Y" Then blnThisSeriesFinished = True
                        If Trim(drSeries("Complete") & "") = "Y" Then blnThisSeriesCompleted = True

                        If blnShowCompleted = False And blnThisSeriesCompleted = True Then blnAddSeries = False
                        If blnShowFinished = False And blnThisSeriesFinished = True Then blnAddSeries = False

                    End If

                    CloseOLECommand(comSeries)
                    CloseDataReader(drSeries)
                End If

                If blnAddSeries Then

                    treFolder = treNode.Nodes.Add(Getlastfolder(strDir))

                    Try

                        For Each strSubDir As String In Directory.GetDirectories(strDir)

                            treFolder.Nodes.Add(Getlastfolder(strSubDir))
                        Next

                    Catch ex As Exception

                    End Try
                End If
            Next

        Catch ex1 As IOException

            AddError(System.Reflection.MethodBase.GetCurrentMethod().Name & " - " & GetDrive(strPath) & " is not connected!")

        Catch ex2 As UnauthorizedAccessException

            AddError(System.Reflection.MethodBase.GetCurrentMethod().Name & " - " & "Error : No permissions to access the folder!")

        End Try

    End Sub

    Private Sub cmdUpdateTV_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpdateTV.Click, cmdUpdateTV_Backup.Click,
                                                                                                        cmdUpdateTV2.Click, cmdUpdateTV2_Backup.Click,
                                                                                                        cmdUpdateTV3.Click, cmdUpdateTV3_Backup.Click,
                                                                                                        cmdUpdateTV4.Click, cmdUpdateTV4_Backup.Click,
                                                                                                        cmdUpdateTV5.Click, cmdUpdateTV5_Backup.Click,
                                                                                                        cmdUpdateTV6.Click, cmdUpdateTV6_Backup.Click,
                                                                                                        cmdUpdateTV7.Click, cmdUpdateTV7_Backup.Click,
                                                                                                        cmdUpdateTV8.Click, cmdUpdateTV8_Backup.Click,
                                                                                                        cmdUpdateTV9.Click, cmdUpdateTV9_Backup.Click,
                                                                                                        cmdUpdateTV10.Click, cmdUpdateTV10_Backup.Click,
                                                                                                        cmdUpdateMovies.Click, cmdUpdateMovies_Backup.Click


        Dim objCmd As ToolStripButton
        Dim blnSuccess As Boolean, strPath As String

        If My.Computer.Name <> HOME_PC Then

            Exit Sub
        End If

        objCmd = sender
        objCmd.Enabled = False

        strPath = objCmd.Text.Replace("Upd ", "").Replace(" Bkp", " Backup")

        If Not My.Computer.FileSystem.DirectoryExists(strPath) Then

            objCmd.Enabled = True

            DisplayMessage("Drive not found!")
            Exit Sub
        End If

        blnSuccess = UpdateFiles(objCmd.Text.Replace(" Bkp", " Backup").Replace("Upd ", ""), sender)

        objCmd.Enabled = True

        If blnSuccess Then

            DisplayMessage("Done backup of " & objCmd.Text)
        Else

            DisplayMessage("Drive not available!")
        End If

    End Sub

    Private Sub cmdFolderSearch_Click(sender As System.Object, e As System.EventArgs) Handles cmdFolderSearch.Click

        lblNumberOfRows.Text = ""
        If txtSearch.Text.Trim = "" Then Exit Sub

        SetupScreenForSearch()

        DoSearch(False)

    End Sub

    Private Sub cmdFileSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFileSearch.Click

        lblNumberOfRows.Text = ""
        If txtSearch.Text.Trim = "" Then Exit Sub

        SetupScreenForSearch()

        DoSearch(True)

    End Sub

    Private Sub SetupScreenForSearch()

        lblNumberOfRows.Text = ""

        tabFiles.Visible = False
        lvwFiles.Visible = False
        tabDetails.Visible = False
        fraDetails.Visible = False

        DisableAll()

        lvwSearchResults.Items.Clear()
        lvwSearchResults.Visible = True

        lvwSearchResults.Top = DEFAULT_TOP
        lvwSearchResults.Left = lvwFiles.Left
        lvwSearchResults.Width = lvwFiles.Width
        lvwSearchResults.Height = SplitContainer1.Panel2.Height - 80

        cmdFinished.Visible = True
        cmdFinished.Top = cmdClose.Top

        ResetBackColourButtons()

    End Sub

    Private Sub DoSearch(ByVal blnDoFileSearch As Boolean)

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand
        Dim objItem As ListViewItem

        Try

            If blnDoFileSearch Then

                strSQL = "Select * from tblDriveContents where (filename like '%" & ParseTextForSQL(txtSearch.Text.Replace(" ", "%")) & "%')"

                If chkBothTypes.Checked = False Then

                    strSQL = strSQL & " and drivename not like '% Backup'"
                End If
            Else

                strSQL = "Select * from tblDriveContents where (foldername like '%" & ParseTextForSQL(txtSearch.Text.Replace(" ", "%")) & "%')"

                If chkBothTypes.Checked = False Then

                    strSQL = strSQL & " and drivename not like '% Backup'"
                End If
            End If

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    If Trim(drTypes("Filename") & "") <> "" Then

                        objItem = lvwSearchResults.Items.Add(Trim(drTypes("DriveName") & ""))

                        objItem.SubItems.Add(Trim(drTypes("FolderName") & ""))
                        objItem.SubItems.Add(Trim(drTypes("FileName") & ""))
                        objItem.SubItems.Add(Trim(drTypes("FileType") & ""))
                        objItem.SubItems.Add(SetBytes(Trim(drTypes("FileSize") & "")))
                        objItem.SubItems.Add(Trim(drTypes("ModifiedDate") & ""))

                        ' if file is found in that drive then highlight the button for it
                        Select Case Trim(drTypes("Drivename") & "")

                            Case TV : cmdUpdateTV.BackColor = mSearchColour
                            Case TV_Backup : cmdUpdateTV_Backup.BackColor = mSearchColour

                            Case TV2 : cmdUpdateTV2.BackColor = mSearchColour
                            Case TV2_Backup : cmdUpdateTV2_Backup.BackColor = mSearchColour

                            Case TV3 : cmdUpdateTV3.BackColor = mSearchColour
                            Case TV3_Backup : cmdUpdateTV3_Backup.BackColor = mSearchColour

                            Case TV4 : cmdUpdateTV4.BackColor = mSearchColour
                            Case TV4_Backup : cmdUpdateTV4_Backup.BackColor = mSearchColour

                            Case TV5 : cmdUpdateTV5.BackColor = mSearchColour
                            Case TV5_Backup : cmdUpdateTV5_Backup.BackColor = mSearchColour

                            Case TV6 : cmdUpdateTV6.BackColor = mSearchColour
                            Case TV6_Backup : cmdUpdateTV6_Backup.BackColor = mSearchColour

                            Case TV7 : cmdUpdateTV7.BackColor = mSearchColour
                            Case TV7_Backup : cmdUpdateTV7_Backup.BackColor = mSearchColour

                            Case TV8 : cmdUpdateTV8.BackColor = mSearchColour
                            Case TV8_Backup : cmdUpdateTV8_Backup.BackColor = mSearchColour

                            Case TV9 : cmdUpdateTV9.BackColor = mSearchColour
                            Case TV9_Backup : cmdUpdateTV9_Backup.BackColor = mSearchColour

                            Case TV10 : cmdUpdateTV10.BackColor = mSearchColour
                            Case TV10_Backup : cmdUpdateTV10_Backup.BackColor = mSearchColour

                            Case Movies : cmdUpdateMovies.BackColor = mSearchColour
                            Case Movies_Backup : cmdUpdateMovies_Backup.BackColor = mSearchColour

                        End Select

                    End If
                End While

                lvwSearchResults.Sorting = SortOrder.Ascending
                lvwSearchResults.Sort()
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

        Try

            lblNumberOfRows.Text = lvwSearchResults.Items.Count & " rows for " & txtSearch.Text

        Catch ex As Exception

        End Try

        lvwSearchResults.Columns(0).Text = "Drive - " & lvwSearchResults.Items.Count & " results"

    End Sub

    Private Sub DisplayEmptyMessage(ByVal strFilename As String)

        MessageBox.Show("File " & strFilename & " is missing or empty!")

    End Sub

    Private Sub treDrives_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles treDrives.MouseDown

        Dim treNode As TreeNode

        mnuFindCompletedFiles.Visible = True
        mnuFindCompletedFilesSeason.Visible = True

        If e.Button = System.Windows.Forms.MouseButtons.Right Then

            treNode = sender.selectednode

            If Mid(treNode.Text, 1, 7) <> "Season " Then

                mnuFindCompletedFilesSeason.Visible = False
            End If

            If InStr(treNode.Text, ":") > 0 Then

                mnuFindCompletedFiles.Visible = False
                mnuFindCompletedFilesSeason.Visible = False
            End If

            If Mid(treNode.Text, 1, 7) <> "Season " Then

                mnuFindCompletedFilesSeason.Visible = False
            End If

            mnuRightClick.Show(System.Windows.Forms.Cursor.Position)
        End If

    End Sub

    Private Function GetFreeSpace(strDriveName) As Long

        Dim objD As New DriveInfo(GetDrive(strDriveName))

        Try

            GetFreeSpace = objD.AvailableFreeSpace

        Catch ex As Exception

            GetFreeSpace = 0
        End Try

    End Function

    Private Sub UpdateLastBackedUpDate(ByVal strDriveName As String)

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand

        Try

            strSQL = "Update tblDrives set LastBackedUp = '" & Format(Now, "dd MMM yyyy HH:mm") & "',FreeSpace = " & GetFreeSpace(strDriveName) & " where Drivename = '" & strDriveName & "'"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Function GetLastUpdatedDate(ByVal strDriveName As String) As String

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand, strFree As String

        strFree = "unknown"

        Try

            strSQL = "Select LastBackedUp, Freespace from tblDrives where Drivename = '" & strDriveName & "'"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                drTypes.Read()

                If Trim(drTypes("LastBackedup") & "") <> "" Then

                    If Trim(drTypes("FreeSpace") & "") <> "" Then

                        strFree = SetBytes(Trim(drTypes("FreeSpace") & ""))
                    End If

                    GetLastUpdatedDate = "Last backed Up - " & drTypes("LastBackedup") & " - Free Space - " & strFree
                Else

                    GetLastUpdatedDate = "Last backed Up - never!"
                End If

            Else

                GetLastUpdatedDate = "Last backed Up - never!"
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Function

    Private Sub DisplayMessage(ByVal strMessage As String)

        lblMessage.Text = "Message - " & strMessage

        Timer1.Enabled = True

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick

        lblMessage.Text = ""
        Timer1.Enabled = False

    End Sub

    Private Sub cmdFinished_Click(sender As System.Object, e As System.EventArgs) Handles cmdFinished.Click

        txtSearch.Text = ""

        tabFiles.Visible = True
        lvwFiles.Visible = True

        tabDetails.Visible = True
        fraDetails.Visible = True

        cmdClose.Visible = True

        DisableAll()

        lvwSearchResults.Visible = False
        cmdFinished.Visible = False

        ResetBackColourButtons()

    End Sub

    Private Sub UpdateLastAutoUpdateDate(ByVal strDrive As String)

        Dim intPos As Integer
        Dim strSQL As String
        Dim comTypes As OleDbCommand

        strDrive = strDrive.Replace(" Backup", "")

        intPos = InStr(strDrive, "\")

        If intPos > 0 Then

            strDrive = Mid(strDrive, intPos + 1)

            strSQL = "Update tblDrives set LastAutoUpdateDate = '" & Format(Now, "dd MMM yyyy") & "' where DriveName like '%" & strDrive & "%'"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            comTypes.ExecuteReader()

            CloseOLECommand(comTypes)

            PlaySound(ROOT_DRIVE & "\VB.Net\_Sounds\Done.mp3")
        End If

    End Sub

    Private Sub ResetBackColourButtons()

        cmdUpdateMovies.BackColor = SystemColors.Control
        cmdUpdateMovies_Backup.BackColor = SystemColors.Control

        cmdUpdateTV10.BackColor = SystemColors.Control
        cmdUpdateTV10_Backup.BackColor = SystemColors.Control
        cmdUpdateTV9.BackColor = SystemColors.Control
        cmdUpdateTV9_Backup.BackColor = SystemColors.Control
        cmdUpdateTV8.BackColor = SystemColors.Control
        cmdUpdateTV8_Backup.BackColor = SystemColors.Control
        cmdUpdateTV7.BackColor = SystemColors.Control
        cmdUpdateTV7_Backup.BackColor = SystemColors.Control
        cmdUpdateTV6.BackColor = SystemColors.Control
        cmdUpdateTV6_Backup.BackColor = SystemColors.Control
        cmdUpdateTV5.BackColor = SystemColors.Control
        cmdUpdateTV5_Backup.BackColor = SystemColors.Control
        cmdUpdateTV4.BackColor = SystemColors.Control
        cmdUpdateTV4_Backup.BackColor = SystemColors.Control
        cmdUpdateTV3.BackColor = SystemColors.Control
        cmdUpdateTV3_Backup.BackColor = SystemColors.Control

        cmdUpdateTV2.BackColor = SystemColors.Control
        cmdUpdateTV2_Backup.BackColor = SystemColors.Control
        cmdUpdateTV.BackColor = SystemColors.Control
        cmdUpdateTV_Backup.BackColor = SystemColors.Control

    End Sub

    Private Sub SetupScreenForDriveStatus()

        tabFiles.Visible = False

        lvwFiles.Visible = False

        tabDetails.Visible = False
        fraDetails.Visible = False

        lvwSearchResults.Visible = False

        EnableDisable_ToDo(False)
        EnableDisable_AiredShows(False)
        EnableDisable_NonStandardFiles(False)
        EnableDisable_omdbAPI(False)
        EnableDisable_MumsStuff(False)
        EnableDisable_RottenTomatoes(False)
        EnableDisable_MajorFolders(False)
        EnableDisable_PeopleAlsoLiked_All(False)
        EnableDisable_ShowList_Dups(False)
        EnableDisable_UpdateStatus_MissingItems(False)
        EnableDisable_KnownDups(False)
        EnableDisable_GeneralListview(False)
        EnableDisable_DriveSummary(False)
        EnableDisable_LastFilesAdded(False)
        EnableDisable_DriveFileSummary(False)

        EnableDisable_DriveStatus(True)

        lvwDriveStatus.Items.Clear()

        lvwDriveStatus.Top = DEFAULT_TOP
        lvwDriveStatus.Left = lvwFiles.Left
        lvwDriveStatus.Width = lvwFiles.Width
        lvwDriveStatus.Height = SplitContainer1.Panel2.Height - DEFAULT_HEIGHT_REDUCATION

        cmdFinished_DriveStatus.Left = cmdFinished.Left
        cmdFinished_DriveStatus.Top = cmdClose.Top

    End Sub

    Private Sub LoadDriveStatus()

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand
        Dim objItem As ListViewItem, strMPath As String
        Dim lngDirSize As Long, objDir_MDrive As DirectoryInfo
        Dim lngFreeSpace As Long, objStreamW As StreamWriter
        Dim strEarliestUpdateDate As String, strName As String
        Dim strLatestAutoUpdateDate As String

        If My.Computer.Name = HOME_PC Then

            strMPath = GetBackupFolderOn_M_Drive()

            If strMPath <> "" Then

                strMPath = ProperisePath(strMPath)

                If My.Computer.FileSystem.FileExists(strMPath & "total_disk_size.txt") Then

                    lngDirSize = My.Computer.FileSystem.OpenTextFileReader(strMPath & "total_disk_size.txt").ReadToEnd
                Else

                    If MessageBox.Show("No size file found. Create one now?", My.Application.Info.ProductName, MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then

                        objDir_MDrive = New DirectoryInfo(strMPath)

                        lngDirSize = GetDirectoriesSize(objDir_MDrive)

                        objStreamW = My.Computer.FileSystem.OpenTextFileWriter(strMPath & "total_disk_size.txt", False)

                        objStreamW.Write(lngDirSize.ToString)

                        objStreamW.Close()
                        objStreamW = Nothing
                    Else

                        lngDirSize = 0
                    End If
                End If

            End If
        End If

        Try

            lvwDriveStatus.ListViewItemSorter = Nothing
            lvwDriveStatus.Sorting = SortOrder.None

            strSQL = "Select * from tblDrives Order by DriveID"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    If Trim(drTypes("Drivename") & "") <> "" Then

                        objItem = lvwDriveStatus.Items.Add(Trim(drTypes("DriveName") & ""))

                        If IsDriveConnected(objItem.Text) Then

                            objItem.Selected = True
                        End If

                        objItem.SubItems.Add(Trim(drTypes("LastBackedup") & ""))
                        objItem.SubItems.Add(SetBytes(Trim(drTypes("FreeSpace") & "")))

                        If My.Computer.Name = HOME_PC And lngDirSize > 0 Then

                            lngFreeSpace = CLng(drTypes("FreeSpace") & "")
                            lngFreeSpace = lngFreeSpace - lngDirSize

                            If lngFreeSpace > 0 Then

                                objItem.SubItems.Add(SetBytes(lngFreeSpace))
                            Else

                                objItem.SubItems.Add("")
                            End If
                        Else

                            objItem.SubItems.Add("")
                        End If

                        objItem.SubItems.Add(Trim(drTypes("DriveCapacity") & ""))

                        If Mid(Trim(drTypes("Drivename") & ""), 1, 3) <> "N:\" And Mid(Trim(drTypes("Drivename") & ""), 1, 3) <> "O:\" Then

                            objItem.SubItems.Add(Trim(drTypes("RefreshDate") & ""))

                            FindEarliestUpdateDate(Trim(drTypes("DriveName") & ""), strEarliestUpdateDate, strName)

                            objItem.SubItems.Add(strEarliestUpdateDate)

                            objItem.SubItems.Add(strName)
                        Else

                            objItem.SubItems.Add("")
                            objItem.SubItems.Add("")
                            objItem.SubItems.Add("")
                        End If

                        objItem.SubItems.Add(Trim(drTypes("DriveID") & ""))

                        strLatestAutoUpdateDate = drTypes("LastAutoUpdateDate") & ""

                        objItem.SubItems.Add(strLatestAutoUpdateDate)
                    End If
                End While
            End If

            mobjColumn_DriveStatus = Nothing

            Dim objE As New ColumnClickEventArgs(COL_DRIVESTATUS_DRIVEID)
            lvwDriveStatus_ColumnClick(Nothing, objE)

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub cmdDriveStatusFinished_Click(sender As System.Object, e As System.EventArgs) Handles cmdFinished_DriveStatus.Click

        ReshowDefaultFormLayout()

    End Sub

    Private Sub lblLastError_Click(sender As System.Object, e As System.EventArgs) Handles lblLastError.Click

        MessageBox.Show("Error History: - " & vbCrLf & mstrErrors)

    End Sub

    Private Sub mnuDriveStatus_Click(sender As System.Object, e As System.EventArgs) Handles mnuDriveStatus.Click

        SetupScreenForDriveStatus()

        LoadDriveStatus()

    End Sub

    Private Sub mnuExit_Click(sender As System.Object, e As System.EventArgs) Handles mnuExit.Click

        cmdClose_Click(sender, e)

    End Sub

    Private Sub mnuMajorfolders_Click(sender As System.Object, e As System.EventArgs) Handles mnuMajorFolders.Click

        SetupScreenForMajorFolders()

        LoadMajorFolders()

    End Sub

    Private Sub SetupScreenForMajorFolders()

        tabFiles.Visible = False

        tabDetails.Visible = False
        fraDetails.Visible = False

        lvwFiles.Visible = False
        lvwDriveStatus.Visible = False
        lvwSearchResults.Visible = False


        EnableDisable_AiredShows(False)
        EnableDisable_omdbAPI(False)
        EnableDisable_MumsStuff(False)
        EnableDisable_NonStandardFiles(False)
        EnableDisable_ToDo(False)
        EnableDisable_RottenTomatoes(False)
        EnableDisable_DriveSummary(False)
        EnableDisable_DriveStatus(False)
        EnableDisable_GeneralListview(False)
        EnableDisable_KnownDups(False)
        EnableDisable_PeopleAlsoLiked_All(False)
        EnableDisable_ShowList_Dups(False)
        EnableDisable_LastFilesAdded(False)
        EnableDisable_DriveFileSummary(False)

        EnableDisable_MajorFolders(True)

        lvwKnownDups.Visible = False

        lvwMajorFolders.Items.Clear()

        lvwMajorFolders.BringToFront()
        lvwMajorFolders.Top = DEFAULT_TOP
        lvwMajorFolders.Left = 5
        lvwMajorFolders.Width = SplitContainer1.Panel2.Width - 15
        lvwMajorFolders.Height = SplitContainer1.Panel2.Height - DEFAULT_HEIGHT_REDUCATION

        cmdFinished_MajorFolders.Left = cmdFinished.Left
        cmdFinished_MajorFolders.Top = cmdClose.Top

    End Sub

    Private Sub LoadMajorFolders()

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand
        Dim objItem As ListViewItem

        Try

            strSQL = "Select * from tblMajorFolders where Drivename <> 'H:\' Order by Drivename, DriveLabel, Foldername"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    If Trim(drTypes("Drivename") & "") <> "" Then

                        objItem = lvwMajorFolders.Items.Add(Trim(drTypes("DriveName") & ""))

                        objItem.SubItems.Add(Trim(drTypes("DriveLabel") & ""))
                        objItem.SubItems.Add(Trim(drTypes("FolderName") & ""))

                    End If
                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub cmdMajorFoldersFinished_Click(sender As System.Object, e As System.EventArgs) Handles cmdFinished_MajorFolders.Click

        ReshowDefaultFormLayout()

    End Sub

    Private Sub mnuDuplicates_Click(sender As System.Object, e As System.EventArgs) Handles mnuDuplicates.Click

        Dim strSQL As String, comTypes As OleDbCommand, daTypes As OleDbDataAdapter
        Dim strFilename As String, strFilenamePrev As String, strFilenameNext As String
        Dim strPath As String, strPathPrev As String, strPathNext As String
        Dim dsFiles As New DataSet, intRows As Integer, blnFirst As Boolean
        Dim strFileSize As String, strFileSizePrev As String, strFileSizeNext As String
        Dim intDupCount As Integer, intProgress As Integer

        mblnDupFile = False

        Me.Text = APP_NAME & " - QuickCheckOnDuplicateFilesUsingNameAndSize"

        If Not QuickCheckOnDuplicateFilesUsingNameAndSize() Then

            Exit Sub
        Else

            MessageBox.Show("Passed first duplicate check type - QuickCheckOnDuplicateFilesUsingNameAndSize")
        End If

        Me.Text = APP_NAME & " - QuickCheckOnFolderNumbers"

        If Not QuickCheckOnFolderNumbers() Then

            Exit Sub
        Else

            MessageBox.Show("Passed second duplicate check type - QuickCheckOnFolderNumbers")
        End If

        Me.Text = APP_NAME & " - QuickCheckOnFileNameAndFileTypes"

        If Not QuickCheckOnFileNameAndFileTypes() Then

            Exit Sub
        Else

            MessageBox.Show("Passed third duplicate check type - QuickCheckOnFileNameAndFileTypes")
        End If

        Me.Text = APP_NAME & " - Long pass through files"

        mstrDuplicatesText = ""
        intProgress = 0

        Try

            strSQL = "Select Drivename,Foldername,filename,FileSize from tblDriveContents Order by Filename ASC"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            daTypes = New OleDbDataAdapter(strSQL, mobjOLEConn)
            daTypes.Fill(dsFiles)
            daTypes.Dispose()

            prgProgress.Minimum = 1
            prgProgress.Value = 1
            prgProgress.Maximum = dsFiles.Tables(0).Rows.Count - 1
            prgProgress.Left = tabDetails.Left
            prgProgress.Top = tabDetails.Top + tabDetails.Height + 5
            prgProgress.Visible = True

            For intRows = 1 To dsFiles.Tables(0).Rows.Count - 1

                prgProgress.Value = intRows
                prgProgress.Refresh()

                blnFirst = Not blnFirst

                strFilename = ""
                strFilenamePrev = ""
                strFilenameNext = ""

                strPath = ""
                strPathPrev = ""
                strPathNext = ""

                strFileSize = ""
                strFileSizePrev = ""
                strFileSizeNext = ""

                Try

                    strFilenamePrev = Trim(dsFiles.Tables(0).Rows(intRows - 1).Item("Filename") & "")
                    strFilename = Trim(dsFiles.Tables(0).Rows(intRows).Item("Filename") & "")
                    strFilenameNext = Trim(dsFiles.Tables(0).Rows(intRows + 1).Item("Filename") & "")

                    strPath = Trim(dsFiles.Tables(0).Rows(intRows - 1).Item("Foldername") & "")
                    strPathPrev = Trim(dsFiles.Tables(0).Rows(intRows).Item("Foldername") & "")
                    strPathNext = Trim(dsFiles.Tables(0).Rows(intRows + 1).Item("Foldername") & "")

                    strFileSizePrev = Trim(dsFiles.Tables(0).Rows(intRows - 1).Item("Filesize") & "")
                    strFileSize = Trim(dsFiles.Tables(0).Rows(intRows).Item("Filesize") & "")
                    strFileSizeNext = Trim(dsFiles.Tables(0).Rows(intRows + 1).Item("Filesize") & "")

                Catch ex As Exception

                    SearchForDuplicateFolders()

                    CloseDataSet(dsFiles)
                    CloseOLECommand(comTypes)

                    ResetProgress()

                    Exit Sub
                End Try

                If intProgress >= 15 Then

                    Me.Text = APP_NAME & " - " & strFilename & " - Long pass through files"

                    intProgress = 1
                    Me.Refresh()
                Else

                    intProgress = intProgress + 1
                End If

                If IsDuplicate(blnFirst, strFilename, strFilenamePrev, strFilenameNext, strFileSize, strFileSizePrev, strFileSizeNext, strPath, strPathPrev, strPathNext) Then

                    mstrDuplicatesText = mstrDuplicatesText & "Duplicates for " & vbCrLf & strPathPrev & "\" & strFilenamePrev _
                                                      & vbCrLf & strPath & "\" & strFilename _
                                                      & vbCrLf & strPathNext & "\" & strFilenameNext & vbCrLf & vbCrLf

                    intDupCount = intDupCount + 1

                    If intDupCount = MAX_DUPLICATE_COUNT Then

                        If MessageBox.Show(mstrDuplicatesText & vbCrLf & vbCrLf & "Quit to sort it out?", "Media Manager", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                            ResetProgress()
                            Exit Sub
                        End If

                    End If
                End If
            Next

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

            ResetProgress()

            Exit Sub
        End Try

        ResetProgress()

        MessageBox.Show("Passed final duplicate check type - Long pass through files")

    End Sub

    Private Sub ResetProgress()

        prgProgress.Left = 953
        prgProgress.Top = 151
        prgProgress.Visible = False

    End Sub

    Private Function IsDuplicate(ByVal blnFirst As Boolean, ByVal strFilename As String, ByVal strFilenamePrev As String, ByVal strFilenameNext As String, _
                                 ByVal strFileSize As String, strFileSizePrev As String, strFileSizeNext As String, _
                                 ByVal strPath As String, ByVal strPathPrev As String, ByVal strPathNext As String) As Boolean

        strPath = RemoveDriveAndAllBut1Folder(strPath)
        strPathPrev = RemoveDriveAndAllBut1Folder(strPathPrev)
        strPathNext = RemoveDriveAndAllBut1Folder(strPathNext)

        If (strFilenamePrev = strFilename And strFilename = strFilenameNext) And (strPath = strPathPrev And strPath = strPathNext) And (strFileSizePrev = strFileSize And strFileSize = strFileSizeNext) Then

            IsDuplicate = True
        Else

            IsDuplicate = False
        End If

    End Function

    Private Sub mnuLastFilesAdded_Click(sender As System.Object, e As System.EventArgs) Handles mnuLastFilesAdded.Click

        SetupScreenForLastAddedFiles()

        DisplayLastAddedFiles()

    End Sub

    Private Sub SetupScreenForLastAddedFiles()

        lblNumberOfRows.Text = ""

        tabFiles.Visible = False
        lvwFiles.Visible = False
        tabDetails.Visible = False
        fraDetails.Visible = False

        DisableAll()

        EnableDisable_LastFilesAdded(True)

        cboFileCount.Top = DEFAULT_TOP
        cboFileCount.Left = lvwFiles.Left

        lvwSearchResults.Items.Clear()

        lvwSearchResults.Top = cboFileCount.Top + 26
        lvwSearchResults.Left = lvwFiles.Left
        lvwSearchResults.Width = lvwFiles.Width
        lvwSearchResults.Height = SplitContainer1.Panel2.Height - 77

        cmdFinished.Top = cmdClose.Top

        cboFileCount.Items.Clear()
        cboFileCount.Items.Add("Last 50 Files")
        cboFileCount.Items.Add("Last 100 Files")
        cboFileCount.Items.Add("Last 250 Files")
        cboFileCount.Items.Add("Last 7 Days")
        cboFileCount.Items.Add("Last 14 Days")
        cboFileCount.Items.Add("Last 31 Days")
        cboFileCount.Items.Add("Last 3 Months")
        cboFileCount.SelectedIndex = 0

        ResetBackColourButtons()

    End Sub

    Private Sub DisplayLastAddedFiles()

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand
        Dim objItem As ListViewItem
        Dim intCount As Integer, intFileCount As Integer
        Dim tsDays As TimeSpan

        Try

            If cboFileCount.Text.Trim = "" Then Exit Sub

            lvwSearchResults.Items.Clear()

            Me.Cursor = Cursors.WaitCursor

            If InStr(cboFileCount.Text, " Files") > 0 Then

                intCount = 0

                intFileCount = cboFileCount.Text.Replace("Last", "").Replace("Files", "").Trim

                strSQL = "Select top " & intFileCount & " Filename, ModifiedDate_JustDate, Drivename, Foldername, FileType, Filesize from tblDriveContents where (foldername not like '%TV%Backup%')  Order by ModifiedDate_JustDate Desc, drivename"

            ElseIf InStr(cboFileCount.Text, " Days") > 0 Or InStr(cboFileCount.Text, " Months") > 0 Then

                intCount = 0

                intFileCount = cboFileCount.Text.Replace("Last", "").Replace("Months", "").Replace("Days", "").Trim

                Select Case intFileCount

                    Case 7 : tsDays = New TimeSpan(7, 0, 0, 0)

                    Case 14 : tsDays = New TimeSpan(14, 0, 0, 0)

                    Case 31 : tsDays = New TimeSpan(31, 0, 0, 0)

                    Case 3 : tsDays = New TimeSpan(91, 0, 0, 0)

                End Select

                intFileCount = 999999999

                strSQL = "Select * from tblDriveContents where  (foldername not like '%Backup%') and ModifiedDate >= #" & Format(Date.Now.Subtract(tsDays), "MM dd yyyy").Replace(" ", "/") & "# Order by ModifiedDate Desc"

            End If

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    If Trim(drTypes("Filename") & "") <> "" And intCount <= intFileCount Then

                        intCount = intCount + 1

                        objItem = lvwSearchResults.Items.Add(Trim(drTypes("DriveName") & ""))

                        objItem.SubItems.Add(Trim(drTypes("FolderName") & ""))
                        objItem.SubItems.Add(Trim(drTypes("FileName") & ""))
                        objItem.SubItems.Add(Trim(drTypes("FileType") & ""))
                        objItem.SubItems.Add(SetBytes(Trim(drTypes("FileSize") & "")))
                        objItem.SubItems.Add(Trim(drTypes("ModifiedDate_JustDate") & ""))

                    End If
                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

            If intCount > 0 Then

                lvwSearchResults.Columns(0).Text = "Drive - " & intCount - 1 & " files"

            Else

                lvwSearchResults.Columns(0).Text = "Drive"
            End If

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

        Me.Cursor = Cursors.Default

    End Sub

    Private Sub SearchForDuplicateFolders()

        Dim strSQL As String, drTypes As OleDbDataReader, drMatch As OleDbDataReader
        Dim comTypes As OleDbCommand, comMatch As OleDbCommand, strFoldername As String
        Dim strDupFoldername As String

        Try

            strSQL = "Select FoldernameWithoutPath from tblDriveContents Where FoldernameWithoutPath Not like '%The %' Group by FoldernameWithoutPath"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    strFoldername = Trim(drTypes("FoldernameWithoutPath") & "")

                    strSQL = "Select FoldernameWithoutPath from tblDriveContents Where FoldernameWithoutPath like '%" & "The " & ParseTextForSQL(strFoldername) & "'"

                    comMatch = New OleDbCommand(strSQL, mobjOLEConn)

                    drMatch = comMatch.ExecuteReader()

                    If drMatch.HasRows Then

                        Try

                            strDupFoldername = Trim(drMatch("FoldernameWithoutPath") & "")

                        Catch ex As Exception

                            MessageBox.Show("Potential duplication - " & strFoldername & " and The " & strFoldername)

                        End Try

                    End If

                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Public Function GetPrefix(ByVal strPath As String) As String

        Dim lngPos As Long

        strPath = RemovePath(strPath)

        lngPos = InStrRev(strPath, ".")

        GetPrefix = Mid$(strPath, lngPos + 1).ToUpper

    End Function

    Public Function RemovePath(ByVal strPath As String) As String

        Dim intPos As Integer

        intPos = InStrRev(strPath, "\")

        RemovePath = Mid$(strPath, intPos + 1)

    End Function

    Public Function RemovePrefix(ByVal strPath As String, Optional ByVal blnRemovePath As Boolean = True) As String

        Dim lngPos As Long

        If blnRemovePath Then strPath = RemovePath(strPath)

        lngPos = InStrRev(strPath, ".")

        RemovePrefix = Mid$(strPath, 1, lngPos - 1)

    End Function

    Private Function PrefixesOK(ByVal strPrefix1 As String, ByVal strPrefix2 As String) As Boolean

        PrefixesOK = False

        strPrefix1 = strPrefix1.Trim.ToUpper
        strPrefix2 = strPrefix2.Trim.ToUpper

        If strPrefix1 = "MP4" Then strPrefix1 = "AVI"
        If strPrefix1 = "MKV" Then strPrefix1 = "AVI"
        If strPrefix1 = "WMV" Then strPrefix1 = "AVI"

        If strPrefix2 = "MP4" Then strPrefix2 = "AVI"
        If strPrefix2 = "MKV" Then strPrefix2 = "AVI"
        If strPrefix2 = "WMV" Then strPrefix2 = "AVI"

        If strPrefix1 = "IDX" And strPrefix2 = "SUB" Then

            PrefixesOK = True
            Exit Function
        End If

        If strPrefix1 = "IDX" And strPrefix2 = "AVI" Then

            PrefixesOK = True
            Exit Function
        End If

        If strPrefix1 = "AVI" And strPrefix2 = "SRT" Then

            PrefixesOK = True
            Exit Function
        End If

        If strPrefix1 = "AVI" And strPrefix2 = "IDX" Then

            PrefixesOK = True
            Exit Function
        End If

        If strPrefix1 = "AVI" And strPrefix2 = "SUB" Then

            PrefixesOK = True
            Exit Function
        End If

    End Function

    Private Function QuickCheckOnFileNameAndFileTypes() As Boolean

        Dim strSQL As String, drTypes As OleDbDataReader, drMatch As OleDbDataReader
        Dim comTypes As OleDbCommand, comMatch As OleDbCommand
        Dim strFilename1 As String, strFilename2 As String
        Dim strFoldername1 As String, strFoldername2 As String
        Dim strFilenameNoPrefix1 As String, strFilenameNoPrefix2 As String
        Dim strPrefix1 As String, strPrefix2 As String

        QuickCheckOnFileNameAndFileTypes = False

        Try

            strSQL = "select * from tblDriveContents where (foldername like '%Movies\Hollywood%' or foldername like '%Movies II\Hollywood%') order by drivename, foldername, filename"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    strFilename1 = ""
                    strFoldername1 = ""
                    strPrefix1 = ""

                    strFilename2 = ""
                    strFoldername2 = ""
                    strPrefix2 = ""

                    strFilename1 = Trim(drTypes("Filename") & "")
                    strFoldername1 = Trim(drTypes("Foldername") & "")

                    drTypes.Read()

                    strFilename2 = Trim(drTypes("Filename") & "")
                    strFoldername2 = Trim(drTypes("Foldername") & "")

                    If (strFoldername1 = strFoldername2) Then

                        If (strFilename1 <> "") And (strFilename2 <> "") Then

                            strFilenameNoPrefix1 = RemovePrefix(strFilename1, False)
                            strFilenameNoPrefix2 = RemovePrefix(strFilename2, False)

                            strPrefix1 = GetPrefix(strFilename1)
                            strPrefix2 = GetPrefix(strFilename2)

                            If strFilenameNoPrefix1 = strFilenameNoPrefix2 And Not PrefixesOK(strPrefix1, strPrefix2) Then

                                If MessageBox.Show("Duplicated by file type - " & vbCrLf & vbCrLf & strFoldername1 & "\" & strFilename1 & vbCrLf & strFoldername2 & "\" & strFilename2 & vbCrLf & vbCrLf &
                                                    "Quit to sort out - (details in clipboard)?", "Media Manager", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                                    Clipboard.SetText("Duplicated by file type - " & vbCrLf & vbCrLf & strFoldername1 & "\" & strFilename1 & vbCrLf & strFoldername2 & "\" & strFilename2)
                                    QuickCheckOnFileNameAndFileTypes = False
                                    Exit Function
                                End If
                            End If

                        End If
                    End If

                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            If ex.Message = "No data exists for the row/column." Then

                QuickCheckOnFileNameAndFileTypes = True
                Exit Function
            End If

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
            Exit Function

        End Try

        QuickCheckOnFileNameAndFileTypes = True

    End Function

    Private Function QuickCheckOnFolderNumbers() As Boolean

        Dim strSQL As String, drTypes As OleDbDataReader, drMatch As OleDbDataReader
        Dim comTypes As OleDbCommand, comMatch As OleDbCommand, strFoldername As String, strFoldernameBackup As String

        QuickCheckOnFolderNumbers = False

        Try

            strSQL = "Select * from tblMajorFolders Where Foldername like '%TV%' and foldername not like '%TV%Backup' Order by Foldername"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    strFoldername = Trim(drTypes("Drivename") & drTypes("Foldername") & "")

                    strFoldernameBackup = RemoveDrive(strFoldername & " Backup")

                    strFoldernameBackup = GetDriveFromPath(strFoldernameBackup) & strFoldernameBackup

                    If CountofSubfolders(strFoldername) <> CountofSubfolders(strFoldernameBackup) Then

                        MessageBox.Show("Difference in subfolders for folders " & strFoldername & " and " & strFoldernameBackup & " - Exiting. Counts are " & CountofSubfolders(strFoldername) & " and " & CountofSubfolders(strFoldernameBackup))

                        Exit Function
                    End If

                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
            Exit Function

        End Try

        QuickCheckOnFolderNumbers = True

    End Function

    Private Function GetDriveFromPath(ByVal strFoldername As String) As String

        Dim strSQL As String, drTypes As OleDbDataReader, drMatch As OleDbDataReader
        Dim comTypes As OleDbCommand, comMatch As OleDbCommand


        GetDriveFromPath = ""

        Try

            strSQL = "Select DriveName from tblMajorFolders Where Foldername = '" & strFoldername & "'"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                If drTypes.Read() Then

                    GetDriveFromPath = drTypes("DriveName")
                End If
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Function

    Private Function CountofSubfolders(ByVal strPath As String) As Integer

        Dim strSQL As String, drTypes As OleDbDataReader, drMatch As OleDbDataReader
        Dim comTypes As OleDbCommand, comMatch As OleDbCommand, strFoldername As String
        Dim strFoldernameBackup As String, intCount As Integer

        Try

            strSQL = "Select count(foldernamewithoutPath) from tblDriveContents Where Drivename = '" & strPath & "' Group by foldernamewithoutPath"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    intCount = intCount + 1

                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

        CountofSubfolders = intCount

    End Function

    Private Function QuickCheckOnDuplicateFilesUsingNameAndSize() As Boolean

        Dim strSQL As String, drTypes As OleDbDataReader, drMatch As OleDbDataReader
        Dim comTypes As OleDbCommand, comMatch As OleDbCommand, strFoldername As String
        Dim strFilename1 As String, strFile1Count As String, strPath1 As String
        Dim strFilename2 As String, strFile2Count As String, strPath2 As String
        Dim strFilename3 As String, strFile3Count As String, strPath3 As String
        Dim objMsgbox As Windows.Forms.DialogResult
        Dim objStreamWriter As StreamWriter

        Try

            strSQL = "SELECT * FROM tblDriveContents where drivename not like '%Movies%' Order by Filename, Filesize"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    strFilename1 = drTypes("Filename")
                    strFile1Count = drTypes("Filesize")
                    strPath1 = drTypes("Foldername") & "\" & drTypes("Filename")

                    If drTypes.Read() Then

                        strFilename2 = drTypes("Filename")
                        strFile2Count = drTypes("Filesize")
                        strPath2 = drTypes("Foldername") & "\" & drTypes("Filename")
                    End If

                    If drTypes.Read() Then

                        strFilename3 = drTypes("Filename")
                        strFile3Count = drTypes("Filesize")
                        strPath3 = drTypes("Foldername") & "\" & drTypes("Filename")
                    End If

                    If strFilename1 = strFilename2 And strFilename1 = strFilename3 And strFile1Count = strFile2Count And strFile1Count = strFile3Count Then

                        If mblnDupFile Then

                            objStreamWriter.WriteLine(strPath1 & vbCrLf & strPath2 & vbCrLf & strPath3 & vbCrLf & vbCrLf)

                        Else

                            objMsgbox = MessageBox.Show("Duplicate - found " & vbCrLf & vbCrLf & strPath1 & vbCrLf & vbCrLf & strPath2 & vbCrLf & vbCrLf & strPath3 & vbCrLf & vbCrLf _
                                           & "Yes to quit to sort it out (details in clipboard), Cancel to write all dups to a file, No to keep going", My.Application.Info.ProductName, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)

                            If objMsgbox = Windows.Forms.DialogResult.Yes Then

                                Clipboard.SetText(strPath1 & vbCrLf & strPath2 & vbCrLf & strPath3)

                                QuickCheckOnDuplicateFilesUsingNameAndSize = False
                                Exit Function
                            End If

                            If objMsgbox = Windows.Forms.DialogResult.Cancel Then

                                mblnDupFile = True

                                objStreamWriter = My.Computer.FileSystem.OpenTextFileWriter("Dups - " & Format(Now, "dd MMM yyyy") & ".txt", False)
                            End If
                        End If
                    End If

                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

            QuickCheckOnDuplicateFilesUsingNameAndSize = False
            Exit Function

        End Try

        If Not objStreamWriter Is Nothing Then

            objStreamWriter.Close()
            objStreamWriter = Nothing
        End If

        QuickCheckOnDuplicateFilesUsingNameAndSize = True

    End Function

    Private Sub txtSearch_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles txtSearch.KeyDown

        If e.KeyCode = Keys.Enter Then

            cmdFileSearch_Click(Nothing, Nothing)
        End If

        If txtSearch.Text.Trim <> "" Then Clipboard.SetText(txtSearch.Text)

    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As System.EventArgs) Handles txtSearch.TextChanged

        lblNumberOfRows.Text = ""

    End Sub

    Private Sub optImdb_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles optImdb.CheckedChanged

        Dim strSeriesName As String

        If Not mblnFinishedLoading Then Exit Sub

        Try

            If IsNothing(treDrives.SelectedNode.FullPath) Then Exit Sub

        Catch ex As Exception

            Exit Sub
        End Try

        If optImdb.Checked Then

            strSeriesName = ReturnLevel3(treDrives.SelectedNode.FullPath)

            LoadSeriesDetails(strSeriesName, True, treDrives.SelectedNode.FullPath)
        End If

    End Sub

    Private Sub cmdUpdateNow_Click(sender As System.Object, e As System.EventArgs) Handles cmdUpdateNow.Click

        Application.DoEvents()
        cmdUpdateNow.Enabled = False
        cmdUpdate_OMDB_Only.Enabled = False
        Application.DoEvents()
        Me.Cursor = Cursors.WaitCursor
        Application.DoEvents()

        txtAPITitle.Text = ""

        If optImdb.Checked = True Then

            UpdateDetailsFromIMDB(txtID.Text, txtSeriesName.Text, True)
        End If

        Application.DoEvents()
        cmdUpdateNow.Enabled = True
        cmdUpdate_OMDB_Only.Enabled = True
        Application.DoEvents()
        Me.Cursor = Cursors.Default
        Application.DoEvents()

        UpdateAppCaption(Me, treDrives)

        Application.DoEvents()

        treDrives.Focus()

        PlaySound(ROOT_DRIVE & "\VB.Net\_Sounds\HB.mp3")

    End Sub

    Private Function UpdateFromOMDBAPI(ByRef strID As String, ByRef strSeriesName As String, ByVal strDrive As String, _
                                       ByRef blnUpdateSuccess As Boolean, ByRef strUpdateException As String) As Boolean

        Dim objHTML As New HTMLReader.clsHTMLReader, strHTML As String
        Dim strElements() As String, strTempElements() As String
        Dim intCount As Integer, intElementCount As Integer, blnStop As Boolean
        Dim strTemp As String, strSQL As String, strTempArray() As String
        Dim strFieldname As String, strComma As String, drTypes As OleDbDataReader, comTypes As OleDbCommand

        ' May have to request a new key in the future

        'http://www.omdbapi.com/?t=1000%20ways%20to%20die&apikey=b98224e1

        UpdateAppCaption(Me, treDrives, "", "Starting OMDB API Update")

        UpdateFromOMDBAPI = False

        Sleep(1001)

        strHTML = objHTML.GetHTMLofURL("http://www.omdbapi.com/?t=" & strSeriesName & "&apikey=b98224e1")

        If strHTML Is Nothing Then

            If mblnAutoUpdating Then

                'PlaySound(My.Application.Info.DirectoryPath & "\Hit a problem.mp3")
                blnStop = True
            End If

            strHTML = "movie not found"
        End If

        If InStr(1, strHTML.ToLower, "movie not found") > 0 Then

            If mblnAutoUpdating Then

                'PlaySound(My.Application.Info.DirectoryPath & "\Hit a problem.mp3")
                blnStop = True
            End If

            If MessageBox.Show("Unable to find " & strSeriesName & " in the OMDB API database! Go to IMDB?", My.Application.Info.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) = Windows.Forms.DialogResult.Yes Then

                Dim p As New Process

                ' Redirect the output stream of the child process.

                If My.Computer.Name = HOME_PC Then

                    p.StartInfo.FileName = "C:\Program Files\Mozilla Firefox\Firefox.exe"
                Else

                    p.StartInfo.FileName = "C:\Program Files (x86)\Mozilla Firefox\Firefox.exe"
                End If

                p.StartInfo.Arguments = "http://www.imdb.com/find?ref_=nv_sr_fn&q=" & strSeriesName.Replace(" ", "+") & "&s=all"
                'p.StartInfo.UseShellExecute = False
                'p.StartInfo.CreateNoWindow = True
                'p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
                'p.StartInfo.RedirectStandardOutput = True

                p.Start()

            End If

            If blnStop = True Then

                mnuAutoUpdate_Click(Nothing, Nothing)
                Exit Function
            End If

            ' End If

            UpdateAppCaption(Me, treDrives)

            Exit Function

        ElseIf strHTML <> "" Then

            strTempElements = strHTML.Split(",")

            ReDim strElements(strTempElements.GetUpperBound(0))

            For intCount = 0 To strTempElements.GetUpperBound(0)

                If InStr(strTempElements(intCount), ":") > 0 Then

                    strTemp = strTempElements(intCount).Replace("""", "").Replace("{", "").Replace("Â", "")
                    strTemp = strTemp.Replace("–", "")

                    If strTemp.Length > 5 Then

                        If Mid(strTemp, 1, 6).ToLower = "title:" Then

                            txtAPITitle.Text = Mid(strTemp, 7)
                        End If
                    End If

                    strElements(intElementCount) = strTemp

                    intElementCount = intElementCount + 1
                Else

                    strElements(intElementCount - 1) = strElements(intElementCount - 1) & "," & strTempElements(intCount)
                End If
            Next

            Try

                strSQL = "insert into tblShows (title) values ('" & ParseTextForSQL(strSeriesName) & "')"

                comTypes = New OleDbCommand(strSQL, mobjOLEConn)

                drTypes = comTypes.ExecuteReader()

                CloseOLECommand(comTypes)
                CloseDataReader(drTypes)

            Catch ex As Exception

                If Mid(ex.Message, 1, 50) = "The changes you requested to the table were not su" Then

                    ' Do nothing
                Else

                    DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name, "strSQL - " * strSQL)
                End If
            End Try


            strSQL = "Update tblShows Set "

            strComma = ""

            For intCount = 0 To strElements.GetUpperBound(0)

                strTempArray = strElements(intCount).Split(":")

                strFieldname = ""

                Select Case strTempArray(0)

                    Case "Plot"

                        strTemp = ParseTextForSQL(strTempArray(1))

                        strTemp = Mid(strTemp, 1, Len(strTemp) - 1)

                        strFieldname = "imdbDescription = '" & strTemp & "'"

                    Case "imdbRating"

                        If strTempArray(1) = "N/A" Then

                            strTempArray(1) = "0"
                        End If

                        strFieldname = "imdbRating = '" & strTempArray(1) & "'"

                    Case "imdbID"

                        strFieldname = "imdbID = '" & strTempArray(1) & "'"

                    Case "imdbVotes"

                        If strTempArray(1) = "N/A" Then

                            strTempArray(1) = "0"
                        End If

                        strTempArray(1) = strTempArray(1).Replace(",", "")
                        strTempArray(1) = strTempArray(1).Replace("""", "")

                        strFieldname = "imdbVotes = '" & strTempArray(1) & "'"

                    Case "Year"

                        If Len(strTempArray(1)) = 4 Then

                            strFieldname = "imdbStartYear = '" & strTempArray(1) & "'"

                        ElseIf Len(strTempArray(1)) = 8 Then

                            strFieldname = "imdbStartYear = '" & Mid(strTempArray(1), 1, 4) & "',"

                            strFieldname = strFieldname & "imdbEndYear = '" & Mid(strTempArray(1), 5) & "'"
                        End If


                    Case "Genre"

                        strFieldname = "Genre = '" & strTempArray(1).Replace("""", "") & "'"

                End Select

                If strFieldname <> "" Then

                    strSQL = strSQL & strComma & strFieldname

                    If strComma = "" Then

                        strComma = ","
                    End If

                    If strTempArray(0) = "imdbID" Then

                        strID = strTempArray(1)

                        ' Last one
                        Exit For
                    End If
                End If

            Next

            strSQL = strSQL & ", imdbDateOfLastUpdate_API = '" & Format(Now, "dd MMM yyyy") & "', Drive = '" & strDrive & "', API_Title = '" & ParseTextForSQL(strSeriesName) & "' Where Title = '" & ParseTextForSQL(strSeriesName) & "'"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)
        End If

        UpdateFromOMDBAPI = True

        UpdateAppCaption(Me, treDrives, "", "Finishing OMDB API Update")

    End Function

    Private Function RemoveTextFrom1StNonNumericAtPosition(ByVal strText As String, ByVal intStart As Integer) As String

        Dim intPos As Integer, strChar As String

        For intPos = intStart To strText.Length

            strChar = Mid(strText, intPos, 1)

            If Not IsNumeric(strChar) Then

                RemoveTextFrom1StNonNumericAtPosition = Mid(strText, 1, intPos - 1)
                Exit Function
            End If
        Next

        RemoveTextFrom1StNonNumericAtPosition = strText

    End Function

    Private Sub UpdateDetailsFromIMDB(ByVal strID As String, strSeriesName As String, ByVal blnRefresh As Boolean)

        Dim strDrive As String, blnContinue As Boolean, blnUpdateSuccess As Boolean, strUpdateException As String
        Dim blnStopProcess As Boolean

        blnUpdateSuccess = False

        Try

            strDrive = ""

            If strID = "" And strSeriesName = "" Then Exit Sub

            If strID = "" Then

                blnContinue = UpdateFromOMDBAPI(strID, strSeriesName, strDrive, blnUpdateSuccess, strUpdateException)
            Else

                blnContinue = True
            End If

            If strID <> "" And blnContinue Then UpdateFromIMDB(Me, treDrives, strID, strSeriesName, strDrive, , blnStopProcess, mblnAutoUpdating)

            If blnStopProcess Then

                Exit Sub
            End If

            If blnRefresh Then LoadSeriesDetails(strSeriesName, True, treDrives.SelectedNode.FullPath)

            If optImdb.Checked = True Then

                If blnRefresh Then LoadIMDBFiles(treDrives.SelectedNode.FullPath)
            Else

            End If

            UpdateAppCaption(Me, treDrives)

        Catch ex As Exception

            If Not mblnAutoUpdating Then MessageBox.Show(ex.Message)

            blnUpdateSuccess = False

        End Try

        If Not blnUpdateSuccess Then

            SetUpdateSuccess(blnUpdateSuccess, strUpdateException)

        End If

    End Sub

    Private Sub SetUpdateSuccess(ByVal blnUpdateSuccess As Boolean, ByVal strUpdateException As String)

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand

        If txtID.Text.Trim = "" Then Exit Sub

        Try

            If optImdb.Checked = True Then

                If blnUpdateSuccess = False Then

                    strSQL = "Update tblShows set imdbUpdateError = '" & strUpdateException & "' where imdbID = '" & txtID.Text & "'"

                Else

                    strSQL = "Update tblShows set imdbUpdateError = '' where imdbID = '" & txtID.Text & "'"
                End If

            Else


            End If

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub mnuMakeSeasonStandard_Click(sender As Object, e As EventArgs) Handles mnuMakeSeasonStandard.Click

        Dim strPath As String, strSeasonPath As String, strTemp As String
        Dim intEndPart As Integer, strNumber As String, strNew As String, strOtherPath As String
        Dim strDrive As String, strMessage As String

        If treDrives.SelectedNode Is Nothing Then Exit Sub
        If My.Computer.Name <> HOME_PC Then Exit Sub

        strPath = treDrives.SelectedNode.FullPath

        If Not IsDriveConnected(GetDriveAndMainFolder(strPath)) Then

            MessageBox.Show("Drive not connected!")
            Exit Sub
        End If

        ' Get other drive to update
        strDrive = GetOtherDrive(GetDriveAndMainFolder(strPath))

        If Not IsDriveConnected(strDrive) Then

            MessageBox.Show("Drive not connected!")
            Exit Sub
        End If

        If strDrive = "" Then

            AddError(System.Reflection.MethodBase.GetCurrentMethod().Name & " - " & "Can't find name of other drive!")
            Exit Sub
        End If

        strOtherPath = strDrive & "\" & RemoveDriveAndFolder(strPath)

        strSeasonPath = ReturnLevel4(strPath)

        strTemp = strSeasonPath.Replace("Season ", "")

        strSeasonPath = ReplaceTextNumerics(strSeasonPath)
        strTemp = strSeasonPath.Replace("Season ", "")

        If Len(strTemp) > 1 Then

            If Mid(strTemp, 1, 1) = "0" Then

                strTemp = Mid(strTemp, 2)
            End If
        End If

        strTemp = strTemp.Replace(" one", " 1")
        strTemp = strTemp.Replace(" two", " 2")
        strTemp = strTemp.Replace(" three", " 3")
        strTemp = strTemp.Replace(" four", " 4")
        strTemp = strTemp.Replace(" five", " 5")
        strTemp = strTemp.Replace(" six", " 6")
        strTemp = strTemp.Replace(" seven", " 7")
        strTemp = strTemp.Replace(" eight", " 8")
        strTemp = strTemp.Replace(" nine", " 9")

        If IsNumeric(strTemp) Then

            strNumber = strTemp
        Else

            intEndPart = InStrRev(strTemp, " ")

            If intEndPart > 0 Then

                strNumber = Mid(strTemp, intEndPart + 1)
            Else

                strNumber = strTemp.ToLower.Replace("season", "")

            End If
        End If

        If strNumber = "" Or Not IsNumeric(strNumber) Then

            strNumber = InputBox("Enter season number - can't find it automatically", My.Application.Info.ProductName)

        Else

            strNumber = InputBox("Is this the correct season number?", My.Application.Info.ProductName, strNumber)
        End If

        If strNumber.Trim = "" Then Exit Sub

        strNew = "Season " & strNumber

        strMessage = "Change " & vbCrLf & vbCrLf & strPath & " to " & vbCrLf & vbCrLf & RemoveOneLevel(strPath) & strNew & vbCrLf & vbCrLf &
                           "and" & vbCrLf & vbCrLf & strOtherPath & " to " & vbCrLf & vbCrLf & strDrive & "\" & RemoveDriveAndFolder(RemoveOneLevel(strPath)) & strNew

        If frmMyMessageBox.ShowQuestion(strMessage, My.Application.Info.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

            ' First one
            Try

                My.Computer.FileSystem.RenameDirectory(strPath, strNew)

            Catch ex As Exception

                MessageBox.Show(ex.Message)
                AddError(System.Reflection.MethodBase.GetCurrentMethod().Name & " - " & ex.Message)

                Exit Sub
            End Try


            ' Second One
            Try

                My.Computer.FileSystem.RenameDirectory(strOtherPath, strNew)

            Catch ex As Exception

                MessageBox.Show(ex.Message)
                AddError(System.Reflection.MethodBase.GetCurrentMethod().Name & " - " & ex.Message)

                Exit Sub
            End Try
        End If

    End Sub

    Private Function GetOtherDrive(ByVal strPath As String) As String

        Dim strSQL As String, drTypes As OleDbDataReader, comTypes As OleDbCommand
        Dim strTempPath As String

        strTempPath = Mid(strPath, InStr(1, strPath, "\") + 1)

        strTempPath = strTempPath.Replace("\", "")

        If strPath = "D:\TV\" Then

            GetOtherDrive = "V:\TV Backup\"
            Exit Function
        End If

        strSQL = "Select drivename from tblDrives where drivename like '%" & strTempPath & "%' and drivename <> '" & Mid(strPath, 1, Len(strPath) - 1) & "'"

        comTypes = New OleDbCommand(strSQL, mobjOLEConn)

        drTypes = comTypes.ExecuteReader()

        If drTypes.HasRows Then

            drTypes.Read()

            GetOtherDrive = Trim(drTypes("Drivename") & "")
        End If

        CloseOLECommand(comTypes)
        CloseDataReader(drTypes)

    End Function

    Private Function GetOtherDriveFromBackup(ByVal strPath As String) As String

        Dim strSQL As String, drTypes As OleDbDataReader, comTypes As OleDbCommand
        Dim strTempPath As String

        strTempPath = Mid(strPath, InStr(1, strPath, "\") + 1)

        strTempPath = strTempPath.Replace("\", "")

        strSQL = "Select drivename from tblDrives where drivename like '%" & strTempPath.Replace(" Backup", "") & "%' and drivename <> '" & Mid(strTempPath, 1, Len(strTempPath) - 1) & "'"

        comTypes = New OleDbCommand(strSQL, mobjOLEConn)

        drTypes = comTypes.ExecuteReader()

        If drTypes.HasRows Then

            drTypes.Read()

            GetOtherDriveFromBackup = Trim(drTypes("Drivename") & "")
        End If

        CloseOLECommand(comTypes)
        CloseDataReader(drTypes)

    End Function

    Private Sub lstOperations_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstOperations.SelectedIndexChanged

        txtUpdFilenamesHelp.Text = ""
        txtCurrentFilename.ReadOnly = True

        Select Case lstOperations.SelectedItems(0).ToString

            Case OPERATION_SORT_OUT_3_DIGIT_SEASONS_AT_END

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes Allo Allo 410.avi to Allo Allo S04E10.avi" & vbCrLf & vbCrLf & "Run Gen. Cleanup so season indicator is last text on the right - Doesn't work otherwise" & vbCrLf & vbCrLf & "Use Change 1st numeric to season format"

            Case OPERATION_CHANGE_NUMERIC_TO_3_DIGIT_SEASON

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes " & vbCrLf & vbCrLf & "Allo Allo 410 - Episode Name.avi to " & vbCrLf & vbCrLf & "Allo Allo S04E10 - Episode Name.avi" & vbCrLf & vbCrLf & "Looks for 1st 3 digit number."

            Case OPERATION_GEN_CLEANUP_AND_REMOVE_TEXT_AFTER_HDTV

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtCurrentFilename.ReadOnly = True
                txtCurrentFilename.Refresh()

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Runs General Cleanup and then Remove Test After HDTV etc."

            Case OPERATION_INDIVIDUAL_EDIT

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Allows you to manually update a single filename to take care of oddball ones"

                txtCurrentFilename.ReadOnly = False
                txtCurrentFilename.Refresh()

            Case OPERATION_GENERAL_CLEANUP, OPERATION_APPLY_PROPERISE_CASE, OPERATION_REMOVE_BRACKETS

                txtUpdFilenamesHelp.Visible = False

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

            Case OPERATION_TEXT_REPLACEMENT_HDTV

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Removal of fixed strings like " & vbCrLf & vbCrLf & "FiNAL.FASTSUB.VOSTFR.HDTV.XviD -F4ST" _
                                         & vbCrLf & "KVCD.by.TinPusher(TUS.Release)" _
                                         & vbCrLf & "WS.PDTV.XviD -RAWNiTRO" _
                                         & vbCrLf & "iNTERNAL.DVDRip.XviD -RAWNiTRO"

            Case OPERATION_TEXT_REPLACEMENT

                lblOperationLabel1.Text = "Replace"
                lblOperationLabel2.Text = "With"

                lblOperationLabel1.Visible = True
                lblOperationLabel2.Visible = True

                txtOperationTextbox1.Visible = True
                txtOperationTextbox2.Visible = True

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Straight forward replacement of 'abc' with 'xyz'"

            Case OPERATION_REMOVE_TEXT_AFTER_CUSTOM_TEXT

                lblOperationLabel1.Text = "Text"

                lblOperationLabel1.Visible = True

                txtOperationTextbox1.Visible = True

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Find 1st instance of user defined text and remove it and all text after"

            Case OPERATION_REMOVE_CURRENT_TITLES

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "1000 Ways To Die S01E03 wrong title.mp4 " & vbCrLf & vbCrLf & " becomes " & vbCrLf & vbCrLf & " 1000 Ways To Die S01E03.mp4" _
                                         & vbCrLf & vbCrLf & " ready for the correct title to be applied using 'Apply Titles'"


            Case OPERATION_APPLY_TITLES

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Apply episode titles from Seasons tab." & vbCrLf & vbCrLf & "May need to run Remove Current Titles first."

            Case OPERATION_REMOVE_TEXT_AFTER_HDTV

                lblOperationLabel1.Visible = False
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = False
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Finds text like HDTV in 1000 Ways To Die S01E03 HDTV 480p XVid.api and changes name to 1000 Ways To Die S01E03.api. " & vbCrLf & vbCrLf & "Assumes general cleanup has been run to get rid of any '.'"

            Case OPERATION_ADD_TEXT_TO_START

                lblOperationLabel1.Text = "Text to add to start"

                lblOperationLabel1.Visible = True
                lblOperationLabel2.Visible = False

                txtOperationTextbox1.Visible = True
                txtOperationTextbox2.Visible = False

                txtUpdFilenamesHelp.Visible = True
                txtUpdFilenamesHelp.Text = "Changes " & vbCrLf & vbCrLf & "101 - Name of Episode.avi " & vbCrLf & vbCrLf & " to say " & vbCrLf & vbCrLf & "Scrubs - 101 - Name of Episode.avi"


        End Select

    End Sub

    Private Sub cmdUpdateFilenames_Click(sender As Object, e As EventArgs) Handles cmdUpdFilesUpdateFilenamesInListview.Click

        Select Case lstOperations.SelectedItems(0).ToString

            Case OPERATION_SORT_OUT_3_DIGIT_SEASONS_AT_END

                Op_3_Digit_Seasons(lvwUpdatefilenames)

            Case OPERATION_CHANGE_NUMERIC_TO_3_DIGIT_SEASON

                Op_Change_Numeric_To_3_Digit_Season(lvwUpdatefilenames)

            Case OPERATION_REMOVE_TEXT_AFTER_CUSTOM_TEXT

                op_Remove_Text_After_Custom_Text(lvwUpdatefilenames, txtOperationTextbox1.Text)

            Case OPERATION_GEN_CLEANUP_AND_REMOVE_TEXT_AFTER_HDTV

                Op_GeneralCleanup(lvwUpdatefilenames)

                Op_RemoveTextAfterlist(lvwUpdatefilenames)

            Case OPERATION_INDIVIDUAL_EDIT

                Op_IndividualEdit(lvwUpdatefilenames, txtCurrentFilename)

            Case OPERATION_GENERAL_CLEANUP

                Op_GeneralCleanup(lvwUpdatefilenames)

            Case OPERATION_TEXT_REPLACEMENT

                If txtOperationTextbox1.Text = "" Then

                    MessageBox.Show("No from text!")
                    Exit Sub
                End If

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2)

                Op_MinorCleanup(lvwUpdatefilenames)

            Case OPERATION_TEXT_REPLACEMENT_HDTV

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "FiNAL.FASTSUB.VOSTFR.HDTV.XviD -F4ST")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "KVCD.by.TinPusher(TUS.Release)")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "WS.PDTV.XviD -RAWNiTRO")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "iNTERNAL.DVDRip.XviD -RAWNiTRO")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "FiNAL FASTSUB VOSTFR HDTV XviD -F4ST")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "KVCD by TinPusher(TUS Release)")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "WS PDTV XviD -RAWNiTRO")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "iNTERNAL DVDRip XviD -RAWNiTRO")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "PDTV.XviD.MP3.MVGroup.org")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "720p.HDTV.x264 -IMMERSE")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "PROPER.HDTV.XviD-2HD")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "PDTV XviD MP3 MVGroup org")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "720p HDTV x264 -IMMERSE")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "PROPER HDTV XviD-2HD")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "REPACK HDTV x264-KILLERS")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "REPACK.HDTV.XviD-AFG")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "REPACK HDTV XviD-AFG")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD-AFG", "")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD-AFG", "")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD AFG", "")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "hdtv x264-killers")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "480p HDTV x264-mSD")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV x264 - KILLERS")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "hdtv x264-mtg")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "Hdtv – Norite")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "480p HDTV x264-mSD")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "480p HDTV X264 – MSD")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "dvdrip.xvid -sfm")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "WEBRip XviD - FUM")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "WEBRip XVID-SaM[ettv]")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV x264 - DUKES")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV x264 - MiNDTHEGAP")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD -LOL.[VTV]")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD -REFiLL.[VTV]")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD -LOL [VTV]")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD -REFiLL [VTV]")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD-SPASTiKUS-")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD-SPASTiKUS-")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV x264 127MB-AureliA")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "[PLEASE SHARE]")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD -k3n")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD -FoV")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD -SYS")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD-2HD")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD -XII")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV.XviD -aAF")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "DVDrip.XviD -XEROS")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "hdtv.xvid -bia")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "hdtv.xvid -fum")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "WS.TVRip.x264 [mR12]")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "PDTV.x264.JIVE")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "Web -DL.x264.JIVE")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD -k3n")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD -FoV")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD -SYS")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD-2HD")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD -XII")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV XviD -aAF")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "DVDrip XviD -XEROS")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "hdtv xvid -bia")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "hdtv xvid -fum")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "WS TVRip x264 [mR12]")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "PDTV x264 JIVE")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "Web -DL x264 JIVE")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "dvdrip.xvid")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "dvdrip.xvid -nodlabs")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "dvdrip xvid")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "dvdrip xvid -nodlabs")

                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "HDTV x264 - FoV")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "[Norwegian-FunFun]")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "XviD AC3 MVGroup org")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "hdtv xvid - nosegment")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "[ettv]")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, Current)")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "REPACK")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "Sno")
                Op_TextReplacement(lvwUpdatefilenames, txtOperationTextbox1, txtOperationTextbox2, "Xvid")

                Op_MinorCleanup(lvwUpdatefilenames)

            Case OPERATION_REMOVE_TEXT_AFTER_HDTV

                Op_RemoveTextAfterlist(lvwUpdatefilenames)

            Case OPERATION_REMOVE_CURRENT_TITLES

                Op_RemoveCurrentTitles(lvwUpdatefilenames)

            Case OPERATION_APPLY_TITLES

                Op_ApplyTitles(lvwUpdatefilenames, optImdb.Checked, txtID.Text)

            Case OPERATION_APPLY_PROPERISE_CASE

                Op_ProperiseCase(lvwUpdatefilenames)

            Case OPERATION_REMOVE_BRACKETS

                Op_RemoveBrackets(lvwUpdatefilenames)

            Case OPERATION_ADD_TEXT_TO_START

                Op_AddTextToStart(lvwUpdatefilenames, txtOperationTextbox1.Text)

        End Select

        UpdateCurrentFilename()

        lvwUpdatefilenames.Focus()

    End Sub

    Private Sub cmdRevertToOriginalNames_Click(sender As Object, e As EventArgs) Handles cmdUpdFilesRevertToOriginalNames.Click

        Op_RestoreFilenames(lvwUpdatefilenames)

        UpdateUpdateFilenamesSelectionCount()

    End Sub

    Private Sub UpdateCurrentFilename()

        If lvwUpdatefilenames.SelectedItems.Count >= 1 Then

            txtCurrentFilename.Text = lvwUpdatefilenames.SelectedItems(0).SubItems(COL_UPDATEFILE_PROPOSEDNAME).Text
        Else

            If lvwUpdatefilenames.Items.Count >= 1 Then


                txtCurrentFilename.Text = lvwUpdatefilenames.Items(0).SubItems(COL_UPDATEFILE_PROPOSEDNAME).Text
            Else

                txtCurrentFilename.Text = ""
            End If
        End If

        UpdateUpdateFilenamesSelectionCount()

    End Sub

    Private Sub lvwUpdatefilenames_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvwUpdatefilenames.SelectedIndexChanged

        UpdateCurrentFilename()

    End Sub

    Private Sub RemoveSelectionsFromGrid(ByRef lvwListview As ListView)

        lvwListview.SelectedItems.Clear()

        UpdateUpdateFilenamesSelectionCount()

    End Sub

    Private Sub cmdRemoveSelectionsinGrid_Click(sender As Object, e As EventArgs) Handles cmdUpdFilesRemoveSelectionsinGrid.Click

        RemoveSelectionsFromGrid(lvwUpdatefilenames)

    End Sub

    Private Sub cmdRemoveItemFromGrid_Click(sender As Object, e As EventArgs) Handles cmdUpdFilesRemoveItemFromGrid.Click

        Try

            If lvwUpdatefilenames.SelectedItems.Count = 0 Then

                DisplayMessage("No selected items!")
            Else

                lvwUpdatefilenames.Items(lvwUpdatefilenames.SelectedItems(0).Index).Remove()
            End If

        Catch ex As Exception

        End Try

        UpdateUpdateFilenamesSelectionCount()

    End Sub

    Private Sub UpdateUpdateFilenamesSelectionCount()

        lvwUpdatefilenames.Columns(0).Text = "Name on Disk - " & lvwUpdatefilenames.SelectedItems.Count & " selected"

        If lvwUpdatefilenames.SelectedItems.Count = 0 Then txtCurrentFilename.Text = ""

    End Sub

    Private Sub cmdUpdFilesApplyProposedFilenames_Click(sender As Object, e As EventArgs) Handles cmdUpdFilesApplyProposedFilenames.Click

        Dim strPath As String, strSeasonPath As String, objItem As ListViewItem
        Dim colFiles() As FileInfo, objFile As FileInfo
        Dim strPathOther As String, strSeasonPathOther As String, strFolders As String
        Dim strFromFileName As String, strToFileName As String, strFiles As String
        Dim strFromFileNameBackup As String, strToFileNameBackup As String
        Dim blnWorked As Boolean, arrFiles() As String

        cmdUpdFilesApplyProposedFilenames.Enabled = False
        Me.Cursor = Cursors.WaitCursor

        strPath = treDrives.SelectedNode.FullPath
        strFolders = "\" & RemoveDriveAndFolder(strPath)

        If Not IsDriveConnected(GetDriveAndMainFolder(strPath)) Then

            MessageBox.Show("Drive not connected!" & strPath)
            Me.Cursor = Cursors.Default
            Exit Sub
        End If

        ' Get other drive to update
        strPathOther = GetOtherDrive(GetDriveAndMainFolder(strPath)) & strFolders

        If Not IsDriveConnected(strPathOther) Then

            MessageBox.Show("Drive not connected!" & strPathOther)
            Me.Cursor = Cursors.Default
            Exit Sub
        End If

        ' Check that proposed filenames are all unique
        strFiles = ""

        For Each objItem In lvwUpdatefilenames.Items

            strFiles = strFiles & objItem.SubItems(COL_UPDATEFILE_PROPOSEDNAME).Text & "*"
        Next

        arrFiles = Split(strFiles, "*")

        QuickSort(arrFiles, arrFiles.GetLowerBound(0), arrFiles.GetUpperBound(0))

        For intcount = arrFiles.GetLowerBound(0) To arrFiles.GetUpperBound(0) - 1

            If arrFiles(intcount) = arrFiles(intcount + 1) Then

                MsgBox("There are at least two files named " & vbCrLf & vbCrLf & arrFiles(intcount) & vbCrLf & vbCrLf & "No Files updated.")
                Exit Sub
            End If
        Next

        strPath = strPath & "\"
        strPathOther = strPathOther & "\"

        For Each objItem In lvwUpdatefilenames.Items

            blnWorked = False

            strFromFileName = objItem.SubItems(COL_UPDATEFILE_DISKFILENAME).Text
            strToFileName = objItem.SubItems(COL_UPDATEFILE_PROPOSEDNAME).Text

            If strFromFileName.ToLower <> strToFileName.ToLower Then

                strFromFileNameBackup = strFromFileName

                Try

                    DisplayMessage("Renaming - " & strFromFileName)

                    If strFromFileName.ToLower = strToFileName.ToLower Then

                        My.Computer.FileSystem.RenameFile(strPath & strFromFileName, strToFileName & "_")
                        My.Computer.FileSystem.RenameFile(strPath & strToFileName & "_", strToFileName)
                    Else

                        My.Computer.FileSystem.RenameFile(strPath & strFromFileName, strToFileName)
                    End If

                    blnWorked = True

                Catch exFile As FileNotFoundException

                    MessageBox.Show("File " & strFromFileName & " not found! Quiiting process")

                Catch ex As Exception

                    DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name & " - 1st File", "strFromFileName - " & strFromFileName)
                End Try

                ' Backup

                If blnWorked Then

                    Try

                        If strFromFileName.ToLower = strToFileName.ToLower Then

                            My.Computer.FileSystem.RenameFile(strPathOther & strFromFileNameBackup, strToFileName & "_")
                            My.Computer.FileSystem.RenameFile(strPathOther & strToFileName & "_", strToFileName)
                        Else

                            My.Computer.FileSystem.RenameFile(strPathOther & strFromFileNameBackup, strToFileName)
                        End If

                    Catch exFile As FileNotFoundException

                        MessageBox.Show("File " & strFromFileName & " was found and changed to " & strToFileName)

                    Catch ex As Exception

                        DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name & " - 2nd File", "strFromFileNameBackup - " & strFromFileNameBackup)
                    End Try

                End If
            End If
        Next

        strPath = treDrives.SelectedNode.FullPath
        LoadUpdateFilenamesFiles(strPath, True)
        LoadFiles(strPath, True)

        cmdUpdFilesApplyProposedFilenames.Enabled = True
        Me.Cursor = Cursors.Default

    End Sub

    Private Sub mnuFindNonStandardFiles_Click(sender As Object, e As EventArgs) Handles mnuFindNonStandardFiles.Click

        SetupScreenForNonStandardFiles()

        LoadNonStandardFiles()

    End Sub

    Private Sub DisableAll()

        EnableDisable_NonStandardFiles(False)
        EnableDisable_AiredShows(False)
        EnableDisable_ToDo(False)
        EnableDisable_omdbAPI(False)
        EnableDisable_MumsStuff(False)
        EnableDisable_RottenTomatoes(False)
        EnableDisable_MajorFolders(False)
        EnableDisable_DriveStatus(False)
        EnableDisable_PeopleAlsoLiked_All(False)
        EnableDisable_ShowList_Dups(False)
        EnableDisable_UpdateStatus_MissingItems(False)
        EnableDisable_KnownDups(False)
        EnableDisable_GeneralListview(False)
        EnableDisable_DriveSummary(False)
        EnableDisable_LastFilesAdded(False)
        EnableDisable_DriveFileSummary(False)

    End Sub

    Private Sub EnableDisable_omdbAPI(ByVal blnEnable As Boolean)

        mstrTypeUsingDriveControl = ""

        lvwOmdbAPI.Visible = blnEnable

        cmdFinished_OmdbAPI.Visible = blnEnable

        txtOmdbAPI_Desc.Visible = blnEnable
        cboOmdbCountries.Visible = blnEnable
        cboOmdbTitleLetter.Visible = blnEnable

        cmdomdbAPI_Back.Visible = blnEnable
        cmdomdbAPI_Forward.Visible = blnEnable

        cmdomdbAPI_IMDB.Visible = blnEnable
        txtomdbAPI_SeriesName.Visible = blnEnable

    End Sub

    Private Sub EnableDisable_LastFilesAdded(ByVal blnEnable As Boolean)

        mstrTypeUsingDriveControl = ""

        lvwSearchResults.Visible = blnEnable

        cmdFinished.Visible = blnEnable

        cboFileCount.Visible = blnEnable

    End Sub

    Private Sub EnableDisable_PeopleAlsoLiked_All(ByVal blnEnable As Boolean)

        mstrTypeUsingDriveControl = ""

        lvwPeopleLiked_All.Visible = blnEnable

        cmdFinishedPeopleLiked_All.Visible = blnEnable

    End Sub

    Private Sub EnableDisable_ShowList_Dups(ByVal blnEnable As Boolean)

        mstrTypeUsingDriveControl = ""

        lvwShowList_Dups.Visible = blnEnable

        cmdFinished_ShowList_Dups.Visible = blnEnable

        cmdShowList_Dups_TrollList.Visible = blnEnable

    End Sub

    Private Sub EnableDisable_DriveSummary(ByVal blnEnable As Boolean)

        mstrTypeUsingDriveControl = ""

        lvwListView.Visible = blnEnable
        cmdFinished_Listview.Visible = blnEnable

        cboDrives.Visible = blnEnable
        txtMultiLineTextbox.Visible = blnEnable

        txtDriveSummary_Desc.Visible = blnEnable

    End Sub

    Private Sub EnableDisable_DriveFileSummary(ByVal blnEnable As Boolean)

        mstrTypeUsingDriveControl = ""

        lvwListView.Visible = blnEnable
        cmdFinished_Listview.Visible = blnEnable

        lblDriveFileSummary_Info.Visible = blnEnable

        cboDrives.Visible = blnEnable

        txtDriveFileSummary_FullFilename.Visible = blnEnable
        cmdDriveFileSummary_FullFilename_Copy.Visible = blnEnable

        txtDriveFileSummary_FullFilenamewithoutETTV.Visible = blnEnable
        cmdDriveFileSummary_FullFilenamewithoutETTV_Copy.Visible = blnEnable

        txtDriveFileSummary_FilenameJustSeason.Visible = blnEnable
        cmdDriveFileSummary_FilenameJustSeason_Copy.Visible = blnEnable

        txtDriveFileSummary_Seriesname.Visible = blnEnable
        cmdDriveFileSummary_SeriesName_Copy.Visible = blnEnable

    End Sub

    Private Sub EnableDisable_GeneralListview(ByVal blnEnable As Boolean)

        mstrTypeUsingDriveControl = ""

        lvwListView.Visible = blnEnable
        cmdFinished_Listview.Visible = blnEnable

    End Sub

    Private Sub EnableDisable_KnownDups(ByVal blnEnable As Boolean)

        mstrTypeUsingDriveControl = ""

        lvwKnownDups.Visible = blnEnable
        cmdFinished_KnownDuplicates.Visible = blnEnable

    End Sub

    Private Sub EnableDisable_UpdateStatus_MissingItems(ByVal blnEnable As Boolean)

        mstrTypeUsingDriveControl = ""

        lvwUpdateStatus.Visible = blnEnable

        cmdFinished_UpdateStatus.Visible = blnEnable

        chkUpdateStatus_Missing.Visible = blnEnable
        chkUpdateStatus_IgnoreCompleted.Visible = blnEnable
        cmdUpdateStatusUpdateDetails.Visible = blnEnable
        cboDrives.Visible = blnEnable

        lblUpdateStatus_Report.Visible = blnEnable

    End Sub

    Private Sub EnableDisable_DriveStatus(ByVal blnEnable As Boolean)

        mstrTypeUsingDriveControl = ""

        lvwDriveStatus.Visible = blnEnable
        cmdFinished_DriveStatus.Visible = blnEnable

    End Sub

    Private Sub EnableDisable_MajorFolders(ByVal blnEnable As Boolean)

        mstrTypeUsingDriveControl = ""

        lvwMajorFolders.Visible = blnEnable
        cmdFinished_MajorFolders.Visible = blnEnable

    End Sub

    Private Sub EnableDisable_RottenTomatoes(ByVal blnEnable As Boolean)

        mstrTypeUsingDriveControl = ""

        lvwRottenTomatoes.Visible = blnEnable

        cmdFinished_RottenTomatoes.Visible = blnEnable

    End Sub

    Private Sub EnableDisable_MumsStuff(ByVal blnEnable As Boolean)

        mstrTypeUsingDriveControl = ""

        lvwMumsStuff.Visible = blnEnable

        cmdFinished_MumsStuff.Visible = blnEnable

    End Sub

    Private Sub EnableDisable_AiredShows(ByVal blnEnable As Boolean)

        mstrTypeUsingDriveControl = ""

        lvwAiredShows.Visible = blnEnable

        cmdFinished_AiredShows.Visible = blnEnable

        calCalendar_AirDates.Visible = blnEnable

        txtAiredItems_FullFilename.Visible = blnEnable
        cmdAiredItems_FullFilename_Copy.Visible = blnEnable

        txtAiredItems_FullFilenamewithoutETTV.Visible = blnEnable
        cmdAiredItems_FullFilenamewithoutETTV_Copy.Visible = blnEnable

        txtAiredItems_FilenameJustSeason.Visible = blnEnable
        cmdAiredItems_FilenameJustSeason_Copy.Visible = blnEnable

        txtAiredItems_Seriesname.Visible = blnEnable
        cmdAiredItems_SeriesName_Copy.Visible = blnEnable

        txtAiredItems_Title.Visible = blnEnable
        cmdAiredItems_Title_Copy.Visible = blnEnable
        lblAiredItems_ExplanationoftxtAiredItems_Title.Visible = blnEnable

        cmdAiredItems_Process.Visible = blnEnable

        prgProgress.Visible = blnEnable

    End Sub

    Private Sub EnableDisable_NonStandardFiles(ByVal blnEnable As Boolean)

        mstrTypeUsingDriveControl = ""

        lvwNonStandardFiles.Visible = blnEnable

        cmdFinished_NonStandardFiles.Visible = blnEnable

        chkNonStandard_DoBackup.Visible = blnEnable
        chkNonStandard_IgnoreSubtitle.Visible = blnEnable
        chkNonStandard_IgnoreTTCFiles.Visible = blnEnable

    End Sub

    Private Sub EnableDisable_ToDo(ByVal blnEnable As Boolean)

        mstrTypeUsingDriveControl = ""

        lvwToDo.Visible = blnEnable

        cmdFinished_ToDo.Visible = blnEnable

        cmdToDo_Add.Visible = blnEnable
        cmdToDo_Edit.Visible = blnEnable
        cmdToDo_Delete.Visible = blnEnable

    End Sub

    Private Sub SetupScreenForNonStandardFiles()

        tabFiles.Visible = False

        tabDetails.Visible = False
        fraDetails.Visible = False

        lvwFiles.Visible = False
        lvwSearchResults.Visible = False

        EnableDisable_AiredShows(False)
        EnableDisable_omdbAPI(False)
        EnableDisable_MumsStuff(False)
        EnableDisable_ToDo(False)
        EnableDisable_RottenTomatoes(False)
        EnableDisable_MajorFolders(False)
        EnableDisable_DriveSummary(False)
        EnableDisable_DriveStatus(False)
        EnableDisable_PeopleAlsoLiked_All(False)
        EnableDisable_ShowList_Dups(False)
        EnableDisable_UpdateStatus_MissingItems(False)
        EnableDisable_KnownDups(False)
        EnableDisable_GeneralListview(False)
        EnableDisable_LastFilesAdded(False)
        EnableDisable_DriveFileSummary(False)

        EnableDisable_NonStandardFiles(True)

        lvwNonStandardFiles.Items.Clear()

        With lvwNonStandardFiles

            .BringToFront()
            .Top = DEFAULT_TOP
            .Left = 5
            .Width = SplitContainer1.Panel2.Width - 15
            .Height = SplitContainer1.Panel2.Height - 53
        End With

        chkNonStandard_DoBackup.Top = lvwNonStandardFiles.Top + lvwNonStandardFiles.Height + 6
        chkNonStandard_DoBackup.Left = lvwNonStandardFiles.Left

        cmdFinished_NonStandardFiles.Left = cmdFinished.Left
        cmdFinished_NonStandardFiles.Top = cmdClose.Top

        chkNonStandard_IgnoreSubtitle.Top = chkNonStandard_DoBackup.Top
        chkNonStandard_IgnoreSubtitle.Left = chkNonStandard_DoBackup.Left + chkNonStandard_DoBackup.Width + 100

        chkNonStandard_IgnoreTTCFiles.Top = chkNonStandard_DoBackup.Top
        chkNonStandard_IgnoreTTCFiles.Left = chkNonStandard_IgnoreSubtitle.Left + chkNonStandard_IgnoreSubtitle.Width + 100

    End Sub

    Private Sub LoadNonStandardFiles()

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand
        Dim objItem As ListViewItem
        Dim strSubTitles As String, strTTCFiles As String

        lvwNonStandardFiles.Items.Clear()

        lvwNonStandardFiles.ListViewItemSorter = Nothing
        lvwNonStandardFiles.Sorting = SortOrder.None

        If chkNonStandard_IgnoreSubtitle.Checked = True Then

            strSubTitles = " and filetype not in ('.srt','.sub','.idx')"
        End If

        If chkNonStandard_IgnoreTTCFiles.Checked = True Then

            strTTCFiles = " and filetype not in ('.pdf','.mht')"
        End If

        Try

            If chkNonStandard_DoBackup.Checked = True Then

                strSQL = "SELECT * FROM tblDriveContents where (filetype <> '.avi' and filetype <> '.mp4' and filetype <> '.mkv') and drivename like '% Backup%'" & strSubTitles & strTTCFiles
            Else

                strSQL = "SELECT * FROM tblDriveContents where (filetype <> '.avi' and filetype <> '.mp4' and filetype <> '.mkv') and drivename not like '% Backup%'" & strSubTitles & strTTCFiles

            End If

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    If Trim(drTypes("Filename") & "") <> "" Then

                        objItem = lvwNonStandardFiles.Items.Add(Trim(drTypes("DriveName") & ""))

                        objItem.SubItems.Add(Trim(drTypes("FolderName") & ""))
                        objItem.SubItems.Add(Trim(drTypes("FileName") & ""))
                        objItem.SubItems.Add(Trim(drTypes("FileType") & ""))
                        objItem.SubItems.Add(SetBytes(Trim(drTypes("FileSize") & "")))
                        objItem.SubItems.Add(Trim(drTypes("ModifiedDate") & ""))

                    End If
                End While
            End If

            lvwNonStandardFiles.Sorting = SortOrder.Ascending

            lvwNonStandardFiles.Sort()

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

            chkNonStandard_DoBackup.Text = "Do Backups - " & lvwNonStandardFiles.Items.Count & " rows"

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub lvwFiles_ItemSelectionChanged(sender As Object, e As ListViewItemSelectionChangedEventArgs) Handles lvwFiles.ItemSelectionChanged

        UpdateListviewFiles(lvwFiles)

    End Sub

    Private Sub lvwListview_MouseClick(sender As Object, e As MouseEventArgs) Handles lvwFiles.MouseClick, lvwUpdatefilenames.MouseClick

        Dim p As New Point, C As Windows.Forms.Cursor

        C = Cursors.Default

        p = New Point(Windows.Forms.Cursor.Position.X, Windows.Forms.Cursor.Position.Y)

        If e.Button = Windows.Forms.MouseButtons.Right Then

            mnuListviewRightClick.Tag = sender.name
            mnuListviewRightClick.Show(p)

        End If
    End Sub

    Private Sub mnuDeleteFiles_Click(sender As Object, e As EventArgs) Handles mnuDeleteFiles.Click

        Dim intCount As Integer, strPath As String, lvwListView As ListView

        If mnuListviewRightClick.Tag = "lvwFiles" Then

            lvwListView = lvwFiles

        ElseIf mnuListviewRightClick.Tag = "lvwUpdatefilenames" Then

            lvwListView = lvwUpdatefilenames
        End If

        If lvwListView Is Nothing Then Exit Sub

        If lvwListView.SelectedItems.Count > 0 Then

            For intCount = 0 To lvwListView.SelectedItems.Count - 1

                strPath = treDrives.SelectedNode.FullPath & "\" & lvwListView.SelectedItems(intCount).SubItems(COL_UPDATEFILE_DISKFILENAME).Text

                Try

                    My.Computer.FileSystem.DeleteFile(strPath)

                Catch ex As Exception

                    AddError(System.Reflection.MethodBase.GetCurrentMethod().Name & " - " & ex.Message)
                End Try

            Next

        End If

        mnuListviewRightClick.Tag = ""

    End Sub

    Private Sub cmdIMDB_Click(sender As Object, e As EventArgs) Handles cmdIMDB.Click, cmdIMDB.DoubleClick

        If txtID.Text.Trim <> "" Then

            OpenWWW("http://www.imdb.com/title/" & txtID.Text & "/")

        Else

            If txtSeriesName.Text <> "" Then

                OpenWWW("http://www.imdb.com/find?ref_=nv_sr_fn&q=" & txtSeriesName.Text & "&s=all")
            End If

        End If

    End Sub

    Private Sub lvwIMDBFiles_Click(sender As Object, e As EventArgs) Handles lvwIMDBFiles.Click

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand, strSeason As String, strEpisode As String

        strSeason = ReturnLevel4(treDrives.SelectedNode.FullPath).Replace("Season ", "").Trim

        strEpisode = Mid(lvwIMDBFiles.SelectedItems(0).Text, 1, InStr(lvwIMDBFiles.SelectedItems(0).Text, " ") - 1).Trim

        If strSeason = "" Or strEpisode = "" Then

            txtPlot.Text = ""
            Exit Sub
        End If

        strSQL = "SELECT * FROM tblSeasons_Imdb where imdbID = '" & txtID.Text & "' and Season = " & strSeason & " and Episode = " & strEpisode

        Try

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    If Trim(drTypes("Description") & "") <> "" Then

                        txtPlot.Text = Trim(drTypes("Description") & "")
                    End If

                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            AddError(System.Reflection.MethodBase.GetCurrentMethod().Name & " - " & ex.Message)

        End Try

    End Sub

    Private Sub lvwIMDBFiles_KeyDown(sender As Object, e As KeyEventArgs) Handles lvwIMDBFiles.KeyDown

        lvwIMDBFiles_Click(sender, e)

    End Sub

    Private Sub lvwIMDBFiles_KeyUp(sender As Object, e As KeyEventArgs) Handles lvwIMDBFiles.KeyUp

        lvwIMDBFiles_Click(sender, e)

    End Sub

    Private Sub cmdFinishedNonStandardFiles_Click(sender As Object, e As EventArgs) Handles cmdFinished_NonStandardFiles.Click

        ReshowDefaultFormLayout()

    End Sub

    Private Sub chkDetailsinDoubt_Click(sender As Object, e As EventArgs) Handles chkDetailsinDoubt.Click

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand

        If txtID.Text.Trim = "" Then Exit Sub

        Try

            If optImdb.Checked = True Then

                If chkDetailsinDoubt.Checked = False Then

                    strSQL = "Update tblShows set DetailsInDoubt = 'N', CorrectVersion='' where imdbID = '" & txtID.Text & "'"

                    cboCorrectVersion.Text = ""
                Else

                    strSQL = "Update tblShows set DetailsInDoubt = 'Y' where imdbID = '" & txtID.Text & "'"
                End If


            Else


            End If

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub cboCorrectVersion_SelectedValueChanged(sender As Object, e As EventArgs) Handles cboCorrectVersion.SelectedValueChanged

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand

        If txtID.Text.Trim = "" Then Exit Sub

        Try

            If optImdb.Checked = True Then

                strSQL = "Update tblShows set CorrectVersion = '" & cboCorrectVersion.Text & "' where imdbID = '" & txtID.Text & "'"
            Else


            End If

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub lvwSeasons_Click(sender As Object, e As EventArgs) Handles lvwSeasons.Click

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand, strSeason As String, strEpisode As String

        If lvwSeasons.SelectedItems(0).Text = "" Then

            txtSeasonsTab_Plot.Text = ""
            Exit Sub
        End If

        strSeason = lvwSeasons.SelectedItems(0).Text

        strEpisode = lvwSeasons.SelectedItems(0).SubItems(1).Text

        If strSeason = "" Or strEpisode = "" Then

            txtSeasonsTab_Plot.Text = ""
            Exit Sub
        End If

        strSQL = "SELECT * FROM tblSeasons_Imdb where imdbID = '" & txtID.Text & "' and Season = " & strSeason & " and Episode = " & strEpisode

        Try

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    If Trim(drTypes("Description") & "") <> "" Then

                        txtSeasonsTab_Plot.Text = Trim(drTypes("Description") & "")
                    End If

                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            AddError(System.Reflection.MethodBase.GetCurrentMethod().Name & " - " & ex.Message)

        End Try

    End Sub

    Private Sub lvwSeasons_KeyDown(sender As Object, e As KeyEventArgs) Handles lvwSeasons.KeyDown

        lvwSeasons_Click(sender, e)

    End Sub

    Private Sub lvwSeasons_KeyUp(sender As Object, e As KeyEventArgs) Handles lvwSeasons.KeyUp

        lvwSeasons_Click(sender, e)

    End Sub

    Private Sub mnuAutoUpdate_Click(sender As Object, e As EventArgs) Handles mnuAutoUpdate.Click

        'If IsHomePC() Then

        '    MessageBox.Show("Best to allow HTTP in Peerblock when running Auto Update at home.")
        'End If

        mstrAutoUpdater_Drive = ""

        If mnuAutoUpdate.Text = AUTO_UPDATE_MENU Then

            If treDrives.SelectedNode.FullPath = "" Then

                Exit Sub
            End If

            mstrAutoUpdater_Drive = Mid(treDrives.SelectedNode.FullPath, 1, 3)

            treDrives.Refresh()
            My.Application.DoEvents()

            treDrives.Focus()

            mblnAutoUpdating = True

            If IsHomePC() Then

                tmrUpdateTimer.Interval = 4000
            Else

                tmrUpdateTimer.Interval = 20000
            End If

            tmrUpdateTimer.Enabled = True
            mnuAutoUpdate.Text = AUTO_UPDATE_STOP_MENU
        Else

            mblnAutoUpdating = False

            tmrUpdateTimer.Enabled = False
            mnuAutoUpdate.Text = AUTO_UPDATE_MENU
        End If

    End Sub

    Private Sub tmrUpdateTimer_Tick(sender As Object, e As EventArgs) Handles tmrUpdateTimer.Tick

        treDrives.SelectedNode = treDrives.SelectedNode.NextVisibleNode

        Dim objNewNode As New System.Windows.Forms.TreeNodeMouseClickEventArgs(treDrives.SelectedNode, MouseButtons.Left, 1, 1, 1)

        'SendKeys.Send("{DOWN}")

        If mstrAutoUpdater_Drive <> Mid(treDrives.SelectedNode.FullPath, 1, 3) Then

            UpdateLastAutoUpdateDate(treDrives.SelectedNode.FullPath)

            tmrUpdateTimer.Enabled = False

            mnuAutoUpdate_Click(Nothing, Nothing)
            Exit Sub
        End If

        tmrUpdateTimer.Enabled = False

        treDrives_NodeMouseClick(Nothing, objNewNode)

    End Sub

    Private Sub treDrives_AfterSelect(sender As Object, e As TreeViewEventArgs) Handles treDrives.AfterSelect

    End Sub

    Private Sub mnuExpandAll_Click(sender As Object, e As EventArgs) Handles mnuExpandAll.Click

        treDrives.SelectedNode.ExpandAll()

    End Sub

    Private Sub mnuFindCompletedFiles_Click(sender As Object, e As EventArgs) Handles mnuFindCompletedFiles.Click

        MessageBox.Show("Not done")

    End Sub

    Private Sub mnuFindCompletedFilesSeason_Click(sender As Object, e As EventArgs) Handles mnuFindCompletedFilesSeason.Click

        MessageBox.Show("Not Done")
    End Sub

    Private Sub mnuCollapseAll_Click(sender As Object, e As EventArgs) Handles mnuCollapseAll.Click

        treDrives.SelectedNode.Collapse()

    End Sub

    Private Sub mnuUpdateStatus_Click(sender As Object, e As EventArgs) Handles mnuUpdateStatus.Click

        SetupScreenForUpdateStatus()

        DisplayUpdateStatus(True)

    End Sub

    Private Sub SetupScreenForUpdateStatus()

        tabFiles.Visible = False

        lvwFiles.Visible = False

        tabDetails.Visible = False
        fraDetails.Visible = False

        lvwSearchResults.Visible = False

        EnableDisable_NonStandardFiles(False)
        EnableDisable_AiredShows(False)
        EnableDisable_omdbAPI(False)
        EnableDisable_MumsStuff(False)
        EnableDisable_ToDo(False)
        EnableDisable_RottenTomatoes(False)
        EnableDisable_MajorFolders(False)
        EnableDisable_DriveStatus(False)
        EnableDisable_DriveSummary(False)
        EnableDisable_PeopleAlsoLiked_All(False)
        EnableDisable_ShowList_Dups(False)
        EnableDisable_KnownDups(False)
        EnableDisable_GeneralListview(False)
        EnableDisable_LastFilesAdded(False)
        EnableDisable_DriveFileSummary(False)

        EnableDisable_UpdateStatus_MissingItems(True)

        cboDrives.Left = 5
        cboDrives.Top = 1

        chkUpdateStatus_Missing.Top = cboDrives.Top + 3
        chkUpdateStatus_Missing.Left = cboDrives.Left + cboDrives.Width + 3

        chkUpdateStatus_IgnoreCompleted.Top = chkUpdateStatus_Missing.Top
        chkUpdateStatus_IgnoreCompleted.Left = chkUpdateStatus_Missing.Left + chkUpdateStatus_Missing.Width + 3

        lblUpdateStatus_Report.Left = chkUpdateStatus_IgnoreCompleted.Left + chkUpdateStatus_IgnoreCompleted.Width + 10
        lblUpdateStatus_Report.Top = chkUpdateStatus_IgnoreCompleted.Top + 3

        lvwUpdateStatus.Items.Clear()

        lvwUpdateStatus.Left = 5
        lvwUpdateStatus.Top = cboDrives.Top + 25
        lvwUpdateStatus.Left = lvwFiles.Left
        lvwUpdateStatus.Width = lvwFiles.Width
        lvwUpdateStatus.Height = SplitContainer1.Panel2.Height - 74

        cmdFinished_UpdateStatus.Left = cmdFinished.Left
        cmdFinished_UpdateStatus.Top = cmdClose.Top

        cmdUpdateStatusUpdateDetails.Left = cmdFinished_UpdateStatus.Left - 100
        cmdUpdateStatusUpdateDetails.Top = cmdFinished_UpdateStatus.Top

    End Sub

    Private Sub LoadRottenTomatoes()

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand, comDriveContents As OleDbCommand, drDriveContents As OleDbDataReader
        Dim objItem As ListViewItem, strTitle As String

        Try

            lvwRottenTomatoes.Items.Clear()

            strSQL = "SELECT DISTINCT imdbRating, imdbVotes, Title, Drivename, imdbDescription, Country, Genre FROM tblShows, tblDriveContents WHERE (imdbRating > 0 and imdbRating < 6) and  tblShows.title = tblDriveContents.FoldernameWithoutPath and drivename not like '% Backup' ORDER BY imdbRating"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    strTitle = Trim(drTypes("DriveName") & "") & "\" & Trim(drTypes("Title") & "")

                    If strTitle <> "" Then

                        objItem = lvwRottenTomatoes.Items.Add(strTitle)

                        objItem.SubItems.Add(Trim(drTypes("imdbRating") & ""))
                        objItem.SubItems.Add(Trim(drTypes("imdbVotes") & ""))

                        objItem.SubItems.Add(Trim(drTypes("Country") & ""))
                        objItem.SubItems.Add(Trim(drTypes("Genre") & ""))

                        objItem.SubItems.Add(Trim(drTypes("imdbDescription") & ""))

                    End If

                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

        mobjColumn_RottenTomatoes = Nothing

        Dim objE As New ColumnClickEventArgs(1)

        lvwRottenTomatoes_ColumnClick(Nothing, objE)
        lvwRottenTomatoes_ColumnClick(Nothing, objE)

        If lvwRottenTomatoes.Items.Count > 0 Then lvwRottenTomatoes.Items(0).Selected = True

    End Sub

    Private Sub LoadKnownDuplicates()

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand
        Dim objItem As ListViewItem

        Try

            lvwKnownDups.Items.Clear()

            strSQL = "Select * from tblDups"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    If Trim(drTypes("DupID") & "") <> "" Then

                        objItem = lvwKnownDups.Items.Add(Trim(drTypes("DupID") & ""))

                        objItem.SubItems.Add(Trim(drTypes("Path") & ""))
                        objItem.SubItems.Add(Trim(drTypes("Notes") & ""))

                    End If

                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

            UpdateKnownDups()

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub LoadToDos()

        Dim strSQL As String, drTypes As OleDbDataReader, comTypes As OleDbCommand
        Dim objItem As ListViewItem

        Try

            lvwToDo.Items.Clear()

            strSQL = "Select * from tblToDo Order by DateEntered"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    objItem = lvwToDo.Items.Add(Trim(drTypes("Title").ToString & ""))

                    objItem.SubItems.Add(Trim(drTypes("Description").ToString & ""))

                    objItem.SubItems.Add(Trim(drTypes("SeqNo").ToString & ""))
                End While

            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

            lvwToDo.Sorting = SortOrder.Ascending
            lvwToDo.Sort()

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub DisplayUpdateStatus(ByVal blnNonTabVersion As Boolean, Optional strDrive As String = "")

        Dim strSQL_DriveContents As String, drTypes_DriveContents As OleDbDataReader, comTypes_DriveContents As OleDbCommand
        Dim strSQL_Shows As String, drTypes_Shows As OleDbDataReader, comTypes_Shows As OleDbCommand
        Dim objItem As ListViewItem, intDiff As Integer, strDifference As String
        Dim strCurrentDrive As String, blnMissing As Boolean
        Dim objDrive As ComboBox, objUpdateStatus As ListView
        Dim objUpdateStatus_Missing As CheckBox, objUpdateStatus_IgnoreCompleted As CheckBox
        Dim intTotalMissing As Integer

        mstrTypeUsingDriveControl = Update_Status

        If blnNonTabVersion Then

            objDrive = cboDrives
            objUpdateStatus = lvwUpdateStatus
            objUpdateStatus_Missing = chkUpdateStatus_Missing
            objUpdateStatus_IgnoreCompleted = chkUpdateStatus_IgnoreCompleted
        Else

            objDrive = cboDrives_Tab
            objUpdateStatus = lvwUpdateStatus_Tab
            objUpdateStatus_Missing = chkUpdateStatus_Missing_Tab
            objUpdateStatus_IgnoreCompleted = chkUpdateStatus_IgnoreCompleted_Tab
        End If

        If strDrive = "" Then

            If Not treDrives.SelectedNode Is Nothing Then

                strCurrentDrive = GetDriveAndMainFolder(treDrives.SelectedNode.FullPath)

                If InStr(strCurrentDrive, "Backup") > 0 Then

                    strCurrentDrive = GetOtherDriveFromBackup(strCurrentDrive)
                    strCurrentDrive = strCurrentDrive & "\"
                End If

                strCurrentDrive = Mid(strCurrentDrive, 1, Len(strCurrentDrive) - 1)

                If strCurrentDrive <> "" Then

                    objDrive.SelectedItem = strCurrentDrive
                End If
            End If
        End If

        ' change update - Update a new field in tblShows table when the update routine goes wrong 
        ' This flag on update status can be used to track them and get problems sorted

        Try

            objUpdateStatus.Items.Clear()

            strSQL_DriveContents = "Select Distinct FoldernameWithoutPath from tblDriveContents where Foldername like '" & objDrive.Text & "%' "

            comTypes_DriveContents = New OleDbCommand(strSQL_DriveContents, mobjOLEConn)

            drTypes_DriveContents = comTypes_DriveContents.ExecuteReader()

            If drTypes_DriveContents.HasRows Then

                While drTypes_DriveContents.Read()

                    strSQL_Shows = "Select * from tblShows where title = '" & ParseTextForSQL(Trim(drTypes_DriveContents("FoldernameWithoutPath") & "")) & "'"

                    comTypes_Shows = New OleDbCommand(strSQL_Shows, mobjOLEConn)

                    drTypes_Shows = comTypes_Shows.ExecuteReader()

                    If drTypes_Shows.HasRows Then

                        drTypes_Shows.Read()

                        If Trim(drTypes_Shows("Title") & "") <> "" Then

                            ' Work out difference details
                            strDifference = ""
                            blnMissing = False

                            If Trim(drTypes_Shows("imdb_AirDateTotal") & "") <> "" And Trim(drTypes_Shows("MyTotal") & "") <> "" Then

                                intDiff = CInt(Trim(drTypes_Shows("MyTotal")) & "") - drTypes_Shows("imdb_AirDateTotal") & ""

                                If intDiff <> 0 Then

                                    If intDiff < 0 Then

                                        strDifference = "Missing " & Math.Abs(intDiff)
                                        blnMissing = True
                                    Else

                                        strDifference = intDiff & " too many"
                                    End If
                                End If
                            End If

                            If (objUpdateStatus_Missing.Checked = True And blnMissing) Or objUpdateStatus_Missing.Checked = False Then

                                If (objUpdateStatus_IgnoreCompleted.Checked = True And Trim(drTypes_Shows("Complete") & "") <> "Y") Or
                                    objUpdateStatus_IgnoreCompleted.Checked = False Then

                                    objItem = objUpdateStatus.Items.Add(Trim(drTypes_Shows("Title") & ""))

                                    objItem.SubItems.Add(Trim(drTypes_Shows("imdbID") & ""))

                                    objItem.SubItems.Add(Trim(drTypes_Shows("MyTotal") & ""))

                                    objItem.SubItems.Add(Trim(drTypes_Shows("imdb_AirDateTotal") & ""))
                                    objItem.SubItems.Add(Trim(drTypes_Shows("imdb_TotalWithoutAirDate") & ""))

                                    objItem.SubItems.Add(strDifference)

                                    objItem.SubItems.Add(Trim(drTypes_Shows("imdbDateOfLastUpdate") & ""))

                                    objItem.SubItems.Add(Trim(drTypes_Shows("DetailsInDoubt") & ""))
                                    objItem.SubItems.Add(Trim(drTypes_Shows("CorrectVersion") & ""))

                                    objItem.SubItems.Add(Trim(drTypes_Shows("Finished") & ""))
                                    objItem.SubItems.Add(Trim(drTypes_Shows("Complete") & ""))

                                    objItem.SubItems.Add(Trim(drTypes_Shows("imdbUpdateError") & ""))

                                    If blnMissing Then intTotalMissing = intTotalMissing + Math.Abs(intDiff)
                                End If
                            End If
                        End If

                    Else

                        If objUpdateStatus_Missing.Checked = False Then

                            objItem = objUpdateStatus.Items.Add(ParseTextForSQL(Trim(drTypes_DriveContents("FoldernameWithoutPath") & "")))
                        End If

                    End If

                    CloseOLECommand(comTypes_Shows)
                    CloseDataReader(drTypes_Shows)
                End While

            End If

            objUpdateStatus.Sorting = SortOrder.Ascending
            objUpdateStatus.Sort()

            CloseOLECommand(comTypes_DriveContents)
            CloseDataReader(drTypes_DriveContents)

            If intTotalMissing > 0 Then

                lblUpdateStatus_Report.Text = "Total missing - " & intTotalMissing
            Else

                lblUpdateStatus_Report.Text = ""
            End If

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub cmdUpdateStatusFinished_Click(sender As System.Object, e As System.EventArgs) Handles cmdFinished_UpdateStatus.Click

        ReshowDefaultFormLayout()

    End Sub

    Private Sub mnuAiredItems_Click(sender As Object, e As EventArgs) Handles mnuAiredItems.Click

        ' Show list of show/episodes that have aired in period of month dropdown
        ' with shows totals if I can
        SetupScreenForAiredShows()

        UpdateAiredShows(Now)

    End Sub

    Private Sub cmdKAT_Click(sender As Object, e As EventArgs)

        If txtSeriesName.Text.Trim <> "" Then

            If optImdb.Checked Then

                OpenWWW(KAT_URL & txtSeriesName.Text.Replace(" ", "%2B"))
            Else

                OpenWWW("" & txtSeriesName.Text)
            End If

        End If

    End Sub

    Private Sub cboDrives_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDrives.SelectedIndexChanged

        If Not mblnFinishedLoading Then Exit Sub

        If mstrTypeUsingDriveControl = DRIVE_SUMMARY Then

            LoadDriveSummary()

        ElseIf mstrTypeUsingDriveControl = DRIVE_FILE_SUMMARY Then

            LoadDriveFileSummary()

        Else

            DisplayUpdateStatus(True, cboDrives.Text)
        End If


    End Sub

    Private Sub lvwPeopleLiked_DoubleClick(sender As Object, e As EventArgs) Handles lvwPeopleLiked.DoubleClick

        Dim strID As String, strTitle As String

        If lvwPeopleLiked.SelectedItems.Count <> 1 Then Exit Sub

        strTitle = lvwPeopleLiked.SelectedItems(0).Text

        If optImdb.Checked Then

            strID = GetIDofShowFromPeopleLiked(strTitle)

            OpenWWW("http://www.imdb.com/title/" & strID & "/")
        Else

            OpenWWW("" & strID)
        End If

    End Sub

    Private Function GetIDofShowFromPeopleLiked(ByVal strTitle As String) As String

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand

        GetIDofShowFromPeopleLiked = ""

        strSQL = "SELECT PickimdbID FROM tblImdb_Shows_People_Liked where PickTitle = '" & ParseTextForSQL(strTitle) & "'"

        Try

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    If Trim(drTypes("PickimdbID") & "") <> "" Then

                        GetIDofShowFromPeopleLiked = Trim(drTypes("PickimdbID") & "")
                    End If

                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            AddError(System.Reflection.MethodBase.GetCurrentMethod().Name & " - " & ex.Message)

        End Try

    End Function

    Private Sub mnuPeopleAlsoLiked_Click(sender As Object, e As EventArgs) Handles mnuPeopleAlsoLiked.Click

        SetupScreenForUpdatePeopleAlsoLiked_All()

        LoadPeopleLiked(True)

    End Sub

    Private Sub SetupScreenForAiredShows()

        Dim MyDate As Date = Now
        Dim intDaysInMonth As Integer = Date.DaysInMonth(MyDate.Year, MyDate.Month)

        tabFiles.Visible = False

        tabDetails.Visible = False
        fraDetails.Visible = False

        lvwFiles.Visible = False
        lvwSearchResults.Visible = False

        EnableDisable_ToDo(False)
        EnableDisable_NonStandardFiles(False)
        EnableDisable_omdbAPI(False)
        EnableDisable_MumsStuff(False)
        EnableDisable_RottenTomatoes(False)
        EnableDisable_MajorFolders(False)
        EnableDisable_DriveStatus(False)
        EnableDisable_PeopleAlsoLiked_All(False)
        EnableDisable_ShowList_Dups(False)
        EnableDisable_UpdateStatus_MissingItems(False)
        EnableDisable_KnownDups(False)
        EnableDisable_DriveSummary(False)
        EnableDisable_GeneralListview(False)
        EnableDisable_LastFilesAdded(False)
        EnableDisable_DriveFileSummary(False)

        EnableDisable_AiredShows(True)

        calCalendar_AirDates.Left = 5
        calCalendar_AirDates.Top = 1

        txtAiredItems_FullFilename.Top = calCalendar_AirDates.Top + 5
        txtAiredItems_FullFilename.Left = calCalendar_AirDates.Left + calCalendar_AirDates.Width + 15

        cmdAiredItems_FullFilename_Copy.Top = txtAiredItems_FullFilename.Top
        cmdAiredItems_FullFilename_Copy.Left = txtAiredItems_FullFilename.Left + txtAiredItems_FullFilename.Width + 5

        txtAiredItems_FullFilenamewithoutETTV.Top = txtAiredItems_FullFilename.Top + 25
        txtAiredItems_FullFilenamewithoutETTV.Left = txtAiredItems_FullFilename.Left

        cmdAiredItems_FullFilenamewithoutETTV_Copy.Top = txtAiredItems_FullFilenamewithoutETTV.Top
        cmdAiredItems_FullFilenamewithoutETTV_Copy.Left = txtAiredItems_FullFilenamewithoutETTV.Left + txtAiredItems_FullFilenamewithoutETTV.Width + 5

        txtAiredItems_FilenameJustSeason.Top = txtAiredItems_FullFilenamewithoutETTV.Top + 25
        txtAiredItems_FilenameJustSeason.Left = txtAiredItems_FullFilenamewithoutETTV.Left

        cmdAiredItems_FilenameJustSeason_Copy.Top = txtAiredItems_FilenameJustSeason.Top
        cmdAiredItems_FilenameJustSeason_Copy.Left = txtAiredItems_FilenameJustSeason.Left + txtAiredItems_FilenameJustSeason.Width + 5

        txtAiredItems_Seriesname.Top = txtAiredItems_FilenameJustSeason.Top + 25
        txtAiredItems_Seriesname.Left = txtAiredItems_FullFilename.Left

        cmdAiredItems_SeriesName_Copy.Top = txtAiredItems_Seriesname.Top
        cmdAiredItems_SeriesName_Copy.Left = txtAiredItems_Seriesname.Left + txtAiredItems_Seriesname.Width + 5

        txtAiredItems_Title.Top = txtAiredItems_Seriesname.Top + 25
        txtAiredItems_Title.Left = txtAiredItems_Seriesname.Left

        cmdAiredItems_Title_Copy.Top = txtAiredItems_Title.Top
        cmdAiredItems_Title_Copy.Left = txtAiredItems_Title.Left + txtAiredItems_Title.Width + 5

        lblAiredItems_ExplanationoftxtAiredItems_Title.Left = cmdAiredItems_Title_Copy.Left + cmdAiredItems_Title_Copy.Width + 5
        lblAiredItems_ExplanationoftxtAiredItems_Title.Top = cmdAiredItems_Title_Copy.Top + 3

        cmdAiredItems_Process.Top = cmdAiredItems_FullFilename_Copy.Top
        cmdAiredItems_Process.Left = cmdAiredItems_FullFilename_Copy.Left + cmdAiredItems_Process.Width + 15

        prgProgress.Left = txtAiredItems_FullFilename.Left
        prgProgress.Top = txtAiredItems_Title.Top + 25
        prgProgress.Width = txtAiredItems_Title.Width

        lvwAiredShows.Items.Clear()

        With lvwAiredShows

            .BringToFront()
            .Left = 5
            .Width = SplitContainer1.Panel2.Width - 15
            .Height = SplitContainer1.Panel2.Height - 220

            .Top = calCalendar_AirDates.Top + calCalendar_AirDates.Height + 5
        End With

        cmdFinished_AiredShows.Left = cmdFinished.Left
        cmdFinished_AiredShows.Top = cmdClose.Top

        My.Application.DoEvents()
        Me.Refresh()
        My.Application.DoEvents()

    End Sub

    Private Sub SetupScreenForKnownDuplicates()

        tabFiles.Visible = False

        tabDetails.Visible = False
        fraDetails.Visible = False

        lvwFiles.Visible = False
        lvwSearchResults.Visible = False

        EnableDisable_AiredShows(False)
        EnableDisable_NonStandardFiles(False)
        EnableDisable_omdbAPI(False)
        EnableDisable_ToDo(False)
        EnableDisable_MumsStuff(False)
        EnableDisable_RottenTomatoes(False)
        EnableDisable_MajorFolders(False)
        EnableDisable_DriveStatus(False)
        EnableDisable_PeopleAlsoLiked_All(False)
        EnableDisable_ShowList_Dups(False)
        EnableDisable_UpdateStatus_MissingItems(False)
        EnableDisable_DriveSummary(False)
        EnableDisable_GeneralListview(False)
        EnableDisable_DriveSummary(False)
        EnableDisable_LastFilesAdded(False)
        EnableDisable_DriveFileSummary(False)

        EnableDisable_KnownDups(True)

        lvwKnownDups.Items.Clear()

        With lvwKnownDups

            .BringToFront()
            .Top = DEFAULT_TOP
            .Left = 5
            .Width = SplitContainer1.Panel2.Width - 15
            .Height = SplitContainer1.Panel2.Height - DEFAULT_HEIGHT_REDUCATION
        End With

        cmdFinished_KnownDuplicates.Left = cmdFinished.Left
        cmdFinished_KnownDuplicates.Top = cmdClose.Top

    End Sub

    Private Sub UpdateAiredShows(ByVal datDate As Date)

        Dim strSQL As String, drTypes As OleDbDataReader, strShowDrive As String
        Dim comTypes As OleDbCommand, strStartDate As String, strEndDate As String, objItem As ListViewItem

        Dim MyDate As Date = datDate
        Dim intDaysInMonth As Integer = Date.DaysInMonth(MyDate.Year, MyDate.Month)
        Dim strlocation As String, intDays As Integer, intCount As Integer

        txtAiredItems_Title.Text = ""
        txtAiredItems_Title.Refresh()

        Me.Cursor = Cursors.WaitCursor

        txtAiredItems_FilenameJustSeason.Text = ""
        txtAiredItems_FullFilenamewithoutETTV.Text = ""
        txtAiredItems_Seriesname.Text = ""
        txtAiredItems_Title.Text = ""

        lvwAiredShows.Items.Clear()

        Me.Refresh()

        strStartDate = String.Concat(Mid(datDate.ToString, 4, 2), "/01/", Mid(datDate.ToString, 7, 4))
        strEndDate = String.Concat(Mid(datDate.ToString, 4, 2), "/", intDaysInMonth, "/", Mid(datDate.ToString, 7, 4))

        strSQL = "SELECT tblShows.Title as Show_Title, tblSeasons_Imdb.Season,tblSeasons_Imdb.Episode, tblSeasons_Imdb.Title as Episode_Title, AirDate, tblShows.imdbID FROM tblSeasons_Imdb, tblShows " _
               & "WHERE tblSeasons_Imdb.imdbID = tblShows.imdbID " _
               & " And (Airdate >= #" & strStartDate & "# And Airdate <= #" & strEndDate & "#) Order by tblShows.Title,AirDate, tblSeasons_Imdb.Episode"

        intCount = 0

        Try

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    intDays = DateDiff(DateInterval.Day, CDate(Trim(drTypes("AirDate").ToString & "")), Now)

                    If intDays > 0 Then

                        intCount = intCount + 1
                    End If
                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

        End Try

        prgProgress.Maximum = intCount
        prgProgress.Value = 0

        Try

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    intDays = DateDiff(DateInterval.Day, CDate(Trim(drTypes("AirDate").ToString & "")), Now)

                    If intDays > 0 Then

                        If Trim(drTypes("Show_Title") & "") <> "" Then

                            strShowDrive = GetDriveForTitle(Trim(drTypes("Show_Title") & ""))

                            objItem = lvwAiredShows.Items.Add(strShowDrive)

                            objItem.SubItems.Add(Trim(drTypes("Show_Title") & ""))
                            txtAiredItems_FullFilename.Text = Trim(drTypes("Show_Title") & "")
                            txtAiredItems_FullFilename.Refresh()

                            objItem.SubItems.Add(Trim(drTypes("Season") & ""))
                            objItem.SubItems.Add(Trim(drTypes("Episode") & ""))

                            objItem.SubItems.Add(Trim(drTypes("AirDate") & ""))

                            strlocation = FindEpisode(ParseTextForSQL(drTypes("Show_Title").trim), Trim(drTypes("Season") & ""), Trim(drTypes("Episode") & ""), drTypes("AirDate") & "")

                            objItem.SubItems.Add(strlocation)
                            objItem.SubItems.Add(Trim(drTypes("imdbID") & ""))

                            objItem.SubItems.Add(Trim(drTypes("Episode_Title") & ""))

                            prgProgress.Value = prgProgress.Value + 1
                            prgProgress.Refresh()

                        End If
                    End If
                End While

            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

            If lvwAiredShows.Items.Count > 0 Then

                lvwAiredShows.Items(0).Selected = True
            End If

        Catch ex As Exception

            AddError(System.Reflection.MethodBase.GetCurrentMethod().Name & " - " & ex.Message)

        End Try

        prgProgress.Value = 0
        prgProgress.Refresh()

        Me.Cursor = Cursors.Default

    End Sub

    Private Sub SetupScreenForUpdatePeopleAlsoLiked_All()

        tabFiles.Visible = False

        tabDetails.Visible = False
        fraDetails.Visible = False

        lvwFiles.Visible = False
        lvwSearchResults.Visible = False

        EnableDisable_ToDo(False)
        EnableDisable_AiredShows(False)
        EnableDisable_NonStandardFiles(False)
        EnableDisable_omdbAPI(False)
        EnableDisable_MumsStuff(False)
        EnableDisable_RottenTomatoes(False)
        EnableDisable_MajorFolders(False)
        EnableDisable_DriveStatus(False)
        EnableDisable_DriveSummary(False)
        EnableDisable_ShowList_Dups(False)
        EnableDisable_UpdateStatus_MissingItems(False)
        EnableDisable_KnownDups(False)
        EnableDisable_GeneralListview(False)
        EnableDisable_LastFilesAdded(False)
        EnableDisable_DriveFileSummary(False)

        EnableDisable_PeopleAlsoLiked_All(True)

        lvwPeopleLiked_All.Items.Clear()

        With lvwPeopleLiked_All

            .BringToFront()
            .Top = DEFAULT_TOP
            .Left = 5
            .Width = SplitContainer1.Panel2.Width - 15
            .Height = SplitContainer1.Panel2.Height - DEFAULT_HEIGHT_REDUCATION
        End With

        cmdFinishedPeopleLiked_All.Left = cmdFinished.Left
        cmdFinishedPeopleLiked_All.Top = cmdClose.Top

        cmdSaveID.Left = lvwPeopleLiked_All.Left
        cmdSaveID.Top = lvwPeopleLiked_All.Top + lvwPeopleLiked_All.Height + 10

    End Sub

    Private Sub cmdFinishedPeopleLiked_All_Click(sender As Object, e As EventArgs) Handles cmdFinishedPeopleLiked_All.Click

        ReshowDefaultFormLayout()

    End Sub

    Private Sub cmdUpdate_OMDB_Only_Click(sender As Object, e As EventArgs) Handles cmdUpdate_OMDB_Only.Click

        Dim strID As String, strSeriesName As String, strDrive As String, blnUpdateSuccess As Boolean, strUpdateException As String

        Application.DoEvents()
        cmdUpdateNow.Enabled = False
        cmdUpdate_OMDB_Only.Enabled = False
        Application.DoEvents()
        Me.Cursor = Cursors.WaitCursor
        Application.DoEvents()

        If optImdb.Checked = True Then

            If txtSeriesName.Text = "" Then Exit Sub

            strSeriesName = txtSeriesName.Text

            If UpdateFromOMDBAPI(strID, strSeriesName, strDrive, blnUpdateSuccess, strUpdateException) Then

                txtID.Text = strID

                LoadSeriesDetails(strSeriesName, True, treDrives.SelectedNode.FullPath, False)
            End If
        End If

        Application.DoEvents()
        cmdUpdateNow.Enabled = True
        cmdUpdate_OMDB_Only.Enabled = True
        Application.DoEvents()
        Me.Cursor = Cursors.Default
        Application.DoEvents()

        UpdateAppCaption(Me, treDrives)

        Application.DoEvents()

        treDrives.Focus()

    End Sub

    Private Sub txtID_TextChanged(sender As Object, e As EventArgs) Handles txtID.TextChanged

        Dim intPos As Integer

        If InStr(1, txtID.Text, "https://www.imdb.com/title/") > 0 Then

            txtID.Text = txtID.Text.Replace("https://www.imdb.com/title/", "")

            intPos = InStr(1, txtID.Text, "/?ref_=")

            If intPos > 0 Then

                txtID.Text = Mid(txtID.Text, 1, intPos - 1)
            End If
        End If

        If InStr(1, txtID.Text, "http://www.imdb.com/title/") > 0 Then

            txtID.Text = txtID.Text.Replace("http://www.imdb.com/title/", "")

            intPos = InStr(1, txtID.Text, "/?ref_=")

            If intPos > 0 Then

                txtID.Text = Mid(txtID.Text, 1, intPos - 1)
            End If
        End If

        If txtID.Text <> txtID.Text.Trim Then

            txtID.Text = txtID.Text.Trim
        End If

        If txtID.Text.Trim <> "" Then

            If Mid(txtID.Text, Len(txtID.Text), 1) = "/" Then

                txtID.Text = Mid(txtID.Text, 1, Len(txtID.Text) - 1)
            End If
        End If

        If txtID.Text.Trim <> "" Then

            If optImdb.Checked Then

                ToolTip1.SetToolTip(cmdIMDB, "http://www.imdb.com/title/" & txtID.Text & "/")
            Else

                ToolTip1.SetToolTip(cmdIMDB, "" & txtID.Text)
            End If
        Else

            ToolTip1.SetToolTip(cmdIMDB, "http://www.imdb.com")
        End If

    End Sub

    Private Sub cmdIMDB_Name_Click(sender As Object, e As EventArgs) Handles cmdIMDB_Name.Click

        Dim strSeriesName As String

        strSeriesName = txtSeriesName.Text

        strSeriesName = strSeriesName.Replace(" & ", " %26 ")

        If strSeriesName <> "" Then

            OpenWWW("http://www.imdb.com/find?ref_=nv_sr_fn&q=" & strSeriesName.Replace(" ", "+") & "&s=all")
        End If

    End Sub

    Private Sub txtSeriesName_TextChanged(sender As Object, e As EventArgs) Handles txtSeriesName.TextChanged

        If txtSeriesName.Text <> "" Then

            If optImdb.Checked Then

                ToolTip1.SetToolTip(cmdIMDB_Name, "http://www.imdb.com/find?ref_=nv_sr_fn&q=" & txtSeriesName.Text.Replace(" ", "+") & "&s=all")
            Else

                ToolTip1.SetToolTip(cmdIMDB_Name, "" & txtSeriesName.Text)
            End If

            txtURLWiki.Text = "https://en.wikipedia.org/wiki/" & txtSeriesName.Text.Replace(" ", "_")
        End If

    End Sub

    Private Sub cmdUpdateStatusUpdateDetails_Click(sender As Object, e As EventArgs) Handles cmdUpdateStatusUpdateDetails.Click

        Dim strID As String, strName As String

        cmdUpdateStatusUpdateDetails.Enabled = False
        cmdFinished_UpdateStatus.Enabled = False

        If optImdb.Checked = True Then

            strID = lvwUpdateStatus.SelectedItems(0).SubItems(COL_UPDATESTATUS_ID).Text
            strName = lvwUpdateStatus.SelectedItems(0).SubItems(COL_UPDATESTATUS_NAME).Text

            txtID.Text = strID
            txtSeriesName.Text = strName

            LoadSeriesDetails(txtSeriesName.Text, True, cboDrives.Text & "\" & strName)

            UpdateDetailsFromIMDB(strID, strName, False)
        End If

        Dim objNewNode As New System.Windows.Forms.TreeNodeMouseClickEventArgs(treDrives.SelectedNode, MouseButtons.Left, 1, 1, 1)

        treDrives_NodeMouseClick(Nothing, objNewNode)

        cmdUpdateStatusUpdateDetails.Enabled = True
        cmdFinished_UpdateStatus.Enabled = True

    End Sub

    Private Sub cmdFinishedAiredShows_Click(sender As Object, e As EventArgs) Handles cmdFinished_AiredShows.Click

        ReshowDefaultFormLayout()

    End Sub

    Private Sub lvwPeopleLiked_All_DoubleClick(sender As Object, e As EventArgs) Handles lvwPeopleLiked_All.DoubleClick

        If lvwPeopleLiked_All.SelectedItems.Count = 0 Then Exit Sub

        OpenWWW("http://www.imdb.com/title/" & lvwPeopleLiked_All.SelectedItems(0).SubItems(PEOPLE_COL_IMDBID).Text & "/")

    End Sub

    Private Sub ToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles mnuShowList_UsedforDups.Click

        SetupScreenForShowList_UsedforDups()

        UpdateShowList_UsedforDups()

    End Sub

    Private Sub SetupScreenForShowList_UsedforDups()

        tabFiles.Visible = False

        tabDetails.Visible = False
        fraDetails.Visible = False

        lvwFiles.Visible = False
        lvwSearchResults.Visible = False

        EnableDisable_ToDo(False)
        EnableDisable_NonStandardFiles(False)
        EnableDisable_AiredShows(False)
        EnableDisable_omdbAPI(False)
        EnableDisable_MumsStuff(False)
        EnableDisable_RottenTomatoes(False)
        EnableDisable_MajorFolders(False)
        EnableDisable_DriveStatus(False)
        EnableDisable_PeopleAlsoLiked_All(False)
        EnableDisable_DriveSummary(False)
        EnableDisable_UpdateStatus_MissingItems(False)
        EnableDisable_KnownDups(False)
        EnableDisable_GeneralListview(False)
        EnableDisable_LastFilesAdded(False)
        EnableDisable_DriveFileSummary(False)

        EnableDisable_ShowList_Dups(True)

        lvwShowList_Dups.Items.Clear()

        lvwShowList_Dups.BringToFront()
        lvwShowList_Dups.Top = DEFAULT_TOP
        lvwShowList_Dups.Left = 5
        lvwShowList_Dups.Width = SplitContainer1.Panel2.Width - 15
        lvwShowList_Dups.Height = SplitContainer1.Panel2.Height - DEFAULT_HEIGHT_REDUCATION

        cmdFinished_ShowList_Dups.Left = cmdFinished.Left
        cmdFinished_ShowList_Dups.Top = cmdClose.Top

        cmdShowList_Dups_TrollList.Top = cmdClose.Top
        cmdShowList_Dups_TrollList.Left = lvwShowList_Dups.Left

    End Sub

    Private Sub UpdateShowList_UsedforDups()

        Dim strSQL_Shows As String, drTypes_Shows As OleDbDataReader, comTypes_Shows As OleDbCommand
        Dim objItem As ListViewItem, strLastName As String, strPath As String, strLastPath As String
        Dim strLocation As String

        Try

            lvwShowList_Dups.Items.Clear()

            lvwShowList_Dups.ListViewItemSorter = Nothing
            lvwShowList_Dups.Sorting = SortOrder.None

            strSQL_Shows = "SELECT distinct title, foldername FROM tblDriveContents, tblShows WHERE foldernamewithoutpath = title and (foldername like '%\TV\%' or foldername like '%\TV %\%')and foldername not like '% Backup%' Order by title"

            comTypes_Shows = New OleDbCommand(strSQL_Shows, mobjOLEConn)

            drTypes_Shows = comTypes_Shows.ExecuteReader()

            If drTypes_Shows.HasRows Then

                While drTypes_Shows.Read()

                    strLocation = GetDriveAndMainFolder(Trim(drTypes_Shows("foldername") & ""))

                    If (strLastName <> Trim(drTypes_Shows("Title") & "")) Or (strLastPath <> strLocation) Then

                        objItem = lvwShowList_Dups.Items.Add(Trim(drTypes_Shows("Title") & ""))

                        strPath = strLocation

                        objItem.SubItems.Add(strPath)
                    End If

                    strLastName = Trim(drTypes_Shows("Title") & "")
                    strLastPath = strLocation

                End While
            End If

            CloseOLECommand(comTypes_Shows)
            CloseDataReader(drTypes_Shows)

            lvwShowList_Dups.Sorting = SortOrder.Ascending
            lvwShowList_Dups.Sort()

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub cmdFinished_ShowList_Dups_Click(sender As Object, e As EventArgs) Handles cmdFinished_ShowList_Dups.Click

        ReshowDefaultFormLayout()

    End Sub

    Private Sub cmdClearID_Click(sender As Object, e As EventArgs) Handles cmdClearID.Click

        Dim strSQL As String, drTypes As OleDbDataReader, comTypes As OleDbCommand

        strSQL = "Update tblShows Set imdbId = '', imdbStartYear = '', imdbEndYear ='', imdbDescription = '', imdbSeasonCount = 0, imdbDateOfLastUpdate = NULL, TV_Com_DateOfLastUpdate = NULL, imdbRating = 0, imdbVotes = 0, imdb_AirDateTotal = 0, imdb_TotalWithoutAirDate = 0, imdbDateOfLastUpdate_API = NULL, LastUpdateomdbAPI = NULL where Title = '" & ParseTextForSQL(txtSeriesName.Text) & "' "

        comTypes = New OleDbCommand(strSQL, mobjOLEConn)

        drTypes = comTypes.ExecuteReader()

        txtID.Text = ""

        CloseOLECommand(comTypes)
        CloseDataReader(drTypes)

    End Sub

    Private Sub mnuEmailMissingFiles_Click(sender As Object, e As EventArgs)

        Dim strProgram As String

        strProgram = treDrives.SelectedNode.FullPath

        SendGmail("MediaManager@gmail.com", "nigellthomas@gmail.com", "Media Manager - ", strProgram, True)

    End Sub

    Private Sub mnuRefreshDrives_Click(sender As Object, e As EventArgs) Handles mnuRefreshDrives.Click

        Dim intPreFileFolderCount As Long, intPostFileFolderCount As Long, intSize As Long
        Dim objDir As DirectoryInfo, strPath As String, dtmStart As Date, dtmEnd As Date
        Dim strTime As String, intPreFileCount As Long, intPostFileCount As Long
        Dim objStream As StreamReader, strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand, dtmModifiedDate As Date

        ' Refresh drives

        If IsHomePC() = False Then

            MessageBox.Show("Home PC Only!")
            Exit Sub
        End If

        frmDrive.LoadDrives(True, True)

        frmDrive.lblHelp.Text = "Goes through the TV folder and read 250 bytes from each file. This will 'refresh' them."

        If frmDrive.ShowDialog() = Windows.Forms.DialogResult.OK Then

            Try

                strPath = frmDrive.cboDrives.Text
                mstrPath = strPath

                dtmStart = Now
                dtmModifiedDate = Now

                objDir = New DirectoryInfo(strPath)

                GetFileFolderCountAndSizeinFolder(objDir, True, intPreFileFolderCount, intSize, True, intPreFileCount)

                frmProgressbar.ProgressBar1.Maximum = intPreFileCount
                frmProgressbar.TopMost = True
                frmProgressbar.Show()
                frmProgressbar.BringToFront()
                My.Application.DoEvents()

                ProcessFiles(strPath, dtmModifiedDate)

            Catch ex As Exception

                Dim blnDrive As Boolean

                blnDrive = IsDriveConnected(mstrPath)

                frmProgressbar.Close()
                frmProgressbar = Nothing

                DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name, "IsDriveConnected - blnDrive=" & blnDrive & vbCrLf & "strPath - " & strPath & vbCrLf & "mstrRefreshPathCurrentFile - " & mstrRefreshPathCurrentFile)
                End
            End Try

            dtmEnd = Now

            strTime = GetTimeDifferenceBetweenTwoDates(dtmEnd, dtmStart)

            If frmProgressbar.Stopped Then

                MessageBox.Show("Stopped after " & strTime & "!")
            Else

                MessageBox.Show("Refreshed successfully in " & strTime & "!")
            End If

            strSQL = "Update tblDrives set RefreshDate = '" & Format(Now, "dd MMM yyyy") & "' where DriveName = '" & strPath & "'"

            Try

                comTypes = New OleDbCommand(strSQL, mobjOLEConn)

                drTypes = comTypes.ExecuteReader()

                CloseOLECommand(comTypes)
                CloseDataReader(drTypes)

            Catch ex As Exception

                DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

            End Try

            strPath = GetOtherDrive(strPath & "\")

            MessageBox.Show("Now doing the backup drive - " & strPath, "Refresh Drives")

            Try

                intPreFileCount = 0
                intPreFileFolderCount = 0
                frmProgressbar.ProgressBar1.Value = 0
                intSize = 0

                mstrPath = strPath

                dtmStart = Now

                objDir = New DirectoryInfo(strPath)

                GetFileFolderCountAndSizeinFolder(objDir, True, intPreFileFolderCount, intSize, True, intPreFileCount)

                frmProgressbar.ProgressBar1.Maximum = intPreFileCount
                frmProgressbar.TopMost = True
                frmProgressbar.Show()
                frmProgressbar.BringToFront()
                My.Application.DoEvents()

                ProcessFiles(strPath, dtmModifiedDate)

            Catch ex As Exception

                Dim blnDrive As Boolean

                blnDrive = IsDriveConnected(mstrPath)

                frmProgressbar.Close()
                frmProgressbar = Nothing

                DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name, "IsDriveConnected - blnDrive=" & blnDrive & vbCrLf & "strPath - " & strPath & vbCrLf & "mstrRefreshPathCurrentFile - " & mstrRefreshPathCurrentFile)
                End
            End Try

            dtmEnd = Now

            strTime = GetTimeDifferenceBetweenTwoDates(dtmEnd, dtmStart)

            If frmProgressbar.Stopped Then

                MessageBox.Show("Stopped after " & strTime & "!")
            Else

                MessageBox.Show("Refreshed successfully in " & strTime & "!")
            End If

            If Mid(strPath, Len(strPath), 1) = "\" Then

                strPath = RemoveLastCharacter(strPath)
            End If

            strSQL = "Update tblDrives set RefreshDate = '" & Format(Now, "dd MMM yyyy") & "' where DriveName = '" & strPath & "'"

            Try

                comTypes = New OleDbCommand(strSQL, mobjOLEConn)

                drTypes = comTypes.ExecuteReader()

                CloseOLECommand(comTypes)
                CloseDataReader(drTypes)

            Catch ex As Exception

                DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

            End Try

        End If

        frmProgressbar.Close()
        frmProgressbar = Nothing

    End Sub

    Public Function ProcessFiles(ByVal strPath As String, ByVal dtmModifiedDate As Date) As Boolean

        Dim objDir As DirectoryInfo, intCount As Integer
        Dim objFile As FileInfo, colFiles() As FileInfo
        Dim buffer(251) As Char

        Try

            objDir = New DirectoryInfo(strPath)

            colFiles = objDir.GetFiles()

            For Each objFile In colFiles

                frmProgressbar.UpdateCaption("Processing " & objFile.FullName)

                frmProgressbar.ProgressBar1.Refresh()
                frmProgressbar.Refresh()

                My.Application.DoEvents()

                frmProgressbar.Show()
                frmProgressbar.BringToFront()
                My.Application.DoEvents()

                If frmProgressbar.Stopped Then

                    ProcessFiles = True
                    Exit Function
                End If

                RemoveReadonlyFromFile(objFile)
                SetFileToBeNormal_UsingFileInfo(objFile)

                My.Application.DoEvents()
                Sleep(10)

                SetModifiedDateofFile(objFile, dtmModifiedDate, False)

                My.Application.DoEvents()
                Sleep(10)

                SetFileToBeNormal_UsingFileInfo(objFile)

                If frmProgressbar.Stopped Then

                    ProcessFiles = True
                    Exit Function
                End If

                Dim objStreamR As New StreamReader(objFile.FullName)

                objStreamR.Read(buffer, 1, 250)

                objStreamR.Close()
                objStreamR = Nothing

                frmProgressbar.Increment()

            Next

            For Each objSubDir In objDir.GetDirectories

                ProcessFiles(objSubDir.FullName, dtmModifiedDate)
            Next

        Catch ex As Exception

            Dim blnDrive As Boolean

            blnDrive = IsDriveConnected(mstrPath)

            frmProgressbar.Close()
            frmProgressbar = Nothing

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name, "IsDriveConnected - blnDrive=" & blnDrive & vbCrLf & "strPath - " & strPath & vbCrLf & "mstrRefreshPathCurrentFile - " & mstrRefreshPathCurrentFile)
            End
        End Try

    End Function

    Private Function ProcessFile(ByRef strPath As String, ByVal strName As String)

        Try

            mstrRefreshPathCurrentFile = strPath & "_"

            If My.Computer.FileSystem.FileExists(strPath & "_") Then

                My.Computer.FileSystem.DeleteFile(strPath & "_")
            End If

            File.Copy(strPath, strPath & "_")

        Catch ex As Exception

            If Mid(ex.Message, 1, 10) = "The file '" And InStr(ex.Message, "' already exists.") > 0 Then

                DeleteFileUsingFSO(strPath & "_")
                File.Copy(strPath, strName & "_")
            Else

                Dim blnDrive As Boolean

                blnDrive = IsDriveConnected(mstrPath)

                frmProgressbar.Close()
                frmProgressbar = Nothing

                DeleteFileUsingFSO(strPath & "_")

                DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name, "Copy - IsDriveConnected - blnDrive=" & blnDrive & vbCrLf & "strPath - " & strPath & vbCrLf & "mstrRefreshPathCurrentFile - " & mstrRefreshPathCurrentFile)
                End
            End If
        End Try

        Try

            DeleteFileUsingFSO(strPath)

            File.Move(strPath & "_", strPath)

            mstrRefreshPathCurrentFile = ""

        Catch ex As Exception

            Dim blnDrive As Boolean

            blnDrive = IsDriveConnected(mstrPath)

            frmProgressbar.Close()
            frmProgressbar = Nothing

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name, "Delete and Move - IsDriveConnected - blnDrive=" & blnDrive & vbCrLf & "strPath - " & strPath & vbCrLf & "mstrRefreshPathCurrentFile - " & mstrRefreshPathCurrentFile)
            End
        End Try

    End Function

    Private Sub mnuDup_Email_Click(sender As Object, e As EventArgs) Handles mnuDup_Email.Click

        Dim strEmail As String, objItem As ListViewItem, strPath As String

        strPath = treDrives.SelectedNode.FullPath

        strEmail = "Found following duplicate" & vbCrLf & vbCrLf

        If lvwFiles.SelectedItems.Count > 1 And tabFiles.SelectedTab.Text.Trim = "Files on Disc" Then

            For Each objItem In lvwFiles.SelectedItems

                strEmail = strEmail & strPath & "\" & objItem.Text & vbCrLf
            Next

            Dim objEmail As New frmEmail

            objEmail.SetEmailText(strEmail)

            objEmail.ShowDialog()

            strEmail = objEmail.EmailText

            objEmail.Close()
            objEmail = Nothing

            SendGmail("MediaManager@gmail.com", "nigellthomas@gmail.com", "Media Manager - Duplicate", strEmail, True)

        ElseIf lvwUpdatefilenames.SelectedItems.Count > 1 And tabFiles.SelectedTab.Text.Trim = "Update Filenames" Then

            For Each objItem In lvwUpdatefilenames.SelectedItems

                strEmail = strEmail & strPath & "\" & objItem.Text & vbCrLf
            Next

            Dim objEmail As New frmEmail

            objEmail.SetEmailText(strEmail)

            objEmail.ShowDialog()

            strEmail = objEmail.EmailText

            objEmail.Close()
            objEmail = Nothing

            SendGmail("MediaManager@gmail.com", "nigellthomas@gmail.com", "Media Manager - Duplicate", strEmail, True)
        End If

    End Sub

    Private Sub mnuDup_Record_Click(sender As Object, e As EventArgs) Handles mnuDup_Record.Click

        Dim objItem As ListViewItem, strPath As String, strSQL As String
        Dim drTypes As OleDbDataReader, comTypes As OleDbCommand, comInsert As OleDbCommand
        Dim intID As Integer, blnInsert As Boolean, strNotes As String

        strPath = treDrives.SelectedNode.FullPath

        strSQL = "select max(DupID) + 1 as Max_Dup from tblDups"

        comTypes = New OleDbCommand(strSQL, mobjOLEConn)

        drTypes = comTypes.ExecuteReader()

        If drTypes.HasRows Then

            drTypes.Read()

            If Trim(drTypes("Max_Dup") & "") <> "" Then

                intID = Trim(drTypes("Max_Dup") & "")
            Else

                intID = 1
            End If
        Else

            Exit Sub
        End If

        strNotes = InputBox("Enter Note if required", "Add Duplicate", "")

        blnInsert = False

        If lvwFiles.SelectedItems.Count > 1 And tabFiles.SelectedTab.Text.Trim = "Files on Disc" Then

            For Each objItem In lvwFiles.SelectedItems

                Try

                    strSQL = "Insert into tblDups (DupID, Path, Notes) values ("

                    strSQL = strSQL & intID & ", '" & ParseTextForSQL(strPath & "\" & objItem.Text)

                    strSQL = strSQL & "','" & ParseTextForSQL(strNotes) & "')"

                    comInsert = New OleDbCommand(strSQL, mobjOLEConn)

                    comInsert.ExecuteReader()

                    CloseOLECommand(comInsert)

                Catch ex As Exception

                    DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name, "strSQL - " & strSQL)

                End Try
            Next

        ElseIf lvwUpdatefilenames.SelectedItems.Count > 1 And tabFiles.SelectedTab.Text.Trim = "Update Filenames" Then

            For Each objItem In lvwUpdatefilenames.SelectedItems

                Try

                    strSQL = "Insert into tblDups (DupID, Path) values ("

                    strSQL = strSQL & intID & ", '" & ParseTextForSQL(strPath & "\" & objItem.Text)

                    strSQL = strSQL & "')"

                    comInsert = New OleDbCommand(strSQL, mobjOLEConn)

                    comInsert.ExecuteReader()

                    CloseOLECommand(comInsert)

                Catch ex As Exception

                    DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name, "strSQL - " & strSQL)

                End Try
            Next

        End If

        UpdateKnownDups()

    End Sub

    Private Sub mnuKnownDuplicates_Click(sender As Object, e As EventArgs) Handles mnuKnownDuplicates.Click

        ' Show list of known dups

        SetupScreenForKnownDuplicates()

        LoadKnownDuplicates()

    End Sub

    Private Sub cmdFinished_KnownDuplicates_Click(sender As Object, e As EventArgs) Handles cmdFinished_KnownDuplicates.Click

        ReshowDefaultFormLayout()

    End Sub

    Private Sub mnuomdbAPI_Click(sender As Object, e As EventArgs) Handles mnuomdbAPI.Click

        SetupScreenForomdbAPI()

        LoadomdbAPI(OMDBAPI_NumberToShow)

    End Sub

    Private Sub SetupScreenForomdbAPI()

        tabFiles.Visible = False

        tabDetails.Visible = False
        fraDetails.Visible = False

        lvwFiles.Visible = False
        lvwSearchResults.Visible = False

        EnableDisable_NonStandardFiles(False)
        EnableDisable_ToDo(False)
        EnableDisable_AiredShows(False)
        EnableDisable_MumsStuff(False)
        EnableDisable_RottenTomatoes(False)
        EnableDisable_MajorFolders(False)
        EnableDisable_DriveStatus(False)
        EnableDisable_PeopleAlsoLiked_All(False)
        EnableDisable_ShowList_Dups(False)
        EnableDisable_DriveSummary(False)
        EnableDisable_UpdateStatus_MissingItems(False)
        EnableDisable_KnownDups(False)
        EnableDisable_GeneralListview(False)
        EnableDisable_LastFilesAdded(False)
        EnableDisable_DriveFileSummary(False)

        EnableDisable_omdbAPI(True)

        lvwOmdbAPI.Items.Clear()

        With lvwOmdbAPI

            .BringToFront()
            .Top = DEFAULT_TOP
            .Left = 5
            .Width = SplitContainer1.Panel2.Width - 15
            .Height = SplitContainer1.Panel2.Height - 100
        End With

        txtOmdbAPI_Desc.Top = lvwOmdbAPI.Top + lvwOmdbAPI.Height + 12
        txtOmdbAPI_Desc.Left = lvwOmdbAPI.Left

        cboOmdbCountries.Left = txtOmdbAPI_Desc.Left + txtOmdbAPI_Desc.Width + 8
        cboOmdbCountries.Top = txtOmdbAPI_Desc.Top

        cboOmdbTitleLetter.Left = cboOmdbCountries.Left
        cboOmdbTitleLetter.Top = cboOmdbCountries.Top + 25

        cmdFinished_OmdbAPI.Left = cmdFinished.Left
        cmdFinished_OmdbAPI.Top = cmdClose.Top

        cmdomdbAPI_Back.Top = cboOmdbCountries.Top
        cmdomdbAPI_Forward.Top = cmdomdbAPI_Back.Top

        cmdomdbAPI_Back.Left = cboOmdbCountries.Left + cboOmdbCountries.Width + 7
        cmdomdbAPI_Forward.Left = cmdomdbAPI_Back.Left + cmdomdbAPI_Back.Width + 5

        txtomdbAPI_SeriesName.Top = cboOmdbTitleLetter.Top + 25
        txtomdbAPI_SeriesName.Left = cboOmdbTitleLetter.Left

        cmdomdbAPI_IMDB.Top = txtOmdbAPI_Desc.Top
        cmdomdbAPI_IMDB.Left = cmdomdbAPI_Forward.Left + cmdomdbAPI_Forward.Width + 7

    End Sub

    Private Sub LoadomdbAPI(ByVal intRowUpperLimit As Integer)

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand, comDriveContents As OleDbCommand, drDriveContents As OleDbDataReader
        Dim objItem As ListViewItem, strTitle As String, intRowCount As Integer
        Dim intRowLowerLimit As Integer, intRowPosition As Integer
        Dim intRowsAdded As Integer, strDrive As String

        If Not mblnFinishedLoading Then Exit Sub

        intRowCount = 0
        mintRowUpperLimit = intRowUpperLimit
        intRowLowerLimit = mintRowUpperLimit - OMDBAPI_NumberToShow

        Try

            lvwOmdbAPI.Items.Clear()

            strSQL = "Select Distinct Top " & mintRowUpperLimit & " tblShows.Title, Drivename, imdbRating, imdbVotes, Country, Genre, " _
                   & "imdbStartYear, imdbEndYear, imdbSeasonCount, imdbDescription " _
                   & " from tblShows Left Join tblDriveContents on tblShows.Title = tblDriveContents.FoldernameWithoutPath where (DriveName is null or Drivename not like '%Backup') and tblShows.AddedByomdbAPI = 'Y'"

            If cboOmdbCountries.Text <> "" Then

                strSQL = strSQL & " and country = '" & cboOmdbCountries.Text & "'"
            End If

            If cboOmdbTitleLetter.Text <> " " Then

                strSQL = strSQL & " and Title like '" & cboOmdbTitleLetter.Text & "%'"
            End If

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    intRowCount = intRowCount + 1
                End While
            End If

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                intRowPosition = 0
                intRowsAdded = 0

                While drTypes.Read()

                    intRowPosition = intRowPosition + 1

                    If (intRowPosition >= intRowLowerLimit) And (intRowPosition <= intRowUpperLimit) Then

                        strTitle = Trim(drTypes("Title") & "")

                        If strTitle <> "" Then

                            objItem = lvwOmdbAPI.Items.Add(strTitle)


                            objItem.SubItems.Add(Trim(drTypes("Drivename") & ""))

                            objItem.SubItems.Add(Trim(drTypes("imdbRating") & ""))
                            objItem.SubItems.Add(Trim(drTypes("imdbVotes") & ""))

                            objItem.SubItems.Add(Trim(drTypes("Country") & ""))
                            objItem.SubItems.Add(Trim(drTypes("Genre") & ""))

                            objItem.SubItems.Add(Trim(drTypes("imdbStartYear") & ""))
                            objItem.SubItems.Add(Trim(drTypes("imdbEndYear") & ""))

                            objItem.SubItems.Add(Trim(drTypes("imdbSeasonCount") & ""))
                            objItem.SubItems.Add(Trim(drTypes("imdbDescription") & ""))

                            intRowsAdded = intRowsAdded + 1
                        End If
                    End If

                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

            lvwOmdbAPI.Columns(0).Text = "Title - " & intRowsAdded & " rows"

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

        If lvwOmdbAPI.Items.Count > 0 Then

            txtOmdbAPI_Desc.Text = objItem.SubItems(OMDBAPI_DescColumn).Text
            txtomdbAPI_SeriesName.Text = objItem.SubItems(OMDBAPI_TitleColumn).Text
        End If

        mobjColumn_omdbAPI = Nothing

        Dim objE As New ColumnClickEventArgs(OMDBAPI_RatingColumn)

        lvwOmdbAPI_ColumnClick(Nothing, objE)
        lvwOmdbAPI_ColumnClick(Nothing, objE)

        If lvwOmdbAPI.Items.Count > 0 Then

            lvwOmdbAPI.Items(0).Selected = True

            lvwOmdbAPI_KeyUp(Nothing, Nothing)
        End If

    End Sub

    Private Sub mnuMumsStuff_Click(sender As Object, e As EventArgs) Handles mnuMumsStuff.Click

        ' Show list of mums stuff

        SetupScreenForMumsStuff()

        LoadMumsStuff()

    End Sub

    Private Sub SetupScreenForMumsStuff()

        tabFiles.Visible = False

        tabDetails.Visible = False
        fraDetails.Visible = False

        lvwFiles.Visible = False
        lvwSearchResults.Visible = False

        EnableDisable_NonStandardFiles(False)
        EnableDisable_ToDo(False)
        EnableDisable_AiredShows(False)
        EnableDisable_omdbAPI(False)
        EnableDisable_RottenTomatoes(False)
        EnableDisable_MajorFolders(False)
        EnableDisable_DriveStatus(False)
        EnableDisable_PeopleAlsoLiked_All(False)
        EnableDisable_ShowList_Dups(False)
        EnableDisable_UpdateStatus_MissingItems(False)
        EnableDisable_KnownDups(False)
        EnableDisable_GeneralListview(False)
        EnableDisable_DriveSummary(False)
        EnableDisable_LastFilesAdded(False)
        EnableDisable_DriveFileSummary(False)

        EnableDisable_MumsStuff(True)

        lvwMumsStuff.Items.Clear()

        With lvwMumsStuff

            .BringToFront()
            .Top = DEFAULT_TOP
            .Left = 5
            .Width = SplitContainer1.Panel2.Width - 15
            .Height = SplitContainer1.Panel2.Height - DEFAULT_HEIGHT_REDUCATION
        End With

        cmdFinished_MumsStuff.Left = cmdFinished.Left
        cmdFinished_MumsStuff.Top = cmdClose.Top

    End Sub

    Private Sub LoadMumsStuff()

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand, comDriveContents As OleDbCommand, drDriveContents As OleDbDataReader
        Dim objItem As ListViewItem

        Try

            strSQL = "Select Title from tblShows where ForMum = 'Y'"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    If Trim(drTypes("Title") & "") <> "" Then

                        objItem = lvwMumsStuff.Items.Add(Trim(drTypes("Title") & ""))

                        ' Get Drive
                        strSQL = "Select DriveName from tblDriveContents where FolderNameWithoutPath = '" & ParseTextForSQL(Trim(drTypes("Title") & "")) & "'"

                        comDriveContents = New OleDbCommand(strSQL, mobjOLEConn)

                        drDriveContents = comDriveContents.ExecuteReader()

                        If drDriveContents.HasRows Then

                            drDriveContents.Read()

                            objItem.SubItems.Add(Trim(drDriveContents("DriveName") & ""))

                        End If

                        CloseOLECommand(comDriveContents)
                        CloseDataReader(drDriveContents)

                    End If
                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub ReshowDefaultFormLayout()

        tabFiles.Visible = True
        lvwFiles.Visible = True

        tabDetails.Visible = True
        fraDetails.Visible = True

        DisableAll()

        Me.Refresh()
        SplitContainer1.Refresh()

    End Sub

    Private Sub cmdFinished_MumsStuff_Click(sender As Object, e As EventArgs) Handles cmdFinished_MumsStuff.Click

        ReshowDefaultFormLayout()

    End Sub

    Private Sub mnuDuplicateBoth_Click(sender As Object, e As EventArgs) Handles mnuDuplicateBoth.Click

        mnuDup_Email_Click(Nothing, Nothing)
        mnuDup_Record_Click(Nothing, Nothing)

    End Sub

    Private Sub chkFinished_Click(sender As Object, e As EventArgs) Handles chkFinished.Click

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand

        If txtID.Text.Trim = "" Then Exit Sub

        Try

            If optImdb.Checked = True Then

                If chkFinished.Checked = False Then

                    strSQL = "Update tblShows set Finished = 'N' where imdbID = '" & txtID.Text & "'"
                Else

                    strSQL = "Update tblShows set Finished = 'Y' where imdbID = '" & txtID.Text & "'"
                End If


            Else


            End If

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub chkComplete_Click(sender As Object, e As EventArgs) Handles chkComplete.Click

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand

        If txtID.Text.Trim = "" Then Exit Sub

        Try

            If optImdb.Checked = True Then

                If chkComplete.Checked = False Then

                    strSQL = "Update tblShows set Complete = 'N' where imdbID = '" & txtID.Text & "'"
                Else

                    strSQL = "Update tblShows set Complete = 'Y' where imdbID = '" & txtID.Text & "'"
                End If


            Else


            End If

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub mnuOptionsFinished_Click(sender As Object, e As EventArgs) Handles mnuOptionsFinished.Click

        Dim strState As String

        If Not mblnFinishedLoading Then Exit Sub

        If mnuOptionsFinished.Checked Then

            mnuOptionsFinished.Checked = False
            strState = "N"
        Else

            mnuOptionsFinished.Checked = True
            strState = "Y"
        End If

        treDrives.Nodes.Clear()

        LoadDrives()

        SaveOptions("ShowFinished", strState)

    End Sub

    Private Sub mnuOptionsComplete_Click(sender As Object, e As EventArgs) Handles mnuOptionsComplete.Click

        Dim strState As String

        If Not mblnFinishedLoading Then Exit Sub

        If mnuOptionsComplete.Checked Then

            mnuOptionsComplete.Checked = False
            strState = "N"
        Else

            mnuOptionsComplete.Checked = True
            strState = "Y"
        End If

        treDrives.Nodes.Clear()

        LoadDrives()

        SaveOptions("ShowCompleted", strState)

    End Sub

    Private Sub mnuMoveFilesFromRootToSeason1_Click(sender As Object, e As EventArgs) Handles mnuMoveFilesFromRootToSeason1.Click

        Dim strPath As String, strSeasonPath As String
        Dim colFiles() As FileInfo, objFile As FileInfo
        Dim strPathOther As String, strSeasonPathOther As String
        Dim strText As String

        strPath = treDrives.SelectedNode.FullPath

        If Not IsDriveConnected(GetDriveAndMainFolder(strPath)) Then

            MessageBox.Show("Drive not connected!")
            Exit Sub
        End If

        ' Get other drive to update
        strPathOther = GetOtherDrive(GetDriveAndMainFolder(strPath))

        If Not IsDriveConnected(strPathOther) Then

            MessageBox.Show("Drive not connected!")
            Exit Sub
        End If

        strSeasonPath = strPath & "\Season 1"
        strSeasonPathOther = strPathOther & "\" & RemoveDriveAndFolder(strPath) & "\Season 1"

        strPathOther = strPathOther & "\" & RemoveDriveAndFolder(strPath)

        If My.Computer.FileSystem.DirectoryExists(strSeasonPath) Then

            MessageBox.Show("The folder " & strSeasonPath & " already exists! Exiting.", My.Application.Info.ProductName, MessageBoxButtons.OK)
            Exit Sub
        End If

        If My.Computer.FileSystem.DirectoryExists(strSeasonPathOther) Then

            MessageBox.Show("The folder " & strSeasonPathOther & " already exists! Exiting.", My.Application.Info.ProductName, MessageBoxButtons.OK)
            Exit Sub
        End If

        My.Computer.FileSystem.CreateDirectory(strSeasonPath)
        My.Computer.FileSystem.CreateDirectory(strSeasonPathOther)

        strText = Me.Text

        colFiles = New DirectoryInfo(strPath).GetFiles

        For Each objFile In colFiles

            Me.Text = strText & " - Moving " & objFile.FullName
            Me.Refresh()
            My.Application.DoEvents()
            My.Computer.FileSystem.MoveFile(objFile.FullName, strSeasonPath & "\" & objFile.Name)
        Next

        colFiles = New DirectoryInfo(strPathOther).GetFiles

        For Each objFile In colFiles

            Me.Text = strText & " - Moving " & objFile.FullName
            Me.Refresh()
            My.Application.DoEvents()
            My.Computer.FileSystem.MoveFile(objFile.FullName, strSeasonPathOther & "\" & objFile.Name)
        Next

        Me.Text = strText

    End Sub

    Private Sub lvwFiles_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvwFiles.SelectedIndexChanged

        UpdateListviewFiles(lvwFiles)

    End Sub

    Private Sub mnuMoveTo_Click(sender As Object, e As EventArgs) Handles mnuMoveTo.Click

        Dim objDrive As New frmDrive, strDrive As String
        Dim strSourcePath As String, strSourceOtherPath As String, strPath As String
        Dim strDestinationPath As String, strDestinationOtherPath As String

        objDrive.LoadDrives(True, False)

        objDrive.ShowDialog()

        strDestinationPath = objDrive.SelectedDrive

        objDrive.Close()
        objDrive = Nothing

        If strDestinationPath = "" Then Exit Sub

        strSourcePath = treDrives.SelectedNode.FullPath
        strPath = RemoveDriveAndFolder(strSourcePath)

        strSourcePath = RemoveOneLevel(strSourcePath)
        strSourceOtherPath = GetOtherDrive(strSourcePath) & "\" & strPath
        strSourcePath = strSourcePath & strPath

        strDestinationOtherPath = GetOtherDrive(strDestinationPath & "\")

        strDestinationPath = strDestinationPath & "\" & strPath
        strDestinationOtherPath = strDestinationOtherPath & "\" & strPath

        If My.Computer.FileSystem.FileExists(strDestinationPath) Or My.Computer.FileSystem.FileExists(strDestinationOtherPath) Then

            MessageBox.Show("Destination folder(s) already exist!" & vbCrLf & vbCrLf & strDestinationPath & vbCrLf & strDestinationOtherPath, My.Application.Info.ProductName, MessageBoxButtons.OK)
            Exit Sub
        End If

        Try

            My.Computer.FileSystem.CopyDirectory(strSourcePath, strDestinationPath)
            My.Computer.FileSystem.CopyDirectory(strSourceOtherPath, strDestinationOtherPath)

        Catch ex As Exception

            If My.Computer.FileSystem.FileExists(strDestinationPath) Then

                My.Computer.FileSystem.DeleteDirectory(strDestinationPath, FileIO.DeleteDirectoryOption.DeleteAllContents)
            End If

            If My.Computer.FileSystem.FileExists(strDestinationOtherPath) Then

                My.Computer.FileSystem.DeleteDirectory(strDestinationOtherPath, FileIO.DeleteDirectoryOption.DeleteAllContents)
            End If

        End Try

        ' Should be copied OK

        Try

            My.Computer.FileSystem.DeleteDirectory(strSourcePath, FileIO.DeleteDirectoryOption.DeleteAllContents)

        Catch ex As Exception

            MessageBox.Show("Problem deleting folder! - " & vbCrLf & vbCrLf & strSourcePath, My.Application.Info.ProductName, MessageBoxButtons.OK)
        End Try

        Try

            My.Computer.FileSystem.DeleteDirectory(strSourceOtherPath, FileIO.DeleteDirectoryOption.DeleteAllContents)

        Catch ex As Exception

            MessageBox.Show("Problem deleting folder! - " & vbCrLf & vbCrLf & strSourceOtherPath, My.Application.Info.ProductName, MessageBoxButtons.OK)
        End Try

    End Sub

    Private Sub chkX264_Season_CheckedChanged(sender As Object, e As EventArgs) Handles chkX264_Season.CheckedChanged, chkX264_Episode.CheckedChanged

        Dim strPath As String

        If treDrives.SelectedNode Is Nothing Then Exit Sub

        strPath = treDrives.SelectedNode.FullPath

        If strPath = "" Then Exit Sub

        LoadMissingElements(strPath)

    End Sub

    Private Sub mnuToDo_Click(sender As Object, e As EventArgs) Handles mnuToDo.Click

        SetupScreenForToDo()

        LoadToDos()

    End Sub

    Private Sub SetupScreenForToDo()

        tabFiles.Visible = False

        lvwFiles.Visible = False

        tabDetails.Visible = False
        fraDetails.Visible = False

        lvwSearchResults.Visible = False

        EnableDisable_NonStandardFiles(False)
        EnableDisable_omdbAPI(False)
        EnableDisable_AiredShows(False)
        EnableDisable_MumsStuff(False)
        EnableDisable_DriveSummary(False)
        EnableDisable_RottenTomatoes(False)
        EnableDisable_MajorFolders(False)
        EnableDisable_DriveStatus(False)
        EnableDisable_PeopleAlsoLiked_All(False)
        EnableDisable_ShowList_Dups(False)
        EnableDisable_UpdateStatus_MissingItems(False)
        EnableDisable_KnownDups(False)
        EnableDisable_GeneralListview(False)
        EnableDisable_LastFilesAdded(False)
        EnableDisable_DriveFileSummary(False)

        EnableDisable_ToDo(True)

        lvwToDo.Items.Clear()

        lvwToDo.Left = 5
        lvwToDo.Top = DEFAULT_TOP
        lvwToDo.Left = lvwFiles.Left
        lvwToDo.Width = lvwFiles.Width
        lvwToDo.Height = SplitContainer1.Panel2.Height - DEFAULT_HEIGHT_REDUCATION

        cmdFinished_ToDo.Left = cmdFinished.Left
        cmdFinished_ToDo.Top = cmdClose.Top

        cmdToDo_Add.Left = 5
        cmdToDo_Edit.Left = cmdToDo_Add.Left + cmdToDo_Add.Width + 5

        cmdToDo_Delete.Left = cmdToDo_Edit.Left + cmdToDo_Edit.Width + 5

        cmdToDo_Add.Top = cmdClose.Top
        cmdToDo_Edit.Top = cmdClose.Top
        cmdToDo_Delete.Top = cmdClose.Top

    End Sub

    Private Sub cmdFinished_ToDo_Click(sender As Object, e As EventArgs) Handles cmdFinished_ToDo.Click

        ReshowDefaultFormLayout()

    End Sub

    Private Sub InsertNewToDo(ByVal strTitle As String, ByVal strDesc As String)

        Dim strSQL As String, comTypes As OleDbCommand, strEnteredDate As String
        Dim drTypes As OleDbDataReader, strSeqNo As String

        Try

            strSQL = "Select Max(SeqNo) +1 as Max_SeqNo from tblToDo"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                drTypes.Read()

                If Trim(drTypes("Max_SeqNo") & "") <> "" Then

                    strSeqNo = Trim(drTypes("Max_SeqNo") & "")

                End If
            End If

            CloseDataReader(drTypes)
            CloseOLECommand(comTypes)

            strEnteredDate = Format(Now, "MM/dd/yyyy")

            If strSeqNo = "" Then strSeqNo = "1"

            strSQL = "Insert into tblToDo (Title, Description, DateEntered, SeqNo) values ('" & ParseTextForSQL(strTitle) & "','" & ParseTextForSQL(strDesc) & "', #" & strEnteredDate & "#, " & strSeqNo & ")"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            comTypes.ExecuteReader()

            CloseOLECommand(comTypes)

        Catch ex As Exception

            If Mid(ex.Message, 1, 145) = "The changes you requested to the table were not successful because they would create duplicate values in the index, primary key, or relationship." Then

                Exit Sub
            End If

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Public Sub AddAToDo(ByVal strTitle As String, ByVal strDescription As String)

        Dim objToDo As New frmToDo

        With objToDo

            .txtTitle.Text = strTitle
            .txtToDo.Text = strDescription

            If .ShowDialog() = Windows.Forms.DialogResult.OK Then

                InsertNewToDo(objToDo.Title, objToDo.Description)
            End If

        End With

        objToDo.Close()
        objToDo = Nothing

        LoadToDos()

    End Sub

    Private Sub cmdToDo_Add_Click(sender As Object, e As EventArgs) Handles cmdToDo_Add.Click

        AddAToDo("", "")

    End Sub

    Private Sub cmdToDo_Delete_Click(sender As Object, e As EventArgs) Handles cmdToDo_Delete.Click

        Dim strSeqNo As String
        Dim strSQL As String, comTypes As OleDbCommand

        If lvwToDo.SelectedItems.Count > 0 Then

            strSeqNo = lvwToDo.SelectedItems(0).SubItems(2).Text
        Else

            Exit Sub
        End If

        Try

            strSQL = "delete from tblToDo where SeqNo = " & strSeqNo

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            comTypes.ExecuteReader()

            CloseOLECommand(comTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

        LoadToDos()

    End Sub

    Private Sub cmdToDo_Edit_Click(sender As Object, e As EventArgs) Handles cmdToDo_Edit.Click

        Dim objToDo As New frmToDo
        Dim strSQL As String, comTypes As OleDbCommand
        Dim strOldTitle As String, strOldDescription As String, strSeqNo As String

        If lvwToDo.SelectedItems.Count > 0 Then

            strOldTitle = lvwToDo.SelectedItems(0).Text
            strOldDescription = lvwToDo.SelectedItems(0).SubItems(1).Text
            strSeqNo = lvwToDo.SelectedItems(0).SubItems(2).Text
        Else

            Exit Sub
        End If

        With objToDo

            .txtTitle.Text = strOldTitle
            .txtToDo.Text = strOldDescription

            If .ShowDialog() = Windows.Forms.DialogResult.OK Then

                Try

                    strSQL = "Update tblToDo set Title = '" & ParseTextForSQL(.Title) & "', Description = '" & ParseTextForSQL(.Description) & "' where SeqNo = " & strSeqNo

                    comTypes = New OleDbCommand(strSQL, mobjOLEConn)

                    comTypes.ExecuteReader()

                    CloseOLECommand(comTypes)

                Catch ex As Exception

                    DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

                End Try
            End If

        End With

        objToDo.Close()
        objToDo = Nothing

        LoadToDos()

    End Sub

    Private Sub lvwToDo_ColumnClick(sender As Object, e As ColumnClickEventArgs) Handles lvwToDo.ColumnClick

        ' Get the new sorting column.
        Dim objListview As ListView, objColumnHeader As ColumnHeader

        objListview = lvwToDo
        objColumnHeader = mobjColumn_ToDo

        Dim new_sorting_column As ColumnHeader = objListview.Columns(e.Column)

        ' Figure out the new sorting order.
        Dim sort_order As System.Windows.Forms.SortOrder

        If objColumnHeader Is Nothing Then

            ' New column. Sort ascending.
            sort_order = SortOrder.Ascending
        Else

            ' See if this is the same column.
            If new_sorting_column.Equals(objColumnHeader) Then

                ' Same column. Switch the sort order.
                If objColumnHeader.Text.EndsWith(" >") Then

                    sort_order = SortOrder.Descending
                Else

                    sort_order = SortOrder.Ascending
                End If
            Else

                ' New column. Sort ascending.
                sort_order = SortOrder.Ascending
            End If

            ' Remove the old sort indicator.
            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, Len(objColumnHeader.Text) - 2)
        End If

        ' Display the new sort order.
        objColumnHeader = new_sorting_column

        If Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " >" Or Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " <" Then

            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, objColumnHeader.Text.Length - 2)
        End If

        If sort_order = SortOrder.Ascending Then

            objColumnHeader.Text = objColumnHeader.Text & " >"
        Else

            objColumnHeader.Text = objColumnHeader.Text & " <"
        End If

        mobjColumn_ToDo = objColumnHeader

        ' Create a comparer.
        objListview.ListViewItemSorter = New ListViewComparer(e.Column, sort_order)

        ' Sort.
        objListview.Sort()

    End Sub

    Private Sub mnuRightClick_Opening(sender As Object, e As ComponentModel.CancelEventArgs) Handles mnuRightClick.Opening

        Dim strPath As String, intCountMissing As Integer, intCount As Integer
        Dim mnuItem As ToolStripItem

        strPath = treDrives.SelectedNode.FullPath

        mnuCreateMissingSeasons.DropDownItems.Clear()

        If Count_Occurrances(strPath, "\") <> 2 Then Exit Sub

        intCountMissing = 0
        intCount = 1

        While intCountMissing < 3

            If Not My.Computer.FileSystem.DirectoryExists(strPath & "\Season " & intCount) Then

                mnuCreateMissingSeasons.DropDownItems.Add("Season " & intCount, Nothing, AddressOf mnuSeasonX_Click)

                intCountMissing = intCountMissing + 1
            End If

            intCount = intCount + 1

        End While

        ' Upto

        mnuCreateMissingSeasonsUpTo.DropDownItems.Clear()

        intCountMissing = 0
        intCount = 1

        While intCountMissing < 10

            If Not My.Computer.FileSystem.DirectoryExists(strPath & "\Season " & intCount) Then

                mnuCreateMissingSeasonsUpTo.DropDownItems.Add("Season " & intCount, Nothing, AddressOf mnuMissingSeasonUptoX_Click)

                intCountMissing = intCountMissing + 1
            End If

            intCount = intCount + 1

        End While

    End Sub

    Private Sub mnuMissingSeasonUptoX_Click(sender As Object, e As EventArgs)

        Dim strPath As String, strPathOther As String
        Dim strSeasonPath As String, strSeasonPathOther As String
        Dim intLastNumber As Integer, blnFinished As Boolean, intCurrentNumber As Integer
        Dim intCount As Integer

        intLastNumber = sender.text.ToString.Replace("Season ", "")

        strPath = treDrives.SelectedNode.FullPath & "\" & sender.ToString

        If Not IsDriveConnected(GetDriveAndMainFolder(strPath)) Then

            MessageBox.Show("Drive not connected!")
            Exit Sub
        End If

        ' Get other drive to update
        strPathOther = GetOtherDrive(GetDriveAndMainFolder(strPath))

        If Not IsDriveConnected(strPathOther) Then

            MessageBox.Show("Drive not connected!")
            Exit Sub
        End If

        blnFinished = False
        intCount = 0

        While Not blnFinished

            intCurrentNumber = mnuCreateMissingSeasonsUpTo.DropDownItems(intCount).Text.ToString.Replace("Season ", "")

            strSeasonPath = treDrives.SelectedNode.FullPath & "\Season " & intCurrentNumber
            strSeasonPathOther = strPathOther & "\" & Replace(treDrives.SelectedNode.FullPath, GetDriveAndMainFolder(strPath), "") & "\Season " & intCurrentNumber

            If My.Computer.FileSystem.DirectoryExists(strSeasonPath) Then

                MessageBox.Show("The folder " & strSeasonPath & " already exists! Exiting.", My.Application.Info.ProductName, MessageBoxButtons.OK)
                Exit Sub
            End If

            If My.Computer.FileSystem.DirectoryExists(strSeasonPathOther) Then

                MessageBox.Show("The folder " & strSeasonPathOther & " already exists! Exiting.", My.Application.Info.ProductName, MessageBoxButtons.OK)
                Exit Sub
            End If

            Try

                My.Computer.FileSystem.CreateDirectory(strSeasonPath)

            Catch ex As Exception

                DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

                Exit Sub

            End Try

            Try

                My.Computer.FileSystem.CreateDirectory(strSeasonPathOther)

            Catch ex As Exception

                My.Computer.FileSystem.DeleteDirectory(strSeasonPath, FileIO.DeleteDirectoryOption.ThrowIfDirectoryNonEmpty)

                Exit Sub
            End Try

            If intCurrentNumber = intLastNumber Then

                blnFinished = True
            End If

            intCount = intCount + 1

        End While

    End Sub


    Private Sub mnuSeasonX_Click(sender As Object, e As EventArgs)

        Dim strPath As String, strPathOther As String
        Dim strSeasonPath As String, strSeasonPathOther As String

        strPath = treDrives.SelectedNode.FullPath & "\" & sender.ToString

        If Not IsDriveConnected(GetDriveAndMainFolder(strPath)) Then

            MessageBox.Show("Drive not connected!")
            Exit Sub
        End If

        ' Get other drive to update
        strPathOther = GetOtherDrive(GetDriveAndMainFolder(strPath))

        If Not IsDriveConnected(strPathOther) Then

            MessageBox.Show("Drive not connected!")
            Exit Sub
        End If

        strSeasonPath = strPath
        strSeasonPathOther = strPathOther & "\" & Replace(treDrives.SelectedNode.FullPath, GetDriveAndMainFolder(strPath), "") & "\" & sender.ToString

        If My.Computer.FileSystem.DirectoryExists(strSeasonPath) Then

            MessageBox.Show("The folder " & strSeasonPath & " already exists! Exiting.", My.Application.Info.ProductName, MessageBoxButtons.OK)
            Exit Sub
        End If

        If My.Computer.FileSystem.DirectoryExists(strSeasonPathOther) Then

            MessageBox.Show("The folder " & strSeasonPathOther & " already exists! Exiting.", My.Application.Info.ProductName, MessageBoxButtons.OK)
            Exit Sub
        End If

        Try

            My.Computer.FileSystem.CreateDirectory(strSeasonPath)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

            Exit Sub

        End Try

        Try

            My.Computer.FileSystem.CreateDirectory(strSeasonPathOther)

        Catch ex As Exception

            My.Computer.FileSystem.DeleteDirectory(strSeasonPath, FileIO.DeleteDirectoryOption.ThrowIfDirectoryNonEmpty)

        End Try

    End Sub

    Private Sub mnuNonStandardFilesDelete_Click(sender As Object, e As EventArgs) Handles mnuNonStandardFilesDelete.Click

        Dim intCurrentRow As Integer, strCurrentRow As String
        Dim item As ListViewItem
        Dim strPath As String, strPathOther As String
        Dim strFilePath As String, strFilePathOther As String

        Try

            Dim Selection As ListView.SelectedListViewItemCollection = lvwNonStandardFiles.SelectedItems

            For Each item In Selection

                strPath = item.SubItems(1).Text

                If Not IsDriveConnected(GetDriveAndMainFolder(strPath)) Then

                    MessageBox.Show("Drive not connected!")
                    Exit Sub
                End If

                ' Get other drive to update
                strPathOther = GetOtherDrive(GetDriveAndMainFolder(strPath))

                If Not IsDriveConnected(strPathOther) Then

                    MessageBox.Show("Drive not connected!")
                    Exit Sub
                End If

                strFilePath = strPath & "\" & item.SubItems(2).Text
                strFilePathOther = strPathOther & "\" & Replace(strPath, GetDriveAndMainFolder(strPath), "") & "\" & item.SubItems(2).Text

                If Not My.Computer.FileSystem.FileExists(strFilePath) Then

                    MessageBox.Show("The file " & strFilePath & " doesn't exist! Exiting.", My.Application.Info.ProductName, MessageBoxButtons.OK)
                    Exit Sub
                End If

                If Not My.Computer.FileSystem.FileExists(strFilePathOther) Then

                    MessageBox.Show("The file " & strFilePathOther & " doesn't exist! Exiting.", My.Application.Info.ProductName, MessageBoxButtons.OK)
                    Exit Sub
                End If

                Try

                    My.Computer.FileSystem.DeleteFile(strFilePath, FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin)

                Catch ex As Exception

                    DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

                    Exit Sub
                End Try

                Try

                    My.Computer.FileSystem.DeleteFile(strFilePathOther, FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin)

                Catch ex As Exception

                    MessageBox.Show("The first file - " & strFilePath & " - has been sent to the recycle bin!")

                    DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

                    Exit Sub
                End Try

            Next

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try


    End Sub

    Private Sub chkNonStandard_DoBackup_CheckedChanged(sender As Object, e As EventArgs) Handles chkNonStandard_DoBackup.CheckedChanged

        LoadNonStandardFiles()

    End Sub

    Private Sub lvwNonStandardFiles_ColumnClick(sender As Object, e As ColumnClickEventArgs) Handles lvwNonStandardFiles.ColumnClick

        ' Get the new sorting column.
        Dim objListview As ListView, objColumnHeader As ColumnHeader

        objListview = lvwNonStandardFiles
        objColumnHeader = mobjColumn_NonStandard

        Dim new_sorting_column As ColumnHeader = objListview.Columns(e.Column)

        ' Figure out the new sorting order.
        Dim sort_order As System.Windows.Forms.SortOrder

        If objColumnHeader Is Nothing Then

            ' New column. Sort ascending.
            sort_order = SortOrder.Ascending
        Else

            ' See if this is the same column.
            If new_sorting_column.Equals(objColumnHeader) Then

                ' Same column. Switch the sort order.
                If objColumnHeader.Text.EndsWith(" >") Then

                    sort_order = SortOrder.Descending
                Else

                    sort_order = SortOrder.Ascending
                End If
            Else

                ' New column. Sort ascending.
                sort_order = SortOrder.Ascending
            End If

            ' Remove the old sort indicator.
            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, Len(objColumnHeader.Text) - 2)
        End If

        ' Display the new sort order.
        objColumnHeader = new_sorting_column

        If Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " >" Or Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " <" Then

            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, objColumnHeader.Text.Length - 2)
        End If

        If sort_order = SortOrder.Ascending Then

            objColumnHeader.Text = objColumnHeader.Text & " >"
        Else

            objColumnHeader.Text = objColumnHeader.Text & " <"
        End If

        mobjColumn_NonStandard = objColumnHeader

        ' Create a comparer.
        objListview.ListViewItemSorter = New ListViewComparer(e.Column, sort_order)

        ' Sort.
        objListview.Sort()

    End Sub

    Private Sub lvwFiles_ColumnClick(sender As Object, e As ColumnClickEventArgs) Handles lvwFiles.ColumnClick

        ' Get the new sorting column.
        Dim objListview As ListView, objColumnHeader As ColumnHeader

        objListview = lvwFiles
        objColumnHeader = mobjColumn_Files

        Dim new_sorting_column As ColumnHeader = objListview.Columns(e.Column)

        ' Figure out the new sorting order.
        Dim sort_order As System.Windows.Forms.SortOrder

        If objColumnHeader Is Nothing Then

            ' New column. Sort ascending.
            sort_order = SortOrder.Ascending
        Else

            ' See if this is the same column.
            If new_sorting_column.Equals(objColumnHeader) Then

                ' Same column. Switch the sort order.
                If objColumnHeader.Text.EndsWith(" >") Then

                    sort_order = SortOrder.Descending
                Else

                    sort_order = SortOrder.Ascending
                End If
            Else

                ' New column. Sort ascending.
                sort_order = SortOrder.Ascending
            End If

            ' Remove the old sort indicator.
            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, Len(objColumnHeader.Text) - 2)
        End If

        ' Display the new sort order.
        objColumnHeader = new_sorting_column

        If Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " >" Or Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " <" Then

            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, objColumnHeader.Text.Length - 2)
        End If

        If sort_order = SortOrder.Ascending Then

            objColumnHeader.Text = objColumnHeader.Text & " >"
        Else

            objColumnHeader.Text = objColumnHeader.Text & " <"
        End If

        mobjColumn_Files = objColumnHeader

        ' Create a comparer.
        objListview.ListViewItemSorter = New ListViewComparer(e.Column, sort_order)

        ' Sort.
        objListview.Sort()

    End Sub

    Private Sub lvwMumsStuff_ColumnClick(sender As Object, e As ColumnClickEventArgs) Handles lvwMumsStuff.ColumnClick

        ' Get the new sorting column.
        Dim objListview As ListView, objColumnHeader As ColumnHeader

        objListview = lvwMumsStuff
        objColumnHeader = mobjColumn_MumsStuff

        Dim new_sorting_column As ColumnHeader = objListview.Columns(e.Column)

        ' Figure out the new sorting order.
        Dim sort_order As System.Windows.Forms.SortOrder

        If objColumnHeader Is Nothing Then

            ' New column. Sort ascending.
            sort_order = SortOrder.Ascending
        Else

            ' See if this is the same column.
            If new_sorting_column.Equals(objColumnHeader) Then

                ' Same column. Switch the sort order.
                If objColumnHeader.Text.EndsWith(" >") Then

                    sort_order = SortOrder.Descending
                Else

                    sort_order = SortOrder.Ascending
                End If
            Else

                ' New column. Sort ascending.
                sort_order = SortOrder.Ascending
            End If

            ' Remove the old sort indicator.
            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, Len(objColumnHeader.Text) - 2)
        End If

        ' Display the new sort order.
        objColumnHeader = new_sorting_column

        If Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " >" Or Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " <" Then

            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, objColumnHeader.Text.Length - 2)
        End If

        If sort_order = SortOrder.Ascending Then

            objColumnHeader.Text = objColumnHeader.Text & " >"
        Else

            objColumnHeader.Text = objColumnHeader.Text & " <"
        End If

        mobjColumn_MumsStuff = objColumnHeader

        ' Create a comparer.
        objListview.ListViewItemSorter = New ListViewComparer(e.Column, sort_order)

        ' Sort.
        objListview.Sort()

    End Sub

    Private Sub lvwKnownDups_ColumnClick(sender As Object, e As ColumnClickEventArgs) Handles lvwKnownDups.ColumnClick

        ' Get the new sorting column.
        Dim objListview As ListView, objColumnHeader As ColumnHeader

        objListview = lvwKnownDups
        objColumnHeader = mobjColumn_KnownDups

        Dim new_sorting_column As ColumnHeader = objListview.Columns(e.Column)

        ' Figure out the new sorting order.
        Dim sort_order As System.Windows.Forms.SortOrder

        If objColumnHeader Is Nothing Then

            ' New column. Sort ascending.
            sort_order = SortOrder.Ascending
        Else

            ' See if this is the same column.
            If new_sorting_column.Equals(objColumnHeader) Then

                ' Same column. Switch the sort order.
                If objColumnHeader.Text.EndsWith(" >") Then

                    sort_order = SortOrder.Descending
                Else

                    sort_order = SortOrder.Ascending
                End If
            Else

                ' New column. Sort ascending.
                sort_order = SortOrder.Ascending
            End If

            ' Remove the old sort indicator.
            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, Len(objColumnHeader.Text) - 2)
        End If

        ' Display the new sort order.
        objColumnHeader = new_sorting_column

        If Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " >" Or Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " <" Then

            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, objColumnHeader.Text.Length - 2)
        End If

        If sort_order = SortOrder.Ascending Then

            objColumnHeader.Text = objColumnHeader.Text & " >"
        Else

            objColumnHeader.Text = objColumnHeader.Text & " <"
        End If

        mobjColumn_KnownDups = objColumnHeader

        ' Create a comparer.
        objListview.ListViewItemSorter = New ListViewComparer(e.Column, sort_order)

        ' Sort.
        objListview.Sort()

    End Sub

    Private Sub lvwSearchResults_ColumnClick(sender As Object, e As ColumnClickEventArgs) Handles lvwSearchResults.ColumnClick

        ' Get the new sorting column.
        Dim objListview As ListView, objColumnHeader As ColumnHeader

        objListview = lvwSearchResults
        objColumnHeader = mobjColumn_Last100FilesAdded

        Dim new_sorting_column As ColumnHeader = objListview.Columns(e.Column)

        ' Figure out the new sorting order.
        Dim sort_order As System.Windows.Forms.SortOrder

        If objColumnHeader Is Nothing Then

            ' New column. Sort ascending.
            sort_order = SortOrder.Ascending
        Else

            ' See if this is the same column.
            If new_sorting_column.Equals(objColumnHeader) Then

                ' Same column. Switch the sort order.
                If objColumnHeader.Text.EndsWith(" >") Then

                    sort_order = SortOrder.Descending
                Else

                    sort_order = SortOrder.Ascending
                End If
            Else

                ' New column. Sort ascending.
                sort_order = SortOrder.Ascending
            End If

            ' Remove the old sort indicator.
            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, Len(objColumnHeader.Text) - 2)
        End If

        ' Display the new sort order.
        objColumnHeader = new_sorting_column

        If Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " >" Or Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " <" Then

            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, objColumnHeader.Text.Length - 2)
        End If

        If sort_order = SortOrder.Ascending Then

            objColumnHeader.Text = objColumnHeader.Text & " >"
        Else

            objColumnHeader.Text = objColumnHeader.Text & " <"
        End If

        mobjColumn_Last100FilesAdded = objColumnHeader

        ' Create a comparer.
        objListview.ListViewItemSorter = New ListViewComparer(e.Column, sort_order)

        ' Sort.
        objListview.Sort()

    End Sub

    Private Sub lvwShowList_Dups_ColumnClick(sender As Object, e As ColumnClickEventArgs) Handles lvwShowList_Dups.ColumnClick

        ' Get the new sorting column.
        Dim objListview As ListView, objColumnHeader As ColumnHeader

        objListview = lvwShowList_Dups
        objColumnHeader = mobjColumn_showList_Dups

        Dim new_sorting_column As ColumnHeader = objListview.Columns(e.Column)

        ' Figure out the new sorting order.
        Dim sort_order As System.Windows.Forms.SortOrder

        If objColumnHeader Is Nothing Then

            ' New column. Sort ascending.
            sort_order = SortOrder.Ascending
        Else

            ' See if this is the same column.
            If new_sorting_column.Equals(objColumnHeader) Then

                ' Same column. Switch the sort order.
                If objColumnHeader.Text.EndsWith(" >") Then

                    sort_order = SortOrder.Descending
                Else

                    sort_order = SortOrder.Ascending
                End If
            Else

                ' New column. Sort ascending.
                sort_order = SortOrder.Ascending
            End If

            ' Remove the old sort indicator.
            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, Len(objColumnHeader.Text) - 2)
        End If

        ' Display the new sort order.
        objColumnHeader = new_sorting_column

        If Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " >" Or Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " <" Then

            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, objColumnHeader.Text.Length - 2)
        End If

        If sort_order = SortOrder.Ascending Then

            objColumnHeader.Text = objColumnHeader.Text & " >"
        Else

            objColumnHeader.Text = objColumnHeader.Text & " <"
        End If

        mobjColumn_showList_Dups = objColumnHeader

        ' Create a comparer.
        objListview.ListViewItemSorter = New ListViewComparer(e.Column, sort_order)

        ' Sort.
        objListview.Sort()

    End Sub

    Private Sub mnuListviewRightClick_Delete_Click(sender As Object, e As EventArgs) Handles mnuListviewRightClick_Delete.Click

        Dim strSQL As String, strID As String, comTypes As OleDbCommand

        If lvwKnownDups.SelectedItems.Count = 0 Then Exit Sub

        strID = lvwKnownDups.SelectedItems(0).SubItems(0).Text

        Try

            strSQL = "Delete from tblDups where DupID = " & strID

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            comTypes.ExecuteReader()

            CloseOLECommand(comTypes)

            LoadKnownDuplicates()

        Catch ex As Exception

            AddError(System.Reflection.MethodBase.GetCurrentMethod().Name & " - " & ex.Message)
        End Try

    End Sub

    Private Sub txtUpdFilenamesHelp_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtUpdFilenamesHelp.KeyPress

        e.Handled = True

    End Sub

    Private Sub cmdAddToToDo_Click(sender As Object, e As EventArgs) Handles cmdAddToToDo.Click

        Dim strToDo As String

        strToDo = txtSeriesName.Text

        AddToToDownload(strToDo)

    End Sub

    Private Sub chkNonStandard_IgnoreSubtitle_CheckedChanged(sender As Object, e As EventArgs) Handles chkNonStandard_IgnoreSubtitle.CheckedChanged

        LoadNonStandardFiles()

    End Sub

    Private Sub chkNonStandard_IgnoreTTCFiles_CheckedChanged(sender As Object, e As EventArgs) Handles chkNonStandard_IgnoreTTCFiles.CheckedChanged

        LoadNonStandardFiles()

    End Sub

    Private Sub lvwDriveStatus_ColumnClick(sender As Object, e As ColumnClickEventArgs) Handles lvwDriveStatus.ColumnClick

        ' Get the new sorting column.
        Dim objListview As ListView, objColumnHeader As ColumnHeader

        objListview = lvwDriveStatus
        objColumnHeader = mobjColumn_DriveStatus

        Dim new_sorting_column As ColumnHeader = objListview.Columns(e.Column)

        ' Figure out the new sorting order.
        Dim sort_order As System.Windows.Forms.SortOrder

        If objColumnHeader Is Nothing Then

            ' New column. Sort ascending.
            sort_order = SortOrder.Ascending
        Else

            ' See if this is the same column.
            If new_sorting_column.Equals(objColumnHeader) Then

                ' Same column. Switch the sort order.
                If objColumnHeader.Text.EndsWith(" >") Then

                    sort_order = SortOrder.Descending
                Else

                    sort_order = SortOrder.Ascending
                End If
            Else

                ' New column. Sort ascending.
                sort_order = SortOrder.Ascending
            End If

            ' Remove the old sort indicator.
            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, Len(objColumnHeader.Text) - 2)
        End If

        ' Display the new sort order.
        objColumnHeader = new_sorting_column

        If Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " >" Or Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " <" Then

            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, objColumnHeader.Text.Length - 2)
        End If

        If sort_order = SortOrder.Ascending Then

            objColumnHeader.Text = objColumnHeader.Text & " >"
        Else

            objColumnHeader.Text = objColumnHeader.Text & " <"
        End If

        mobjColumn_DriveStatus = objColumnHeader

        ' Create a comparer.
        objListview.ListViewItemSorter = New ListViewComparer(e.Column, sort_order)

        ' Sort.
        objListview.Sort()

    End Sub

    Private Sub lvwUpdateStatus_ColumnClick(sender As Object, e As ColumnClickEventArgs) Handles lvwUpdateStatus.ColumnClick

        ' Get the new sorting column.
        Dim objListview As ListView, objColumnHeader As ColumnHeader

        objListview = lvwUpdateStatus
        objColumnHeader = mobjColumn_UpdateStatus

        Dim new_sorting_column As ColumnHeader = objListview.Columns(e.Column)

        ' Figure out the new sorting order.
        Dim sort_order As System.Windows.Forms.SortOrder

        If objColumnHeader Is Nothing Then

            ' New column. Sort ascending.
            sort_order = SortOrder.Ascending
        Else

            ' See if this is the same column.
            If new_sorting_column.Equals(objColumnHeader) Then

                ' Same column. Switch the sort order.
                If objColumnHeader.Text.EndsWith(" >") Then

                    sort_order = SortOrder.Descending
                Else

                    sort_order = SortOrder.Ascending
                End If
            Else

                ' New column. Sort ascending.
                sort_order = SortOrder.Ascending
            End If

            ' Remove the old sort indicator.
            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, Len(objColumnHeader.Text) - 2)
        End If

        ' Display the new sort order.
        objColumnHeader = new_sorting_column

        If Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " >" Or Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " <" Then

            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, objColumnHeader.Text.Length - 2)
        End If

        If sort_order = SortOrder.Ascending Then

            objColumnHeader.Text = objColumnHeader.Text & " >"
        Else

            objColumnHeader.Text = objColumnHeader.Text & " <"
        End If

        mobjColumn_UpdateStatus = objColumnHeader

        ' Create a comparer.
        objListview.ListViewItemSorter = New ListViewComparer(e.Column, sort_order)

        ' Sort.
        objListview.Sort()

    End Sub

    Private Sub cmdToDo_General_Click(sender As Object, e As EventArgs) Handles cmdToDo_General.Click

        Dim strDrive As String

        strDrive = treDrives.SelectedNode.FullPath

        AddAToDo(strDrive & " - " & txtSeriesName.Text, "")

    End Sub

    Private Sub cmdFinished_OmdbAPI_Click(sender As Object, e As EventArgs) Handles cmdFinished_OmdbAPI.Click

        ReshowDefaultFormLayout()

    End Sub

    Private Sub lvwOmdbAPI_ColumnClick(sender As Object, e As ColumnClickEventArgs) Handles lvwOmdbAPI.ColumnClick

        ' Get the new sorting column.
        Dim objListview As ListView, objColumnHeader As ColumnHeader

        objListview = lvwOmdbAPI
        objColumnHeader = mobjColumn_omdbAPI

        Dim new_sorting_column As ColumnHeader = objListview.Columns(e.Column)

        ' Figure out the new sorting order.
        Dim sort_order As System.Windows.Forms.SortOrder

        If objColumnHeader Is Nothing Then

            ' New column. Sort ascending.
            sort_order = SortOrder.Ascending
        Else

            ' See if this is the same column.
            If new_sorting_column.Equals(objColumnHeader) Then

                ' Same column. Switch the sort order.
                If objColumnHeader.Text.EndsWith(" >") Then

                    sort_order = SortOrder.Descending
                Else

                    sort_order = SortOrder.Ascending
                End If
            Else

                ' New column. Sort ascending.
                sort_order = SortOrder.Ascending
            End If

            ' Remove the old sort indicator.
            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, Len(objColumnHeader.Text) - 2)
        End If

        ' Display the new sort order.
        objColumnHeader = new_sorting_column

        If Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " >" Or Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " <" Then

            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, objColumnHeader.Text.Length - 2)
        End If

        If sort_order = SortOrder.Ascending Then

            objColumnHeader.Text = objColumnHeader.Text & " >"
        Else

            objColumnHeader.Text = objColumnHeader.Text & " <"
        End If

        mobjColumn_omdbAPI = objColumnHeader

        ' Create a comparer.
        objListview.ListViewItemSorter = New ListViewComparer(e.Column, sort_order)

        ' Sort.
        objListview.Sort()

    End Sub

    Private Sub lvwOmdbAPI_KeyUp(sender As Object, e As KeyEventArgs) Handles lvwOmdbAPI.KeyUp

        If lvwOmdbAPI.Items.Count > 0 Then

            txtOmdbAPI_Desc.Text = lvwOmdbAPI.SelectedItems(0).SubItems(OMDBAPI_DescColumn).Text
            txtomdbAPI_SeriesName.Text = lvwOmdbAPI.SelectedItems(0).SubItems(OMDBAPI_TitleColumn).Text
        End If
    End Sub

    Private Sub lvwOmdbAPI_MouseUp(sender As Object, e As MouseEventArgs) Handles lvwOmdbAPI.MouseUp

        If lvwOmdbAPI.Items.Count > 0 Then

            txtOmdbAPI_Desc.Text = lvwOmdbAPI.SelectedItems(0).SubItems(OMDBAPI_DescColumn).Text
            txtomdbAPI_SeriesName.Text = lvwOmdbAPI.SelectedItems(0).SubItems(OMDBAPI_TitleColumn).Text
        End If

    End Sub

    Private Sub cboCountries_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboOmdbCountries.SelectedIndexChanged

        LoadomdbAPI(mintRowUpperLimit)

    End Sub

    Private Sub cboOmdbTitleLetter_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboOmdbTitleLetter.SelectedIndexChanged

        LoadomdbAPI(mintRowUpperLimit)

    End Sub

    Private Sub mnuToDownload_Click(sender As Object, e As EventArgs) Handles mnuToDownload.Click

        Dim frmD As New frmDownload

        frmD.mstrUpdateType = ToDownload

        frmD.LoadDownloads()

        frmD.Show()

        frmD.txtDownload.SelectionLength = 0

    End Sub

    Private Sub mnuFailedDownloads_Click(sender As Object, e As EventArgs) Handles mnuFailedDownloads.Click

        Dim frmD As New frmDownload

        frmD.mstrUpdateType = FailedDownloads

        frmD.LoadDownloads()

        frmD.Show()

        frmD.txtDownload.SelectionLength = 0

    End Sub

    Private Sub txtSearch_LostFocus(sender As Object, e As EventArgs) Handles txtSearch.LostFocus

        If txtSearch.Text = "" Then ResetBackColourButtons()

    End Sub

    Private Sub cmdAddMissingToToDownload_Click(sender As Object, e As EventArgs) Handles cmdAddMissingToToDownload.Click

        Dim strToDo As String

        If txtMissingEpisodes.Text.Trim = "" Then Exit Sub

        strToDo = txtMissingEpisodes.Text

        AddToToDownload(strToDo)

    End Sub

    Private Sub AddToToDownload(ByVal strToDo As String)

        Dim strSQL As String, comTypes As OleDbCommand, drTypes As OleDbDataReader
        Dim strTVDrive As String

        strTVDrive = GetDriveAndMainFolder(treDrives.SelectedNode.FullPath)

        strSQL = "Update tblDownloads set DownloadsToDo = DownloadsToDo + '" & vbCrLf & vbCrLf & strTVDrive & ParseTextForSQL(strToDo) & "'"

        Try

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub cmdAddSelMissingToToDownload_Click(sender As Object, e As EventArgs) Handles cmdAddSelMissingToToDownload.Click

        Dim strToDo As String

        If txtMissingEpisodes.SelectedText.Trim = "" Then Exit Sub

        strToDo = txtMissingEpisodes.SelectedText

        AddToToDownload(strToDo)

    End Sub

    Private Sub chkUpdateStatus_Missing_CheckedChanged(sender As Object, e As EventArgs) Handles chkUpdateStatus_Missing.CheckedChanged

        cboDrives_SelectedIndexChanged(Nothing, Nothing)

    End Sub

    Private Sub cmdAddMissingSeasonsToToDownload_Click(sender As Object, e As EventArgs) Handles cmdAddMissingSeasonsToToDownload.Click

        Dim strToDo As String

        If txtMissingSeasons.Text.Trim = "" Then Exit Sub

        strToDo = txtMissingSeasons.Text

        AddToToDownload(strToDo)

    End Sub

    Private Sub cmdAddSelMissingSeasonsToToDownload_Click(sender As Object, e As EventArgs) Handles cmdAddSelMissingSeasonsToToDownload.Click

        Dim strToDo As String

        If txtMissingSeasons.SelectedText.Trim = "" Then Exit Sub

        strToDo = txtMissingSeasons.SelectedText

        AddToToDownload(strToDo)

    End Sub

    Private Sub chkUpdateStatus_IgnoreCompleted_CheckedChanged(sender As Object, e As EventArgs) Handles chkUpdateStatus_IgnoreCompleted.CheckedChanged

        cboDrives_SelectedIndexChanged(Nothing, Nothing)

    End Sub

    ' code will go through all the files in TV 6 \ BBC and remove the BBC from the start
    Private Sub Button1_Click(sender As Object, e As EventArgs)

        Dim strPath As String, objFile As FileInfo
        Dim intCount As Integer

        strPath = "Y:\TV 6\BBC\"

        intCount = 0

        Dim objDir As New DirectoryInfo(strPath)

        For Each objFile In objDir.GetFiles

            If Mid(objFile.Name, 1, 4).ToUpper = "BBC " Then

                Try

                    objFile.MoveTo(GetPath(objFile.FullName) & "\" & Mid(objFile.Name, 5))

                Catch ex As Exception

                    intCount = intCount + 1

                    If ex.Message.Trim = "Cannot create a file when that file already exists." Then

                        objFile.MoveTo(GetPath(objFile.FullName) & "\" & Mid(objFile.Name, 5) & Space(intCount).Replace(" ", "_"))

                    End If

                End Try

            End If
        Next

        objDir = Nothing

        strPath = "Z:\TV 6 Backup\BBC\"

        intCount = 0

        objDir = New DirectoryInfo(strPath)

        For Each objFile In objDir.GetFiles

            If Mid(objFile.Name, 1, 4).ToUpper = "BBC " Then

                Try

                    objFile.MoveTo(GetPath(objFile.FullName) & "\" & Mid(objFile.Name, 5))

                Catch ex As Exception

                    intCount = intCount + 1

                    If ex.Message.Trim = "Cannot create a file when that file already exists." Then

                        objFile.MoveTo(GetPath(objFile.FullName) & "\" & Mid(objFile.Name, 5) & Space(intCount).Replace(" ", "_"))

                    End If

                End Try

            End If
        Next

    End Sub

    Private Sub cmdMissing_Click(sender As Object, e As EventArgs) Handles cmdMissing.Click

        mnuUpdateStatus_Click(Nothing, Nothing)

    End Sub

    Private Sub mnuUpdateMyTotals_Click(sender As Object, e As EventArgs) Handles mnuUpdateMyTotals.Click

        Dim strStartDrive As String, strCurrentDrive As String, strPath As String, intTotal As Integer
        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand, strID As String, intPos As Integer
        Dim intStart As Integer, strSeries As String

        If treDrives.SelectedNode.FullPath = "" Then Exit Sub

        If Count_Occurrances(treDrives.SelectedNode.FullPath, "\") = 1 Then

            treDrives.SelectedNode.ExpandAll()
            treDrives.SelectedNode = treDrives.SelectedNode.Nodes(0)
        End If

        strStartDrive = GetDrive(treDrives.SelectedNode.FullPath)
        strCurrentDrive = strStartDrive

        treDrives.Refresh()
        My.Application.DoEvents()

        treDrives.Focus()

        While strCurrentDrive <> ""

            Dim objNewNode As New System.Windows.Forms.TreeNodeMouseClickEventArgs(treDrives.SelectedNode, MouseButtons.Left, 1, 1, 1)

            strPath = treDrives.SelectedNode.FullPath

            If Count_Occurrances(strPath, "\") = 2 Then

                intStart = InStrRev(strPath, "\") + 1

                strSeries = Mid(strPath, intStart)
                strID = ""

                ' Get ID from Title
                strSQL = "Select imdbID from tblShows where Title = '" & ParseTextForSQL(strSeries) & "'"

                comTypes = New OleDbCommand(strSQL, mobjOLEConn)

                drTypes = comTypes.ExecuteReader()

                If drTypes.HasRows Then

                    drTypes.Read()

                    If Trim(drTypes("imdbID") & "") <> "" Then

                        strID = Trim(drTypes("imdbID") & "")

                    End If
                End If

                CloseOLECommand(comTypes)
                CloseDataReader(drTypes)

                If strID <> "" Then

                    intTotal = GetMyTotalOfFilesForSeries(strPath)

                    ' Update The Total
                    strSQL = "Update tblShows set MyTotal = " & intTotal & " Where imdbID = '" & strID & "'"

                    Try

                        comTypes = New OleDbCommand(strSQL, mobjOLEConn)

                        drTypes = comTypes.ExecuteReader()

                        CloseOLECommand(comTypes)
                        CloseDataReader(drTypes)

                    Catch ex As Exception

                        DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

                    End Try
                End If

            End If

            treDrives.SelectedNode = treDrives.SelectedNode.NextVisibleNode

            'If Count_Occurrances(treDrives.SelectedNode.FullPath, "\") = 1 Then

            '

            'Else

            'treDrives.SelectedNode.ExpandAll()
            'treDrives.SelectedNode = treDrives.SelectedNode.Nodes(0)
            'End If

            strCurrentDrive = ""

            Try

                strCurrentDrive = GetDrive(treDrives.SelectedNode.FullPath)

            Catch ex As Exception

            End Try

            If Count_Occurrances(treDrives.SelectedNode.FullPath, "\") = 1 Then

                If treDrives.SelectedNode.FullPath = "N:\Movies" Then Exit Sub

                treDrives.SelectedNode.ExpandAll()

                If treDrives.SelectedNode.Nodes.Count Then

                    treDrives.SelectedNode = treDrives.SelectedNode.Nodes(0)
                Else

                    strCurrentDrive = strCurrentDrive
                    treDrives.SelectedNode = treDrives.SelectedNode.NextNode
                End If
            End If

        End While

    End Sub

    Private Sub cmdReloadDrives_Click(sender As Object, e As EventArgs) Handles cmdReloadDrives.Click

        treDrives.Nodes.Clear()

        LoadDrives()

    End Sub

    Private Sub tabFiles_SelectedIndexChanged(sender As Object, e As EventArgs) Handles tabFiles.SelectedIndexChanged

        If tabFiles.SelectedTab.Name = COMPLETED_TAB Then

            If Not LoadCompletedSeasonDefaults() Then Exit Sub

            LoadCompletedFiles()
        End If

    End Sub

    Private Function LoadCompletedSeasonDefaults() As Boolean

        Dim strText As String, intPos As Integer, objNode As TreeNode, colNodes As TreeNodeCollection
        Dim objN As TreeNode, strSeason As String, blnFinished As Boolean, intCount As Integer
        Dim strLastAddedSeason As String

        LoadCompletedSeasonDefaults = False

        mblnLoadingCompletedFiles = True

        cboCompletedSeasons.Items.Clear()

        strText = treDrives.SelectedNode.FullPath

        If Count_Occurrances(strText, "\") <= 1 Then

            mblnLoadingCompletedFiles = False
            Exit Function
        End If

        cboCompletedSeasons.Items.Add("All")

        intPos = InStr(strText, "Season ")

        If intPos = 0 Then

            objNode = treDrives.SelectedNode

            colNodes = objNode.Nodes

            For Each objN In colNodes

                cboCompletedSeasons.Items.Add(objN.Text)
                strLastAddedSeason = objN.Text.Replace("Season ", "")
            Next

            cboCompletedSeasons.SelectedIndex = 0
        Else

            strSeason = Mid(strText, intPos)

            objNode = treDrives.SelectedNode.Parent

            colNodes = objNode.Nodes

            For Each objN In colNodes

                cboCompletedSeasons.Items.Add(objN.Text)
                strLastAddedSeason = objN.Text.Replace("Season ", "")
            Next

            blnFinished = False
            intCount = 1

            While blnFinished = False

                If cboCompletedSeasons.Items(intCount) = strSeason Then

                    cboCompletedSeasons.SelectedIndex = intCount
                    blnFinished = True
                Else

                    intCount = intCount + 1
                End If

            End While

        End If

        If strLastAddedSeason <> "" Then

            cboCompletedSeasons.Items.Add("Season " & CInt(strLastAddedSeason) + 1)
        End If

        mblnLoadingCompletedFiles = False

        LoadCompletedSeasonDefaults = True

    End Function

    Private Sub LoadCompletedFiles()

        Dim strDrive As String, strTVFolder As String, strShow As String
        Dim strTVFolderFiles As String, strCopyFromFolderFiles As String
        Dim strPath As String, strCopyFromFolder As String, intCount As Integer
        Dim arrAllShows() As String
        Dim strSeason As String

        If cboCompletedSeasons.Items.Count = 0 Then Exit Sub

        strSeason = cboCompletedSeasons.SelectedItem.ToString

        strDrive = GetDrive(treDrives.SelectedNode.FullPath)
        strTVFolder = GetDriveAndMainFolder(treDrives.SelectedNode.FullPath).Replace(strDrive, "").Replace("\", "")

        strShow = txtSeriesName.Text
        strSeason = cboCompletedSeasons.Text

        strCopyFromFolder = ROOT_DRIVE & "\_Torrent\Completed\_TV\_Copy From\" & strTVFolder & "\"
        strTVFolder = ROOT_DRIVE & "\_Torrent\Completed\_TV\"

        lvwCompletedFiles.Items.Clear()

        strTVFolderFiles = ""
        strCopyFromFolderFiles = ""

        If marrTVFolderFiles Is Nothing Then

            ' TV in Completed
            GetAllTVFiles(ROOT_DRIVE & "\_Torrent\Completed", strTVFolderFiles)

            ' TV Folder and subs

            GetAllFiles(strTVFolder, strTVFolderFiles)

            If strTVFolderFiles <> "" Then marrTVFolderFiles = strTVFolderFiles.Split(Chr(137))
        End If

        AddFilesToCompletedListview(marrTVFolderFiles, strShow, strSeason)

    End Sub

    Public Sub GetAllTVFiles(ByVal strPath As String, ByRef strFiles As String)

        Dim objDir As DirectoryInfo, objFile As FileInfo, colFiles() As FileInfo, colFolders() As DirectoryInfo
        Dim strPrefix As String, strName As String

        objDir = New DirectoryInfo(strPath)

        If objDir.Exists = False Then Exit Sub

        colFiles = objDir.GetFiles()

        For Each objFile In colFiles

            strPrefix = GetPrefix(objFile.FullName).ToLower

            If InStr("avi,mp4,mkv,", strPrefix & ",") > 0 Then

                strPrefix = GetPrefix(objFile.FullName).ToLower
                strName = GetPath(objFile.FullName) & RemovePrefix(objFile.FullName).Replace(".", " ")

                strFiles = strFiles & strName & "." & strPrefix & Chr(137)
            End If
        Next

        colFolders = objDir.GetDirectories()

        For Each objFolder In colFolders

            If IsDirectoryToBeProcessed(objFolder) Then

                GetAllTVFiles(objFolder.FullName, strFiles)
            End If
        Next

    End Sub

    Private Sub AddFilesToCompletedListview(ByRef arrFiles() As String, ByVal strShow As String, ByVal strSeason As String)

        Dim intCount As Integer, intLimit As Integer
        Dim objItem As ListViewItem, strPath As String
        Dim strShowName As String, intPos As Integer
        Dim strSearchTerm As String, intNumber As Integer, strNumber As String

        lvwCompletedFiles.Columns(0).Text = "Path"

        intLimit = arrFiles.GetUpperBound(0) - 1

        If strSeason = "All" Then

            strSearchTerm = strShow
        Else

            intNumber = strSeason.Replace("Season ", "")

            strNumber = intNumber

            If Len(strNumber) = 1 Then strNumber = "0" & strNumber

            strSearchTerm = strShow & " " & "S" & strNumber
        End If

        strSearchTerm = strSearchTerm.ToLower

        For intCount = 0 To intLimit

            If InStr(arrFiles(intCount).ToLower, strSearchTerm) > 0 Then

                strPath = GetPath(arrFiles(intCount))
                strPath = Mid(strPath, 1, Len(strPath) - 1)

                intPos = InStrRev(strPath, "\")

                If intPos > 0 Then

                    intPos = InStrRev(strPath, "\", intPos - 1)

                    If intPos > 0 Then

                        strShowName = Mid(strPath, intPos + 1)

                        intPos = InStr(strShowName, "\")

                        If intPos > 0 Then

                            strShowName = Mid(strShowName, 1, intPos - 1)
                        End If
                    End If
                End If

                objItem = lvwCompletedFiles.Items.Add(strPath.Replace(ROOT_DRIVE & "\_Torrent\Completed\_TV\", ""))

                objItem.SubItems.Add(RemovePath(arrFiles(intCount)))
            End If

        Next

        lvwCompletedFiles.Columns(0).Text = "Path - " & lvwCompletedFiles.Items.Count & " files"

        mblnLoadingCompletedFiles = False

    End Sub

    Private Sub cboDrives_Tab_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDrives_Tab.SelectedIndexChanged

        If mblnFinishedLoading = False Then Exit Sub

        DisplayUpdateStatus(False, cboDrives_Tab.Text)

    End Sub

    Private Sub chkUpdateStatus_Missing_Tab_CheckedChanged(sender As Object, e As EventArgs) Handles chkUpdateStatus_Missing_Tab.CheckedChanged

        If mblnFinishedLoading = False Then Exit Sub

        cboDrives_Tab_SelectedIndexChanged(Nothing, Nothing)

    End Sub

    Private Sub chkUpdateStatus_IgnoreCompleted_Tab_CheckedChanged(sender As Object, e As EventArgs) Handles chkUpdateStatus_IgnoreCompleted_Tab.CheckedChanged

        If mblnFinishedLoading = False Then Exit Sub

        cboDrives_Tab_SelectedIndexChanged(Nothing, Nothing)

    End Sub

    Private Sub mnuRottenTomatoes_Click(sender As Object, e As EventArgs) Handles mnuRottenTomatoes.Click

        SetupScreenForRottenTomatoes()

        LoadRottenTomatoes()

    End Sub

    Private Sub SetupScreenForRottenTomatoes()

        tabFiles.Visible = False

        tabDetails.Visible = False
        fraDetails.Visible = False

        lvwFiles.Visible = False
        lvwSearchResults.Visible = False

        EnableDisable_ToDo(False)
        EnableDisable_NonStandardFiles(False)
        EnableDisable_AiredShows(False)
        EnableDisable_omdbAPI(False)
        EnableDisable_MumsStuff(False)
        EnableDisable_MajorFolders(False)
        EnableDisable_DriveSummary(False)
        EnableDisable_DriveStatus(False)
        EnableDisable_PeopleAlsoLiked_All(False)
        EnableDisable_ShowList_Dups(False)
        EnableDisable_UpdateStatus_MissingItems(False)
        EnableDisable_KnownDups(False)
        EnableDisable_GeneralListview(False)
        EnableDisable_LastFilesAdded(False)
        EnableDisable_DriveFileSummary(False)

        EnableDisable_RottenTomatoes(True)

        lvwRottenTomatoes.Items.Clear()

        lvwRottenTomatoes.BringToFront()
        lvwRottenTomatoes.Top = DEFAULT_TOP
        lvwRottenTomatoes.Left = 5
        lvwRottenTomatoes.Width = SplitContainer1.Panel2.Width - 15
        lvwRottenTomatoes.Height = SplitContainer1.Panel2.Height - DEFAULT_HEIGHT_REDUCATION

        cmdFinished_RottenTomatoes.Left = cmdFinished.Left
        cmdFinished_RottenTomatoes.Top = cmdClose.Top

    End Sub

    Private Sub cmdFinished_RottenTomatoes_Click(sender As Object, e As EventArgs) Handles cmdFinished_RottenTomatoes.Click

        ReshowDefaultFormLayout()

    End Sub

    Private Sub lvwRottenTomatoes_ColumnClick(sender As Object, e As ColumnClickEventArgs) Handles lvwRottenTomatoes.ColumnClick

        ' Get the new sorting column.
        Dim objListview As ListView, objColumnHeader As ColumnHeader

        objListview = lvwRottenTomatoes
        objColumnHeader = mobjColumn_RottenTomatoes

        Dim new_sorting_column As ColumnHeader = objListview.Columns(e.Column)

        ' Figure out the new sorting order.
        Dim sort_order As System.Windows.Forms.SortOrder

        If objColumnHeader Is Nothing Then

            ' New column. Sort ascending.
            sort_order = SortOrder.Ascending
        Else

            ' See if this is the same column.
            If new_sorting_column.Equals(objColumnHeader) Then

                ' Same column. Switch the sort order.
                If objColumnHeader.Text.EndsWith(" >") Then

                    sort_order = SortOrder.Descending
                Else

                    sort_order = SortOrder.Ascending
                End If
            Else

                ' New column. Sort ascending.
                sort_order = SortOrder.Ascending
            End If

            ' Remove the old sort indicator.
            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, Len(objColumnHeader.Text) - 2)
        End If

        ' Display the new sort order.
        objColumnHeader = new_sorting_column

        If Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " >" Or Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " <" Then

            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, objColumnHeader.Text.Length - 2)
        End If

        If sort_order = SortOrder.Ascending Then

            objColumnHeader.Text = objColumnHeader.Text & " >"
        Else

            objColumnHeader.Text = objColumnHeader.Text & " <"
        End If

        mobjColumn_RottenTomatoes = objColumnHeader

        ' Create a comparer.
        objListview.ListViewItemSorter = New ListViewComparer(e.Column, sort_order)

        ' Sort.
        objListview.Sort()

    End Sub

    Private Sub mnuDriveFileSummary_Click(sender As Object, e As EventArgs) Handles mnuDriveFileSummary.Click

        SetupScreenForDriveFileSummary()

        LoadDriveFileSummary()

    End Sub

    Private Sub SetupScreenForDriveFileSummary()

        tabFiles.Visible = False

        tabDetails.Visible = False
        fraDetails.Visible = False

        lvwFiles.Visible = False
        lvwSearchResults.Visible = False

        EnableDisable_AiredShows(False)
        EnableDisable_NonStandardFiles(False)
        EnableDisable_omdbAPI(False)
        EnableDisable_ToDo(False)
        EnableDisable_MumsStuff(False)
        EnableDisable_RottenTomatoes(False)
        EnableDisable_MajorFolders(False)
        EnableDisable_DriveStatus(False)
        EnableDisable_PeopleAlsoLiked_All(False)
        EnableDisable_ShowList_Dups(False)
        EnableDisable_UpdateStatus_MissingItems(False)
        EnableDisable_KnownDups(False)
        EnableDisable_GeneralListview(False)
        EnableDisable_LastFilesAdded(False)
        EnableDisable_DriveSummary(False)

        EnableDisable_DriveFileSummary(True)

        lvwListView.Columns.Clear()
        lvwListView.Columns.Add("Show", 200)
        lvwListView.Columns.Add("FileName", 500)
        lvwListView.Columns.Add("Size", 100)
        lvwListView.Columns.Add("Size (in Mb)", 100)

        lvwListView.ContextMenuStrip = mnuListview_DriveFileSummary

        cboDrives.Top = 1
        cboDrives.Left = 5

        lvwListView.Items.Clear()

        With lvwListView

            .BringToFront()
            .Top = cboDrives.Top + cboDrives.Height + 8
            .Left = 5
            .Width = SplitContainer1.Panel2.Width - 15
            .Height = SplitContainer1.Panel2.Height - 180
        End With

        txtDriveFileSummary_FullFilename.Top = lvwListView.Top + lvwListView.Height + 7
        txtDriveFileSummary_FullFilename.Left = lvwListView.Left
        cmdDriveFileSummary_FullFilename_Copy.Top = txtDriveFileSummary_FullFilename.Top
        cmdDriveFileSummary_FullFilename_Copy.Left = txtDriveFileSummary_FullFilename.Left + txtDriveFileSummary_FullFilename.Width + 5

        txtDriveFileSummary_FullFilenamewithoutETTV.Top = txtDriveFileSummary_FullFilename.Top + 25
        txtDriveFileSummary_FullFilenamewithoutETTV.Left = lvwListView.Left
        cmdDriveFileSummary_FullFilenamewithoutETTV_Copy.Top = txtDriveFileSummary_FullFilenamewithoutETTV.Top
        cmdDriveFileSummary_FullFilenamewithoutETTV_Copy.Left = txtDriveFileSummary_FullFilenamewithoutETTV.Left + txtDriveFileSummary_FullFilenamewithoutETTV.Width + 5

        txtDriveFileSummary_FilenameJustSeason.Top = txtDriveFileSummary_FullFilenamewithoutETTV.Top + 25
        txtDriveFileSummary_FilenameJustSeason.Left = lvwListView.Left
        cmdDriveFileSummary_FilenameJustSeason_Copy.Top = txtDriveFileSummary_FilenameJustSeason.Top
        cmdDriveFileSummary_FilenameJustSeason_Copy.Left = txtDriveFileSummary_FilenameJustSeason.Left + txtDriveFileSummary_FilenameJustSeason.Width + 5

        txtDriveFileSummary_Seriesname.Top = txtDriveFileSummary_FilenameJustSeason.Top + 25
        txtDriveFileSummary_Seriesname.Left = lvwListView.Left
        cmdDriveFileSummary_SeriesName_Copy.Top = txtDriveFileSummary_Seriesname.Top
        cmdDriveFileSummary_SeriesName_Copy.Left = txtDriveFileSummary_Seriesname.Left + txtDriveFileSummary_Seriesname.Width + 5

        lblDriveFileSummary_Info.Top = cmdFinished.Top - 10
        lblDriveFileSummary_Info.Left = lvwListView.Left

        cmdFinished_Listview.Left = cmdFinished.Left
        cmdFinished_Listview.Top = cmdClose.Top

    End Sub

    Private Sub LoadDriveFileSummary()

        Try

            mstrTypeUsingDriveControl = DRIVE_FILE_SUMMARY

            lvwListView.Items.Clear()

            LoadDriveSummaryFiles("Asc")
            LoadDriveSummaryFiles("Desc")

            mobjColumn_Listview = Nothing

            Dim objE As New ColumnClickEventArgs(COL_DRIVEFILESUMMARY_SIZEINMB)
            lvwListView_ColumnClick(Nothing, objE)
            lvwListView_ColumnClick(Nothing, objE)

            lvwListView.Sort()

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub LoadDriveSummaryFiles(ByVal strOrderType As String)

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand
        Dim objItem As ListViewItem, strDrive As String
        Dim intItemsAdded As Integer

        Try

            strSQL = "SELECT DISTINCT top 150 FoldernameWithoutPath, FileName, FileSize " _
                   & "FROM tblDriveContents Left Join tblShows on  tblDriveContents.FoldernameWithoutPath = tblShows.Title Where tblDriveContents.drivename = '" & cboDrives.Text & "' Order by FileSize " & strOrderType

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    If intItemsAdded < 50 Then


                        If Trim(drTypes("FoldernameWithoutPath") & "") <> "" Then

                            If Not IsFileASubTitleFileType(Trim(drTypes("Filename") & "")) Then

                                objItem = lvwListView.Items.Add(Trim(drTypes("FoldernameWithoutPath") & ""))

                                objItem.SubItems.Add(Trim(drTypes("FileName") & ""))
                                objItem.SubItems.Add(Trim(drTypes("FileSize") & ""))
                                objItem.SubItems.Add(GetFileSizeInMB_UsingSize(Trim(drTypes("FileSize") & "")))

                                intItemsAdded = intItemsAdded + 1
                            End If
                        End If
                    End If

                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub mnuDriveSummary_Click(sender As Object, e As EventArgs) Handles mnuDriveSummary.Click

        SetupScreenForDriveSummary()

        LoadDriveSummary()

    End Sub

    Private Sub SetupScreenForDriveSummary()

        tabFiles.Visible = False

        tabDetails.Visible = False
        fraDetails.Visible = False

        lvwFiles.Visible = False
        lvwSearchResults.Visible = False

        EnableDisable_AiredShows(False)
        EnableDisable_NonStandardFiles(False)
        EnableDisable_omdbAPI(False)
        EnableDisable_ToDo(False)
        EnableDisable_MumsStuff(False)
        EnableDisable_RottenTomatoes(False)
        EnableDisable_MajorFolders(False)
        EnableDisable_DriveStatus(False)
        EnableDisable_PeopleAlsoLiked_All(False)
        EnableDisable_ShowList_Dups(False)
        EnableDisable_UpdateStatus_MissingItems(False)
        EnableDisable_KnownDups(False)
        EnableDisable_GeneralListview(False)
        EnableDisable_LastFilesAdded(False)
        EnableDisable_DriveFileSummary(False)

        EnableDisable_DriveSummary(True)

        lvwListView.Columns.Clear()
        lvwListView.Columns.Add("Show", 175)
        lvwListView.Columns.Add("imdbID", 100)
        lvwListView.Columns.Add("imdbRating", 75)
        lvwListView.Columns.Add("imdbVotes", 75)
        lvwListView.Columns.Add("My Total", 80)
        lvwListView.Columns.Add("imdb AirDate Total", 100)
        lvwListView.Columns.Add("For Mum", 65)
        lvwListView.Columns.Add("Finished", 70)
        lvwListView.Columns.Add("Complete", 65)
        lvwListView.Columns.Add("Total (GB)", 70)
        lvwListView.Columns.Add("Lst Upd omdbAPI", 105)
        lvwListView.Columns.Add("Lst Upd IMDB", 100)

        cboDrives.Top = 1
        cboDrives.Left = 5

        lvwListView.Items.Clear()

        With lvwListView

            .BringToFront()
            .Top = cboDrives.Top + cboDrives.Height + 8
            .Left = 5
            .Width = SplitContainer1.Panel2.Width - 15
            .Height = SplitContainer1.Panel2.Height - 210
        End With

        cmdFinished_Listview.Left = cmdFinished.Left
        cmdFinished_Listview.Top = cmdClose.Top

        txtDriveSummary_Desc.Top = lvwListView.Top + lvwListView.Height + 8
        txtDriveSummary_Desc.Left = lvwListView.Left

        txtMultiLineTextbox.Top = txtDriveSummary_Desc.Top + txtDriveSummary_Desc.Height + 8
        txtMultiLineTextbox.Left = lvwListView.Left

        txtMultiLineTextbox.Width = lvwListView.Width - 200
        txtMultiLineTextbox.Height = 75

    End Sub

    Private Sub LoadDriveSummary()

        Dim strSQL As String, drTypes As OleDbDataReader, drTypes_Size As OleDbDataReader
        Dim comTypes As OleDbCommand, comTypes_Size As OleDbCommand
        Dim objItem As ListViewItem, strDrive As String

        Dim intItems_WithoutomdbID As Integer
        Dim intItems_Finished As Integer
        Dim intItems_Completed As Integer
        Dim intItems_ForMum As Integer
        Dim intItems_TotalMissingFiles As Integer
        Dim strSize As String, strSQL_Size As String

        mstrTypeUsingDriveControl = DRIVE_SUMMARY

        lvwListView.Items.Clear()

        Try

            strSQL = "SELECT DISTINCT imdbRating, imdbVotes, FoldernameWithoutPath, imdbDescription, imdbID, MyTotal, imdb_AirDateTotal,ForMum, Finished,Complete, imdbDateOfLastUpdate_API, imdbDateOfLastUpdate " _
                   & "FROM tblDriveContents Left Join tblShows on  tblDriveContents.FoldernameWithoutPath = tblShows.Title Where tblDriveContents.drivename = '" & cboDrives.Text & "' Order by FoldernameWithoutPath"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                While drTypes.Read()

                    If Trim(drTypes("FoldernameWithoutPath") & "") <> "" Then

                        strSQL_Size = "Select sum(filesize) as Sum_FileSize from tblDriveContents where FolderNameWithoutPath = '" & ParseTextForSQL(Trim(drTypes("FoldernameWithoutPath") & "")) & "'"

                        objItem = lvwListView.Items.Add(Trim(drTypes("FoldernameWithoutPath") & ""))

                        objItem.SubItems.Add(Trim(drTypes("imdbID") & ""))

                        If Trim(drTypes("imdbID") & "") <> "" Then

                            objItem.SubItems.Add(Trim(drTypes("imdbRating") & ""))
                            objItem.SubItems.Add(Trim(drTypes("imdbVotes") & ""))
                            objItem.SubItems.Add(Trim(drTypes("MyTotal") & ""))
                            objItem.SubItems.Add(Trim(drTypes("imdb_AirDateTotal") & ""))
                            objItem.SubItems.Add(Trim(drTypes("ForMum") & ""))
                            objItem.SubItems.Add(Trim(drTypes("Finished") & ""))
                            objItem.SubItems.Add(Trim(drTypes("Complete") & ""))

                            strSize = ""

                            comTypes_Size = New OleDbCommand(strSQL_Size, mobjOLEConn)

                            drTypes_Size = comTypes_Size.ExecuteReader()

                            If drTypes_Size.HasRows Then

                                While drTypes_Size.Read()

                                    strSize = GetFileSizeInGB_UsingSize(drTypes_Size("Sum_FileSize"))
                                End While
                            End If

                            CloseDataReader(drTypes_Size)
                            CloseOLECommand(comTypes_Size)

                            objItem.SubItems.Add(strSize)

                            objItem.SubItems.Add(Trim(drTypes("imdbDateOfLastUpdate_API") & ""))
                            objItem.SubItems.Add(Trim(drTypes("imdbDateOfLastUpdate") & ""))

                            If Trim(drTypes("Finished") & "") = "Y" Then intItems_Finished = intItems_Finished + 1
                            If Trim(drTypes("Complete") & "") = "Y" Then intItems_Completed = intItems_Completed + 1
                            If Trim(drTypes("ForMum") & "") = "Y" Then intItems_ForMum = intItems_ForMum + 1

                            If Trim(drTypes("MyTotal") & "") < Trim(drTypes("imdb_AirDateTotal") & "") Then

                                intItems_TotalMissingFiles = intItems_TotalMissingFiles + (Trim(drTypes("imdb_AirDateTotal") & "") - Trim(drTypes("MyTotal") & ""))
                            End If

                        Else

                            intItems_WithoutomdbID = intItems_WithoutomdbID + 1

                        End If

                    End If
                End While
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

            If lvwListView.Items.Count > 1 Then

                lvwListView.Columns(0).Text = "Show - " & lvwListView.Items.Count & " shows"

                lvwListView.Items(0).Selected = True

                lvwListView_Click(Nothing, Nothing)
            End If

            txtMultiLineTextbox.Text = intItems_WithoutomdbID & " items without an omdbID and " & intItems_TotalMissingFiles & " missing files in total" & vbCrLf & vbCrLf
            txtMultiLineTextbox.Text = txtMultiLineTextbox.Text & "Completed - " & intItems_Completed & " Finished - " & intItems_Finished & " For Mum - " & intItems_ForMum

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

    End Sub

    Private Sub cmdFinished_Listview_Click(sender As Object, e As EventArgs) Handles cmdFinished_Listview.Click

        ReshowDefaultFormLayout()

    End Sub

    Private Sub chkSeasonOK_CheckedChanged(sender As Object, e As EventArgs) Handles chkSeasonOK.CheckedChanged

        Dim strSQL As String, strSeasonImOn As String, strSeriesName As String
        Dim comTypes As OleDbCommand

        If mblnIgnoreCheckedEvent Then Exit Sub

        strSeriesName = ParseTextForSQL(txtSeriesName.Text)

        OnSeasonInTreeview(treDrives.SelectedNode.FullPath, strSeasonImOn)

        If Len(strSeasonImOn) < 7 Then Exit Sub
        If Mid(strSeasonImOn, 1, 7) <> "Season " Then Exit Sub

        strSQL = "delete from tblSeasonOK where SeriesName = '" & strSeriesName & "' and Season = '" & strSeasonImOn & "'"

        comTypes = New OleDbCommand(strSQL, mobjOLEConn)

        comTypes.ExecuteNonQuery()

        CloseOLECommand(comTypes)

        If chkSeasonOK.Checked = True Then

            strSQL = "Insert into tblSeasonOK (SeriesName, Season) values ('" & strSeriesName & "', '" & strSeasonImOn & "')"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            comTypes.ExecuteNonQuery()

            CloseOLECommand(comTypes)
        End If

    End Sub

    Private Sub lvwAiredShows_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvwAiredShows.SelectedIndexChanged

        Dim strPath As String

        strPath = ""

        If lvwAiredShows.SelectedItems.Count = 1 Then

            txtAiredItems_FullFilename.Text = FindEpisodeName(lvwAiredShows.SelectedItems(0).SubItems(1).Text, lvwAiredShows.SelectedItems(0).SubItems(2).Text, lvwAiredShows.SelectedItems(0).SubItems(3).Text) & " Ettv"
            txtAiredItems_FullFilenamewithoutETTV.Text = FindEpisodeName(lvwAiredShows.SelectedItems(0).SubItems(1).Text, lvwAiredShows.SelectedItems(0).SubItems(2).Text, lvwAiredShows.SelectedItems(0).SubItems(3).Text)

            txtAiredItems_FilenameJustSeason.Text = FindSeasonName(lvwAiredShows.SelectedItems(0).SubItems(1).Text, lvwAiredShows.SelectedItems(0).SubItems(2).Text)
            txtAiredItems_Seriesname.Text = lvwAiredShows.SelectedItems(0).SubItems(1).Text
            txtAiredItems_Title.Text = lvwAiredShows.SelectedItems(0).SubItems(7).Text & " Ettv"
        End If

    End Sub

    Private Sub txtAiredItems_FullFilename_DoubleClick(sender As Object, e As EventArgs) Handles txtAiredItems_FullFilename.DoubleClick

        Clipboard.SetText(txtAiredItems_FullFilename.Text)
        txtAiredItems_FullFilename.SelectAll()

    End Sub

    Private Sub txtAiredItems_FullFilenamewithoutETTV_DoubleClick(sender As Object, e As EventArgs) Handles txtAiredItems_FullFilenamewithoutETTV.DoubleClick

        Clipboard.SetText(txtAiredItems_FullFilenamewithoutETTV.Text)
        txtAiredItems_FullFilenamewithoutETTV.SelectAll()

    End Sub

    Private Sub txtAiredItems_FilenameJustSeason_DoubleClick(sender As Object, e As EventArgs) Handles txtAiredItems_FilenameJustSeason.DoubleClick

        Clipboard.SetText(txtAiredItems_FilenameJustSeason.Text)
        txtAiredItems_FilenameJustSeason.SelectAll()

    End Sub

    Private Sub txtAiredItems_Title_DoubleClick(sender As Object, e As EventArgs) Handles txtAiredItems_Title.DoubleClick

        Clipboard.SetText(txtAiredItems_Title.Text)
        txtAiredItems_Title.SelectAll()

    End Sub

    Private Sub txtAiredItems_Seriesname_DoubleClick(sender As Object, e As EventArgs) Handles txtAiredItems_Seriesname.DoubleClick

        Clipboard.SetText(txtAiredItems_Seriesname.Text)
        txtAiredItems_Seriesname.SelectAll()

    End Sub

    Private Sub cmdAiredItems_FullFilename_Click(sender As Object, e As EventArgs) Handles cmdAiredItems_FullFilename_Copy.Click

        Clipboard.SetText(txtAiredItems_FullFilename.Text)

        txtAiredItems_FullFilename.Focus()
        txtAiredItems_FullFilename.SelectAll()

    End Sub

    Private Sub cmdAiredItems_FullFilenamewithoutETTV_Click(sender As Object, e As EventArgs) Handles cmdAiredItems_FullFilenamewithoutETTV_Copy.Click

        Clipboard.SetText(txtAiredItems_FullFilenamewithoutETTV.Text)

        txtAiredItems_FullFilenamewithoutETTV.Focus()
        txtAiredItems_FullFilenamewithoutETTV.SelectAll()

    End Sub

    Private Sub cmdAiredItems_FilenameJustSeason_Click(sender As Object, e As EventArgs) Handles cmdAiredItems_FilenameJustSeason_Copy.Click

        Clipboard.SetText(txtAiredItems_FilenameJustSeason.Text)

        txtAiredItems_FilenameJustSeason.Focus()
        txtAiredItems_FilenameJustSeason.SelectAll()

    End Sub

    Private Sub cmdAiredItems_Title_Click(sender As Object, e As EventArgs) Handles cmdAiredItems_Title_Copy.Click

        Clipboard.SetText(txtAiredItems_Title.Text)

        txtAiredItems_Title.Focus()
        txtAiredItems_Title.SelectAll()

    End Sub

    Private Sub cmdAiredItems_SeriesName_Click(sender As Object, e As EventArgs) Handles cmdAiredItems_SeriesName_Copy.Click

        Clipboard.SetText(txtAiredItems_Seriesname.Text)

        txtAiredItems_Seriesname.Focus()
        txtAiredItems_Seriesname.SelectAll()

    End Sub

    Private Sub mnuListview_AddToDupsOnly_MouseClick(sender As Object, e As MouseEventArgs) Handles mnuListview_AddToDupsOnly.MouseClick

        Dim p As New Point, C As Windows.Forms.Cursor

        C = Cursors.Default

        p = New Point(Windows.Forms.Cursor.Position.X, Windows.Forms.Cursor.Position.Y)

        If e.Button = Windows.Forms.MouseButtons.Right Then

            mnuListview_AddToDupsOnly.Tag = sender.name
            mnuListview_AddToDupsOnly.Show(p)

        End If

    End Sub

    Private Sub mnuAddToDups_Click(sender As Object, e As EventArgs) Handles mnuAddToDups.Click

        Dim objItem As ListViewItem, strPath As String, strSQL As String
        Dim drTypes As OleDbDataReader, comTypes As OleDbCommand, comInsert As OleDbCommand
        Dim intID As Integer, blnInsert As Boolean, strNotes As String

        If lvwShowList_Dups.SelectedItems.Count <= 1 Then Exit Sub

        strSQL = "select max(DupID) + 1 as Max_Dup from tblDups"

        comTypes = New OleDbCommand(strSQL, mobjOLEConn)

        drTypes = comTypes.ExecuteReader()

        If drTypes.HasRows Then

            drTypes.Read()

            If Trim(drTypes("Max_Dup") & "") <> "" Then

                intID = Trim(drTypes("Max_Dup") & "")
            Else

                intID = 1
            End If
        Else

            Exit Sub
        End If

        strNotes = InputBox("Enter Note if required", "Add Duplicated Show", "")

        blnInsert = False


        For Each objItem In lvwShowList_Dups.SelectedItems

            Try

                strSQL = "Insert into tblDups (DupID, Path, Notes) values ("

                strSQL = strSQL & intID & ", '" & ParseTextForSQL(objItem.SubItems(1).Text & objItem.Text)

                strSQL = strSQL & "','" & ParseTextForSQL(strNotes) & "')"

                comInsert = New OleDbCommand(strSQL, mobjOLEConn)

                comInsert.ExecuteReader()

                CloseOLECommand(comInsert)

            Catch ex As Exception

                DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name, "strSQL - " & strSQL)

            End Try
        Next

        UpdateKnownDups()

    End Sub

    Private Sub cmdomdbAPI_Back_Click(sender As Object, e As EventArgs) Handles cmdomdbAPI_Back.Click

        mintRowUpperLimit = mintRowUpperLimit - 1000

        If mintRowUpperLimit < 0 Then mintRowUpperLimit = 1000

        LoadomdbAPI(mintRowUpperLimit)

    End Sub

    Private Sub cmdomdbAPI_Forward_Click(sender As Object, e As EventArgs) Handles cmdomdbAPI_Forward.Click

        mintRowUpperLimit = mintRowUpperLimit + 1000

        LoadomdbAPI(mintRowUpperLimit)

    End Sub

    Private Sub cboFileCount_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboFileCount.SelectedIndexChanged

        DisplayLastAddedFiles()

    End Sub

    Private Sub cmdWikiLoad_Click(sender As Object, e As EventArgs) Handles cmdWikiLoad.Click

        If txtURLWiki.Text.Trim = "" Then Exit Sub

        webWiki.Navigate(txtURLWiki.Text)

    End Sub

    Private Sub cmdWikiLoadEpisodes_Click(sender As Object, e As EventArgs) Handles cmdWikiLoadEpisodes.Click

        If txtSeriesName.Text.Trim = "" Then Exit Sub

        'https://en.wikipedia.org/wiki/List_of_The_Brittas_Empire_episodes

        webWiki.Navigate("https://en.wikipedia.org/wiki/List_of_" & txtSeriesName.Text.Replace(" ", "_") & "_episodes")

    End Sub

    Private Sub cmdWikiBack_Click(sender As Object, e As EventArgs) Handles cmdWikiBack.Click

        webWiki.GoBack()

    End Sub

    Private Sub cmdWikiForward_Click(sender As Object, e As EventArgs) Handles cmdWikiForward.Click

        webWiki.GoForward()
    End Sub

    Private Sub txtomdbAPI_SeriesName_TextChanged(sender As Object, e As EventArgs) Handles txtomdbAPI_SeriesName.TextChanged

        If txtomdbAPI_SeriesName.Text = "" Then

            ToolTip1.SetToolTip(cmdomdbAPI_IMDB, "http://www.imdb.com/find?ref_=nv_sr_fn&q=" & txtomdbAPI_SeriesName.Text.Replace(" ", "+") & "&s=all")
        Else

            ToolTip1.SetToolTip(cmdomdbAPI_IMDB, "http://www.imdb.com/find?ref_=nv_sr_fn&q=" & txtomdbAPI_SeriesName.Text.Replace(" ", "+") & "&s=all")
        End If

    End Sub

    Private Sub cmdomdbAPI_IMDB_Click(sender As Object, e As EventArgs) Handles cmdomdbAPI_IMDB.Click

        Dim strSeriesName As String

        strSeriesName = txtomdbAPI_SeriesName.Text

        strSeriesName = strSeriesName.Replace(" & ", " %26 ")

        If strSeriesName <> "" Then

            OpenWWW("http://www.imdb.com/find?ref_=nv_sr_fn&q=" & strSeriesName.Replace(" ", "+") & "&s=all")
        End If

    End Sub

    Private Sub lvwToDo_DoubleClick(sender As Object, e As EventArgs) Handles lvwToDo.DoubleClick

        cmdToDo_Edit_Click(Nothing, Nothing)

    End Sub

    Private Sub cmdCompletedSeasons_Click(sender As Object, e As EventArgs) Handles cmdCompletedSeasons.Click

        If mblnLoadingCompletedFiles = True Then Exit Sub

        If Not LoadCompletedSeasonDefaults() Then Exit Sub

        LoadCompletedFiles()

    End Sub

    Private Sub cboCompletedSeasons_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboCompletedSeasons.SelectedIndexChanged

        If mblnLoadingCompletedFiles = True Then Exit Sub

        LoadCompletedFiles()

    End Sub

    Private Sub mnuSimpleConsistencyChecker_Click(sender As Object, e As EventArgs) Handles mnuSimpleConsistencyChecker.Click

        Dim intPreFileFolderCount As Long, intPostFileFolderCount As Long, intSize As Long
        Dim objDir As DirectoryInfo, strPath As String, dtmStart As Date, dtmEnd As Date
        Dim strTime As String, intPreFileCount As Long, intPostFileCount As Long
        Dim objStream As StreamReader, strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand, dtmModifiedDate As Date, strRootBackupPath As String

        If IsHomePC() = False Then

            MessageBox.Show("Home PC Only!")
            Exit Sub
        End If

        frmDrive.lblHelp.Width = 425

        frmDrive.cmdOK.Left = 300
        frmDrive.cmdCancel.Left = 395

        frmDrive.Width = 500

        frmDrive.cboDrives.Items.Clear()

        frmDrive.LoadDrives(True, False)

        frmDrive.lblHelp.Text = "Goes through the TV folder and checks that each file exists on the backup. Sometimes modified date is different between the files on TV and TV Backup so KDiff3 thinks the files are missing (Running this or Refresh Drives should sort this out)."

        If frmDrive.ShowDialog() = Windows.Forms.DialogResult.OK Then

            Try

                strPath = frmDrive.cboDrives.Text
                mstrPath = strPath

                strRootBackupPath = GetOtherDrive(strPath & "\")

                dtmStart = Now
                dtmModifiedDate = Now

                objDir = New DirectoryInfo(strPath)

                GetFileFolderCountAndSizeinFolder(objDir, True, intPreFileFolderCount, intSize, True, intPreFileCount)

                intPreFileCount = intPreFileCount * 2

                frmProgressbar.ProgressBar1.Maximum = intPreFileCount
                frmProgressbar.TopMost = True
                frmProgressbar.Show()
                frmProgressbar.BringToFront()
                My.Application.DoEvents()

                CheckFiles(strPath, strRootBackupPath, strPath, dtmModifiedDate)

            Catch ex As Exception

                Dim blnDrive As Boolean

                blnDrive = IsDriveConnected(mstrPath)

                frmProgressbar.Close()
                frmProgressbar = Nothing

                DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name, "mnuSimpleConsistencyChecker_Click - blnDrive=" & blnDrive & vbCrLf & "strPath - " & strPath & vbCrLf & "mstrRefreshPathCurrentFile - " & mstrRefreshPathCurrentFile)
                End
            End Try

        End If

        frmProgressbar.Close()
        frmProgressbar = Nothing

    End Sub

    Private Function CheckFiles(ByVal strRootPath As String, ByVal strRootBackupPath As String, ByVal strPath As String, dtmModifiedDate As DateTime) As Boolean

        Dim strBackupPath As String

        Dim objDir As DirectoryInfo, intCount As Integer
        Dim objFile As FileInfo, colFiles() As FileInfo
        Dim objBackupDir As DirectoryInfo, objBackupFile As FileInfo

        strBackupPath = strPath.Replace(strRootPath, strRootBackupPath)

        Try

            objDir = New DirectoryInfo(strPath)

            colFiles = objDir.GetFiles()

            For Each objFile In colFiles

                frmProgressbar.UpdateCaption("Processing " & objFile.FullName)

                frmProgressbar.ProgressBar1.Refresh()
                frmProgressbar.Refresh()

                My.Application.DoEvents()

                frmProgressbar.Show()
                frmProgressbar.BringToFront()
                My.Application.DoEvents()

                If frmProgressbar.Stopped Then

                    Exit Function
                End If

                ' Check TV File
                RemoveReadonlyFromFile(objFile)
                SetFileToBeNormal_UsingFileInfo(objFile)

                My.Application.DoEvents()
                Sleep(10)

                SetModifiedDateofFile(objFile, dtmModifiedDate, False)

                My.Application.DoEvents()
                Sleep(10)

                SetFileToBeNormal_UsingFileInfo(objFile)

                If frmProgressbar.Stopped Then

                    Exit Function
                End If

                ' Check TV Backup File
                objBackupDir = New DirectoryInfo(strBackupPath)

                If objBackupDir.GetFiles(objFile.Name).Count = 1 Then

                    objBackupFile = objBackupDir.GetFiles(objFile.Name).First
                Else

                    CheckFiles = False

                    MessageBox.Show("Missing file " & vbCrLf & vbCrLf & objFile.FullName & vbCrLf & vbCrLf & " on backup!")
                    Exit Function
                End If

                ' Check TV File
                RemoveReadonlyFromFile(objBackupFile)
                SetFileToBeNormal_UsingFileInfo(objBackupFile)

                My.Application.DoEvents()
                Sleep(10)

                SetModifiedDateofFile(objBackupFile, dtmModifiedDate, False)

                My.Application.DoEvents()
                Sleep(10)

                SetFileToBeNormal_UsingFileInfo(objBackupFile)

                If frmProgressbar.Stopped Then

                    Exit Function
                End If

                frmProgressbar.Increment()
            Next

            For Each objSubDir In objDir.GetDirectories

                If Not CheckFiles(strRootPath, strRootBackupPath, objSubDir.FullName, dtmModifiedDate) Then

                    CheckFiles = False
                    Exit Function
                End If

            Next

            CheckFiles = True

        Catch ex As Exception

            Dim blnDrive As Boolean

            blnDrive = IsDriveConnected(mstrPath)

            frmProgressbar.Close()
            frmProgressbar = Nothing

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name, "CheckFiles - blnDrive=" & blnDrive & vbCrLf & "strPath - " & strPath & vbCrLf & "mstrRefreshPathCurrentFile - " & mstrRefreshPathCurrentFile)
            End
        End Try

        ' Now ensure that everything on backup in on TV
        Try

            objBackupDir = New DirectoryInfo(strBackupPath)

            colFiles = objBackupDir.GetFiles()

            For Each objBackupFile In colFiles

                frmProgressbar.UpdateCaption("Processing " & objBackupFile.FullName)

                frmProgressbar.ProgressBar1.Refresh()
                frmProgressbar.Refresh()

                My.Application.DoEvents()

                frmProgressbar.Show()
                frmProgressbar.BringToFront()
                My.Application.DoEvents()

                If frmProgressbar.Stopped Then

                    Exit Function
                End If

                ' Check TV File
                objDir = New DirectoryInfo(strPath)

                If objDir.GetFiles(objBackupFile.Name).Count = 1 Then

                    objFile = objDir.GetFiles(objBackupFile.Name).First
                Else

                    CheckFiles = False

                    MessageBox.Show("Missing file " & vbCrLf & vbCrLf & objBackupFile.FullName & vbCrLf & vbCrLf & " on non backup!")
                    Exit Function
                End If
            Next

            CheckFiles = True

        Catch ex As Exception

            Dim blnDrive As Boolean

            blnDrive = IsDriveConnected(mstrPath)

            frmProgressbar.Close()
            frmProgressbar = Nothing

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name, "CheckFiles - blnDrive=" & blnDrive & vbCrLf & "strPath - " & strPath & vbCrLf & "mstrRefreshPathCurrentFile - " & mstrRefreshPathCurrentFile)
            End
        End Try


    End Function

    Private Sub lvwListView_KeyDown(sender As Object, e As KeyEventArgs) Handles lvwListView.KeyDown

        lvwListView_Click(Nothing, Nothing)

    End Sub

    Private Sub lvwListView_KeyUp(sender As Object, e As KeyEventArgs) Handles lvwListView.KeyUp

        lvwListView_Click(Nothing, Nothing)

    End Sub

    Private Sub lvwListView_Click(sender As Object, e As EventArgs) Handles lvwListView.Click

        Dim strSQL As String, drTypes As OleDbDataReader
        Dim comTypes As OleDbCommand, strDiscSeasonsEpisodes As String
        Dim objItem As ListViewItem, strDrivename As String
        Dim strLevels() As String, intCount As Integer
        Dim strDrive As String, objNode As TreeNode, objLevel1 As TreeNode, objTest As TreeNode
        Dim intPartCount As Integer, strNextPart As String, objPrevLevel As TreeNode
        Dim intSlashCount As Integer, strFoldername As String, objTryToFindNode As TreeNode
        Dim strFilename As String, intPos As Integer
        Dim intArrayCount As Integer, strArrayItems() As String, strPrefix As String

        If mstrTypeUsingDriveControl = DRIVE_SUMMARY Then

            strSQL = "Select * from tblShows where Title = '" & ParseTextForSQL(lvwListView.SelectedItems(0).Text) & "'"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                drTypes.Read()

                If optImdb.Checked = True Then

                    If Trim(drTypes("imdbID") & "") <> "" Then

                        txtDriveSummary_Desc.Text = Trim(drTypes("imdbDescription") & "").Replace("&quot;", " & ").Replace("  ", " ")
                    End If
                End If
            Else

                txtDriveSummary_Desc.Text = ""
            End If

        ElseIf mstrTypeUsingDriveControl = DRIVE_FILE_SUMMARY Then

            strFilename = lvwListView.SelectedItems(0).SubItems(1).Text
            strPrefix = GetPrefix(strFilename).ToLower

            intPos = InStrRev(strFilename, "E")

            If intPos > 0 Then

                If IsNumeric(Mid(strFilename, intPos - 1, 1)) And IsNumeric(Mid(strFilename, intPos + 1, 1)) Then

                    intPos = InStr(intPos + 1, strFilename, " ")

                    If intPos > 0 Then
                        strFilename = Mid(strFilename, 1, intPos - 1)

                        strFilename = strFilename & "." & strPrefix
                    End If
                End If
            End If

            strFilename = GeneralCleanup(strFilename)

            strArrayItems = STRING_REMOVALS.Split(",")

            For intArrayCount = strArrayItems.GetLowerBound(0) To strArrayItems.GetUpperBound(0)

                strFilename = RemoveTextAfterFirstChar(strFilename, ProperiseCase(strArrayItems(intArrayCount)))

            Next

            strFilename = MinorCleanup(strFilename)

            strFilename = RemovePrefix(strFilename)

            If lvwListView.SelectedItems.Count = 1 Then

                txtDriveFileSummary_FullFilename.Text = strFilename & " Ettv"
                txtDriveFileSummary_FullFilenamewithoutETTV.Text = strFilename

                intPos = InStrRev(strFilename, "E")

                If intPos > 0 Then

                    strFilename = Mid(strFilename, 1, intPos - 1)

                    txtDriveFileSummary_FilenameJustSeason.Text = strFilename
                Else

                    txtDriveFileSummary_FilenameJustSeason.Text = ""
                End If

                intPos = InStrRev(strFilename, "S")

                If intPos > 0 Then

                    strFilename = Mid(strFilename, 1, intPos - 1)

                    txtDriveFileSummary_Seriesname.Text = strFilename.Trim
                Else

                    txtDriveFileSummary_Seriesname.Text = ""
                End If


            End If
        End If

    End Sub

    Private Sub lvwListView_ColumnClick(sender As Object, e As ColumnClickEventArgs) Handles lvwListView.ColumnClick

        ' Get the new sorting column.
        Dim objListview As ListView, objColumnHeader As ColumnHeader

        objListview = lvwListView
        objColumnHeader = mobjColumn_Listview

        Dim new_sorting_column As ColumnHeader = objListview.Columns(e.Column)

        ' Figure out the new sorting order.
        Dim sort_order As System.Windows.Forms.SortOrder

        If objColumnHeader Is Nothing Then

            ' New column. Sort ascending.
            sort_order = SortOrder.Ascending
        Else

            ' See if this is the same column.
            If new_sorting_column.Equals(objColumnHeader) Then

                ' Same column. Switch the sort order.
                If objColumnHeader.Text.EndsWith(" >") Then

                    sort_order = SortOrder.Descending
                Else

                    sort_order = SortOrder.Ascending
                End If
            Else

                ' New column. Sort ascending.
                sort_order = SortOrder.Ascending
            End If

            ' Remove the old sort indicator.
            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, Len(objColumnHeader.Text) - 2)
        End If

        ' Display the new sort order.
        objColumnHeader = new_sorting_column

        If Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " >" Or Mid(objColumnHeader.Text, objColumnHeader.Text.Length - 1, 2) = " <" Then

            objColumnHeader.Text = Mid(objColumnHeader.Text, 1, objColumnHeader.Text.Length - 2)
        End If

        If sort_order = SortOrder.Ascending Then

            objColumnHeader.Text = objColumnHeader.Text & " >"
        Else

            objColumnHeader.Text = objColumnHeader.Text & " <"
        End If

        mobjColumn_Listview = objColumnHeader

        ' Create a comparer.
        objListview.ListViewItemSorter = New ListViewComparer(e.Column, sort_order)

        ' Sort.
        objListview.Sort()

    End Sub

    Private Sub cmdSeasonsTab_Order_Click(sender As Object, e As EventArgs) Handles cmdSeasonsTab_Order.Click

        mblnSeasonsOrderAsc = Not mblnSeasonsOrderAsc

        LoadSeasons()

    End Sub

    Private Sub cmdShowList_Dups_TrollList_Click(sender As Object, e As EventArgs) Handles cmdShowList_Dups_TrollList.Click

        Dim objItem As ListViewItem
        Dim strPrev As String, strCurrent As String, strText As String
        Dim strDupsFound As String = ""
        Dim strPrevDrive As String, strCurrentDrive As String

        strText = Me.Text

        For Each objItem In lvwShowList_Dups.Items

            Me.Text = APP_NAME & " - " & objItem.Text

            strCurrent = objItem.Text.ToUpper
            strCurrentDrive = objItem.SubItems(1).Text

            If strCurrent <> "" And strPrev <> "" Then

                If strCurrent = strPrev Then

                    If MessageBox.Show("Found possible dup. - " & objItem.Text & vbCrLf & vbCrLf & "Click Yes to exit so I can sort out" & vbCrLf & vbCrLf & "Items found are in clipboard",
                                       My.Application.Info.ProductName, MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then

                        strDupsFound = strDupsFound & objItem.Text & " - " & strCurrentDrive & " - " & strPrevDrive

                        Me.Text = Me.Text & " - " & strDupsFound

                        Clipboard.SetText(strDupsFound)
                        Exit Sub
                    End If

                    strDupsFound = strDupsFound & objItem.Text & " - " & strCurrentDrive & " - " & strPrevDrive & vbCrLf
                End If
            End If

            strPrev = strCurrent
            strPrevDrive = strCurrentDrive
        Next

        Me.Text = APP_NAME
        Me.Refresh()

        If strDupsFound <> "" Then

            Clipboard.SetText(strDupsFound)
        Else

            MessageBox.Show("Nothing found!")
        End If

    End Sub

    Private Sub mnuDriveFileSummary_GeneralTodo_Click(sender As Object, e As EventArgs) Handles mnuDriveFileSummary_GeneralTodo.Click

        Dim strDrive As String, strText As String, lngSize As Long, strProblem As String

        If lvwListView.SelectedItems.Count = 0 Then Exit Sub

        strDrive = cboDrives.Text

        lngSize = lvwListView.SelectedItems(0).SubItems(3).Text

        If lngSize > 300 Then

            strProblem = " large!"
        Else

            strProblem = " small!"
        End If

        strText = lvwListView.SelectedItems(0).SubItems(1).Text & " is too" & strProblem
        strText = strText & vbCrLf & vbCrLf & lvwListView.SelectedItems(0).SubItems(3).Text & " Mb"

        AddAToDo(strDrive & " - " & lvwListView.SelectedItems(0).Text, strText)

    End Sub

    Private Sub cmdDriveFileSummary_FilenameJustSeason_Copy_Click(sender As Object, e As EventArgs) Handles cmdDriveFileSummary_FilenameJustSeason_Copy.Click

        Clipboard.SetText(txtDriveFileSummary_FilenameJustSeason.Text)

        txtDriveFileSummary_FilenameJustSeason.Focus()
        txtDriveFileSummary_FilenameJustSeason.SelectAll()

    End Sub

    Private Sub cmdDriveFileSummary_FullFilename_Copy_Click(sender As Object, e As EventArgs) Handles cmdDriveFileSummary_FullFilename_Copy.Click

        Clipboard.SetText(txtDriveFileSummary_FullFilename.Text)

        txtDriveFileSummary_FullFilename.Focus()
        txtDriveFileSummary_FullFilename.SelectAll()

    End Sub

    Private Sub cmdDriveFileSummary_FullFilenamewithoutETTV_Copy_Click(sender As Object, e As EventArgs) Handles cmdDriveFileSummary_FullFilenamewithoutETTV_Copy.Click

        Clipboard.SetText(txtDriveFileSummary_FullFilenamewithoutETTV.Text)

        txtDriveFileSummary_FullFilenamewithoutETTV.Focus()
        txtDriveFileSummary_FullFilenamewithoutETTV.SelectAll()

    End Sub

    Private Sub cmdDriveFileSummary_SeriesName_Copy_Click(sender As Object, e As EventArgs) Handles cmdDriveFileSummary_SeriesName_Copy.Click

        Clipboard.SetText(txtDriveFileSummary_Seriesname.Text)

        txtDriveFileSummary_Seriesname.Focus()
        txtDriveFileSummary_Seriesname.SelectAll()

    End Sub

    Private Sub txtDriveFileSummary_FilenameJustSeason_DoubleClick(sender As Object, e As EventArgs) Handles txtDriveFileSummary_FilenameJustSeason.DoubleClick

        Clipboard.SetText(txtDriveFileSummary_FilenameJustSeason.Text)
        txtDriveFileSummary_FilenameJustSeason.SelectAll()

    End Sub

    Private Sub txtDriveFileSummary_FullFilename_DoubleClick(sender As Object, e As EventArgs) Handles txtDriveFileSummary_FullFilename.DoubleClick

        Clipboard.SetText(txtDriveFileSummary_FullFilename.Text)
        txtDriveFileSummary_FullFilename.SelectAll()

    End Sub

    Private Sub txtDriveFileSummary_FullFilenamewithoutETTV_DoubleClick(sender As Object, e As EventArgs) Handles txtDriveFileSummary_FullFilenamewithoutETTV.DoubleClick

        Clipboard.SetText(txtDriveFileSummary_FullFilenamewithoutETTV.Text)
        txtDriveFileSummary_FullFilenamewithoutETTV.SelectAll()

    End Sub

    Private Sub txtDriveFileSummary_Seriesname_DoubleClick(sender As Object, e As EventArgs) Handles txtDriveFileSummary_Seriesname.DoubleClick

        Clipboard.SetText(txtDriveFileSummary_Seriesname.Text)
        txtDriveFileSummary_Seriesname.SelectAll()

    End Sub

    Private Sub cmdAiredItems_Process_Click(sender As Object, e As EventArgs) Handles cmdAiredItems_Process.Click

        cmdFinished_AiredShows.Enabled = False

        calCalendar_AirDates.Refresh()

        UpdateAiredShows(calCalendar_AirDates.SelectionStart)

        lvwAiredShows.Focus()

        cmdFinished_AiredShows.Enabled = True

    End Sub

    Private Sub calCalendar_AirDates_DateChanged(sender As Object, e As DateRangeEventArgs) Handles calCalendar_AirDates.DateChanged

        txtAiredItems_FilenameJustSeason.Text = ""
        txtAiredItems_FullFilenamewithoutETTV.Text = ""
        txtAiredItems_Seriesname.Text = ""
        txtAiredItems_Title.Text = ""
        txtAiredItems_FullFilename.Text = ""

    End Sub

    Private Sub cmdSaveID_Click(sender As Object, e As EventArgs) Handles cmdSaveID.Click

        Dim strSQL As String, drTypes As OleDbDataReader, comTypes As OleDbCommand

        Try

            strSQL = "Insert into tblShows (Title, imdbId) values ('" & ParseTextForSQL(txtSeriesName.Text) & "','" & txtID.Text & "')"

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            comTypes.ExecuteReader()

            CloseOLECommand(comTypes)

        Catch ex As Exception

        End Try

        strSQL = "Update tblShows Set imdbId = '" & txtID.Text & "', imdbStartYear = '', imdbEndYear ='', imdbDescription = '', imdbSeasonCount = 0, imdbDateOfLastUpdate = NULL, TV_Com_DateOfLastUpdate = NULL, imdbRating = 0, imdbVotes = 0, imdb_AirDateTotal = 0, imdb_TotalWithoutAirDate = 0, imdbDateOfLastUpdate_API = NULL, LastUpdateomdbAPI = NULL where Title = '" & ParseTextForSQL(txtSeriesName.Text) & "' "

        comTypes = New OleDbCommand(strSQL, mobjOLEConn)

        comTypes.ExecuteNonQuery()

        CloseOLECommand(comTypes)
        CloseDataReader(drTypes)

    End Sub

    Private Sub mnuUseTV9R_Click(sender As Object, e As EventArgs) Handles mnuUseTV9R.Click

        ChangeDrive("R", TV9, "TV9")

    End Sub

    Private Function ChangeDrive(ByVal strTargetDriveLetter As String,
                                 ByVal strDriveConstant As String,
                                 ByVal strFilename As String) As Boolean

        Dim strTemplateFile As String, strFile As String, objStreamR As StreamReader, objStreamW As StreamWriter
        Dim strLines() As String, intCount As Integer
        Dim strCurrently As String

        ChangeDrive = False

        strTemplateFile = ROOT_DRIVE & "\VB.Net\My Projects\_BatchFiles\MediaManager\Template - Mount" & strFilename & ".bat"
        strFile = ROOT_DRIVE & "\VB.Net\My Projects\_BatchFiles\MediaManager\Mount" & strFilename & "_R.bat"

        objStreamR = My.Computer.FileSystem.OpenTextFileReader(strTemplateFile)

        strLines = objStreamR.ReadToEnd.Split(vbCrLf)

        objStreamR.Close()
        objStreamR.Dispose()

        strCurrently = GetCurrentDrive(strDriveConstant)

        If strCurrently = "" Then

            strCurrently = InputBox("Enter current drive", My.Application.Info.ProductName, "").Trim

            If strCurrently = "" Then Exit Function
        End If

        strLines(0) = strLines(0).Replace(OLDDRIVE, strCurrently)
        strLines(1) = strLines(1).Replace(NEWDRIVE, strTargetDriveLetter)

        objStreamW = My.Computer.FileSystem.OpenTextFileWriter(strFile, False, encoding:=System.Text.Encoding.ASCII)

        For intCount = 0 To strLines.GetUpperBound(0)

            objStreamW.Write(strLines(intCount) & vbCrLf)
        Next

        objStreamW.Close()
        objStreamW.Dispose()

        StartProcess(strFile)

        ChangeDrive = True

    End Function


End Class