﻿Public Class frmDownload

    Public mstrUpdateType As String

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click

        Me.Hide()

    End Sub

    Public Sub LoadDownloads()

        Dim strSQL As String, drTypes As OleDbDataReader, comTypes As OleDbCommand

        txtDownload.Text = ""

        Try

            Select Case mstrUpdateType

                Case ToDownload

                    strSQL = "Select * from tblDownloads"

                Case FailedDownloads

                    strSQL = "Select * from tblFailedDownloads"

            End Select


            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            If drTypes.HasRows Then

                drTypes.Read()

                txtDownload.Text = Trim(drTypes("DownloadsToDo").ToString & "")
            End If

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

        cmdSave.Enabled = False

        txtDownload.Refresh()

    End Sub

    Private Sub txtDownload_TextChanged(sender As Object, e As EventArgs) Handles txtDownload.TextChanged

        cmdSave.Enabled = True

    End Sub

    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click

        Dim strSQL As String, drTypes As OleDbDataReader, comTypes As OleDbCommand

        Select Case mstrUpdateType

            Case ToDownload

                strSQL = "Update tblDownloads set DownloadsToDo = '" & ParseTextForSQL(txtDownload.Text.Trim) & "'"

            Case FailedDownloads

                strSQL = "Update tblFailedDownloads set DownloadsToDo = '" & ParseTextForSQL(txtDownload.Text.Trim) & "'"

        End Select

        Try

            comTypes = New OleDbCommand(strSQL, mobjOLEConn)

            drTypes = comTypes.ExecuteReader()

            CloseOLECommand(comTypes)
            CloseDataReader(drTypes)

        Catch ex As Exception

            DisplayException_Messagebox(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)

        End Try

        cmdSave.Enabled = False

    End Sub

    Private Sub frmDownload_Resize(sender As Object, e As EventArgs) Handles Me.Resize

        If Me.Width < 734 Then Me.Width = 734
        If Me.Height < 363 Then Me.Height = 363

    End Sub

End Class