﻿Public Class frmEmail

    Public EmailText As String

    Public Sub SetEmailText(strEmail As String)

        txtEmail.Text = strEmail
    End Sub

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click

        EmailText = txtEmail.Text

        Me.Hide()

    End Sub
End Class