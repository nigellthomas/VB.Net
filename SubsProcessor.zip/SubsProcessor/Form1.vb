﻿Public Class frmSubsProcessor
    Private Sub cmdFolder_Click(sender As Object, e As EventArgs) Handles cmdFolder.Click

        FolderBrowserDialog1.SelectedPath = "E:\_Torrent\Completed\"

        If FolderBrowserDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then

            If FolderBrowserDialog1.SelectedPath <> "" Then txtPath.Text = Mid(FolderBrowserDialog1.SelectedPath, 1, 1).ToLower & Mid(FolderBrowserDialog1.SelectedPath, 2)
        End If

    End Sub

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click

        Me.Close()

    End Sub

    Private Sub cmdProcess_Click(sender As Object, e As EventArgs) Handles cmdProcess.Click

        cmdProcess.Enabled = False

        SubsProcessor(txtPath.Text, True)

        cmdProcess.Enabled = True

    End Sub

    Public Sub SubsProcessor(ByVal strPath As String, ByVal blnDeleteSubFolder As Boolean)

        Dim strSubsPath As String = "", strNextSubFileName As String = ""
        Dim blnFoundFile = False
        Dim lngFileSize As Long = 999999999, strSubFilePath As String = ""
        Dim strElements() As String
        Dim intCount As Integer = 0
        Dim blnFoundSEIndicator As Boolean = False, strNextFileName As String = ""

        strPath = strPath & "\"

        strSubsPath = strPath & "Subs"

        If My.Computer.FileSystem.DirectoryExists(strSubsPath) Then

            Dim objFolder As New DirectoryInfo(strSubsPath)

            For Each objSubFolder In objFolder.GetDirectories()

                blnFoundFile = False
                lngFileSize = 999999999
                strSubFilePath = ""
                blnFoundSEIndicator = False

                For Each objFile In objSubFolder.GetFiles("*.srt")

                    If objFile.Name.ToUpper.Contains("ENGLISH") Or objFile.Name.ToUpper.Contains(".ENG.") Then

                        If blnFoundFile Then

                            If objFile.Length < lngFileSize Then

                                strSubFilePath = objFile.FullName
                                lngFileSize = objFile.Length
                            End If
                        Else

                            strSubFilePath = objFile.FullName
                            lngFileSize = objFile.Length
                            blnFoundFile = True
                        End If
                    End If
                Next

                If blnFoundFile Then

                    ' Do a check on the file size - can sometimes be very small files
                    If lngFileSize < 10000 Then

                        MessageBox.Show("Manually check files in " & vbCrLf & vbCrLf & objSubFolder.FullName & vbCrLf & vbCrLf & "Delete any .srt files that are too small!")
                        End
                    End If

                    strNextSubFileName = objSubFolder.Name

                    strNextSubFileName = strNextSubFileName.Replace(".", " ")

                    strElements = strNextSubFileName.Split(" ")

                    For intCount = 0 To strElements.GetUpperBound(0)

                        If Not blnFoundSEIndicator Then

                            If Len(strElements(intCount)) = 6 Then

                                If Mid(strElements(intCount), 1, 1) = "S" And Mid(strElements(intCount), 4, 1) = "E" Then

                                    blnFoundSEIndicator = True
                                End If
                            End If
                        Else

                            strElements(intCount) = ""
                        End If
                    Next

                    If blnFoundSEIndicator Then

                        strNextSubFileName = ""

                        For intCount = 0 To strElements.GetUpperBound(0)

                            strNextSubFileName = strNextSubFileName & " " & strElements(intCount)
                        Next

                        strNextSubFileName = strNextSubFileName.Trim() & ".srt"

                        My.Computer.FileSystem.MoveFile(strSubFilePath, strPath & strNextSubFileName)
                    Else

                        MessageBox.Show("Can't find season indictor in " & strNextSubFileName)
                        End
                    End If
                End If

                If blnDeleteSubFolder Then My.Computer.FileSystem.DeleteDirectory(objSubFolder.FullName, FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin)
            Next

            If blnDeleteSubFolder And My.Computer.FileSystem.DirectoryExists(strSubsPath) Then My.Computer.FileSystem.DeleteDirectory(strSubsPath, FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin)

            ' Now rename the Files

            Dim objFileFolder As New DirectoryInfo(strPath)

            For Each objFile In objFileFolder.GetFiles("*.MKV")

                blnFoundSEIndicator = False

                If objFile.Name.ToUpper.Contains(".MKV") Then

                    strNextFileName = objFile.Name

                    strNextFileName = strNextFileName.Replace(".", " ")

                    strElements = strNextFileName.Split(" ")

                    For intCount = 0 To strElements.GetUpperBound(0)

                        If Not blnFoundSEIndicator Then

                            If Len(strElements(intCount)) = 6 Then

                                If Mid(strElements(intCount), 1, 1) = "S" And Mid(strElements(intCount), 4, 1) = "E" Then

                                    blnFoundSEIndicator = True
                                End If
                            End If
                        Else

                            strElements(intCount) = ""
                        End If
                    Next

                    If blnFoundSEIndicator Then

                        strNextFileName = ""

                        For intCount = 0 To strElements.GetUpperBound(0)

                            strNextFileName = strNextFileName & " " & strElements(intCount)
                        Next

                        strNextFileName = strNextFileName.Trim() & ".mkv"

                        If objFile.FullName <> (strPath & strNextFileName) Then My.Computer.FileSystem.MoveFile(objFile.FullName, strPath & strNextFileName)
                    End If
                End If

            Next


            For Each objFile In objFileFolder.GetFiles("*.MP4")

                blnFoundSEIndicator = False

                If objFile.Name.ToUpper.Contains(".MP4") Then

                    strNextFileName = objFile.Name

                    strNextFileName = strNextFileName.Replace(".", " ")

                    strElements = strNextFileName.Split(" ")

                    For intCount = 0 To strElements.GetUpperBound(0)

                        If Not blnFoundSEIndicator Then

                            If Len(strElements(intCount)) = 6 Then

                                If Mid(strElements(intCount), 1, 1) = "S" And Mid(strElements(intCount), 4, 1) = "E" Then

                                    blnFoundSEIndicator = True
                                End If
                            End If
                        Else

                            strElements(intCount) = ""
                        End If
                    Next

                    If blnFoundSEIndicator Then

                        strNextFileName = ""

                        For intCount = 0 To strElements.GetUpperBound(0)

                            strNextFileName = strNextFileName & " " & strElements(intCount)
                        Next

                        strNextFileName = strNextFileName.Trim() & ".mp4"

                        If objFile.FullName <> (strPath & strNextFileName) Then My.Computer.FileSystem.MoveFile(objFile.FullName, strPath & strNextFileName)
                    End If
                End If

            Next
        End If

    End Sub

End Class
